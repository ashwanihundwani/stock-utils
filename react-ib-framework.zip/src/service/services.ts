import axios from 'axios';
import {handleApiError} from '../constants/errors';
import {API_BASEURL, API_TIMEOUT} from 'config';

// auth req
export const authHandler = axios.create({
  baseURL: API_BASEURL,
  headers: {
    Authorization:
      'Basic cXdLUjRHbG5veGhBSVk3WEpvZ01RVDM4SUhvYTpxa0tRZmRTX215amthWmpmcmVqY1J0M0gyYVFh',
  },
  timeout: API_TIMEOUT,
});

authHandler.interceptors.response.use(
  response => {
    return response.data.data;
  },
  error => {
    throw handleApiError(error);
  },
);

authHandler.interceptors.request.use(async function (config) {
  return config;
});

// Post Login Handler
export const httpHandler = axios.create({
  baseURL: API_BASEURL,
  headers: {
    Authorization:
      'Basic cXdLUjRHbG5veGhBSVk3WEpvZ01RVDM4SUhvYTpxa0tRZmRTX215amthWmpmcmVqY1J0M0gyYVFh',
  },
  timeout: API_TIMEOUT,
});

httpHandler.interceptors.response.use(
  response => {
    return response.data.data;
  },
  error => {
    throw handleApiError(error);
  },
);

httpHandler.interceptors.request.use(async function (config) {
  return config;
});
