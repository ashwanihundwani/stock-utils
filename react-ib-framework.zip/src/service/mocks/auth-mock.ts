import MockAdapter from 'axios-mock-adapter';

export default function applyMockAdapter(axiosInstance: any) {
  const mock = new MockAdapter(axiosInstance);

  mock.onPost('/api/login').reply(200, loginOkResponse);

  // mock.onPost('/api/login').reply(401, {
  //   httpStatusCode: 401,
  //   message: 'Invalid Credentials',
  // });
}

const loginOkResponse = {
  cifNo: '10207511',
  userId: '1234',
  isLimitedReached: 'false',
  httpStatusCode: 200,
  nationalId: '1018891877',
  isDebitCreated: 'true',
};
