import {IconProps} from 'constants/types';
import {FC} from 'react';

export const ArrowLeft02Sharp: FC<IconProps> = props => {
  const {size = 20, color = '#7D7495'} = props;
  return (
    <svg width={size} height={size} fill="none" viewBox="0 0 20 20">
      <path
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M4.167 10h12.5M7.5 5.832l-3.46 3.46c-.333.333-.5.5-.5.707 0 .207.167.373.5.707l3.46 3.46"
      />
    </svg>
  );
};
