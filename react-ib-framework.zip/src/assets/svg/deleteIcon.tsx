export function DeleteIcon() {
  return (
    <svg
      width="12"
      height="12"
      viewBox="0 0 8 8"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M7.5 0.499939L0.5 7.49994M0.5 0.499939L7.5 7.49994"
        stroke="#6C608B"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
