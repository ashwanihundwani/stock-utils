export function TrustedBrowserIcon() {
  return (
    <svg
      width="80"
      height="80"
      viewBox="0 0 80 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <rect width="80" height="80" rx="40" fill="#E8F6EE" />
      <path
        d="M29.5 43L34.75 48.25L50.5 31.75"
        stroke="#2CA85A"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
