import {FC} from 'react';
import {IconProps} from '../../constants/types';

const AlertCircle: FC<IconProps> = ({size = '43'}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 46 46"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <circle
        cx="23.0002"
        cy="22.9997"
        r="21.6667"
        stroke="#FF3939"
        strokeWidth="2"
      />
      <path
        d="M22.983 29.5H23.0024"
        stroke="#FF3939"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M23 23L23 14.3333"
        stroke="#FF3939"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export {AlertCircle};
