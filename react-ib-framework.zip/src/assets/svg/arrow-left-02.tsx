export function ArrowLeft() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M4.1665 10L16.6665 9.9998"
        stroke="#7D7495"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.49992 5.83301L4.04036 9.29257C3.70703 9.6259 3.54036 9.79257 3.54036 9.99967C3.54036 10.2068 3.70703 10.3734 4.04036 10.7068L7.49992 14.1663"
        stroke="#7D7495"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
