export function ListRequirementsEnabled() {
  return (
    <svg
      width="17"
      height="20"
      viewBox="0 0 17 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M0.5 10C0.5 5.58172 4.08172 2 8.5 2C12.9183 2 16.5 5.58172 16.5 10C16.5 14.4183 12.9183 18 8.5 18C4.08172 18 0.5 14.4183 0.5 10Z"
        fill="#F7F7FA"
      />
      <path
        d="M5 11L6.75 12.75L12 7.25"
        stroke="#6C608B"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function ListRequirementsCompleted() {
  return (
    <svg
      width="17"
      height="16"
      viewBox="0 0 17 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M0.5 8C0.5 3.58172 4.08172 0 8.5 0C12.9183 0 16.5 3.58172 16.5 8C16.5 12.4183 12.9183 16 8.5 16C4.08172 16 0.5 12.4183 0.5 8Z"
        fill="#2CA85A"
      />
      <path
        d="M5 9L6.75 10.75L12 5.25"
        stroke="white"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function ListRequirementsError() {
  return (
    <svg
      width="17"
      height="16"
      viewBox="0 0 17 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M0.5 8C0.5 3.58172 4.08172 0 8.5 0C12.9183 0 16.5 3.58172 16.5 8C16.5 12.4183 12.9183 16 8.5 16C4.08172 16 0.5 12.4183 0.5 8Z"
        fill="#FF3939"
      />
      <path
        d="M12 4.49994L5 11.4999M5 4.49994L12 11.4999"
        stroke="white"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
