import {IconProps} from 'constants/types';
import {FC} from 'react';

export const SquarePassword: FC<IconProps> = props => {
  const {size = 20, color = '#19074A'} = props;
  return (
    <svg width={size} height={size} fill="none" viewBox="0 0 20 20">
      <path
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12.076 12.918h.007m-4.167 0h.008"
      />
      <path
        stroke={color}
        strokeWidth={1.5}
        d="M3.556 15.704c.188 1.392 1.34 2.482 2.744 2.547 1.18.054 2.38.082 3.7.082 1.32 0 2.52-.028 3.7-.082 1.403-.065 2.556-1.155 2.743-2.547.123-.908.224-1.84.224-2.787 0-.948-.101-1.88-.224-2.788-.187-1.391-1.34-2.482-2.743-2.546A79.525 79.525 0 0 0 10 7.5c-1.32 0-2.52.028-3.7.083-1.403.064-2.556 1.155-2.744 2.546-.122.909-.223 1.84-.223 2.788 0 .948.101 1.879.223 2.787Z"
      />
      <path
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M6.25 7.501V5.418a3.75 3.75 0 1 1 7.5 0v2.083"
      />
    </svg>
  );
};
