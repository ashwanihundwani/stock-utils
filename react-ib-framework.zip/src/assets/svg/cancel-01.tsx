import {IconProps} from 'constants/types';
import {FC} from 'react';

export const Cancel01: FC<IconProps> = props => {
  const {size = 12, color = '#ffffff'} = props;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      fill="none"
      viewBox="0 0 12 12">
      <path
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        d="m9.5 2.5-7 7m0-7 7 7"
      />
    </svg>
  );
};
