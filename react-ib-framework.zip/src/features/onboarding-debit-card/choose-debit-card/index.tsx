import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from './styles';
import {useTranslation} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Images} from 'constants/images';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import Button from 'components/button';
const ChooseDebitCard: FC = () => {
  const styles = getStyles();
  const {t} = useTranslation();
  return (
    <Grid size={7} sx={styles.gridContainer}>
      <Box sx={styles.titleContainer}>
        <CustomLabel
          id="idChooseDebitCard"
          variant={variants.titleXL}
          text={t('OnboardingDebitCardChooseLblTitleWeb')}
        />
      </Box>
      <Box sx={styles.cardsContainers}>
        <Box sx={styles.cardsRowContainers}>
          <Box sx={styles.centerAlignment}>
            <img
              alt="img"
              style={styles.imgStyle}
              src={Images.debit_card}></img>{' '}
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.titleS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
          </Box>
          <Box sx={styles.textAlignment}>
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.bodyRegularS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.bodyRegularS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.bodyRegularS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
          </Box>

          {/* <Box sx={styles.nextBtnStyle}> */}
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
            onClick={() => console.log('Button Clicked')}
          />
          {/* </Box> */}
        </Box>
        <Box sx={styles.cardsRowContainers}>
          <Box sx={styles.centerAlignment}>
            <img
              alt="img"
              style={styles.imgStyle}
              src={Images.debit_card}></img>{' '}
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.titleS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
          </Box>
          <Box sx={styles.textAlignment}>
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.bodyRegularS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.bodyRegularS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.bodyRegularS}
              text={t('OnboardingDebitCardChooseLblTitleWeb')}
            />
          </Box>

          {/* <Box sx={styles.nextBtnStyle}> */}
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
            onClick={() => console.log('Button Clicked')}
          />
          {/* </Box> */}
        </Box>
      </Box>
    </Grid>
  );
};

export default ChooseDebitCard;
