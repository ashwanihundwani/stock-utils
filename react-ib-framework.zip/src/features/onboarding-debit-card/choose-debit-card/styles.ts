export const getStyles = () => {
  return {
    gridContainer: {
      height: '431px',
      width: '802px',
      gap: '32px',
      dispaly: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    },
    titleContainer: {
      height: 'fit-content',
      justifyContent: 'center',
      alignItems: 'center',
      dispaly: 'flex',
      flexDirection: 'column',
      width: '100%',
      gap: '16px',
    },
    cardsContainers: {
      height: '367px',
      width: '802px',
      gap: '24px',
      display: 'flex',
      flexDirection: 'row',
    },
    cardsRowContainers: {
      height: 'fit-content',
      width: '50%',
      gap: '24px',
      display: 'flex',
      padding: '16px',
      flexDirection: 'column',
    },
    imgStyle: {
      width: '195px',
      height: '123px',
      borderRadius: '16px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    centerAlignment: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      gap: '16px',
    },
    textAlignment: {
      display: 'flex',
      flexDirection: 'column',

      gap: '16px',
    },
  };
};
