import React, {useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../styles';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Box} from '@mui/system';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {Typography} from '@mui/material';
import {Dropdown} from 'components';
import Chip from 'components/chip-component';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';

const CitizenshipDetails: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const [residentStatus, setResidentStatus] = useState('yes');
  const [citizenStatus, setCitizenStatus] = useState('yes');
  const [stateOfResidency, setStateOfResidency] = useState('');

  const ddlOptions = [
    {
      id: '1',
      value: 'Spain',
      label: 'Spain',
    },

    {
      id: '2',
      value: 'India',
      label: 'India',
    },

    {
      id: '3',
      value: 'Germany',
      label: 'Germany',
    },
  ];

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={'Back'}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingTaxDeclarationBirthDetailsLblTitle')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingStatusLblSubtitle')}
        </Typography>
        <Typography sx={styles.chipLabel}>
          {t('OnboardingStatusLblCitizenship')}
        </Typography>
        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={citizenStatus === 'yes'}
            onClick={() => setCitizenStatus('yes')}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={citizenStatus === 'no'}
            onClick={() => setCitizenStatus('no')}
          />
        </Box>
        {citizenStatus === 'yes' ? (
          <Dropdown
            id="select-dropdown"
            labelId="select-dropdown-lablel"
            placeholder={t('OnboardingStatusDdCountries')}
            options={ddlOptions}
            customstyle={styles.dropdown}
            disabled={false}
          />
        ) : (
          ''
        )}
        <Typography sx={styles.chipLabel}>
          {t('OnboardingStatusLblVisa')}
        </Typography>
        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={residentStatus === 'yes'}
            onClick={() => setResidentStatus('yes')}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={residentStatus === 'no'}
            onClick={() => setResidentStatus('no')}
          />
        </Box>
        {residentStatus === 'yes' ? (
          <>
            <Box>
              <Dropdown
                id="select-dropdown"
                labelId="select-dropdown-lablel"
                placeholder={t('OnboardingStatusDdCountries')}
                options={ddlOptions}
                customstyle={styles.dropdown}
                disabled={false}
              />
            </Box>
            <Box>
              <Typography sx={styles.chipLabel}>
                {t('OnboardingStatusLblSelectedCountries')}
              </Typography>
              <TextInput
                label={t('OnboardingStatusTxtFirstStateResidency')}
                value={stateOfResidency}
                setValue={setStateOfResidency}
                type={InputType.Text}
                customStyle={styles.sharedTrustedInputStyles}
              />
            </Box>
          </>
        ) : (
          ''
        )}
        <Grid sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingSalaryDetailsBtnNext')}
            disabled={false}
          />
        </Grid>
      </Box>
    </Grid>
  );
};

export default CitizenshipDetails;
