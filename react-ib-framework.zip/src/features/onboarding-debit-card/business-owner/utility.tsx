export const industryDropdown = [
  {
    id: '1',
    value: 'aramco',
    label: 'Aramco',
  },

  {
    id: '2',
    value: 'sabic',
    label: 'Sabic',
  },
];

export const AnnualIncome = [
  {
    id: '1',
    value: '10000-20000',
    label: '10000-20000',
  },
  {
    id: '2',
    value: '20000-30000',
    label: '30000-40000',
  },
];

export const monthlyIncome = [
  {
    id: '1',
    value: '+10000',
    label: '+10000',
  },
  {
    id: '2',
    value: '+15000',
    label: '+15000',
  },
];
