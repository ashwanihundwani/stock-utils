import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
      ml: 5,
      padding: '32px',
      alignItems: 'center',
    },
    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      textAlign: 'left',
      width: '100%',
    },

    backButton: {
      display: 'flex',
      mb: 2,
    },

    title: {
      fontSize: 28,
      fontWeight: 500,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-primary'],
    },

    subTitle: {
      fontSize: 16,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-secondary'],
    },

    birthDetails: {
      paddingTop: '3px',
      display: 'flex',
      flexDirection: 'row',
      gap: '16px',
      mb: 2,
      mt: 4,
    },

    sharedTrustedInputStyles: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '393px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },
    dropdown: {
      background: theme.colors['surface-01'],
      width: '393px',
    },
    chipLabel: {
      fontSize: 16,
      fontWeight: 500,
      fontFamily: fonts.regular,
      pt: 4,
      color: theme.colors['content-primary'],
    },
    chipContainer: {
      display: 'flex',
      gap: '8px',
      width: 'fit-content',
      padding: '16px 0px 16px',
    },
    tId: {
      mt: 2,
      mb: 1,
    },
    checkbox: {
      display: 'flex',
      alignItems: 'center',
      mt: 2,
      padding: '6px',
    },
    IacceptTitle: {
      fontFamily: fonts.regular,
      fontSize: '16px',
      color: theme.colors['content-primary'],
      paddingRight: '4px',
    },
    button: {
      mt: 4,
    },
  };
};
