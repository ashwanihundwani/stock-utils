import React, {useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../styles';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Box} from '@mui/system';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {Typography} from '@mui/material';
import {Dropdown} from 'components';
import Chip from 'components/chip-component';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';

const TaxIdentificationNum: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const [ksaAddress, setKsaAddress] = useState('');
  const [activeChip, setActiveChip] = useState('yes');

  const ddlOptions = [
    {
      id: '1',
      value: 'US',
      label: 'US',
    },

    {
      id: '2',
      value: 'India',
      label: 'India',
    },

    {
      id: '3',
      value: 'Germany',
      label: 'Germany',
    },
  ];

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={'Back'}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingTaxDeclarationBirthDetailsLblTitle')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingTaxDeclarationBirthDetailsLblSubtitle')}
        </Typography>
        <Typography sx={styles.chipLabel}>
          {t('OnboardingTaxIdentificationNumberLblNumber')}
        </Typography>
        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={activeChip === 'yes'}
            onClick={() => setActiveChip('yes')}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={activeChip === 'no'}
            onClick={() => setActiveChip('no')}
          />
        </Box>
        {activeChip === 'yes' ? (
          <Box sx={styles.tId}>
            <TextInput
              label={t('OnboardingTaxIdentificationNumberTxtNumber')}
              value={ksaAddress}
              setValue={setKsaAddress}
              type={InputType.Text}
              customStyle={styles.sharedTrustedInputStyles}
            />
          </Box>
        ) : (
          <Box sx={styles.tId}>
            <Dropdown
              id="select-dropdown"
              labelId="select-dropdown-lablel"
              placeholder={t('OnboardingTaxIdentificationNumberDdReason')}
              options={ddlOptions}
              customstyle={styles.dropdown}
              disabled={false}
            />
          </Box>
        )}

        <Grid sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingSalaryDetailsBtnNext')}
            disabled={false}
          />
        </Grid>
      </Box>
    </Grid>
  );
};

export default TaxIdentificationNum;
