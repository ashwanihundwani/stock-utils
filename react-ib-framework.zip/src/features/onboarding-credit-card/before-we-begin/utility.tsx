import {
  Absher,
  DecorativeIcon,
  Nafath,
  Vector,
  VectorCreditCard,
} from 'assets/svg/decorativeIcon';

const data = [
  {
    id: '1',
    value: 'Valid National ID or Iqama',
    icon: <DecorativeIcon />,
  },
  {
    id: '2',
    value: 'Saudi mobile number registered under your name',
    icon: <Vector />,
  },
  {
    id: '3',
    value: 'Registered in Absher and have a national address',
    icon: <Absher />,
  },
  {
    id: '4',
    value: 'Registered in the Nafath App',
    linkText: 'Download App',
    icon: <Nafath />,
  },
  {
    id: '5',
    value: 'Credit cards are available to eligible customers only',
    linkText: 'Check eligibility criteria',
    icon: <VectorCreditCard />,
  },
];

export {data};
