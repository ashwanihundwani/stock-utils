import {FC, useState} from 'react';
import {Box, SvgIcon} from '@mui/material';
import Grid from '@mui/material/Grid2';
import CustomCheckbox from 'components/checkbox';
import Link from 'components/link';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import {LinkSize} from 'components/link/types';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {getStyles} from './styles';
import {useNewTheme, useTranslation} from 'react-core';
import Modal from 'components/modal';
import Tabs from 'components/tabs';
import EligibilityCriteria from '../eligibility-criteria';
import {
  saudiConditions,
  expatriatesConditions,
} from '../eligibility-criteria/utility';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {getCardType} from 'utils/localStorage';
import {TermsAndCondition} from '../terms-n-condition';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {DownloadNafathPopUP} from '../download-nafath-popup';

import {data} from './utility';

const BeforeWeBegin: FC = () => {
  const cardType = getCardType();
  const [checkboxValue, setCheckboxValue] = useState(false);
  const theme = useNewTheme();
  const navigate = useNavigate();
  const styles = getStyles(theme);
  const [open, setOpen] = useState(false);
  const {t} = useTranslation();
  const [termsAndConditionOpen, setTermsAndConditionOpen] = useState(false);
  const [downloadnafath, setDownloadnafath] = useState(false);
  const handleSubmit = () => {
    if (cardType === 'debit') {
      navigate(AppPath.IdVerify);
    } else {
      navigate(AppPath.employmentStatus);
    }
  };

  const onChange = () => {
    setCheckboxValue(!checkboxValue);
  };
  const onCloseTermsAndConditionPopup = () => {
    setTermsAndConditionOpen(false);
  };
  const handleOnClosEligibilty = () => {
    setOpen(false);
  };
  const onCloseDownloadNafath = () => {
    setDownloadnafath(false);
  };
  const linkPopUp = (value: string) => {
    if (value === 'Download App') {
      setDownloadnafath(true);
    } else {
      setOpen(true);
    }
  };

  const filteredData =
    cardType === 'debit' ? data.filter(item => item.id !== '5') : data;

  return (
    <Grid size={7} sx={styles.outerGrid}>
      <Grid>
        <CustomLabel
          id="lblTitle"
          variant={variants.titleXL}
          text={t('OnboardingInstructionLblTitle')}
        />
      </Grid>
      <Grid>
        <CustomLabel
          id="lblSubtitle"
          variant={variants.bodyRegularM}
          text={t('OnboardingInstructionLblSubtitleWeb')}
        />
      </Grid>
      <Grid sx={styles.listGrid}>
        {filteredData?.map((value, index) => {
          return (
            <Grid
              key={value.id}
              sx={
                data?.length - 1 === index
                  ? styles.listItemsLast
                  : styles.listItems
              }>
              <Box sx={styles.listItemRoot}>{value.icon}</Box>
              <Box sx={styles.listItemText}>
                {value.value}
                <Link
                  linkText={value?.linkText || ''}
                  size={LinkSize.Large}
                  onClick={() => linkPopUp(value.linkText!)}
                />
              </Box>
            </Grid>
          );
        })}
      </Grid>
      <Box>
        <CustomLabel
          id="lblNafath"
          variant={variants.bodyRegularXS}
          text={t('OnboardingInstructionLblNafathAvailableWeb')}
        />
      </Box>

      <Box sx={styles.checkbox}>
        <CustomCheckbox
          id="checkbox-cmp"
          errorText={''}
          helperText={''}
          disabled={false}
          onChange={onChange}
          icon={<CheckboxDefaultIcon />}
          checkedIcon={<CheckboxSelectedIcon />}
        />
        <CustomLabel
          id="Checkbox1"
          variant={variants.bodyRegularM}
          style={styles.IacceptTitle}
          text={t('OnboardingInstructionLblIaccept')}
        />
        <Link
          linkText={t('OnboardingInstructionLblTerms&ConditionWeb')}
          size={LinkSize.Large}
          onClick={() => setTermsAndConditionOpen(true)}
        />
      </Box>
      <Box sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          onClick={handleSubmit}
          disabled={!checkboxValue}
          text={t('OnboardingInstructionBtnApply')}
        />
      </Box>
      <Modal open={open} onClose={() => setOpen(false)}>
        <Box sx={styles.modalContainer}>
          <Box sx={styles.cancelIconStyle}>
            <SvgIcon onClick={handleOnClosEligibilty}>
              <DeleteIcon />
            </SvgIcon>
          </Box>

          <Tabs
            variant="content-switcher"
            tabs={[
              {
                id: 0,
                label: 'Saudi conditions',
                content: <EligibilityCriteria data={saudiConditions} />,
              },
              {
                id: 1,
                label: 'Expatriates conditions',
                content: <EligibilityCriteria data={expatriatesConditions} />,
              },
            ]}
          />
        </Box>
      </Modal>

      <Modal
        open={termsAndConditionOpen}
        onClose={onCloseTermsAndConditionPopup}>
        <TermsAndCondition modalClose={onCloseTermsAndConditionPopup} />
      </Modal>
      <Modal open={downloadnafath} onClose={onCloseDownloadNafath}>
        <DownloadNafathPopUP modalClose={onCloseDownloadNafath} />
      </Modal>
    </Grid>
  );
};

export default BeforeWeBegin;
