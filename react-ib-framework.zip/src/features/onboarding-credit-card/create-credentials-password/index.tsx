import {FC, useState} from 'react';
import {Box, IconButton} from '@mui/material';
import Grid from '@mui/material/Grid2';
import {getStyles} from '../styles';
import TextInput from 'components/text-input';

import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useFormik} from 'formik';

import {
  OnboardingCredentialsCreationPasswordInitialValues,
  OnboardingCredentialsCreationPasswordSchema,
} from '../schemas/create-credentials-password';

import {useNewTheme, useTranslation} from 'react-core';
import {InputType} from 'components/text-input/types';
import {
  ONEDIGIT,
  ONELOWERCASE,
  ONEUPPERCASE,
  ONESPECIALCHAR,
  MINLENEIGHT,
  MAXLENTWENTY,
} from 'utils/text-input-validation';
import Button from 'components/button';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {View} from 'assets/svg/view';
import {ViewOff} from 'assets/svg/viewOff';
import {Tick02} from 'assets/svg/tick02';

const CreateCredentialPassword: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();

  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const handleClickShowRePassword = () => {
    setShowRePassword(!showRePassword);
  };
  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingCredentialsCreationPasswordInitialValues,
    validationSchema: OnboardingCredentialsCreationPasswordSchema,
    onSubmit: () => {
      navigate(AppPath.disabilities);
    },
  });

  const renderValidationListItem = (
    validationType: (value: string | undefined) => boolean,
    text: string,
  ) => {
    return (
      <Box id={`vw${text}`} sx={styles.validationBox}>
        {validationType(formik.values.password) && (
          <Box sx={styles.tickIconGreenStyle}>
            <Tick02 color={theme.colors['icon-inverted-primary']} size="8" />
          </Box>
        )}
        {!validationType(formik.values.password) &&
          formik.values.password !== '' && (
            <Box sx={styles.tickIconRedStyle}>
              <Tick02 color={theme.colors['icon-inverted-primary']} size="8" />
            </Box>
          )}
        {!validationType(formik.values.password) &&
          formik.values.password === '' && (
            <Box sx={styles.tickIconWhitetyle}>
              <Tick02 color={theme.colors['icon-secondary']} size="8" />
            </Box>
          )}

        <CustomLabel
          id="lblSubtitle"
          variant={variants.bodyRegularM}
          style={styles.validationLabel}
          text={t(text)}
        />
      </Box>
    );
  };
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="lblTitle"
          variant={variants.titleXL}
          text={t('OnboardingCredentialsCreationPasswordLblTitle')}
        />
        <CustomLabel
          id="lblSubtitle"
          variant={variants.bodyRegularM}
          text={t('OnboardingCredentialsCreationPasswordLblSubtitle')}
        />

        <Box sx={styles.crendentialStyle}>
          <Box sx={styles.passwordContainer}>
            <TextInput
              label={t('OnboardingCredentialsCreationPasswordTxtPassword')}
              value={formik.values.password}
              setValue={formik.handleChange('password')}
              customStyle={styles.inputOthersStyle}
              type={showPassword ? InputType.Text : InputType.Password}
              endElement={
                <>
                  {formik.values.password.length > 0 ? (
                    <IconButton onClick={handleClickShowPassword} edge="end">
                      {showPassword ? (
                        <ViewOff
                          color={
                            theme.colors['surface-interactive-primary-enabled']
                          }
                        />
                      ) : (
                        <View
                          color={
                            theme.colors['surface-interactive-primary-enabled']
                          }
                        />
                      )}
                    </IconButton>
                  ) : (
                    ''
                  )}
                </>
              }
            />
            <TextInput
              label={t('OnboardingCredentialsCreationPasswordTxtRePassword')}
              value={formik.values.repassword}
              setValue={formik.handleChange('repassword')}
              errorText={t(`${formik.errors.repassword ?? ''}`)}
              type={showRePassword ? InputType.Text : InputType.Password}
              customStyle={styles.inputOthersStyle}
              endElement={
                <>
                  {formik.values.repassword.length > 0 ? (
                    <IconButton onClick={handleClickShowRePassword} edge="end">
                      {showRePassword ? (
                        <ViewOff
                          color={
                            theme.colors['surface-interactive-primary-enabled']
                          }
                        />
                      ) : (
                        <View
                          color={
                            theme.colors['surface-interactive-primary-enabled']
                          }
                        />
                      )}
                    </IconButton>
                  ) : (
                    ''
                  )}
                </>
              }
            />
          </Box>

          <Box id="bxPattern">
            {renderValidationListItem(
              ONELOWERCASE,
              'OnboardingCredentialsCreationUsernameLblOneLowerCase',
            )}
            {renderValidationListItem(
              ONEUPPERCASE,
              'OnboardingCredentialsCreationUsernameLblOneUpperCase',
            )}
            {renderValidationListItem(
              ONEDIGIT,
              'OnboardingCredentialsCreationUsernameLblOneNumber',
            )}
            {renderValidationListItem(
              ONESPECIALCHAR,
              'OnboardingCredentialsCreationUsernameLblOneSpecialChar',
            )}
            {renderValidationListItem(
              MINLENEIGHT,
              'OnboardingCredentialsCreationUsernameLblMinLengthEight',
            )}
            {renderValidationListItem(
              MAXLENTWENTY,
              'OnboardingCredentialsCreationUsernameLblMaxLengthTwenty',
            )}
          </Box>
        </Box>

        <Box sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingCredentialsCreationPasswordBtnConfirm')}
            disabled={!(formik.isValid && formik.dirty)}
            onClick={formik.handleSubmit}
          />
        </Box>
      </Box>
    </Grid>
  );
};

export default CreateCredentialPassword;
