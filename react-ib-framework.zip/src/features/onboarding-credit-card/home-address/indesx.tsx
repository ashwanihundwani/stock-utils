import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import Button from 'components/button';
import {useFormik} from 'formik';
import Dropdown from 'components/select-dropdown';
import CustomCheckbox from 'components/checkbox';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {
  HomeAddressInitialValues,
  HomeAddressSchema,
} from '../schemas/home-address';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';

const HomeAddress: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const [isChecked, setIsChecked] = useState<boolean>(false);
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: HomeAddressInitialValues,
    validationSchema: HomeAddressSchema,

    onSubmit: () => {
      navigate(AppPath.firstNameTitle);
    },
  });
  const countryData = [
    {
      id: '1',
      label: 'Saudi',
      value: 'Saudi',
    },
    {id: '2', label: 'Dubai', value: 'Dubai'},
  ];

  const onChangeCheckbox = () => {
    setIsChecked(!isChecked);
  };
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingHomeAddressLblTitle')}
        />
        <Box sx={styles.tellAboutlblStyle}>
          <CustomLabel
            id="idEmploymentStatus"
            variant={variants.bodyRegularM}
            text={t('OnboardingHomeAddressLblSubtitle')}
          />
        </Box>
      </Box>
      <Grid sx={styles.listGrid}>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingHomeAddressTxtStreetAddress')}
            value={formik.values.StreetAddress}
            setValue={formik.handleChange('StreetAddress')}
            errorText={t(`${formik.errors.StreetAddress ?? ''}`)}
            customStyle={styles.sharedTrustedInputStyles}
          />
          <TextInput
            label={t('OnboardingHomeAddressTxtStreetAddress2')}
            value={formik.values.StreetAddress2}
            setValue={formik.handleChange('StreetAddress2')}
            errorText={t(`${formik.errors.StreetAddress2 ?? ''}`)}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
        </Grid>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingHomeAddressTxtCity')}
            value={formik.values.City}
            setValue={formik.handleChange('City')}
            errorText={t(`${formik.errors.City ?? ''}`)}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
          <TextInput
            label={t('OnboardingHomeAddressTxtStreetDistrict')}
            value={formik.values.StreetDistrict}
            setValue={formik.handleChange('StreetDistrict')}
            errorText={t(`${formik.errors.StreetDistrict ?? ''}`)}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
        </Grid>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingHomeAddressTxtZipCode')}
            value={formik.values.ZipCode}
            setValue={formik.handleChange('ZipCode')}
            errorText={t(`${formik.errors.ZipCode ?? ''}`)}
            type={InputType.Number}
            customStyle={styles.sharedTrustedInputStyles}
          />
          <Dropdown
            id={t('OnboardingHomeAddressDdCountry')}
            labelId={t('OnboardingHomeAddressDdCountry')}
            placeholder={t('OnboardingHomeAddressDdCountry')}
            options={countryData}
            errorText={t(`${formik.errors.Country ?? ''}`)}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.Country}
            setValue={formik.handleChange('Country')}
          />
        </Grid>
        <Box sx={styles.checkBoxAcceptGrid}>
          <CustomCheckbox
            id="checkbox-cmp"
            errorText={''}
            helperText={''}
            disabled={false}
            onChange={onChangeCheckbox}
            icon={<CheckboxDefaultIcon />}
            checkedIcon={<CheckboxSelectedIcon />}
          />
          <Box sx={styles.checkboxLabel}>
            <CustomLabel
              id="lblCheckboxtext"
              variant={variants.bodyRegularM}
              text={t('OnboardingHomeAddressChkAccept')}
            />

            <Link
              size={LinkSize.Medium}
              linkText={t('OnboardingHomeAddressChkConsent')}
            />
          </Box>
        </Box>
        <Box sx={styles.nextBtnStyle}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            disabled={!(formik.isValid && formik.dirty && isChecked)}
            text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
            onClick={formik.handleSubmit}
          />
        </Box>
      </Grid>
    </Grid>
  );
};

export {HomeAddress};
