import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    conatiner: {
      height: '100vh',
    },
    leftSideGrid: {
      //   backgroundColor: 'green',
      height: '100vh',
      direction: 'column',
    },
    imageGrid: {
      height: '60vh',
    },
    qrGrid: {
      width: '157px',
      height: '220px',
      backgroundColor: 'grey',
    },
    rightSideGrid: {
      //   backgroundColor: 'green',
      height: '100vh',
    },
    rightSideContent: {
      height: '90vh',
      display: 'flex',
      //   backgroundColor: 'blue',
      alignItems: 'center',
      justifyContent: 'center',
    },
    dynamicContent: {
      //   backgroundColor: 'yellow',
      width: '330px',
      height: '414px',
    },
    productSelctionContainer: {
      display: 'flex',
      flexDirection: 'row',
      paddingTop: '40px',
      gap: '8px',
    },
    productSelectionContentBox: {
      width: '157px',
      height: '220px',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: theme.colors['surface-interactive-secondary-enabled'],
      borderRadius: '10px',
      gap: '8px',
    },
    productSelectionContentBox2: {
      width: '157px',
      height: '220px',
      marginLeft: '16px',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: theme.colors['surface-interactive-secondary-enabled'],
      borderRadius: '10px',
    },
    backNavigation: {
      // fontFamily: fonts.semi_bold is not working as expected
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontSize: '16px',
      paddingLeft: '8px',
    },
    title: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      color: theme.colors['content-primary'],
      fontSize: '24px',
      gap: '8px',
    },
    subTitle: {
      fontFamily: fonts.regular,
      fontWeight: '400',
      color: theme.colors['content-secondary'],
      fontSize: '16px',
    },
    cardTitle: {
      // fontFamily:Title is given as Title in figma not sure about it
      fontFamily: fonts.regular,
      color: theme.colors['content-primary'],
      fontWeight: '500',
      fontSize: '18px',
      paddingTop: '16px',
      paddingLeft: '16px',
      gap: '2px',
      // paddingRight: '16px',
      lineHeight: '24px',
    },
    cardSubTitle: {
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      fontSize: '14px',
      paddingTop: '10px',
      paddingLeft: '16px',
      paddingRight: '16px',
      // lineHeight: '20px',
    },
    buttonGrid: {
      padding: '16px',
    },
    onePackBox: {
      height: '160px',
    },
    backNavGrid: {
      display: 'flex',
      flexDirection: 'row',
      gap: '10px',
    },
    meemMadeSimpleGrid: {
      display: 'grid',
      gap: '10px',
      mt: 2,
    },
    backLblstyle: {
      width: '36px',
      height: '24px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
  };
};
