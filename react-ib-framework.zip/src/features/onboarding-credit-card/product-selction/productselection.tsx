import Grid from '@mui/material/Grid2';
import Box from '@mui/material/Box';
import {FC} from 'react';
import {getStyles} from './styles';
import {useNewTheme, useTranslation} from 'react-core';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {setCardType} from 'utils/localStorage';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
const ProductSelction: FC = () => {
  const theme = useNewTheme();
  const [t] = useTranslation();
  const styles = getStyles(theme);
  const navigate = useNavigate();

  const handleSelect = (cardType: 'debit' | 'credit') => {
    setCardType(cardType);
    if (cardType === 'debit') {
      navigate(AppPath.BeforeWeBegin);
    } else {
      navigate(AppPath.CompareCreditCard);
    }
  };

  return (
    <Grid container size={12}>
      <Box>
        <Grid sx={styles.backNavGrid}>
          <ArrowLeft />

          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Grid>
        <Box sx={styles.meemMadeSimpleGrid}>
          <Grid size={9}>
            <CustomLabel
              id="idLblWelcome"
              variant={variants.bodyRegularM}
              style={styles.title}
              text={t('AuthenticationLoginLblWelcome')}
            />
          </Grid>
          <CustomLabel
            id="idLblPickOnepack"
            variant={variants.bodyRegularM}
            style={styles.subTitle}
            text={t('OnboardingJoinMeemLblSubtitle')}
          />
        </Box>
        <Grid sx={styles.productSelctionContainer}>
          <Box sx={styles.productSelectionContentBox}>
            <Box sx={styles.onePackBox}>
              <CustomLabel
                id="lblOnePackTitle"
                style={styles.cardTitle}
                text={t('OnboardingJoinMeemLblOnepackTitle')}
                variant={variants.titleS}
              />
              <CustomLabel
                id="lblOnePackSubTitle"
                style={styles.cardSubTitle}
                variant={variants.bodyRegularS}
                text={t('OnboardingJoinmeemLblOnepackSubtitle')}
              />
            </Box>
            <Box sx={styles.buttonGrid}>
              <Button
                variant={ButtonStyle.Primary}
                size={ButtonSize.Small}
                type={ButtonType.Text}
                text="Choose"
                onClick={() => handleSelect('debit')}
              />
            </Box>
          </Box>
          <Box sx={styles.productSelectionContentBox2}>
            <Box sx={styles.onePackBox}>
              <CustomLabel
                id="lblCreditCardTitle"
                style={styles.cardTitle}
                text={t('OnboardingJoinmeemLblCreditCardTitle')}
                variant={variants.titleS}
              />
              <CustomLabel
                id="lblCreditCardSubTitle"
                style={styles.cardSubTitle}
                variant={variants.bodyRegularS}
                text={t('OnboardingJoinmeemLblCreditCardSubtitle')}
              />
            </Box>
            <Box sx={styles.buttonGrid}>
              <Button
                variant={ButtonStyle.Primary}
                size={ButtonSize.Small}
                type={ButtonType.Text}
                text="Choose"
                onClick={() => handleSelect('credit')}
              />
            </Box>
          </Box>
        </Grid>
      </Box>
    </Grid>
  );
};

export default ProductSelction;
