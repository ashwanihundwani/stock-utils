import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../employment-details/styles';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import {variants} from 'components/custom-label/types';
import CustomLabel from 'components/custom-label';
import {Dropdown} from 'components';
import Chip from 'components/chip-component';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {Gift} from 'assets/svg/gift';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {data} from './utility';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import Modal from 'components/modal';
import Popupchildren from './popup-children';
import {useFormik} from 'formik';
import {
  OnboardingOfferpreferenceInitialValues,
  OnboardingOfferpreferenceSchema,
} from '../schemas/onboarding-offer-preferences';

const GetLatestUpdates: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [open, setOpen] = useState(false);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();
  const [commercialChip, setCommercialChip] = useState('yes');
  const [activeChip, setActiveChip] = useState('yes');

  const handleOnClosePopup = () => {
    setOpen(false);
  };

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingOfferpreferenceInitialValues,
    validationSchema: OnboardingOfferpreferenceSchema,
    onSubmit: values => {
      if (formik.isValid) {
        console.log(values);
        navigate(AppPath.onboardingCreateUsername);
      }
    },
  });

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingOfferPreferenceLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingOfferPreferenceLblTitle')}
        />
      </Grid>
      <Grid>
        <CustomLabel
          id={t('OnboardingOfferPreferenceLblSubtitle')}
          variant={variants.bodyMediumM}
          text={t('OnboardingOfferPreferenceLblSubtitle')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <Dropdown
          id={t('OnboardingOfferPreferenceDdHearAboutMeem')}
          labelId={t('OnboardingOfferPreferenceDdHearAboutMeem')}
          placeholder={t('OnboardingOfferPreferenceDdHearAboutMeem')}
          options={data}
          helperText={''}
          disabled={false}
          customstyle={styles.dropdown}
          labelstyle={styles.labelStyle}
          value={formik.values.hearaboutmeem}
          setValue={formik.handleChange('hearaboutmeem')}
          errorText={`${t(formik.errors.hearaboutmeem ?? '')}`}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingOfferPreferenceLblReceivePromoCalls')}
          variant={variants.bodyMediumM}
          text={t('OnboardingOfferPreferenceLblReceivePromoCalls')}
        />
      </Grid>
      <Grid sx={styles.monthlyAnnualChip}>
        <Chip
          label={t('OnboardingOfferPreferenceBtnChipYes')}
          isActive={activeChip === 'yes'}
          isInverted={!(activeChip === 'yes')}
          onClick={() => setActiveChip('yes')}
        />
        <Chip
          label={t('OnboardingOfferPreferenceBtnChipNo')}
          isActive={activeChip === 'no'}
          isInverted={!(activeChip === 'no')}
          onClick={() => setActiveChip('no')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingOfferPreferenceLblCommercialMsg')}
          variant={variants.bodyMediumM}
          text={t('OnboardingOfferPreferenceLblCommercialMsg')}
        />
      </Grid>
      <Grid sx={styles.monthlyAnnualChip}>
        <Chip
          label={t('OnboardingOfferPreferenceBtnChipYes')}
          isActive={commercialChip === 'yes'}
          isInverted={!(commercialChip === 'yes')}
          onClick={() => setCommercialChip('yes')}
        />
        <Chip
          label={t('OnboardingOfferPreferenceBtnChipNo')}
          isActive={commercialChip === 'no'}
          isInverted={!(commercialChip === 'no')}
          onClick={() => setCommercialChip('no')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <Dropdown
          id={t('OnboardingOfferPreferenceDdChannel')}
          labelId={t('OnboardingOfferPreferenceDdChannel')}
          placeholder={t('OnboardingOfferPreferenceDdChannel')}
          options={data}
          helperText={''}
          disabled={false}
          customstyle={styles.dropdown}
          labelstyle={styles.labelStyle}
          value={formik.values.channel}
          setValue={formik.handleChange('channel')}
          errorText={`${t(formik.errors.channel ?? '')}`}
        />
      </Grid>
      <Grid sx={styles.giftIcon}>
        <Gift />
        <Link
          size={LinkSize.Medium}
          linkText={t('OnboardingOfferPreferenceLblReferralCodeLink')}
          onClick={() => setOpen(true)}
        />
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingSalaryDetailsBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={formik.handleSubmit}
        />
      </Grid>
      <Modal open={open} onClose={() => setOpen(false)} icon={false}>
        <Popupchildren onClose={handleOnClosePopup} />
      </Modal>
    </Grid>
  );
};

export default GetLatestUpdates;
