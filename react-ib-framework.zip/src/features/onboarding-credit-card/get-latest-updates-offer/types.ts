export interface PopupChildrenProps {
  onClose?: () => void;
}
