import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {Typography} from '@mui/material';
import ProductSelction from '../product-selction/productselection';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {QRCodeIcon} from 'assets/svg/qrcode-icon';
import {MeemIcon} from 'assets/svg/meem-icon';
import {LanguageSkill} from 'assets/svg/language-skill';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';

const OnboardingLayout: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);

  return (
    <Grid container columns={12} sx={styles.container}>
      <Grid size={7} sx={styles.leftSideGrid}>
        <Grid>
          <MeemIcon />
        </Grid>
        <Grid sx={{height: '50vh'}}>
          {/* <img
            src={Images.meem_login_logo}
            alt="meem_login_logo"
            style={styles.meemLoginLogo}></img> */}
        </Grid>
        <Grid sx={styles.qrGrid}>
          <QRCodeIcon />
        </Grid>
      </Grid>
      <Grid size={5} sx={styles.rightSideGrid}>
        <Grid container direction="row" sx={styles.rightTopGrid}>
          <Grid sx={styles.languageSkillIcon}>
            <LanguageSkill />
            <Typography sx={styles.languageBtn}>عربي</Typography>
          </Grid>
          <Grid sx={styles.needHelpTextGrid}>
            <Typography sx={styles.needhelpText}> Do you need help?</Typography>
            <Link linkText="Contact us" size={LinkSize.Medium} />
          </Grid>
        </Grid>
        <Grid sx={styles.rightSideContent}>
          <Grid sx={styles.dynamicContent}>
            <ProductSelction />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default OnboardingLayout;
