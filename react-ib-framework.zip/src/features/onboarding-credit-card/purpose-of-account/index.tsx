import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import TextInput from 'components/text-input';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import Button from 'components/button';
import {InputType} from 'components/text-input/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {
  OnboardingAccountPurposeInitialValues,
  OnboardingAccountPurposeSchema,
} from '../schemas/onboarding-purpose-account';
import {useFormik} from 'formik';
import {MaximumInputLength} from 'constants/types';

const PurposeOfAccount: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );

  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);
    if (item.name !== 'Other') {
      navigate(AppPath.MoneyTransfer);
      formik.setFieldValue('other', '');
    }
  };

  const data = [
    {
      id: '1',
      name: t('OnboardingAccountPurposeBtn1'),
    },
    {id: '2', name: t('OnboardingAccountPurposeBtn2')},
    {id: '3', name: t('OnboardingAccountPurposeBtn3')},
    {id: '4', name: t('OnboardingAccountPurposeBtn4')},
  ];

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingAccountPurposeInitialValues,
    validationSchema: OnboardingAccountPurposeSchema,
    onSubmit: () => {
      console.log(formik.isValid, 'valid');
      if (formik.isValid) {
        navigate(AppPath.MoneyTransfer);
      }
    },
  });
  const checkButtonStatus = () => {
    if (!selectedValue) return true;
    else if (
      selectedValue?.name === t('OnboardingAccountPurposeBtn4') &&
      (!formik.values.other || formik.values.other === '')
    ) {
      return true;
    }
    return false;
  };
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingAccountPurposeLblTitle')}
        />
        <Box sx={styles.tellAboutlblStyle}>
          <CustomLabel
            id="idEmploymentStatus"
            variant={variants.bodyRegularM}
            text={t('OnboardingAccountPurposeLblSubtitle')}
          />
        </Box>
      </Box>
      <Box sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
        />
        {selectedValue?.name === t('OnboardingAccountPurposeBtn4') && (
          <Box>
            <Box sx={styles.textBoxStyle}>
              <TextInput
                label={t('OnboardingAccountPurposeBtn4')}
                value={formik.values.other}
                type={InputType.Text}
                bgWhite
                setValue={formik.handleChange('other')}
                errorText={`${t(formik.errors.other ?? '')}`}
                maximumLength={MaximumInputLength}
                customStyle={styles.inputOthersStyle}
              />
            </Box>
            <Box sx={styles.nextBtnStyle}>
              <Button
                variant={ButtonStyle.Primary}
                size={ButtonSize.Large}
                type={ButtonType.Text}
                text={t('OnboardingAccountPurposeBtnNext')}
                onClick={formik.handleSubmit}
                disabled={checkButtonStatus()}
              />
            </Box>
          </Box>
        )}
      </Box>
    </Grid>
  );
};

export {PurposeOfAccount};
