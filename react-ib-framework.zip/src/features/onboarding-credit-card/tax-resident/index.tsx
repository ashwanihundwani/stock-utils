import {FC, useState, useEffect} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {getCardType} from 'utils/localStorage';

const TaxResident: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();
  const cardType = getCardType();

  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );
  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);
  };

  useEffect(() => {
    console.log(selectedValue);
    if (selectedValue?.name === 'Yes') {
      navigate(AppPath.TaxDeclarationDetails);
    }
    if (cardType === 'debit' && selectedValue?.name === 'No') {
      navigate(AppPath.politicalyExposed);
    } else if (cardType === 'credit' && selectedValue?.name === 'No') {
      navigate(AppPath.boardMember);
    }
  }, [selectedValue, navigate, cardType]);
  const data = [
    {id: '1', name: t('OnboardingAdditionalincomeBtnOptionNo')},
    {id: '2', name: t('OnboardingAdditionalIncomeBtnOptionYes')},
  ];
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmpllblTitleoymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingTaxResidentLblTitle')}
        />
      </Box>
      <Box sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
        />
      </Box>
    </Grid>
  );
};

export {TaxResident};
