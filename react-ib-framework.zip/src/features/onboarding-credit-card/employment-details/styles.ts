import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      display: 'grid',
      width: '802px',
      paddingTop: '32px',
      ml: 6,
      alignItems: 'center',
    },
    container: {
      backgroundColor: theme.colors['background-02'],
      height: '100vh',
    },
    listGrid: {
      paddingTop: '32px',
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: '16px',
    },
    dropdown: {
      background: theme.colors['surface-01'],
      width: '393px',
    },
    incomeSourceDropdown: {
      background: theme.colors['surface-01'],
      width: '448px',
    },
    incomeSourceDropdownGrid: {
      paddingTop: '32px',
    },
    labelStyle: {
      fontFamily: fonts.figtree_regular,
      color: theme.colors['content-secondary'],
    },
    backLblstyle: {
      width: '36px',
      height: '24px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    textInput: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '393px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },

      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },
    button: {
      paddingTop: '32px',
    },
    title: {
      paddingTop: '16px',
    },
    backNavGrid: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    textArea: {
      width: '448px',
      backgroundColor: theme.colors['surface-01'],
      borderRadius: '10px',
      '&:hover': {
        // borderColor: theme.colors['border-focus'],
        backgroundColor: theme.colors['surface-01'],
      },
      '& .MuiFilledInput-root': {
        border: `1px solid transparent`,
        borderRadius: '10px',
        fontFamily: fonts.regular,
        backgroundColor: theme.colors['surface-01'],
        color: theme.colors['content-primary'],
        height: '192px',
        alignItems: 'flex-end',
        paddingTop: '12px',
        paddingLeft: '16px',
        marginTop: '3px',
        '&:hover': {
          // borderColor: theme.colors['border-focus'],
          backgroundColor: theme.colors['surface-01'],
        },
        '&.Mui-focused': {
          backgroundColor: theme.colors['surface-01'],
        },
      },
    },
    textAreaGrid: {
      paddingTop: '16px',
    },
    incomeAmountDropdown: {
      paddingTop: '16px',
    },
    rangeOfmonthlyIncome: {
      paddingTop: '32px',
    },
    monthlyAnnualChip: {
      display: 'flex',
      paddingTop: '16px',
      gap: '16px',
    },
    giftIcon: {
      display: 'flex',
      paddingTop: '32px',
      gap: '8px',
    },
    popupCloseIcon: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    popupText: {
      marginTop: '16px',
    },
    popupGrid: {
      padding: '16px',
    },
    popupButton: {
      display: 'flex',
      padding: '16px',
      gap: '16px',
      justifyContent: 'flex-end',
    },
    listItems: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      height: '80px',
      width: '389px',
      backgroundColor: theme.colors['surface-01'],
      paddingLeft: '16px',
      borderRadius: '10px',
    },
  };
};
