import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {getStyles} from './styles';
import {translation, useNewTheme} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import Dropdown from 'components/select-dropdown';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import {
  autoPaymentInstructionsData,
  salaryAccountBankData,
  whenAccountOpenedData,
} from './utility';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {useFormik} from 'formik';
import {
  OnboardingSalaryDetailsInitialValues,
  OnboardingSalaryDetailsSchema,
} from '../schemas/salary-details';

const SalaryDetails: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const navigate = useNavigate();

  const {t} = translation.useTranslation();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingSalaryDetailsInitialValues,
    validationSchema: OnboardingSalaryDetailsSchema,
    onSubmit: values => {
      navigate(AppPath.MonthlySalary);
      console.log(values);
    },
  });
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id="idBack"
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingSalaryDetailsLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingSalaryDetailsLblTitle')}
        />
      </Grid>
      <Grid sx={{paddingTop: '8px'}}>
        <CustomLabel
          id={t('OnboardingSalaryDetailsLblSubtitle')}
          variant={variants.bodyMediumM}
          text={t('OnboardingSalaryDetailsLblSubtitle')}
        />
      </Grid>
      <Grid sx={styles.listGrid}>
        <Grid>
          <Dropdown
            id={t('OnboardingSalaryDetailsDdSalaryAccountBank')}
            labelId={t('OnboardingSalaryDetailsDdSalaryAccountBank')}
            placeholder={t('OnboardingSalaryDetailsDdSalaryAccountBank')}
            options={salaryAccountBankData}
            errorText={`${t(formik.errors.salaryAccountBank ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            // value={salaryAccountBankValue}
            value={formik.values.salaryAccountBank}
            setValue={formik.handleChange('salaryAccountBank')}
          />
        </Grid>
        <Grid>
          <Dropdown
            id={t('OnboardingSalaryDetailsDdWhenAccountOpened')}
            labelId={t('OnboardingSalaryDetailsDdWhenAccountOpened')}
            placeholder={t('OnboardingSalaryDetailsDdWhenAccountOpened')}
            options={whenAccountOpenedData}
            errorText={`${t(formik.errors.whenAccountOpened ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            // value={accountOpenedValue}
            value={formik.values.whenAccountOpened}
            setValue={formik.handleChange('whenAccountOpened')}
          />
        </Grid>
        <Grid>
          <Dropdown
            id={t('OnboardingSalaryDetailsDdAutoPaymentInstructions')}
            labelId={t('OnboardingSalaryDetailsDdAutoPaymentInstructions')}
            placeholder={t('OnboardingSalaryDetailsDdAutoPaymentInstructions')}
            options={autoPaymentInstructionsData}
            errorText={`${t(formik.errors.autoPaymentInstructions ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.autoPaymentInstructions}
            setValue={formik.handleChange('autoPaymentInstructions')}
          />
        </Grid>
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingSalaryDetailsBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={formik.handleSubmit}
        />
      </Grid>
    </Grid>
  );
};

export default SalaryDetails;
