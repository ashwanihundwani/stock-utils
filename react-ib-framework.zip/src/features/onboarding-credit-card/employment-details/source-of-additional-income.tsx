import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {getStyles} from './styles';
import {useNewTheme, translation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Dropdown} from 'components';
import TextArea from 'components/text-area';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {incomeSourceDropdown} from './utility';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {useFormik} from 'formik';
import {
  OnboardingAdditionalIncomeSourceInitialValues,
  OnboardingAdditionalIncomeSourceSchema,
} from '../schemas/onboarding-additionalincome-source';

const SourceOfAdditionalIncome: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();

  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingAdditionalIncomeSourceInitialValues,
    validationSchema: OnboardingAdditionalIncomeSourceSchema,
    onSubmit: () => {
      // do nothing
      navigate(AppPath.TellUsAboutAdditionalIncome);
    },
  });

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id="idBack"
          variant={variants.bodySemiBoldM}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id="idtitle"
          variant={variants.titleXL}
          text={t('OnboardingAdditionalIncomesourceLblTitle')}
        />
      </Grid>
      <Grid sx={styles.incomeSourceDropdownGrid}>
        <Dropdown
          id={t('OnboardingAdditionalIncomesourceDdIncomeSource')}
          labelId={t('OnboardingAdditionalIncomesourceDdIncomeSource')}
          placeholder={t('OnboardingAdditionalIncomesourceDdIncomeSource')}
          options={incomeSourceDropdown}
          errorText={`${t(formik.errors.incomeSource ?? '')}`}
          helperText={''}
          disabled={false}
          customstyle={styles.incomeSourceDropdown}
          labelstyle={styles.labelStyle}
          // value={incomeSource}
          value={formik.values.incomeSource}
          setValue={formik.handleChange('incomeSource')}
        />
      </Grid>
      <Grid sx={styles.textAreaGrid}>
        <TextArea
          id={t('OnboardingAdditionalIncomesourceTxtIncomeSourceDescription')}
          placeholder={t(
            'OnboardingAdditionalIncomesourceTxtIncomeSourceDescription',
          )}
          // onChange={handleOnTextArea}
          errorText={`${t(formik.errors.incomeSourceDescription ?? '')}`}
          helperText=""
          disabled={false}
          value={formik.values.incomeSourceDescription}
          onChange={formik.handleChange('incomeSourceDescription')}
          customStyle={styles.textArea}
        />
      </Grid>
      <Grid>
        <Grid sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingAdditionalIncomesourceBtnNext')}
            disabled={!(formik.isValid && formik.dirty)}
            onClick={formik.handleSubmit}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default SourceOfAdditionalIncome;
