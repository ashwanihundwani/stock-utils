import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      display: 'flex',
      height: '480px',
      padding: '30px',
      margin: '20px',
      flexDirection: 'column',
    },
    backNavGrid: {
      display: 'flex',
      flexDirection: 'column',
    },
    rowStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '8px',
    },
    tellAboutlblStyle: {
      width: '802px',
      mt: 1,
    },
    container: {
      width: '100%',
      height: '100%',
      backgroundColor: theme.colors['background-02'],
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    },

    contentContainerStyle: {
      width: '802px',
      height: '480px',
      display: 'flex',
      marginLeft: '40px',
      flexDirection: 'column',
    },

    backLblstyle: {
      width: '36px',
      height: '24px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    optionBtnContainerStyle: {
      width: '448px',
      height: '200px',
      mt: 2,
    },
    inputOthersStyle: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '448px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },
    inputStyles: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      marginTop: '8px',
    },
    nextBtnStyle: {width: '100px', mt: 2},
    textInputStyles: {width: '448px'},
    listGrid: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
      mt: 4,
    },
    listrow: {
      display: 'flex',
      flexDirection: 'row',
      gap: '16px',
    },
    button: {
      mt: 4,
    },
    sharedTrustedInputStyles: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '393px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },

    defaultContainer: {
      display: 'flex',
      justifyContent: 'center',
      width: '614px',
    },
    title: {
      fontFamily: fonts.regular,
      fontSize: '20px',
      fontWeight: '600',
      color: theme.colors['content-primary'],
      paddingBottom: '16px',
    },
    textBoxStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      mt: '2px',
    },
    subtitle: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
      width: '330px',
      paddingBottom: '16px',
    },
    validationBox: {
      display: 'flex',
      alignItems: 'center',
      paddingTop: '4px',
      gap: '4px',
    },
    validationLabel: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
    },
    usernameBox: {
      display: 'grid',
    },
    backNavigationBox: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      paddingBottom: '8px',
    },
    backNavigation: {
      fontFamily: fonts.regular,
      fontSize: '16px',
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    crendentialStyle: {
      width: '802px',
      height: '160px',
      gap: '24px',
      flexDirection: 'row',
      display: 'flex',
      mt: '2',
      paddingTop: '20px',
    },
    tickIconGreenStyle: {
      borderRadius: '999px',
      width: '16px',
      height: '16px',
      backgroundColor: theme.colors['surface-semantic-success-02'],
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
    },
    tickIconRedStyle: {
      borderRadius: '999px',
      width: '16px',
      height: '16px',
      backgroundColor: theme.colors['surface-semantic-error-02'],
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
    },
    tickIconWhitetyle: {
      borderRadius: '999px',
      width: '16px',
      height: '16px',
      backgroundColor: theme.colors['surface-01'],
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
    },
    passwordContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
    passwordBoxStyle: {
      width: '802px',
      minHeight: '64px',
      mt: 1,
    },
    dropdown: {
      background: theme.colors['surface-01'],
      width: '393px',
    },
    labelStyle: {
      fontFamily: fonts.figtree_regular,
      color: theme.colors['content-secondary'],
    },
    checkBoxAcceptGrid: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1px',
    },
    checkboxLabel: {
      display: 'flex',
      flexDirection: 'row',
      gap: '5px',
      margin: '2px',
    },
    textArea: {
      width: '100%',
      gap: '8px',
      mt: 2,

      backgroundColor: theme.colors['surface-01'],
      borderRadius: '10px',
      '&:hover': {
        // borderColor: theme.colors['border-focus'],
        backgroundColor: theme.colors['surface-01'],
      },
      '& .MuiFilledInput-root': {
        border: `1px solid transparent`,
        borderRadius: '10px',
        mt: 6,

        fontFamily: fonts.regular,
        backgroundColor: theme.colors['surface-01'],
        color: theme.colors['content-primary'],
        height: '192px',
        alignItems: 'flex-end',
        paddingTop: '12px',
        paddingLeft: '16px',
        marginTop: '3px',
        '&:hover': {
          // borderColor: theme.colors['border-focus'],
          backgroundColor: theme.colors['surface-01'],
        },
        '&.Mui-focused': {
          backgroundColor: theme.colors['surface-01'],
        },
        '& label': {
          margin: '5px 10px 8px',
          fontSize: '14px',
          fontFamily: fonts.regular,
          fontWeight: 'normal',
          // width: '100%',
          minWidth: '100%',
          whiteSpace: 'normal',
          overflow: 'visible',

          display: 'block',
          backgroundColor: 'red',
          color: theme.colors['content-secondary'],
          transform: 'Titlecase',
          '&.Mui-focused': {
            fontSize: '14px',
            fontWeight: 'normal',
            backgroundColor: 'violet',

            fontFamily: fonts.regular,
            color: theme.colors['content-primary'],
          },
        },
      },
    },
  };
};
