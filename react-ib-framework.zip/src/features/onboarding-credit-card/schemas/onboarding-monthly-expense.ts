import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingMonthlyExpensesSchema = yup.object().shape({
  education: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxteEducation),
  food: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtFood),
  medical: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtMedical),
  transportation: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtTransportation),
  utilitybills: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtUtilityBills),
  domensticlabor: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtDomensticLabor),
  financial: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtFinancial),
  expected: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtExpected),
  monthlyrent: yup
    .string()
    .required(Errors.OnboardingMonthlyExpensesErrorRequiredtxtMonthlyRent),
});

export const OnboardingMonthlyExpensesInitialValues = {
  education: undefined,
  food: undefined,
  medical: undefined,
  transportation: undefined,
  utilitybills: undefined,
  domensticlabor: undefined,
  financial: undefined,
  expected: undefined,
  monthlyrent: undefined,
};
