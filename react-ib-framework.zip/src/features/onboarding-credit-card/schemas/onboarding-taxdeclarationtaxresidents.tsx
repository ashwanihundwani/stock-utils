import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingTaxDeclarationTaxResidentSchema = yup.object().shape({
  countriesData: yup.array().of(
    yup.object().shape({
      countryOfTax: yup
        .string()
        .required(
          Errors.OnboardingTaxDeclarationTaxResidentErrorRequiredDdCountry,
        ),
      address: yup
        .string()
        .required(
          Errors.OnboardingTaxDeclarationTaxResidentErrorRequiredTxtAddress,
        ),
      state: yup
        .string()
        .required(
          Errors.OnboardingTaxDeclarationTaxResidentErrorRequiredTxtState,
        ),
      phoneNumber: yup
        .string()
        .required(
          Errors.OnboardingTaxDeclarationTaxResidentErrorRequiredTxtPhoneNumber,
        )
        .nullable(),
    }),
  ),
});
export type countryData = {
  countryOfTax: string;
  address: string;
  state: string;
  phoneNumber: string;
  mail: string;
  id: number;
};
type OnboardingTaxDeclarationTaxResidentInitialValuesType = {
  id: number;
  countriesData: countryData[];
};
export const OnboardingTaxDeclarationTaxResidentInitialValues: OnboardingTaxDeclarationTaxResidentInitialValuesType =
  {
    countriesData: [
      {
        countryOfTax: '',
        address: '',
        state: '',
        phoneNumber: '',
        mail: '',
        id: 0,
      },
    ],
    id: 0,
  };
