import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingCredentialsCreationPasswordSchema = yup.object().shape({
  password: yup
    .string()
    .required(
      Errors.OnboardingCredentialsCreationPasswordErrorRequiredTxtPassword,
    )
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&*@^])(?=.{12,})/),

  repassword: yup
    .string()
    .required(
      Errors.OnboardingCredentialsCreationPasswordErrorRequiredTxtRePassword,
    )
    .oneOf(
      [yup.ref('password'), ''],
      Errors.OnboardingCredentialsCreationPasswordErrorPasswordMismatch,
    ),
});

export const OnboardingCredentialsCreationPasswordInitialValues = {
  password: '',
  repassword: '',
};
