import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingDisabilitiesSchema = yup.object().shape({
  disability: yup
    .string()
    .required(Errors.OnboardingDisabilitiesErrorRequiredTxtDisability),
});

export const OnboardingDisabilitiesInitialValues = {
  disability: undefined,
};
