import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingSalaryDetailsSchema = yup.object().shape({
  salaryAccountBank: yup
    .string()
    .required(Errors.OnboardingSalaryDetailsErrorRequiredDdSalaryAccountBank),
  whenAccountOpened: yup
    .string()
    .required(Errors.OnboardingSalaryDetailsErrorRequiredDdWhenAccountOpend),
  autoPaymentInstructions: yup
    .string()
    .required(
      Errors.OnboardingSalaryDetailsErrorRequiredDdAutoPaymentInstructions,
    ),
});

export const OnboardingSalaryDetailsInitialValues = {
  salaryAccountBank: undefined,
  whenAccountOpened: undefined,
  autoPaymentInstructions: undefined,
};
