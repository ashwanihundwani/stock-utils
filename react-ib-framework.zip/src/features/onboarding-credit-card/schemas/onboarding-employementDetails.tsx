import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingEmploymentDetailsSchema = yup.object().shape({
  employerName: yup
    .string()
    .required(Errors.OnboardingEmploymentDetailsErrorRequiredDdEmployerName),
  jobTitle: yup
    .string()
    .required(Errors.OnboardingEmploymentDetailsErrorRequiredDdJobTitle),
  //   workSector: yup
  //     .string()
  //     .required(Errors.OnboardingEmploymentDetailsErrorRequiredDdWorkSector),
  joiningDate: yup
    .string()
    .required(Errors.OnboardingEmploymentDetailsErrorRequiredTxtJoiningDate),
  totalWorkExperience: yup
    .string()
    .required(
      Errors.OnboardingEmploymentDetailsErrorRequiredDdTotalWorkExperience,
    ),
  periodInCurrentJob: yup
    .string()
    .required(
      Errors.OnboardingEmploymentDetailsErrorRequiredDdPeriodInCurrentJob,
    ),
  //   workContactNumber: yup
  //     .string()
  //     .matches(/^(5\d{8})$/)
  //     .required(
  //       Errors.OnboardingEmploymentDetailsErrorRequiredTxtWorkContactNumber,
  //     ),
});

export const OnboardingEmploymentDetailsInitialValues = {
  employerName: '',
  otherEmployerName: '',
  jobTitle: '',
  workSector: '',
  joiningDate: '',
  totalWorkExperience: '',
  periodInCurrentJob: '',
  workContactNumber: '',
  monthlyIncome: '',
};
