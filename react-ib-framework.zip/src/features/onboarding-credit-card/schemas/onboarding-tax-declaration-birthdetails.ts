import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingTaxDeclarationBirthDetailsSchema = yup.object().shape({
  countryOfBirth: yup
    .string()
    .required(
      Errors.OnboardingTaxDeclarationBirthDetailsErrorRequiredDdCountryOfBirth,
    ),
  cityOfBirth: yup
    .string()
    .required(
      Errors.OnboardingTaxDeclarationBirthDetailsErrorRequiredTxtCityOfBirth,
    ),
  Address: yup
    .string()
    .required(
      Errors.OnboardingTaxDeclarationBirthDetailsErrorRequiredTxtAddress,
    ),
});

export const OnboardingTaxDeclarationBirthDetailsInitialValues = {
  countryOfBirth: '',
  cityOfBirth: '',
  Address: '',
};
