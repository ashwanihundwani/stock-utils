import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingEmailSchema = yup.object().shape({
  email: yup
    .string()
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
      Errors.OnboardingEmailErrorMusttxtEmail,
    )
    .required(Errors.OnboardingEmailErrorRequiredtxtEmail),
  repeatemail: yup
    .string()
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
      Errors.OnboardingEmailErrorMusttxtRepeatemail,
    )
    .oneOf([yup.ref('email')], Errors.OnboardingEmailsErrorMustMatchtxtEmail)
    .required(Errors.OnboardingEmailErrorRequiredtxtEmail),
});

export const OnboardingEmailInitialValues = {
  email: '',
  repeatemail: undefined,
};
