import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingAboutAddtionalIncomeSchema = yup.object().shape({
  monthlyIncome: yup
    .string()
    .required(
      Errors.OnboardingAboutAddtionalIncomeErrorRequiredDdMonthlyIncome,
    ),
});

export const OnboardingAboutAddtionalIncomeInitialValues = {
  monthlyIncome: '',
  rangedMonthlyIncome: '',
};
