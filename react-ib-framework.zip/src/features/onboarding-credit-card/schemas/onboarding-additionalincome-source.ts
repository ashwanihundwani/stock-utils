import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingAdditionalIncomeSourceSchema = yup.object().shape({
  incomeSource: yup
    .string()
    .required(
      Errors.OnboardingAdditionalIncomesourceErrorRequiredDdIncomeSource,
    ),
  incomeSourceDescription: yup
    .string()
    .required(
      Errors.OnboardingAdditionalIncomesourceErrorRequiredTxtIncomeSourceDescription,
    ),
});

export const OnboardingAdditionalIncomeSourceInitialValues = {
  incomeSource: undefined,
  incomeSourceDescription: undefined,
};
