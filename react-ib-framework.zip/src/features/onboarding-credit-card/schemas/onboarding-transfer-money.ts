import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingTransferMoneySchema = yup.object().shape({
  countries: yup
    .string()
    .required(Errors.OnboardingTransferMoneyErrorrequiredDdCountries),
});

export const OnboardingTransferMoneyInitialValues = {
  countries: '',
};
