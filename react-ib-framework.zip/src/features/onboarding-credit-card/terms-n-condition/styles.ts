export const getStyles = () => {
  return {
    tc_Container: {
      display: 'flex',
      borderRadius: '8px',
      gap: '10px',
      padding: '20px',
      flexDirection: 'column',
    },
    titleContainer: {gap: '8px'},
    urlContent: {
      width: '100%',
      height: '250px',
    },
    buttonContainer: {
      display: 'flex',
      justifyContent: 'center',
      backgroundColor: 'yellow',
      padding: '10px',
      width: '100%',
      height: '100%',
    },
    checkboxContainer: {
      display: 'flex',
      flexDirection: 'row',
      mt: 2,
    },
    checkboxTitleStyle: {
      display: 'flex',
      alignItems: 'center',
    },
    button: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      paddingTop: '16px',
      gap: '16px',
    },
    cancelIconStyle: {
      textAlign: 'right',
    },
  };
};
