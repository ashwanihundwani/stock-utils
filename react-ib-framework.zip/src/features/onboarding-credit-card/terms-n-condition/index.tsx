import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useTranslation} from 'react-core';
import {getStyles} from './styles';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Box, SvgIcon} from '@mui/material';
import CustomCheckbox from 'components/checkbox';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ModalTypeProps} from './types';
import {DeleteIcon} from 'assets/svg/deleteIcon';

const TermsAndCondition: FC<ModalTypeProps> = ({modalClose}) => {
  const [checkboxValue, setCheckboxValue] = useState(false);

  const styles = getStyles();
  const {t} = useTranslation();

  const onChange = () => {
    setCheckboxValue(!checkboxValue);
  };

  return (
    <Grid size={6} sx={styles.tc_Container}>
      <Box>
        <Box sx={styles.cancelIconStyle}>
          <SvgIcon onClick={modalClose}>
            <DeleteIcon />
          </SvgIcon>
        </Box>
        <Box sx={styles.titleContainer}>
          <CustomLabel
            id="idEmploymentStatus"
            variant={variants.titleS}
            text={t('OnboardingTermsAndConditionsLblTitle')}
          />
          <CustomLabel
            id="lblSubtitle"
            variant={variants.bodyRegularM}
            text={t('OnboardingTermsAndConditionsLblSubtitle')}
          />
        </Box>
      </Box>

      <Box sx={styles.urlContent}>
        {/* <Link
          href={'https://www.w3schools.com/'}
          target="_blank"
          sx={styles.buttonContainer}
          underline="none"
          rel="noopner"
        /> */}

        <iframe
          src="https://www.w3schools.com/"
          //   src="https://meem.com.sa/media/lvflrc1h/general-terms-and-conditons_opening-account_en-general.pdf"
          width="100%"
          height="100%"
          style={{border: 'none'}}
          title="External Content"></iframe>
      </Box>
      <Box sx={styles.checkboxContainer}>
        <CustomCheckbox
          id="checkbox-cmp"
          errorText={''}
          helperText={''}
          disabled={false}
          onChange={onChange}
          icon={<CheckboxDefaultIcon />}
          checkedIcon={<CheckboxSelectedIcon />}
        />
        <CustomLabel
          id="Checkbox1"
          variant={variants.bodyRegularM}
          style={styles.checkboxTitleStyle}
          text={t('OnboardingTermsAndConditionsChkAcknowledge')}
        />
      </Box>
      <Box sx={styles.button}>
        <Button
          variant={ButtonStyle.Secondary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          onClick={modalClose}
          text={t('OnboardingTermsAndConditionsBtnDecline')}
        />
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          onClick={modalClose}
          text={t('OnboardingTermsAndConditionsBtnAccept')}
        />
      </Box>
    </Grid>
  );
};

export {TermsAndCondition};
