import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {useFormik} from 'formik';
import {
  TrustedContactDetailsInitialValues,
  TrustedContactDetailsSchema,
} from '../schemas/onboarding-trusted-contact-details';

const ShareTruestedDetails: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: TrustedContactDetailsInitialValues,
    validationSchema: TrustedContactDetailsSchema,
    onSubmit: () => {
      navigate(AppPath.taxResident);
    },
  });

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingTrustedContactDetailsLblTitle')}
        />
        <Box sx={styles.tellAboutlblStyle}>
          <CustomLabel
            id="idEmploymentStatus"
            variant={variants.bodyRegularM}
            text={t('OnboardingTrustedContactDetailsLblSubtitle')}
          />
        </Box>
      </Box>
      <Grid sx={styles.listGrid}>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingTrustedContactDetailsTxtFullname')}
            type={InputType.Text}
            value={formik.values.fullname}
            setValue={formik.handleChange('fullname')}
            bgWhite
            errorText={`${t(formik.errors.fullname ?? '')}`}
          />
          <TextInput
            label={t('OnboardingTrustedContactDetailsTxtRelationship')}
            value={formik.values.relationship}
            setValue={formik.handleChange('relationship')}
            type={InputType.Text}
            bgWhite
            errorText={`${t(formik.errors.relationship ?? '')}`}
          />
        </Grid>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingTrustedContactDetailsTxtPhonenumber')}
            value={formik.values.phonenumber}
            type={InputType.Number}
            prefix={'+966'}
            startElement={true}
            bgWhite
            setValue={text =>
              formik.handleChange('phonenumber')(text.replace(/[|s,.]/g, ''))
            }
            errorText={`${t(formik.errors.phonenumber ?? '')}`}
          />
          <TextInput
            label={t('OnboardingTrustedContactDetailsTxtHomephone')}
            bgWhite
            value={formik.values.homephonenumber}
            type={InputType.Number}
            setValue={formik.handleChange('homephonenumber')}
            errorText={`${t(formik.errors.homephonenumber ?? '')}`}
          />
        </Grid>
        <Box sx={styles.nextBtnStyle}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            disabled={!(formik.isValid && formik.dirty)}
            text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
            onClick={formik.handleSubmit}
          />
        </Box>
      </Grid>
    </Grid>
  );
};

export {ShareTruestedDetails};
