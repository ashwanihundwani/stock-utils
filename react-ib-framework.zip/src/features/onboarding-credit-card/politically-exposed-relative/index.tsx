import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';

const PoliticalyExposedRelative: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );
  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);
    navigate(AppPath.disabilities);
  };
  const data = [
    {id: '1', name: t('OnboardingAdditionalincomeBtnOptionNo')},
    {id: '2', name: t('OnboardingAdditionalIncomeBtnOptionYes')},
  ];
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingPepRelativeStageLblTitle')}
        />
      </Box>
      <Box sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
        />
      </Box>
    </Grid>
  );
};

export {PoliticalyExposedRelative};
