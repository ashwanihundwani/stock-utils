import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import Typography from '@mui/material/Typography';
import {Box} from '@mui/material';
import {MeemCreditCardIcon} from 'assets/svg/meem-credit-card-icon';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {AlNaseerCreditCardIcon} from 'assets/svg/al-naseer-credit-card-icon';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import CompareCreditCardDropdown from './compareCreditCardDropdown';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';

// Header to be implemented
const CompareCreditCard: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate(AppPath.BeforeWeBegin);
  };

  return (
    <Grid container size={12} sx={styles.gridContainer}>
      <Grid size={8} offset={2}>
        <Grid sx={styles.backNavGrid}>
          <ArrowLeft />
          <Typography sx={styles.backNavigation}>Back</Typography>
        </Grid>
        <Grid sx={styles.ourCreditCardGrid}>
          <CustomLabel
            id="lblTitle"
            variant={variants.titleXL}
            text={t('OnboardingOurCreditCardLblTitle')}
          />

          <CustomLabel
            id="lblSubTite"
            variant={variants.bodyRegularM}
            text={t('OnboardingOurCreditCardLblSubtitle')}
          />
        </Grid>
        <Grid sx={styles.cardContainerType}>
          <Box sx={styles.meemCardStyle}>
            <Box sx={styles.meemImageStyle}>
              <MeemCreditCardIcon />
            </Box>
            <Box sx={styles.meemCardLabelStyle}>
              <Box sx={styles.labelStyle}>
                <CustomLabel
                  id="lblMeemCcTitle"
                  style={styles.lblContentStyle}
                  variant={variants.bodyMediumL}
                  text={t('OnboardingOurCreditCardLblMeemCcTitle')}
                />
                <CustomLabel
                  id="lblSubtitle"
                  variant={variants.bodyRegularS}
                  text={t('OnboardingOurCreditCardLblMeemCcSubtitle')}
                />
              </Box>
              <Box sx={styles.meemImageStyle}>
                <Button
                  variant={ButtonStyle.Primary}
                  size={ButtonSize.Small}
                  type={ButtonType.Text}
                  text="Apply for meem"
                  onClick={handleSubmit}></Button>
              </Box>
            </Box>
          </Box>
          <Box sx={styles.meemCardStyle}>
            <Box sx={styles.meemImageStyle}>
              <AlNaseerCreditCardIcon />
            </Box>
            <Box sx={styles.meemImageStyle}>
              <Box sx={styles.meemCardLabelStyle}>
                <Box sx={styles.labelStyle}>
                  <CustomLabel
                    id="lblNassrCcTitle"
                    style={styles.lblContentStyle}
                    variant={variants.titleS}
                    text={t('OnboardingOurCreditCardLblNassrCctTitle')}
                  />
                  <CustomLabel
                    id="lblNassrCcSubtitle"
                    // style={styles.lblSubTiteStyle}
                    variant={variants.bodyRegularS}
                    text={t('OnboardingOurCreditCardLblNassrCctSubtitle')}
                  />
                </Box>
              </Box>
              <Box>
                <Button
                  variant={ButtonStyle.Primary}
                  size={ButtonSize.Small}
                  type={ButtonType.Text}
                  text="Apply for meem"
                  onClick={handleSubmit}></Button>
              </Box>
            </Box>
          </Box>
        </Grid>
        <Box sx={styles.comparecardlblStyle}>
          <CustomLabel
            id="lblTitle"
            variant={variants.titleM}
            text={t('OnboardingCompareCreditCardLblTitle')}
          />
        </Box>

        <Grid size={12} container sx={styles.gridCompareStyle}>
          <Box sx={styles.cardDetailsSTyle}>
            <CompareCreditCardDropdown />
          </Box>
          <Box sx={styles.cardDetailsSTyle}>
            <CompareCreditCardDropdown />
          </Box>
          <Box sx={styles.cardDetailsSTyle}>
            <CompareCreditCardDropdown />
          </Box>{' '}
        </Grid>
      </Grid>
    </Grid>
  );
};

export default CompareCreditCard;
