export interface creditcardDataItem {
  id: string;
  bank: string;
  name: string;
}
