import {fonts} from 'utils/typography';
import {Theme} from 'react-core';
export const getStyles = (theme: Theme) => {
  return {
    backNavGrid: {
      display: 'flex',
    },
    gridContainer: {
      backgroundColor: '#F7F7FA',
      height: '100%',
      overflow: 'auto',
    },
    cardContainerType: {display: 'flex', gap: '16px', paddingTop: '24px'},
    meemCardStyle: {
      width: '448px',
      height: '193px',
      display: 'flex',
      flexDirection: 'row',
      padding: '20px',
      backgroundColor: 'white',
    },
    meemImageStyle: {
      padding: '16px',
    },
    labelStyle: {
      height: '89px',
      width: '286px',
      gap: '20px',
      padding: '10px',
    },
    meemCardLabelStyle: {
      display: 'flex',
      flexDirection: 'column',
      width: '286px',
      minHeight: '145px',
      gap: '16px',
    },
    backNavigation: {
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontSize: '16px',
      paddingLeft: '8px',
    },
    ourCreditCardGrid: {
      paddingTop: '16px',
    },

    lblContentStyle: {
      width: '100%',
      alignItems: 'center',
      // textAlign: 'center',
      color: theme.colors['content-primary'],
    },
    creditCardStyle: {
      width: '70px',
      height: '50px',
      alignItem: 'center',
      justifyContent: 'center',
    },
    cardDetailstextStyle: {
      color: theme.colors['content-secondary'],
      width: '258px',
      height: '60px',
      gap: '20px',
    },

    listDataStyle: {
      width: '100%',
      color: theme.colors['content-secondary'],
    },

    dropdownStyle: {
      width: '290px',
      minHeight: '64px',

      backgroundColor:
        theme.colors['surface-interactive-primary-inverted-enabled'],
    },
    placeholderStyle: {
      marginTop: '5px',
      width: '218px',
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      '&.Mui-focused': {
        fontSize: '12px',
        marginLeft: '2px',
        marginTop: '18px',
        width: '218px',

        color: theme.colors['content-secondary'],
      },
      '&.MuiFormLabel-filled': {
        fontSize: '12px',
        marginLeft: '2px',
        width: '218px',

        marginTop: '18px',
        color: theme.colors['content-secondary'],
      },
    },

    comparecardlblStyle: {
      gap: '20px',
      paddingTop: '15px',
      paddingBottom: '15px',
    },
    gridCompareStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '14px',
    },
    cardDetailsSTyle: {
      width: '290px',
      minHeight: '660px',
      gap: '16px',
    },
    dropdwonBoxStyle: {
      width: '290px',
      minHeight: '660px',
      gap: '16px',
    },

    beloDropDownBoxStyle: {
      width: '290px',
      height: '580px',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'column',
      marginTop: '16px',
      marginBottom: '16px',
      paddingTop: '16px',
      backgroundColor: 'white',
    },
    cardTypeDetaikStyle: {
      width: '290px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      minHeight: '172px',
      gap: '20px',
    },
    cardDetailLblStyle: {
      width: '258px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      minHeight: '24px',
      gap: '8px',
    },
    cardListConatinerStyle: {
      width: '258px',
      minHeight: '344px',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'column',
      marginTop: '16px',
      marginBottom: '16px',
      gap: '16px',
    },
    cardDetailContainerStyle: {
      display: 'flex',
      flexDirection: 'row',
      width: '258px',
      minHeight: '64px',
      gap: '8px',
    },
    checkMarkIconStyle: {height: '32px', width: '32px'},
    titleAndValueListStyle: {
      display: 'flex',
      flexDirection: 'column',
      width: '230px',
    },
  };
};
