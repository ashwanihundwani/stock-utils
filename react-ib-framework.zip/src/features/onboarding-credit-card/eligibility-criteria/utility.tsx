const saudiConditions = [
  {
    id: 1,
    title: 'OnePack Account held',
    content: 'Yes',
  },
  {
    id: 2,
    title: 'Minumum Age',
    content: '18 years old',
  },
  {
    id: 3,
    title: 'Maximum age at maturity',
    content: 'Employed: Retirement age',
    sub_content: 'Retired: 65 years old',
  },
  {
    id: 4,
    title: 'OnePack Account held',
    content: 'Yes',
  },
  {
    id: 5,
    title: 'Employment Status',
    content: 'Employed',
  },
  {
    id: 6,
    title: 'Minimum Salary',
    content:
      'Government and semigovernment (2,000 SAR), Employer A, B, C & D (2,000 SAR) and Retired (1,900 SAR)',
  },
  {
    id: 7,
    title: 'Minimum Employment Period',
    content: 'At least 1 month',
  },
  {
    id: 8,
    title: 'Fulfillment',
    content: 'Requires GOSI certificate for automated processing',
  },
  {
    id: 9,
    title: 'Credit History',
    content: 'No SIMAH history required',
  },
];

const expatriatesConditions = [
  {
    id: 1,
    title: 'OnePack Account held',
    content: 'Yes',
  },
  {
    id: 2,
    title: 'Minumum Age',
    content: '18 years old',
  },
  {
    id: 3,
    title: 'Maximum age at maturity',
    content: '55 years',
  },
  {
    id: 4,
    title: 'Employment Status',
    content: 'Employed',
  },
  {
    id: 5,
    title: 'Minimum Salary',
    content:
      'Government and semigovernment (7,500 SAR), Employer A, B, C (7,500 SAR)',
  },
  {
    id: 6,
    title: 'Minimum Employment Period',
    content: 'At least 3 months',
  },
  {
    id: 7,
    title: 'Fulfillment',
    content: 'Requires GOSI certificate for automated processing',
  },
  {
    id: 8,
    title: 'Credit History',
    content: 'No SIMAH history required',
  },
];
export {saudiConditions, expatriatesConditions};
