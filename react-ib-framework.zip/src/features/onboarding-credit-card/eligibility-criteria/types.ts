export interface EligibilityCriteriaProps {
  data: {
    id: number;
    title: string;
    content: string;
    sub_content?: string;
  }[];
}
