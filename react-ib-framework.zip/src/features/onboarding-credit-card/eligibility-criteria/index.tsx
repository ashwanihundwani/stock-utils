import {Divider} from '@mui/material';
import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme} from 'react-core';
import {getStyles} from './styles';
import {EligibilityCriteriaProps} from './types';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
const EligibilityCriteria: FC<EligibilityCriteriaProps> = ({data}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  return data?.map(value => {
    return (
      <Grid key={value.id} sx={styles.container}>
        <CustomLabel
          id="lblTitle"
          variant={variants.bodySemiBoldS}
          style={styles.title}
          text={value.title}
        />
        <CustomLabel
          id="lblContnet"
          variant={variants.bodyRegularS}
          style={styles.content}
          text={value.content}
        />
        <CustomLabel
          id="lblSubContnet"
          variant={variants.bodyRegularS}
          style={styles.content}
          text={value.sub_content || ''}
        />

        {data.length !== value.id && <Divider sx={styles.divider} />}
      </Grid>
    );
  });
};

export default EligibilityCriteria;
