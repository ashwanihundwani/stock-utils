import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    title: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '600',
      color: theme.colors['content-primary'],
    },
    content: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      display: 'flex',

      color: theme.colors['content-primary'],
    },
    container: {
      marginTop: '16px',
      // width: '636px',
    },
    divider: {
      color: theme.colors['border-enabled-01'],
      marginTop: '16px',
      marginBottom: '16px',
    },
  };
};
