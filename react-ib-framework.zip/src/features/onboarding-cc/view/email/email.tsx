import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box, Typography} from '@mui/material';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import CustomCheckbox from 'components/checkbox';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';

const EmailScreen: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [emailValue, setEmailValue] = useState('');
  const [repeatEmailValue, setRepeatEmailValue] = useState('');
  const [checkboxValue, setCheckboxValue] = useState(false);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const onChange = () => {
    setCheckboxValue(!checkboxValue);
  };

  const handleSubmit = () => {
    navigate(AppPath.firstNameTitle);
  };

  return (
    <Grid container size={12} sx={styles.container}>
      <Grid offset={2} size={8}>
        <Grid>
          <Typography sx={styles.emailTitle}>
            {t('OnboardingEmailLblEmail')}
          </Typography>
          <Typography sx={styles.emailContent}>
            Make sure you always use the same email address.
          </Typography>
          <Box sx={styles.emailGrid}>
            <TextInput
              value={emailValue}
              label={t('OnboardingEmailLblEmail')}
              setValue={setEmailValue}
              type={InputType.Text}
              customStyle={styles.emailStyle}
            />
          </Box>
          <Box>
            <TextInput
              value={repeatEmailValue}
              label={t('OnboardingEmailLblRepeatEmail')}
              setValue={setRepeatEmailValue}
              type={InputType.Text}
              customStyle={styles.emailStyle}
            />
          </Box>
          <Box sx={styles.checkBoxGrid}>
            <CustomCheckbox
              id="checkbox-cmp"
              errorText={''}
              helperText={''}
              disabled={false}
              onChange={onChange}
              icon={<CheckboxDefaultIcon />}
              checkedIcon={<CheckboxSelectedIcon />}
            />
            <Typography sx={styles.contents}>
              I consent meem verifying my information against my data registered
              at GOSI
            </Typography>
          </Box>
          <Box sx={styles.checkBoxAcceptGrid}>
            <Box>
              <CustomCheckbox
                id="checkbox-cmp"
                errorText={''}
                helperText={''}
                disabled={false}
                onChange={onChange}
                icon={<CheckboxDefaultIcon />}
                checkedIcon={<CheckboxSelectedIcon />}
              />
            </Box>
            <Typography sx={styles.contents}>
              {t('OnboardingEmailChkSimahDisclaimer')}
            </Typography>
            <Link
              size={LinkSize.Medium}
              linkText={t('OnboardingEmailLblDisclaimer')}
            />
          </Box>
          <Box sx={styles.button}>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Small}
              type={ButtonType.Text}
              text={t('OnboardingEmailBtnNext')}
              onClick={handleSubmit}
            />
          </Box>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default EmailScreen;
