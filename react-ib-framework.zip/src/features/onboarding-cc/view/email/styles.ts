import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      backgroundColor: theme.colors['background-02'],
      height: '100vh',
    },
    emailTitle: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '28px',
      color: theme.colors['content-primary'],
    },
    emailContent: {
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '16px',
      color: theme.colors['content-secondary'],
    },
    contents: {
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '16px',
      color: theme.colors['content-secondary'],
      paddingRight: '4px',
    },
    button: {
      paddingTop: '32px',
    },
    emailStyle: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '448px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },
    emailGrid: {
      paddingBottom: '16px',
      paddingTop: '16px',
    },
    checkBoxGrid: {
      paddingTop: '32px',
      paddingBottom: '16px',
      width: '400px',
      display: 'flex',
      alignItems: 'base-line',
    },
    checkBoxAcceptGrid: {
      display: 'flex',
      flexDirection: 'row',
      width: '253px',
    },
  };
};
