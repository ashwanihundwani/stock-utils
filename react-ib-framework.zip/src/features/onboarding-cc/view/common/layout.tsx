import React from 'react';
import {Box} from '@mui/material';
import {useNewTheme} from 'react-core';
import {layoutStyles} from './styles';
import Sidebar from './sidebar';
import Header from './header';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({children}) => {
  const theme = useNewTheme();
  const styles = layoutStyles(theme);

  return (
    <Box sx={styles.layout}>
      <Header />
      <Box sx={styles.container}>
        <Box sx={styles.mainContentContainer}>
          <Sidebar />
          <Box sx={styles.content}>{children}</Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Layout;
