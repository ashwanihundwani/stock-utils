import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const headerStyles = (theme: Theme) => ({
  header: {
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: '10%',
    padding: '0 16px',
    backgroundColor: theme.colors['surface-01'],
    borderBottom: `1px solid ${theme.colors['border-enabled-01']} `,
  },
  logo: {
    pl: 1,
  },
  closeIcon: {
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    pr: 4,
  },
});

export const layoutStyles = (theme: Theme) => ({
  layout: {
    height: '100vh',
  },
  container: {
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: theme.colors['surface-02'],
  },
  mainContentContainer: {
    display: 'flex',
    flexGrow: 1,
  },
  content: {
    display: 'flex',
    flexDirection: 'column',

    gap: '32px',
  },
});

export const sidebarStyles = (theme: Theme) => ({
  container: {
    width: '250px',
    display: 'flex',
    flexDirection: 'column',
    minHeight: 'calc( 100vh - 64px)', // Full height of the viewport
    padding: '0 16px',
    backgroundColor: theme.colors['background-01'],
  },
  title: {
    fontSize: 14,
    fontFamily: fonts.figtree_medium,
  },
  subTitle: {
    fontSize: 14,
    fontFamily: fonts.regular,
    color: theme.colors['content-secondary'],
  },
  contact: {
    pt: 1,
    pb: 1,
  },
  stepperWrapper: {
    flexGrow: 1,
    mt: 1,
  },
  supportSection: {
    textAlign: 'left',
  },
});

export const CannotOfferCCStyles = (theme: Theme) => ({
  container: {
    height: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
    gap: '32px',
  },
  innerGrid: {
    width: '448px',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'column',
    gap: '16px',
  },
  title: {
    fontFamily: fonts.regular,
    weight: '500',
    fontSize: '28px',
    color: theme.colors['content-primary'],
    paddingTop: '32px',
  },
  content: {
    fontFamily: fonts.regular,
    weight: '400',
    fontSize: '16px',
    color: theme.colors['content-secondary'],
    paddingBottom: '16px',
  },
  circleIcon: {
    borderRadius: '50%',
    backgroundColor: theme.colors['surface-semantic-error-01'],
    height: '104px',
    width: '104px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  successIcon: {
    borderRadius: '50%',
    backgroundColor: theme.colors['surface-semantic-success-01'],
    height: '104px',
    width: '104px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  listItems: {
    display: 'flex',
    alignItems: 'center',
    paddingLeft: '16px',
    borderRadius: '10px',
    width: '448px',
    minHeight: '100px',
    backgroundColor: theme.colors['surface-02'],
  },
  icons: {
    width: '42px',
    height: '32px',
    backgroundColor: theme.colors['surface-03'],
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '8px',
  },
  iconText: {
    textAlign: 'left',
    paddingLeft: '16px',
  },
  iconBox: {
    width: '60px',
  },
  overallOnePackAccountSet: {
    fontFamily: fonts.regular,
    weight: '500',
    fontSize: '28px',
    color: theme.colors['content-primary'],
    paddingTop: '32px',
    paddingBottom: '32px',
  },
  buttonPadding: {
    paddingTop: '32px',
  },
});
