import React from 'react';
import {Box, Typography} from '@mui/material';
import {translation, useNewTheme} from 'react-core';
import {sidebarStyles} from './styles';
import VerticalStepper from 'components/stepper';
import {AudioIcon} from 'assets/svg/headerIcons';
import Link from 'components/link';

const Sidebar: React.FC = () => {
  const theme = useNewTheme();
  const styles = sidebarStyles(theme);
  const {t} = translation.useTranslation();

  const steps = [
    'Verify your identity',
    'About you',
    'Your employment details',
    'Your finances',
    'Other details',
    'Set up your account',
  ];

  return (
    <Box sx={styles.container}>
      <Box sx={styles.stepperWrapper}>
        <VerticalStepper steps={steps} activeStep={3} />
      </Box>
      <Box sx={styles.supportSection}>
        <AudioIcon />
        <Typography sx={styles.title}>
          {t('OnboardingIdVerificationLblTitleWeb')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingIdVerificationLblSubtitleWeb')}
        </Typography>
        <Box sx={styles.contact}>
          <Link linkText={t('OnboardingIdVerificationLblLinkWeb')} />
        </Box>
      </Box>
    </Box>
  );
};

export default Sidebar;
