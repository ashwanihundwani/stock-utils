export const getStyles = () => {
  return {
    sessionContainer: {
      display: 'flex',
      width: '448px',
      borderRadius: '8px',
      padding: '24px',
      flexDirection: 'column',
    },
    titleContainer: {
      width: '100%',
      heigght: '80px',
      gap: '8px',
    },
    urlContent: {
      width: '100%',
      height: '250px',
    },
    buttonContainer: {
      display: 'flex',
      justifyContent: 'center',
      backgroundColor: 'yellow',
      padding: '10px',
      width: '100%',
      height: '100%',
    },
    checkboxContainer: {
      display: 'flex',
      flexDirection: 'row',
      mt: 2,
      ml: 4,
    },
    checkboxTitleStyle: {
      display: 'flex',
      alignItems: 'center',
    },
    button: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      paddingTop: '16px',
      gap: '16px',
    },
  };
};
