import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useTranslation} from 'react-core';
import {getStyles} from './styles';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Box} from '@mui/material';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ModalTypeProps} from '../types';

const HeaderSessionPopUp: FC<ModalTypeProps> = ({modalClose}) => {
  const styles = getStyles();
  const {t} = useTranslation();

  return (
    <Grid size={4} sx={styles.sessionContainer}>
      <Box sx={styles.titleContainer}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleS}
          text={t('OnbaordingHeaderPopUpLblTitleWeb')}
        />
        <CustomLabel
          id="lblSubtitle"
          variant={variants.bodyRegularM}
          text={t('OnbaordingHeaderPopUpLblSubTitleWeb')}
        />
      </Box>

      <Box sx={styles.button}>
        <Button
          variant={ButtonStyle.Secondary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          onClick={modalClose}
          text={t('OnboardingTermsAndConditionsBtnDecline')}
        />
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          onClick={modalClose}
          text={t('OnboardingTermsAndConditionsBtnAccept')}
        />
      </Box>
    </Grid>
  );
};

export {HeaderSessionPopUp};
