import {FC, useState, useEffect, useRef} from 'react';
import {Box, Typography} from '@mui/material';
import Grid from '@mui/material/Grid2';
import OtpInput from 'components/otp-input';
import {useNewTheme} from 'react-core/hooks';
import {getStyles} from 'features/auth/view/otp-verify/style';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {translation} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Button, CustomCheckbox} from 'components';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
interface OtpScreenProps {
  screenName: string;
  topNavigation?: boolean;
  nextScreenPath: string;
}

const DirectDebitPin: FC<OtpScreenProps> = ({nextScreenPath}) => {
  const {t} = translation.useTranslation();
  const [pin, setPin] = useState(['', '', '', '']);
  const [repeatPin, setRepeatPin] = useState(['', '', '', '']);

  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [timeRemaining, setTimeRemaining] = useState<number>(120);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const initialTimeInSeconds = 120;
  const timerInterval = 1000;
  const [checkboxValue, setCheckboxValue] = useState(false);

  const onChange = () => {
    setCheckboxValue(!checkboxValue);
  };
  useEffect(() => {
    setTimeRemaining(initialTimeInSeconds);
  }, [initialTimeInSeconds]);

  // timer logic
  useEffect(() => {
    if (timeRemaining === 0) return;
    intervalRef.current = setInterval(() => {
      setTimeRemaining(prevTime => {
        if (prevTime <= 1) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
          }
          return 0;
        }
        return prevTime - 1;
      });
    }, timerInterval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timeRemaining]);

  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={'Back'}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingDebitCardPinLblTitleWeb')}
        </Typography>
        <Grid sx={styles.pinCodeGrid}>
          <CustomLabel
            id="create"
            variant={variants.bodyRegularM}
            style={styles.pinCodeText}
            text={t('OnboardingCreateCardPinLblCreatePinCodeWeb')}
          />
          <OtpInput
            nextScreenPath={nextScreenPath}
            otp={pin}
            setOtp={setPin}
            pin={true}
            bgWhite></OtpInput>
        </Grid>
        <Grid>
          <CustomLabel
            id="create"
            variant={variants.bodyRegularM}
            style={styles.resetPinCodeText}
            text={t('OnboardingCreateCardPinLblCreatePinCodeWeb')}
          />
          <OtpInput
            nextScreenPath={nextScreenPath}
            otp={repeatPin}
            setOtp={setRepeatPin}
            pin={true}
            bgWhite></OtpInput>
        </Grid>
        <Box sx={styles.checkBoxGrid}>
          <CustomCheckbox
            id="checkbox-cmp"
            errorText={''}
            helperText={''}
            disabled={false}
            onChange={onChange}
            icon={<CheckboxDefaultIcon />}
            checkedIcon={<CheckboxSelectedIcon />}
          />
          <CustomLabel
            id="createpin"
            variant={variants.bodyRegularM}
            style={styles.pinCodeCheckBox}
            text={t('OnboardingCreateCardPinChkTitle')}
          />
        </Box>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('AuthenticationPasscodeBtnConfirm')}
          onClick={() => console.log('Button Clicked')}
        />
      </Box>
    </Box>
  );
};

export default DirectDebitPin;
