import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {useTranslation, useNewTheme} from 'react-core';
import {getStyles} from './styles';
import Chip from 'components/chip-component';
import TextInput from 'components/text-input';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';

const TypeOfTaxIdentificationNumber: FC = () => {
  const {t} = useTranslation();
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [Tin, setTin] = useState(true);
  const [Ssn, setSsn] = useState(false);
  const [Itin, setItin] = useState(false);

  const handleOnBtn = (name: string, value: boolean) => {
    if (name === 'Tin') {
      setTin(value);
      setSsn(false);
      setItin(false);
    } else if (name === 'SSN') {
      setTin(false);
      setSsn(value);
      setItin(false);
    } else {
      setTin(false);
      setSsn(false);
      setItin(value);
    }
  };
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingTaxIdentificationNumberLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingTaxIdentificationNumberLblTitle')}
        />
      </Grid>
      <Grid>
        <CustomLabel
          id={t('OnboardingTaxDeclarationBirthDetailsLblSubtitle')}
          variant={variants.bodyRegularM}
          text={t('OnboardingTaxDeclarationBirthDetailsLblSubtitle')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingTaxDeclarationTaxTypeErrorRequiredTxtNumber')}
          variant={variants.bodyRegularM}
          text={t('OnboardingTaxDeclarationTaxTypeErrorRequiredTxtNumber')}
        />
      </Grid>
      <Grid sx={styles.chipComponents}>
        <Chip
          label={t('OnboardingTaxTypeBtnOption1')}
          isActive={Tin}
          isInverted={!Tin}
          onClick={() => {
            handleOnBtn('Tin', true);
          }}
        />
        <Chip
          label={t('OnboardingTaxTypeBtnOption2')}
          isActive={Ssn}
          isInverted={!Ssn}
          onClick={() => handleOnBtn('SSN', true)}
        />
        <Chip
          label={t('OnboardingTaxTypeBtnOption3')}
          isActive={Itin}
          isInverted={!Itin}
          onClick={() => handleOnBtn('ITIN', true)}
        />
      </Grid>
      <Grid sx={styles.title}>
        {Tin ? (
          <TextInput
            label={t('OnboardingTaxDeclarationTinNumberWeb')}
            customStyle={styles.textInput}
          />
        ) : Ssn ? (
          <TextInput
            label={t('OnboardingTaxDeclarationSSNNumberWeb')}
            customStyle={styles.textInput}
          />
        ) : (
          <TextInput
            label={t('OnboardingTaxDeclarationITINNumberWeb')}
            customStyle={styles.textInput}
          />
        )}
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingSalaryDetailsBtnNext')}
          disabled={false}
        />
      </Grid>
    </Grid>
  );
};

export default TypeOfTaxIdentificationNumber;
