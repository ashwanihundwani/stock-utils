import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Button, Dropdown} from 'components';
import TextInput from 'components/text-input';
import {LinkSize} from 'components/link/types';
import Link from 'components/link';
import {AddCircle} from 'assets/svg/addCircle';
import Divider from '@mui/material/Divider';
import {Delete03Icon} from 'assets/svg/delete-03';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Typography} from '@mui/material';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {useNavigate} from 'react-router-dom';
import {useFormik} from 'formik';
import {
  OnboardingTaxDeclarationTaxResidentInitialValues,
  OnboardingTaxDeclarationTaxResidentSchema,
  countryData,
} from 'features/onboarding-credit-card/schemas/onboarding-taxdeclarationtaxresidents';
// import navigation from 'navigation';

const TaxDecalrationAddCountry: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingTaxDeclarationTaxResidentInitialValues,
    validationSchema: OnboardingTaxDeclarationTaxResidentSchema,
    onSubmit: () => {
      //   if (countryValue === 'Yes') {
      //     navigation.navigate(OnboardingRoutes.TaxType);
      //   } else if (countryValue === 'No') {
      //     navigation.navigate(OnboardingRoutes.TaxIdentificationNumber);
      //   }
      // },
    },
  });

  // const [fields, setFields] = useState([
  //   {
  //     id: 1,
  //     countryOfTax: '',
  //     taxResidentAddress: '',
  //     taxResidentState: '',
  //     phoneNumber: '',
  //     mailInstructions: '',
  //   },
  // ]);

  // const handleOnAdd = () => {
  //   if (fields.length < 3) {
  //     setFields([
  //       ...fields,
  //       {
  //         id: fields.length + 1,
  //         countryOfTax: '',
  //         taxResidentAddress: '',
  //         taxResidentState: '',
  //         phoneNumber: '',
  //         mailInstructions: '',
  //       },
  //     ]);
  //   }
  // };

  const handleOnAdd = () => {
    if (formik.values.countriesData.length < 3) {
      formik.setValues(prevValues => ({
        id: prevValues.id + 1,
        countriesData: [
          ...prevValues.countriesData,
          {
            countryOfTax: '',
            address: '',
            state: '',
            phoneNumber: '',
            mail: '',
            id: prevValues.countriesData.length + 1,
          },
        ],
      }));
    }
  };

  // const handleOnDelete = (id: number) => {
  //   if (fields.length !== 1) {
  //     setFields(fields.filter(field => field.id !== id));
  //   }
  // };

  const handleOnDelete = (id: number) => {
    if (formik.values.countriesData.length !== 1) {
      // formik.values.countriesData = formik.values.countriesData.filter(
      //   field => field.id !== id,
      // );
      formik.setFieldValue(
        'countriesData',
        formik.values.countriesData.filter((_, ind) => ind !== id),
      );
    }
  };

  const handleOnClick = () => {
    navigate('/tax-identification-number');
  };

  const employerName = [
    {
      id: '1',
      value: 'aramco',
      label: 'Aramco',
    },

    {
      id: '2',
      value: 'sabic',
      label: 'Sabic',
    },
  ];

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingTaxIdentificationNumberLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingTaxIdentificationNumberLblTitle')}
        />
      </Grid>
      <Grid>
        <CustomLabel
          id={t('OnboardingDebitCardDetailsTaxDetailsSubTitleWeb')}
          variant={variants.bodyMediumM}
          text={t('OnboardingDebitCardDetailsTaxDetailsSubTitleWeb')}
        />
      </Grid>
      {formik.values.countriesData.map((field, index) => (
        <Grid key={field.id}>
          {/* {formik.setFieldValue(`countriesData[${index}].id`, index)} */}

          <Grid size={12} sx={styles.incomeSourceDropdownGrid}>
            <Dropdown
              id={t('OnboardingTaxDeclarationTaxResidentDdCountry')}
              labelId={t('OnboardingTaxDeclarationTaxResidentDdCountry')}
              placeholder={t('OnboardingTaxDeclarationTaxResidentDdCountry')}
              options={employerName}
              // errorText={t(`${formik.errors.countryOfTax ?? ''}`)}
              errorText={
                (formik.errors.countriesData?.[index] as countryData)
                  ?.countryOfTax
              }
              helperText={''}
              disabled={false}
              customstyle={styles.dropdown}
              labelstyle={styles.labelStyle}
              value={formik.values.countriesData[index].countryOfTax}
              setValue={formik.handleChange(
                `countriesData[${index}].countryOfTax`,
              )}
            />
          </Grid>
          <Grid sx={styles.listGrid}>
            <TextInput
              label={t('OnboardingTaxDeclarationTaxResidentTxtAddress')}
              customStyle={styles.textInput}
              value={formik.values.countriesData[index].address}
              // errorText={formik.errors.countriesData[index]?.address}
              setValue={formik.handleChange(`countriesData[${index}].address`)}
            />
            <TextInput
              label={t('OnboardingTaxDeclarationTaxResidentTxtState')}
              customStyle={styles.textInput}
              // value={field.taxResidentState}
              value={formik.values.countriesData[index].state}
              setValue={formik.handleChange(`countriesData[${index}].state`)}
              // setValue={value => {
              //   const newfields = [...fields];
              //   newfields[index].taxResidentState = value;
              //   setFields(newfields);
              // }}
            />
            <TextInput
              label={t('OnboardingTaxDeclarationTaxResidentTxtPhoneNumber')}
              customStyle={styles.textInput}
              // value={field.phoneNumber}
              value={formik.values.countriesData[index].phoneNumber}
              setValue={formik.handleChange(
                `countriesData[${index}].phoneNumber`,
              )}

              // setValue={value => {
              //   const newfields = [...fields];
              //   newfields[index].phoneNumber = value;
              //   setFields(newfields);
              // }}
            />
            <TextInput
              label={t(
                'OnboardingTaxDeclarationTaxResidentTxtMail handling instructions (optional)',
              )}
              customStyle={styles.textInput}
              // value={field.mailInstructions}
              value={formik.values.countriesData[index].mail}
              setValue={formik.handleChange(`countriesData[${index}].mail`)}
              // setValue={value => {
              //   const newfields = [...fields];
              //   newfields[index].mailInstructions = value;
              //   setFields(newfields);
              // }}
            />
          </Grid>

          {index !== 0 && (
            <Grid>
              <Grid
                sx={styles.deleteCountryIcon}
                onClick={() => handleOnDelete(index)}>
                <Delete03Icon />
                <Typography sx={styles.deleteText}>
                  {t('OnboardingTaxDeclarationTaxResidentLinkDeleteCountryWeb')}
                </Typography>
              </Grid>

              <Divider sx={styles.divider} />
            </Grid>
          )}
        </Grid>
      ))}
      {formik.values.countriesData.length !== 3 && (
        <Grid sx={styles.giftIcon}>
          <AddCircle />
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingTaxDeclarationTaxResidentLinkAddCountry')}
            onClick={handleOnAdd}
          />
        </Grid>
      )}
      {formik.values.countriesData.length === 3 && (
        <HelperText
          type={HelperTextType.HelperText}
          message={`${t('OnboardingTaxDeclarationYouHaveReachedLimitOfCountriesWeb')}`}
        />
      )}
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingSalaryDetailsBtnNext')}
          disabled={false}
          onClick={handleOnClick}
        />
      </Grid>
    </Grid>
  );
};

export default TaxDecalrationAddCountry;
