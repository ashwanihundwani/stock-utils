import {fonts} from 'utils/typography';
import {Theme} from 'react-core/types';
export const getStyles = (theme: Theme.Theme) => {
  return {
    content: {
      height: '100%',
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      overflow: 'auto',
      justifyContent: 'center',
      alignItems: 'center',
      color: theme.colors['content-primary'],
      backgroundColor: theme.colors['background-02'],
    },
    leftPanel: {
      padding: '10px 24px',
    },
    logoutBtn: {
      position: 'absolute',
      bottom: '20px',
      gap: '8px',
      height: '24px',
      fontWeight: '600',
      fontSize: '16px',
      lineHeight: '24px',
    },
    rightPanel: {
      height: '550px',
    },
    modalStyle: {
      width: '448px',
    },
    modaleTitle: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '18px',
      lineHeight: '24px',
      letterSpacing: '0%',
      marginTop: '-30px',
      color: theme.colors['content-primary'],
    },
    modalInfo: {
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      fontSize: '16px',
      lineHeight: '24px',
      letterSpacing: '0%',
    },
    modalButtons: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: '16px',
      marginTop: '20px',
    },
    modalCancelbtn: {
      float: 'inline-start',
      marginLeft: '220px',
    },
    modalLogoutbtn: {
      float: 'right',
      '& .MuiButton-textPrimary': {
        backgroundColor: theme.colors['surface-semantic-error-02'],
        borderColor: theme.colors['border-semantic-error'],
        '&:hover': {
          backgroundColor: theme.colors['surface-semantic-error-02'],
        },
        '&:active': {
          backgroundColor: theme.colors['surface-semantic-error-02'],
          borderColor: theme.colors['border-semantic-error'],
        },
      },
    },
    listItems: {
      color: theme.colors['content-interactive-secondary-enabled'],
      fontFamily: fonts.regular,
      fontWeight: '600',
      fontSize: '15px',
      lineHeight: '20px',
      letterSpacing: '0%',
      paddingTop: '30px',
      '& .MuiListItem-root': {
        padding: '2px 0',
        gap: '5px',
      },
    },
    listItemsStyle: {
      '& .MuiListItemText-primary': {
        color: theme.colors['content-interactive-secondary-enabled'],
        fontFamily: fonts.regular,
        fontWeight: '600',
        fontSize: '15px',
        lineHeight: '20px',
        letterSpacing: '0%',
      },
    },
    inviteFriend: {
      marginTop: '30px',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontFamily: fonts.regular,
      fontWeight: '600',
      fontSize: '15px',
      lineHeight: '24px',
      letterSpacing: '0%',
    },
    primaryText: {
      margin: '15px 0 5px 0',
      color: theme.colors['content-primary'],
      fontFamily: fonts.regular,
      fontWeight: '600',
      fontSize: '22px',
      lineHeight: '28px',
      letterSpacing: '0%',
    },
    secondaryText: {
      color: theme.colors['content-secondary'],
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '14px',
      lineHeight: '20px',
      letterSpacing: '0%',
    },
  };
};
