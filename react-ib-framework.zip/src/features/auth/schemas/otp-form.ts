import * as yup from 'yup';

export const otpFormInitialValue = {
  otp: ['', '', '', ''],
};

const requiredNumber = yup.string().required().matches(/^\d$/);
export const otpFormValidation = yup.object().shape({
  otp: yup.array().of(requiredNumber).required(),
});
