import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const AuthenticationCredentialsCreationUsernameInitialValues = {
  password: '',
  repassword: '',
};

export const AuthenticationgCredentialsCreationUsernameSchema = yup
  .object()
  .shape({
    password: yup
      .string()
      .required(Errors.AuthenticationCreatePasswordTxtErrorrequiredpassword)
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&*@^])(?=.{8,20})/),
    repassword: yup
      .string()
      .required(Errors.AuthenticationCreatePasswordTxtErrorrequiredrepassword)
      .oneOf(
        [yup.ref('password'), ''],
        Errors.AuthenticationCreatePasswordErrorPasswordMismatch,
      ),
  });
