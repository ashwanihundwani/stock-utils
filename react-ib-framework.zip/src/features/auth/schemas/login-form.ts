import * as yup from 'yup';

export const loginInitialValues: {username: string; password: string} = {
  username: '',
  password: '',
};

export const loginValidation = yup.object().shape({
  username: yup.string().required('Invalid Username'),
  password: yup.string().required('Invalid Password'),
});
