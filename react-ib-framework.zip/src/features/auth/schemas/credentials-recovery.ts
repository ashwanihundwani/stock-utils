import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const CredentialsRecoveryInitialState = {
  idOrIqama: '',
  email: '',
  iBan: '',
  debitCard: '',
};

export const CredentialsRecoverySchema = yup.object().shape({
  idOrIqama: yup
    .string()
    .min(10, Errors.AuthenticationCredentialsRecoveryTxtAtleasttendigits)
    .matches(
      /^\d+$/,
      Errors.AuthenticationCredentialsRecoveryTxtOnlydigitsallowed,
    )
    .max(10)
    .required(Errors.AuthenticationCredentialsRecoveryTxtErrorrequiredenterid),
  email: yup
    .string()
    .email()
    .required(Errors.AuthenticationCredentialsRecoveryTxtErrorrequiredemail),
  iBan: yup.lazy(() =>
    yup.string().when('debitCard', {
      is: (value: string) => !value || value.length === 0,
      then: schema =>
        schema.required(
          Errors.AuthenticationCredentialsRecoveryTxtErrorrequirediban,
        ),
      otherwise: schema => schema.notRequired(),
    }),
  ),
  debitCard: yup.lazy(() =>
    yup.string().when('iBan', {
      is: (value: string) => !value || value.length === 0,
      then: schema =>
        schema.required(
          Errors.AuthenticationCredentialsRecoveryTxtErrorrequireddebitcard,
        ),
      otherwise: schema => schema.notRequired(),
    }),
  ),
});
