import React, {useState} from 'react';
import {Box} from '@mui/material';
import AmountInput from 'components/amount-input';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {translation, useNewTheme} from 'react-core';
import {getStyles} from './style';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {getCardType} from 'utils/localStorage';
import {ArrowLeft} from 'assets/svg/arrow-left-02';

const MonthlyDepositScreen: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (cardType === 'credit') {
      navigate(AppPath.MonthlyExpenses);
    } else {
      navigate(AppPath.employmentStatus);
    }
  };

  const [amount, setAmount] = useState('');
  const cardType = getCardType();

  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingMonthlyDepositLblTitle')}
        />
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.bodyRegularM}
          text={
            cardType === 'credit'
              ? t('OnboardingMonthlyDepositLblSubTitle')
              : t('OnboardingMonthlyDepositDebitCardLblSubTitle')
          }
        />

        <AmountInput
          value={amount}
          onChange={(value: string) => setAmount(value)}
          disabled={false}
          currency={''}
        />
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Small}
          type={ButtonType.Text}
          disabled={!amount}
          text={t('OnboardingMonthlyDepositBtnNext')}
          onClick={handleSubmit}
        />
      </Box>
    </Box>
  );
};

export default MonthlyDepositScreen;
