import React, {useState} from 'react';
import {Box} from '@mui/material';
import AmountInput from 'components/amount-input';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {translation, useNewTheme} from 'react-core';
import {getStyles} from './style';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {ArrowLeft} from 'assets/svg/arrow-left-02';

const MonthlyAdditionalIncomeAmount: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');

  const handleSubmit = () => {
    navigate(AppPath.shareTrustedDetails);
  };

  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>

        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingAddtionalIncomeAmountLblTitle')}
        />

        <AmountInput
          value={amount}
          onChange={(value: string) => setAmount(value)}
          disabled={false}
          currency={''}
          helperText={t('OnboardingAddtionalIncomeAmountLblHelperText')}
        />
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Small}
          type={ButtonType.Text}
          disabled={!amount}
          text={t('OnboardingMonthlyDepositBtnNext')}
          onClick={handleSubmit}
        />
      </Box>
    </Box>
  );
};

export {MonthlyAdditionalIncomeAmount};
