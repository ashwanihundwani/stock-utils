// style.ts
import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      position: 'absolute',
      gap: '32px',
      top: '15%',
      padding: '32px',
    },

    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      textAlign: 'left',
      gap: '6px',
      width: '100%',
    },

    backButton: {
      display: 'flex',
      mb: 2,
    },
    backNavGrid: {
      display: 'flex',
      flexDirection: 'column',
    },
    rowStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '8px',
    },
    backLblstyle: {
      width: '36px',
      height: '24px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    title: {
      fontSize: 28,
      fontWeight: 500,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-primary'],
    },

    subTitle: {
      fontSize: 16,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-secondary'],
    },
    list: {
      mt: 2,
      mb: 4,
    },
    dropdown: {
      background: theme.colors['surface-01'],
      width: '393px',
    },
  };
};
