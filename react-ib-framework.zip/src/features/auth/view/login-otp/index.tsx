import {OtpContainer} from 'components';
import {AuthRoutes} from 'constants/path';
import {useNavigate} from 'react-router-dom';
const LoginOtp = () => {
  const navigate = useNavigate();
  return (
    <OtpContainer
      title={'AuthenticationEnterOtpLblTitle'}
      subtitle={'AuthenticationEnterOtpLblSubtitle'}
      resendOtpLabel={'AuthenticationEnterOtpLblTimer'}
      requestOtpLabel={'AuthenticationEnterOtpLblLinkCode'}
      onResendOtp={() => {
        // Logic
      }}
      onSubmitOtp={() => {
        navigate(AuthRoutes.TrustedBrowser);
      }}
    />
  );
};
export default LoginOtp;
