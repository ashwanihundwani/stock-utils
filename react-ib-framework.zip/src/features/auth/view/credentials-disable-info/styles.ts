import {DisableCredentialsInfoStyleProps} from './types';

export const getStyles = (props: DisableCredentialsInfoStyleProps) => {
  const {theme} = props;
  return {
    listContentStyle: {
      color: theme.colors['content-primary'],
      flex: 1,
    },
    contentStyle: {
      paddingTop: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
    },
    infoListContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
    },
    infoItemStyle: {
      display: 'flex',
      flexDirection: 'row',
      minHeight: '56px',
      gap: '16px',
      padding: '12px',
      borderRadius: '8px',
      backgroundColor: theme.colors['surface-02'],
    },
    iconDecoratorStyle: {
      width: '32px',
      height: '32px',
      backgroundColor: theme.colors['surface-01'],
      borderRadius: '8px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
  };
};
