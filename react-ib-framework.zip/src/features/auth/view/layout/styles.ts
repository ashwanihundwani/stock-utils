import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    container: {
      height: '100vh',
      backgroundColor: theme.colors['background-03'],
    },
    meemLoginLogo: {
      height: '462px',
      width: '908px',
    },
    leftSideGrid: {
      backgroundColor: theme.colors['background-03'],
      //   height: '100vh',
      direction: 'column',
      paddingLeft: '16px',
    },
    // imageGrid: {
    //   height: '60vh',
    // },
    qrGrid: {
      width: '157px',
      height: '220px',
    },
    rightSideGrid: {
      height: '100vh',
      borderRadius: '20px 0 0 20px',
      backgroundColor: 'white',
    },
    rightSideContent: {
      height: '90vh',
      display: 'flex',
      // backgroundColor: 'blue',
      alignItems: 'center',
      justifyContent: 'center',
    },
    dynamicContent: {
      width: '330px',
      height: '414px',
    },
    needhelpText: {
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontSize: '14px',
      paddingRight: '4px',
    },
    rightTopGrid: {
      justifyContent: 'space-between',
      paddingTop: '24px',
      paddingLeft: '16px',
    },
    languageSkillIcon: {
      display: 'flex',
    },
    languageBtn: {
      paddingLeft: '8px',
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '600px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    needHelpTextGrid: {
      display: 'flex',
      paddingRight: '24px',
    },
  };
};
