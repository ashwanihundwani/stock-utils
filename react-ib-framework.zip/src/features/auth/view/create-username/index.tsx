import {FC} from 'react';
import {Box} from '@mui/material';
import Label from 'components/label';
import {getStyles} from './styles';
import TextInput from 'components/text-input';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useFormik} from 'formik';
import {
  AuthenticationCredentialsCreationUsernameInitialValues,
  AuthenticationgCredentialsCreationUsernameSchema,
} from '../../../auth/schemas/create-username';
import {
  ListRequirementsCompleted,
  ListRequirementsEnabled,
  ListRequirementsError,
} from 'assets/svg/listRequirements';

import {
  ONEDIGIT,
  ONELOWERCASE,
  ONEUPPERCASE,
  ONESPECIALCHAR,
  MINLENEIGHT,
  MAXLENTWENTY,
} from 'utils/text-input-validation';
import Button from 'components/button';
import {BackArrow} from 'assets/svg/backArrow';
import {useNewTheme, useTranslation} from 'react-core';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
const CreateUserName: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t: translate} = useTranslation();
  const navigate = useNavigate();
  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: AuthenticationCredentialsCreationUsernameInitialValues,
    validationSchema: AuthenticationgCredentialsCreationUsernameSchema,
    onSubmit: () => {
      navigate(AuthRoutes.SetPasswordScreen);
    },
  });

  const renderValidationListItem = (
    validationType: (value: string | undefined) => boolean,
    text: string,
  ) => {
    return (
      <Box id={`vw${text}`} sx={styles.validationBox}>
        {validationType(formik.values.username) ? (
          <ListRequirementsCompleted />
        ) : formik.values.username !== undefined ? (
          <ListRequirementsError />
        ) : (
          <ListRequirementsEnabled />
        )}
        <Label Title={text} sx={styles.validationLabel} />
      </Box>
    );
  };
  return (
    <>
      <Box sx={styles.defaultContainer}>
        <Box sx={styles.usernameBox}>
          <Box sx={styles.backNavigationBox}>
            <BackArrow />
            <Label
              Title={'AuthenticationCreateUserNameBtnBackWeb'}
              sx={styles.backNavigation}
            />
          </Box>
          <Label
            sx={styles.title}
            Title={'AuthenticationCreateUserNameLblTitle'}
          />
          <Label
            sx={styles.subtitle}
            Title={'AuthenticationCreateUserNameLblSubtitle'}
          />
          <TextInput
            label={translate('AuthenticationCreateUserNameTxtUsernameplc')}
            value={formik.values.username}
            autoComplete={'off'}
            autoFocus={true}
            maxLength={20}
            setValue={formik.handleChange('username')}
          />

          <Box id="vwList" sx={{paddingTop: '16px', paddingBottom: '24px'}}>
            {renderValidationListItem(
              ONELOWERCASE,
              'AuthenticationCreateUserNameLblListrequirement1',
            )}
            {renderValidationListItem(
              ONEUPPERCASE,
              'AuthenticationCreateUserNameLblListrequirement2',
            )}
            {renderValidationListItem(
              ONEDIGIT,
              'AuthenticationCreateUserNameLblListrequirement3',
            )}
            {renderValidationListItem(
              ONESPECIALCHAR,
              'AuthenticationCreateUserNameLblListrequirement4',
            )}
            {renderValidationListItem(
              MINLENEIGHT,
              'AuthenticationCreateUserNameLblListrequirement5Web',
            )}
            {renderValidationListItem(
              MAXLENTWENTY,
              'AuthenticationCreateUserNameLblListrequirement6Web',
            )}
          </Box>
          <Box>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              text={translate('AuthenticationCreateUserNameBtnNextWeb')}
              disabled={!(formik.isValid && formik.dirty)}
              onClick={() => formik.handleSubmit()}
            />
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default CreateUserName;
