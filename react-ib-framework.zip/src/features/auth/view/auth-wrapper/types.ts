export type AuthWrapperProps = {
  translateLabel?: string;
  contactLabel?: string;
  contactHightlightLabel?: string;
};
