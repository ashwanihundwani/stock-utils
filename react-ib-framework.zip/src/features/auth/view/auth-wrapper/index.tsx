import {useNewTheme} from 'react-core';
import {getStyles} from './styles';
import {Box, Grid2 as Grid} from '@mui/material';
import {Outlet} from 'react-router-dom';
import {Label} from 'components';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {TranslationIcon} from 'assets/svg/translationIcon';
import {QRIcon} from 'assets/svg/qrIcon';
import {Images} from 'constants/images';
import {MeemIcon} from 'assets/svg/meemIcon';
import {FC} from 'react';
import {AuthWrapperProps} from './types';
import {useTranslation} from 'react-core/translation';
import {variants} from 'components/custom-label/types';

const AuthWrapper: FC<AuthWrapperProps> = props => {
  const {
    translateLabel = 'AuthenticationLoginBtnTranslate',
    contactLabel = 'AuthenticationLoginLblContactUsWeb',
    contactHightlightLabel = 'AuthenticationLoginLblContactUsLinkWeb',
  } = props;
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t: translate} = useTranslation();

  const changeUserLang = () => {
    // Change Lang Logic
  };

  return (
    <Grid container sx={styles.authContainer}>
      <Grid size={11} sx={styles.backgroundGradient} />
      <Grid size={7} sx={styles.loginContainer}>
        <Grid size={1} sx={styles.meemIcon}>
          <MeemIcon />
        </Grid>
        <Grid size={8} sx={styles.backgroundImgContainer}>
          <img
            src={Images.meem_login_logo}
            alt="meem_login_logo"
            style={styles.backgroundImgStyle}
          />
        </Grid>
        <Box sx={styles.qrIcon}>
          <QRIcon />
        </Box>
      </Grid>

      <Grid size={5} sx={styles.outletContainer}>
        {/* Lang Options & Contact Info */}
        <Grid sx={styles.outletHeader}>
          <Box sx={styles.langContainer} onClick={changeUserLang}>
            <TranslationIcon />
            <Label
              text={translate(translateLabel)}
              id={'lang'}
              variant={variants.bodySemiBoldS}
              style={styles.outletTranslateLabel}
            />
          </Box>
          <Box sx={styles.needHelpContainer}>
            <Label
              text={translate(contactLabel)}
              id={'contactlabel'}
              variant={variants.bodyMediumS}
              style={styles.contactUsLabel}
            />
            <Link
              size={LinkSize.Medium}
              linkText={translate(contactHightlightLabel)}
            />
          </Box>
        </Grid>
        <Grid container columns={5} sx={styles.outletContent}>
          <Grid size={3}>
            <Outlet />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default AuthWrapper;
