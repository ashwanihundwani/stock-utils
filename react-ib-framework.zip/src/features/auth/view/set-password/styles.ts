import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    defaultContainer: {
      height: 'fit-content',
      display: 'flex',
      flexDirection: 'column',
      flexWrap: 'wrap',
      gap: '32px',
      width: '100%',
      paddingTop: '20px',
    },
    title: {
      fontFamily: fonts.regular,
      fontSize: '20px',
      fontWeight: '600',
      color: theme.colors['content-primary'],
      paddingBottom: '12px',
    },
    subtitle: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
      width: '330px',
      paddingBottom: '13px',
    },
    validationBox: {
      display: 'flex',
      alignItems: 'center',
      paddingTop: '4px',
      gap: '4px',
    },
    validationLabel: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
    },
    usernameBox: {
      display: 'grid',
    },
    backNavigationBox: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      paddingBottom: '8px',
    },
    backNavigation: {
      fontFamily: fonts.regular,
      fontSize: '16px',
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    passwordField: {
      width: '100%',
      paddingBottom: '9px',
    },
    repeatPasswordField: {
      width: '100%',
      '& .MuiTypography-root.MuiTypography-caption': {
        marginTop: '5px',
        dispaly: 'block',
      },
    },
    loginContainer: {
      backgroundColor: theme.colors['background-03'],
      height: '100vh',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
    },
    rightSideBox: {
      backgroundColor: theme.colors['surface-01'],
      width: '592px',
      height: '100vh',
      justifyContent: 'flex-end',
      borderStartStartRadius: '20px',
      borderEndStartRadius: '20px',
      position: 'fixed',
      right: '0',
    },
    comfirmBtn: {
      width: '124px',
      height: '48px',
      marginTop: '20px',
      '& .MuiButton-text.MuiButton-textPrimary': {
        minWidth: '124px',
      },
    },
  };
};
