import {fonts} from 'utils/typography';
import {Theme} from 'react-core/types';
export const getStyles = (theme: Theme.Theme) => {
  return {
    modal: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      height: 'fit-content',
    },
    container: {
      padding: '20px 40px 20px 40px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: '10px',
    },
    description: {
      fontSize: '14px',
      textAlign: 'left',
      fontFamily: fonts.regular,
    },
    Title: {
      fontSize: '18px',
      fontWeight: 'bold',
      fontFamily: fonts.bold,
      color: 'black',
    },
    Header: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px 20px 0px 40px',
    },
    modalStyle: {
      width: '448px',
    },
    modaleTitle: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '18px',
      lineHeight: '24px',
      letterSpacing: '0%',
      marginTop: '-30px',
      color: theme.colors['content-primary'],
    },
    modalInfo: {
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      fontSize: '16px',
      lineHeight: '24px',
      letterSpacing: '0%',
    },
    modalButtons: {
      display: 'flex',
      gap: '16px',
      flexDirection: 'row',
      marginTop: '15px',
      float: 'right',
    },
    modalLogoutbtn: {
      float: 'right',
    },
    listItems: {
      color: theme.colors['content-interactive-secondary-enabled'],
      fontFamily: fonts.regular,
      fontWeight: '600',
      fontSize: '16px',
      lineHeight: '24px',
      letterSpacing: '0%',
      '& .MuiListItem-root': {
        padding: '5px 0',
        gap: '8px',
      },
    },
    inviteFriend: {
      marginTop: '40px',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontFamily: fonts.regular,
      fontWeight: '600',
      fontSize: '16px',
      lineHeight: '24px',
      letterSpacing: '0%',
    },
    primaryText: {
      margin: '15px 0 10px 0',
      color: theme.colors['content-primary'],
      fontFamily: fonts.regular,
      fontWeight: '600',
      fontSize: '24px',
      lineHeight: '28px',
      letterSpacing: '0%',
    },
    secondaryText: {
      color: theme.colors['content-secondary'],
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '14px',
      lineHeight: '20px',
      letterSpacing: '0%',
    },
  };
};
