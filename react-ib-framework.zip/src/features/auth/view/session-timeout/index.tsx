import {Box, Typography} from '@mui/material';
import {useEffect, useState} from 'react';
import {useNewTheme, useTranslation} from 'react-core';
import {useIdleTimer} from 'react-idle-timer';
import {getStyles} from './styles';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {useDispatch} from 'react-redux';
import {AppSection} from 'constants/appSection';
import {setAppSection} from 'service/app-global';
import Modal from 'components/modal';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
const SessionTimeout = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [timeLeft, setTimeLeft] = useState(180);
  const [popup, setPopup] = useState<boolean>(false);
  const {t: translate} = useTranslation();
  const handleOnIdle = () => {
    setPopup(true);
  };

  const timerId = popup
    ? setInterval(() => {
        setTimeLeft(prevTime => (prevTime > 0 ? prevTime - 1 : 0));
      }, 10000)
    : '';

  const handleOnLogout = () => {
    setPopup(false);
    dispatch(setAppSection(AppSection.AuthSection));
    navigate(AppPath.LoginScreen);
    clearInterval(timerId);
  };
  useEffect(() => {
    if (timeLeft === 0)
      return () => {
        clearInterval(timerId);
      };
  }, [popup, handleOnLogout, timeLeft]);

  const handleOnContinue = () => {
    setPopup(false);
    setTimeLeft(180);
  };
  const useCustomIdleTimer = () => {
    const idleTimer = useIdleTimer({
      timeout: 1000 * 60 * 5,
      onIdle: handleOnIdle,
      debounce: 500,
      events: ['mousemove', 'keydown', 'wheel'],
    });
    return idleTimer;
  };
  useCustomIdleTimer();
  return (
    <Modal open={popup} onClose={() => handleOnContinue()}>
      <Box sx={styles.modalStyle}>
        <Box sx={styles.modaleTitle}>
          <Typography id="modal-modal-title">
            {translate('TimeoutLoginLblBtmtitle')}
          </Typography>
        </Box>
        <Box sx={styles.modalInfo}>
          <Typography id="modal-modal-description" sx={{mt: 2}}>
            {translate('TimeoutLoginLblBtmSubtitleWeb')}
          </Typography>
        </Box>
        <Box sx={styles.modalButtons}>
          <Box>
            <Button
              variant={ButtonStyle.Secondary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              text={translate('TimeoutLoginBtnCancel')}
              inverted={false}
              onClick={() => handleOnContinue()}
            />
          </Box>
          <Box sx={styles.modalLogoutbtn}>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              text={translate('TimeoutLoginBtnLogin')}
              inverted={false}
              onClick={() => handleOnLogout()}
            />
          </Box>
        </Box>
      </Box>
    </Modal>
  );
};
export default SessionTimeout;
