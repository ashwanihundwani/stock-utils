import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
      padding: '32px',
      mr: 4,
      position: 'absolute',
      top: '15%',
      left: '30%',
    },

    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      textAlign: 'left',
      width: '100%',
    },

    backButton: {
      display: 'flex',
      mb: 1,
    },
    title: {
      fontSize: 28,
      fontWeight: 500,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-primary'],
    },

    subTitle: {
      fontSize: 16,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-secondary'],
      mb: 4,
    },
    resendBtn: {
      color: theme.colors['content-interactive-primary-enabled'],
      fontWeight: '600',
      fontFamily: fonts.regular,
      fontSize: '14px',
      lineHeight: '20px',
      letterSpacing: '0%',
      horizontalAlignment: 'center',
      mt: 4,
    },
    pinCodeGrid: {
      paddingTop: '32px',
    },
    resetPinCodeText: {
      paddingBottom: '16px',
      paddingTop: '16px',
    },
    pinCodeText: {
      paddingBottom: '16px',
    },
    checkBoxGrid: {
      paddingTop: '32px',
      paddingBottom: '16px',
      width: '400px',
      display: 'flex',
      alignItems: 'base-line',
    },
    pinCodeCheckBox: {
      color: theme.colors['content-primary'],
    },
  };
};
