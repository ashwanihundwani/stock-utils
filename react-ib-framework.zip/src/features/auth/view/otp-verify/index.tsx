import {FC, useState, useEffect, useRef} from 'react';
import {Box, Typography} from '@mui/material';
import OtpInput from 'components/otp-input';
import {useNewTheme} from 'react-core/hooks';
import {getStyles} from './style';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {translation} from 'react-core';
interface OtpScreenProps {
  screenName: string;
  topNavigation?: boolean;
  nextScreenPath: string;
}

const OtpVerify: FC<OtpScreenProps> = ({nextScreenPath}) => {
  const {t} = translation.useTranslation();
  const [otp, setOtp] = useState(['', '', '', '']);
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [timeRemaining, setTimeRemaining] = useState<number>(120);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const initialTimeInSeconds = 120;
  const timerInterval = 1000;
  useEffect(() => {
    setTimeRemaining(initialTimeInSeconds);
  }, [initialTimeInSeconds]);

  // timer logic
  useEffect(() => {
    if (timeRemaining === 0) return;
    intervalRef.current = setInterval(() => {
      setTimeRemaining(prevTime => {
        if (prevTime <= 1) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
          }
          return 0;
        }
        return prevTime - 1;
      });
    }, timerInterval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timeRemaining]);

  // time format
  const formatTime = (time: number): string => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(
      2,
      '0',
    )}`;
  };
  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={'Back'}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>{t('OtpVerifyCodeTextWeb')}</Typography>
        <Typography sx={styles.subTitle}>
          {t('AuthenticationOtpScreenLblSubtitleWeb')} *******019
        </Typography>

        <OtpInput
          nextScreenPath={nextScreenPath}
          otp={otp}
          setOtp={setOtp}
          bgWhite></OtpInput>
        <Typography sx={styles.subTitle}>
          {t('AuthenticationOtpScreenLblResendWeb')} {formatTime(timeRemaining)}
        </Typography>
        <Link
          size={LinkSize.Large}
          linkText={t('AuthenticationOtpScreenLblResendLinkWeb')}
          type={LinkType.Primary}
        />
      </Box>
    </Box>
  );
};

export default OtpVerify;
