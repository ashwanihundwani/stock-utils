import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import InfoScreen from 'components/info-screen';
import {InfoIconType} from 'components/info-screen/types';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
const TrustedBrowser = () => {
  const navigate = useNavigate();
  const handleSubmit = () => {
    navigate(AuthRoutes.CreateUserNameScreen);
  };
  return (
    <InfoScreen
      title={'AuthenticationTrustedDeviceSecureLblTitleWeb'}
      subtitle={'AuthenticationTrustedDeviceSecureLblSubtitleWeb'}
      iconType={InfoIconType.success}
      primaryBtn={{
        label: 'AuthenticationTrustedDeviceBtnRequestcall',
        type: ButtonType.Text,
        size: ButtonSize.Large,
        variant: ButtonStyle.Primary,
        onClick: () => {
          handleSubmit();
        },
      }}></InfoScreen>
  );
};

export default TrustedBrowser;
