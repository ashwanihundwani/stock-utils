import {Values} from 'constants/labelvalues';
import useLoginPage from '../../hooks/useLoginPage';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  const {langDir}: {langDir: string} = useLoginPage();
  return {
    loginContainer: {
      backgroundColor: theme.colors['background-03'],
      height: '100vh',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
    },
    meemIcon: {
      paddingLeft: document.dir === Values.ltr ? '24px' : '',
      paddingRight: document.dir === Values.rtl ? '24px' : '',
    },
    qrIcon: {
      position: 'fixed',
      bottom: '10px',
      left: document.dir === Values.ltr ? '24px' : '',
      right: langDir === Values.rtl ? '24px' : '',
      zIndex: '1000',
    },
    leftSideBox: {
      display: 'flex',
      justifyContent: 'center',
      paddingLeft: document.dir === Values.ltr ? '200px' : '',
      paddingRight: document.dir === Values.rtl ? '200px' : '',
    },
    meemLoginLogo: {
      width: '908.2px',
      height: '462.82px',
    },
  };
};
