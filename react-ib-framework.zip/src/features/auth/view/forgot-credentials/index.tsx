import {lazy} from 'react';

export const ResetPassword = lazy(() => import('./view/reset-password'));
