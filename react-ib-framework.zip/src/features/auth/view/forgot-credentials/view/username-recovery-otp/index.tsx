import {OtpContainer} from 'components';
import {AuthRoutes} from 'constants/path';
import {useNavigate} from 'react-router-dom';

const UsernameRecoveryOtp = () => {
  const navigate = useNavigate();
  return (
    <OtpContainer
      onResendOtp={() => {}}
      title={'AuthenticationEnterOtpLblTitle'}
      subtitle={'AuthenticationEnterOtpLblSubtitle'}
      resendOtpLabel={'AuthenticationEnterOtpLblTimer'}
      requestOtpLabel={'AuthenticationEnterOtpLblLinkCode'}
      onSubmitOtp={() => {
        navigate(AuthRoutes.UsernameRecoverySuccess);
      }}
    />
  );
};

export default UsernameRecoveryOtp;
