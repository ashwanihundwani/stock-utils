import {ScreenContainer, OptionButton} from 'components';
import {AuthRoutes} from 'constants/path';
import {useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';

const RecoverySelection = () => {
  const [selectedValue, setSelectedValue] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const navigate = useNavigate();

  const options = [
    {
      id: '1',
      name: 'AuthenticationForgotCredentialsBtnRecoverUsernameWeb',
    },
    {
      id: '2',
      name: 'AuthenticationForgotCredentialsBtnResetPasswordWeb',
    },
  ];

  useEffect(() => {
    if (selectedValue !== null) {
      if (options[0].name === selectedValue?.name) {
        navigate(AuthRoutes.UsernameRecovery);
      }
      if (options[1].name === selectedValue?.name) {
        navigate(AuthRoutes.PasswordRecovery);
      }
    }
  }, [selectedValue]);

  return (
    <ScreenContainer
      backLabel="AuthenticationForgotCredentialsLblGoBack"
      title="AuthenticationForgotCredentialsLblTitleWeb">
      <OptionButton
        options={options}
        value={selectedValue}
        onSelected={value => setSelectedValue(value)}
      />
    </ScreenContainer>
  );
};

export default RecoverySelection;
