import {FC} from 'react';
import {TrustedBrowserIcon} from 'assets/svg';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
import {InfoScreen} from 'components';

const ResetPasswordSuccess: FC = () => {
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate(AuthRoutes.AuthWrapper);
  };

  return (
    <InfoScreen
      title="AuthenticationResetPasswordSuccessLblTitle"
      subtitle="AuthenticationResetPasswordSuccessLblSubtitle"
      Icon={<TrustedBrowserIcon />}
      primaryBtn={{
        label: 'AuthenticationResetPasswordSuccessBtnLogin',
        size: ButtonSize.Large,
        variant: ButtonStyle.Primary,
        type: ButtonType.Text,
        onClick: () => handleSubmit(),
      }}
    />
  );
};

export default ResetPasswordSuccess;
