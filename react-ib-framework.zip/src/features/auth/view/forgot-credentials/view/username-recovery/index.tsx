import {AuthRoutes} from 'constants/path';
import {CredentialsRecovery} from 'features/auth/view/components';
import {useNavigate} from 'react-router-dom';

const UsernameRecovery = () => {
  const navigate = useNavigate();
  return (
    <CredentialsRecovery
      title="AuthenticationUsernameRecoveryLblTitleWeb"
      backLabel="AuthenticationUsernameRecoveryLblGoBackWeb"
      subtitle="AuthenticationUsernameRecoveryLblSubtitle"
      onFormSubmit={() => {
        navigate(AuthRoutes.UsernameRecoveryOtp);
      }}
    />
  );
};

export default UsernameRecovery;
