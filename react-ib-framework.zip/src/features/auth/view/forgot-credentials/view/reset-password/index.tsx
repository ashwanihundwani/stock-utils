import {PasswordSetup} from 'features/auth/view/components';

const ResetPassword = () => {
  return (
    <PasswordSetup
      title={'AuthenticationResetPasswordLblTitle'}
      backLabel={'AuthenticationResetPasswordLblBackWeb'}
      btnLabel={'AuthenticationResetPasswordBtnNextWeb'}
    />
  );
};

export default ResetPassword;
