import {FC, useState} from 'react';
import {Box} from '@mui/material';
import {getStyles} from './styles';
import {CallIncoming02} from 'assets/svg';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Label, InfoScreen, Timer} from 'components';
import {variants} from 'components/custom-label/types';
import {useTranslation, useNewTheme} from 'react-core';
import {InfoIconType} from 'components/info-screen/types';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';

const ResetPasswordCallback: FC = () => {
  const navigate = useNavigate();
  const {t: translate} = useTranslation();
  const styles = getStyles();
  const theme = useNewTheme();

  const [initialTime, setInitialTime] = useState<number>(5);
  const [disabled, setdisabled] = useState<boolean>(true);

  const startNewTimer = () => {
    setdisabled(true);
    setInitialTime(5);
    navigate(AuthRoutes.ResetPasswordSuccess);
  };
  const handleTimerComplete = () => {
    setdisabled(false);
  };

  return (
    <InfoScreen
      title="AuthenticationResetPasswordCallbackLblTitle"
      subtitle="AuthenticationResetPasswordCallbackLblSubtitle"
      Icon={<CallIncoming02 color={theme.colors['icon-semantic-success-01']} />}
      iconType={InfoIconType.success}
      primaryBtn={{
        label: 'AuthenticationResetPasswordCallbackBtnRequestCallback',
        size: ButtonSize.Large,
        variant: ButtonStyle.Primary,
        type: ButtonType.Text,
        onClick: () => startNewTimer(),
        disabled,
      }}>
      <Box sx={styles.resetPasswordCallbackTimerContainer}>
        <Label
          text={translate('AuthenticationResetPasswordCallbackLblTimer')}
          id="timerTitle"
          variant={variants.bodyRegularS}
        />
        <Timer
          initialTimeInSeconds={initialTime}
          onTimerComplete={() => handleTimerComplete()}
        />
      </Box>
    </InfoScreen>
  );
};

export default ResetPasswordCallback;
