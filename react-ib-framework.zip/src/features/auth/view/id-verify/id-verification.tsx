import {FC} from 'react';
import Box from '@mui/material/Box';
import {translation, Theme, useNewTheme} from 'react-core';
import TextInput from 'components/text-input';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {getStyles} from './style';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {Typography} from '@mui/material';
import {InputType} from 'components/text-input/types';
import {useFormik} from 'formik';
import {
  OnboardingIdverificationInitialValues,
  OnboardingIdVerificationSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-id-verification';
import {setNationalId} from 'utils/localStorage';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';

const OnboardingIdVerification: FC = () => {
  const theme: Theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingIdverificationInitialValues,
    validationSchema: OnboardingIdVerificationSchema,
    onSubmit: () => {
      const isIqama = String(formik?.values?.nationalIdiqama).startsWith('2');
      setNationalId(isIqama ? 'Expart' : 'Residential');
      navigate(AppPath.IdOtp);
    },
  });

  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={'Back'}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingIdVerificationLblTitle')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingIdVerificationLblSubtitle')}
        </Typography>

        <Box id="boxsection1" sx={styles.section1}>
          <TextInput
            label={t('OnboardingIdVerificationtxtNationalIdIqamaPlc')}
            type={InputType.Text}
            value={formik.values.nationalIdiqama}
            setValue={formik.handleChange('nationalIdiqama')}
            errorText={formik.errors.nationalIdiqama}
            bgWhite
          />
          <TextInput
            label={t('OnboardingIdVerificationtxtPhoneNumberPlc')}
            type={InputType.Number}
            prefix={'+966'}
            startElement={true}
            value={formik.values.phoneNumber}
            setValue={formik.handleChange('phoneNumber')}
            errorText={formik.errors.phoneNumber}
            bgWhite
          />
        </Box>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingMonthlyDepositBtnNext')}
          onClick={formik.handleSubmit}
          disabled={!(formik.isValid && formik.dirty)}
        />
      </Box>
    </Box>
  );
};

export default OnboardingIdVerification;
