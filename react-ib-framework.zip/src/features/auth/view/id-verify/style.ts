import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      position: 'absolute',
      gap: '32px',
      top: '15%',
      left: '30%',
      padding: '32px',
    },

    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      textAlign: 'left',
      width: '100%',
    },

    backButton: {
      display: 'flex',
      mb: 3,
    },

    title: {
      fontSize: 28,
      fontWeight: 500,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-primary'],
    },

    subTitle: {
      fontSize: 16,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-secondary'],
      mb: 4,
    },

    section1: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: '16px',
      mb: 4,
    },

    inputStyle: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '393px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },

    code: {
      fontFamily: fonts.regular,
      fontWeight: 400,
      fontSize: '64px',
      color: theme.colors['content-primary'],
    },
    popupContainer: {
      display: 'flex',
      width: '100%',
      height: 'fit-content',
      borderRadius: '8px',
      padding: '24px',
      gap: '24px',
      flexDirection: 'column',
    },
    titleContainer: {
      width: '100%',
      height: 'fit-content',
      display: 'flex',
      gap: '24px',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    },
    inputOthersStyle: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '12px',

      justifyContent: 'center',

      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        // width: '448px',
        borderRadius: '10px',
        borderColor: theme.colors['border-enabled-02'],
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },
    iconContainer: {
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      display: 'flex',
    },
    circleIcon: {
      borderRadius: '50%',
      backgroundColor: theme.colors['surface-semantic-error-01'],
      height: '48px',
      width: '48px',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'row',
      justifyContent: 'center',
    },
    button: {
      display: 'flex',
      gap: '16px',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'center',
      justifyContent: 'center',
    },
  };
};
