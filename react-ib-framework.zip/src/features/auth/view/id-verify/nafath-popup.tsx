import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, useTranslation} from 'react-core';
import {getStyles} from './style';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Box, IconButton} from '@mui/material';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ModalTypeProps} from 'features/onboarding-cc/view/common/types';
import {AlertCircle} from 'assets/svg';
import {TextInput} from 'components';
import {Copy01} from 'assets/svg/copy01';

const NafathfailPopUp: FC<ModalTypeProps> = ({modalClose}) => {
  const theme = useNewTheme();

  const styles = getStyles(theme);
  const {t} = useTranslation();

  return (
    <Grid size={4} sx={styles.popupContainer}>
      <Box sx={styles.titleContainer}>
        <Box sx={styles.circleIcon}>
          <AlertCircle size="24" />
        </Box>

        <Box
          sx={{
            gap: '8px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}>
          <CustomLabel
            id="idNafathFailedTitle"
            variant={variants.titleS}
            text={t('OnboardingNafathFailLblTitleWeb')}
          />
          <CustomLabel
            id="lblSubtitle"
            variant={variants.bodyRegularM}
            text={t('OnboardingNafathFailLblSubTitleWeb')}
          />
        </Box>
      </Box>
      <Box sx={styles.inputOthersStyle}>
        <TextInput
          label={t('OnbaordingNafathFailTxtTicketNumberWeb')}
          endElement={
            <IconButton>
              <Copy01></Copy01>
            </IconButton>
          }
        />
      </Box>

      <Box sx={styles.button}>
        <Button
          variant={ButtonStyle.Secondary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          onClick={modalClose}
          text={t('OnboardingNafathFailBtnLblWeb')}
        />
      </Box>
    </Grid>
  );
};

export {NafathfailPopUp};
