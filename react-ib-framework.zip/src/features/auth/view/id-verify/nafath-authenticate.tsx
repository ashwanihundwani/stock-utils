import {FC, useState} from 'react';

import {Box, Typography} from '@mui/material';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {translation, useNewTheme} from 'react-core';
import {getStyles} from './style';
import {NafathIcon} from 'assets/svg/nafathIcon';
import {NafathfailPopUp} from './nafath-popup';
import Modal from 'components/modal';

const NafathAuth: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const [nafathFailOpen, setNafathFailOpen] = useState(false);

  const popupOpen = () => {
    setNafathFailOpen(true);
  };
  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={'Back'}
            showIcon
            onClick={popupOpen}
            type={LinkType.Secondary}
          />
        </Box>
        <NafathIcon />
        <Typography sx={styles.title}>
          {t('OnboardingNafathAuthenticateLblTitle')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingNafathAuthenticateLblSubtitle')}
        </Typography>
        <Typography sx={styles.code}>20</Typography>

        <Modal open={nafathFailOpen} onClose={() => setNafathFailOpen(false)}>
          <NafathfailPopUp />
        </Modal>
      </Box>
    </Box>
  );
};

export default NafathAuth;
