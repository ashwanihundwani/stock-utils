export const getStyles = () => {
  return {
    contentStyle: {
      paddingTop: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
    },
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
  };
};
