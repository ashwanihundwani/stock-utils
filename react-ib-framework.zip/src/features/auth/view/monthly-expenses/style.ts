import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    body: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
      padding: '32px',
      justifyContent: 'center',
      minHeight: '440px',
    },

    header: {
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'flex-start',
      gap: '16px',
    },
    backButton: {
      display: 'flex',
      mb: 2,
    },

    content1: {
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'flex-start',
      gap: '8px',
    },

    LblSubtitleStyle: {
      width: '100%',
      textAlign: 'left',
      fontSize: 16,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-secondary'],
    },

    total: {
      display: 'flex',
      alignItems: 'center',
      fontSize: '56px',
      color: theme.colors['content-primary'],
      gap: 1,
    },

    sharedTrustedInputStyles: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '393px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },

    section1: {
      display: 'flex',
      flexDirection: 'row',
      width: '100%',
      alignItems: 'flex-start',
      gap: '16px',
    },

    frame1739333900: {
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'flex-start',
      gap: '16px',
    },

    frame1739333901: {
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'flex-start',
      gap: '16px',
    },

    actions: {
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'flex-start',
      gap: '10px',
    },
  };
};
