import {PasswordSetupStyleProps} from './types';

export const getStyles = (props: PasswordSetupStyleProps) => {
  const {contentDirection, theme} = props;
  return {
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    passwordContainer: {
      display: 'flex',
      flexDirection: contentDirection,
      gap: '1.5rem',
      paddingTop: '24px',
      paddingBottom: '32px',
    },
    rulesContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    iconDecoratorStyle: {
      height: '1rem',
      width: '1rem',
      borderRadius: '999px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: theme.colors['surface-02'],
    },
    inValidIconDecoratorStyle: {
      backgroundColor: theme.colors['surface-semantic-error-02'],
    },
    validIconDecoratorStyle: {
      backgroundColor: theme.colors['surface-semantic-success-02'],
    },
    ruleFieldContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      alignItems: 'center',
    },
  };
};
