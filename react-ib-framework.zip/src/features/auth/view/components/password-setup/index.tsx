import {Box} from '@mui/material';
import {Button, Label, ScreenContainer, TextInput} from 'components';
import {FC} from 'react';
import {getStyles} from './styles';
import {
  checkLowerCase,
  checkMaxLength,
  checkMinLength,
  checkOneDigit,
  checkSpecialChar,
  checkUpperCase,
  Theme,
  translation,
  useNewTheme,
} from 'react-core';
import * as yup from 'yup';
import {useFormik} from 'formik';
import {variants} from 'components/custom-label/types';
import {Cancel01, Tick02} from 'assets/svg';
import {InputType} from 'components/text-input/types';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {PasswordSetupDirection, PasswordSetupProps} from './types';

const PasswordSetup: FC<PasswordSetupProps> = ({
  title,
  backLabel = '',
  btnLabel = '',
  firstInputPlc = 'CommonPasswordSetupTxtNewPassword',
  secondInputPlc = 'CommonPasswordSetupTxtRepeatPassword',
  lowerCaseTitle = 'CommonPasswordSetupLblLowerCase',
  upperCaseTitle = 'CommonPasswordSetupLblUpperCase',
  oneNumberTitle = 'CommonPasswordSetupLblOneNumber',
  oneSpecialTitle = 'CommonPasswordSetupLblOneSpecial',
  minLengthTitle = 'CommonPasswordSetupLblMinLength',
  maxLengthTitle = 'CommonPasswordSetupLblMaxLength',
  passwordNotMatchLabel = 'CommonPasswordSetupTxtPwdMatch',
  contentDirection = PasswordSetupDirection.column,
  onSubmit,
}) => {
  const theme: Theme = useNewTheme();
  const styles = getStyles({contentDirection, theme});
  const {t: translate} = translation.useTranslation();

  const PasswordSetupInitialValues = {
    password: '',
    repassword: '',
  };

  const PasswordSetupSchema = yup.object().shape({
    password: yup
      .string()
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&*@-^])(?=.{8,})/, '')
      .required(),

    repassword: yup
      .string()
      .oneOf([yup.ref('password'), ''], passwordNotMatchLabel)
      .required(),
  });

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: PasswordSetupInitialValues,
    validationSchema: PasswordSetupSchema,
    onSubmit: values => {
      onSubmit?.(values);
    },
  });
  const renderValidationListItem = (
    validationType: (value: string | undefined) => boolean,
    text: string,
  ) => {
    const value = formik.values.password;
    const validField = validationType(value);
    return (
      <Box sx={styles.ruleFieldContainer}>
        <Box
          sx={{
            ...styles.iconDecoratorStyle,
            ...(value && validField && styles.validIconDecoratorStyle),
            ...(value && !validField && styles.inValidIconDecoratorStyle),
          }}>
          {(!value || validField) && (
            <Tick02
              size={'12'}
              color={
                validField
                  ? theme.colors['icon-inverted-primary']
                  : theme.colors['icon-secondary']
              }
            />
          )}
          {value && !validField && (
            <Cancel01
              size={'12'}
              color={theme.colors['icon-inverted-primary']}
            />
          )}
        </Box>
        <Label
          id={translate(text)}
          variant={variants.bodyRegularS}
          text={translate(text)}
        />
      </Box>
    );
  };

  return (
    <ScreenContainer title={title} backLabel={translate(backLabel)}>
      <Box sx={styles.passwordContainer}>
        <Box sx={styles.inputContainer}>
          <TextInput
            label={translate(firstInputPlc)}
            type={InputType.Password}
            value={formik.values.password}
            setValue={formik.handleChange('password')}
          />
          <TextInput
            label={translate(secondInputPlc)}
            type={InputType.Password}
            value={formik.values.repassword}
            setValue={formik.handleChange('repassword')}
            errorText={formik.errors.repassword}
          />
        </Box>
        <Box sx={styles.rulesContainer}>
          {renderValidationListItem(checkLowerCase, lowerCaseTitle)}
          {renderValidationListItem(checkUpperCase, upperCaseTitle)}
          {renderValidationListItem(checkOneDigit, oneNumberTitle)}
          {renderValidationListItem(checkSpecialChar, oneSpecialTitle)}
          {renderValidationListItem(checkMinLength, minLengthTitle)}
          {renderValidationListItem(checkMaxLength, maxLengthTitle)}
        </Box>
      </Box>
      <Button
        text={translate(btnLabel)}
        variant={ButtonStyle.Primary}
        type={ButtonType.Text}
        size={ButtonSize.Large}
        disabled={!(formik.dirty && formik.isValid)}
      />
    </ScreenContainer>
  );
};

export default PasswordSetup;
