export const getStyles = () => {
  return {
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
    tabContainer: {
      marginTop: '16px',
    },
  };
};
