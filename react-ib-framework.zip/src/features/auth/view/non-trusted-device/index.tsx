import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import InfoScreen from 'components/info-screen';
import {InfoIconType} from 'components/info-screen/types';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
const NonTrustedDevice = () => {
  const navigate = useNavigate();
  const handleSubmit = () => {
    navigate(AuthRoutes.LoginScreen);
  };
  return (
    <InfoScreen
      title={'AuthenticationRegisterDeviceLblTitleWeb'}
      subtitle={'AuthenticationRegisterDeviceLblSubtitleWeb'}
      iconType={InfoIconType.error}
      primaryBtn={{
        label: 'AuthenticationRegisterDeviceBtnLoginWeb',
        type: ButtonType.Text,
        size: ButtonSize.Large,
        variant: ButtonStyle.Primary,
        onClick: () => {
          handleSubmit();
        },
      }}></InfoScreen>
  );
};

export default NonTrustedDevice;
