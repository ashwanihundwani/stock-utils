import {fonts} from 'utils/typography';
import {Theme} from 'react-core';
export const getStyles = (theme: Theme) => {
  return {
    welcomeHeading: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '24px',
    },
    label: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '500',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    mainContainer: {
      height: 'fit-content',
      display: 'flex',
      flexDirection: 'column',
      flexWrap: 'wrap',
      gap: '40px',
      width: '100%',
    },
    wecomeContainer: {
      gap: '8px',
      marginTop: '40px',
    },
    meemHeading: {
      display: 'flex',
      gap: '8px',
    },
    loginContainer: {
      gap: '16px',
      display: 'flex',
      flexWrap: 'wrap',
      width: '100%',
    },
    loginSection: {
      gap: '16px',
      height: 'fit-content',
      display: 'flex',
      flexWrap: 'wrap',
    },
    nationalId: {
      gap: '8px',
      height: 'fit-content',
      display: 'flex',
      flexWrap: 'wrap',
      width: '100%',
      '& .MuiTypography-root': {
        marginTop: '2px',
        marginBottom: '2px',
      },
      '& span>svg': {
        display: 'inline !important',
      },
    },
    password: {
      gap: '8px',
      display: 'flex',
      flexWrap: 'wrap',
      width: '100%',
      '& .MuiTypography-root': {
        marginTop: '3px',
      },
      '& span>svg': {
        display: 'inline !important',
      },
    },
    forgotCredentials: {
      display: 'flex',
      flexWrap: 'wrap',
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-primary-enabled'],
      gap: '8px',
    },
    loginBtn: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
    },
    loginFooter: {
      gap: '24px',
      position: 'fixed',
      bottom: '20px',
      display: 'flex',
    },
    joinMeem: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
      width: '100%',
    },
    meemLabel: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '24px',
      paddingLeft: '5px',
      paddingRight: '5px',
      color: theme.colors['content-interactive-primary-enabled'],
    },
  };
};
