import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    loginHeaderBox: {
      display: 'flex',
      justifyContent: 'space-between',
    },
    loginHeader: {
      paddingTop: '24px',
      paddingLeft: '16px',
      paddingRight: '16px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    needHelp: {
      paddingTop: '24px',
      paddingLeft: '16px',
      paddingRight: '16px',
      gap: '10px',
    },
    label: {
      paddingLeft: '5px',
      paddingRight: '5px',
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    meemHeading: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '80vh',
    },
    meemBox: {
      height: '378px',
      width: '330px',
    },
    nationalId: {
      paddingBottom: '12px',
      paddingTop: '32px',
    },
    forgotCredentials: {
      paddingTop: '16px',
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-primary-enabled'],
    },
    loginBtn: {
      paddingTop: '32px',
      paddingBottom: '16px',
    },
    loginFooter: {
      display: 'flex',
      gap: '24px',
      justifyContent: 'center',
      paddingTop: '40px',
    },
    joinMeem: {
      paddingBottom: '24px',
    },
    contactUs: {
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-primary-enabled'],
    },
    meemLabel: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '24px',
      paddingLeft: '5px',
      paddingRight: '5px',
      color: theme.colors['content-interactive-primary-enabled'],
    },
    meemLoginLogo: {
      width: '908.2px',
      height: '462.82px',
    },
    credentialUpdateMain: {
      width: '330px',
      height: '268px',
      position: 'absolute',
      left: '140px',
      top: '190px',
    },
    credentialUpdateIcon: {
      paddingBottom: '10px',
    },
    credentialUpdateHeader: {
      fontSize: '18px',
      width: '330px',
      height: '48px',
      fontWeight: '500',
      fontFamily: fonts.regular,
      lineHeight: '24px',
      color: theme.colors['content-primary'],
    },
    credentialUpdateParagraph: {
      fontSize: '14px',
      fontWeight: '400',
      fontFamily: fonts.regular,
      lineHeight: '20px',
      color: theme.colors['content-secondary'],
    },
    homeBtn: {
      paddingTop: '32px',
      paddingBottom: '16px',
      '& .MuiButtonBase-root.MuiButton-root.MuiButton-text.MuiButton-textPrimary.MuiButton-sizeMedium.MuiButton-textSizeMedium':
        {
          width: '188px',
          height: '48px',
        },
    },
    loginContainer: {
      backgroundColor: theme.colors['background-03'],
      height: '100vh',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
    },
    rightSideBox: {
      backgroundColor: theme.colors['surface-01'],
      width: '592px',
      height: '100vh',
      justifyContent: 'flex-end',
      borderStartStartRadius: '20px',
      borderEndStartRadius: '20px',
      position: 'fixed',
      right: '0',
    },
  };
};
