import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import InfoScreen from 'components/info-screen';
import {InfoIconType} from 'components/info-screen/types';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
import {useDispatch} from 'react-redux';
import {AppSection} from 'constants/appSection';
import {setAppSection} from 'service/app-global';
const TrustedDeviceLinkedUser = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleLogin = () => {
    dispatch(setAppSection(AppSection.AuthSection));
    navigate(AuthRoutes.LoginScreen);
  };
  return (
    <InfoScreen
      title={'AuthenticationLinkedDeviceLblTitleWeb'}
      subtitle={'AuthenticationLinkedDeviceLblSubtitle'}
      iconType={InfoIconType.error}
      primaryBtn={{
        label: 'AuthenticationLinkedDeviceBtnLoginWeb',
        type: ButtonType.Text,
        size: ButtonSize.Large,
        variant: ButtonStyle.Primary,
        onClick: () => {
          handleLogin();
        },
      }}></InfoScreen>
  );
};

export default TrustedDeviceLinkedUser;
