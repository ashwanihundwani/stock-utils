import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    title: {
      fontSize: '12px',
      lineHeight: '16px',
      fontWeight: 600,
      fontFamily: fonts.regular,
      color: theme.colors['content-primary'],
    },
    footerStyle: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: '32px',
    },
    footerChrome: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: '10px',
    },
    modalStyle: {
      width: '448px',
    },
    modaleTitle: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '18px',
      lineHeight: '24px',
      letterSpacing: '0%',
      marginTop: '-30px',
      color: theme.colors['content-primary'],
    },
    modalInfo: {
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      fontSize: '16px',
      lineHeight: '24px',
      letterSpacing: '0%',
    },
    modalButtons: {
      display: 'flex',
      gap: '16px',
      flexDirection: 'row',
      marginTop: '15px',
      float: 'right',
    },
    modalLogoutbtn: {
      '& .MuiButton-textPrimary': {
        backgroundColor: theme.colors['surface-semantic-error-02'],
        borderColor: theme.colors['border-semantic-error'],
        '&:hover': {
          backgroundColor: theme.colors['surface-semantic-error-02'],
        },
        '&:active': {
          backgroundColor: theme.colors['surface-semantic-error-02'],
          borderColor: theme.colors['border-semantic-error'],
        },
      },
    },
  };
};
