import {useState} from 'react';
import InfoScreen from 'components/info-screen';
import {InfoIconType} from 'components/info-screen/types';
import {Box, Typography} from '@mui/material';
import {getStyles} from './styles';
import {useNewTheme, useTranslation} from 'react-core';
import Link from 'components/link';
import {Label} from 'components';
import {LinkSize} from 'components/link/types';
import {variants} from 'components/custom-label/types';
import {ChromeIcon} from 'assets/svg/chromeIcon';
import InfoPopup from 'components/info-popup';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
const TrustedDevice = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t: translate} = useTranslation();
  const [open, setOpen] = useState(false);
  const handleLogout = () => {};
  return (
    <>
      <InfoScreen
        title={'AuthenticationTrustedDeviceNegativeLblTitleWeb'}
        subtitle={'AuthenticationTrustedDeviceNegativeLblSubtitleWeb'}
        iconType={InfoIconType.error}>
        <Box sx={styles.title}>
          <Typography>
            {translate('AuthenticationTrustedDeviceNegativeBrowserLblWeb')}
          </Typography>
        </Box>
        <Box sx={styles.footerStyle}>
          <Box sx={styles.footerChrome}>
            <ChromeIcon />
            <Label
              id={'title-text'}
              text={'Google Chrome 13.0'}
              variant={variants.titleS}
            />
          </Box>
          <Box>
            <Link
              size={LinkSize.Medium}
              linkText={translate(
                'AuthenticationTrustedDeviceNegativeBtnRemoveWeb',
              )}
              onClick={() => setOpen(true)}
            />
          </Box>
        </Box>
      </InfoScreen>
      <InfoPopup open={open} onClose={() => setOpen(false)} icon={true}>
        <Box sx={styles.modalStyle}>
          <Box sx={styles.modaleTitle}>
            <Typography id="modal-modal-title">
              {translate('AuthenticationTrustedDeviceNegativePopupLblTitleWeb')}
            </Typography>
          </Box>
          <Box sx={styles.modalInfo}>
            <Typography id="modal-modal-description" sx={{mt: 2}}>
              {translate(
                'AuthenticationTrustedDeviceNegativePopupLblSubtitleWeb',
              )}
            </Typography>
          </Box>
          <Box sx={styles.modalButtons}>
            <Box>
              <Button
                variant={ButtonStyle.Secondary}
                size={ButtonSize.Large}
                type={ButtonType.Text}
                text={translate(
                  'AuthenticationTrustedDeviceNegativePopupBtnCancelWeb',
                )}
                inverted={false}
                onClick={() => setOpen(false)}
              />
            </Box>
            <Box sx={styles.modalLogoutbtn}>
              <Button
                variant={ButtonStyle.Primary}
                size={ButtonSize.Large}
                type={ButtonType.Text}
                text={translate(
                  'AuthenticationTrustedDeviceNegativePopupBtnRemoveWeb',
                )}
                inverted={false}
                onClick={() => handleLogout()}
              />
            </Box>
          </Box>
        </Box>
      </InfoPopup>
    </>
  );
};

export default TrustedDevice;
