import {Box} from '@mui/material';
import {TranslationIcon} from 'assets/svg/translationIcon';
import Label from 'components/label';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {FC} from 'react';
import useLoginPage from 'features/auth/hooks/useLoginPage';
import {useNewTheme} from 'react-core/hooks';
import {getStyles} from './styles';

const LoginHeader: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {changeUserLang, translate} = useLoginPage();

  return (
    <Box sx={styles.loginHeaderBox}>
      <Box sx={styles.loginHeader} onClick={changeUserLang}>
        <TranslationIcon />
        <Label Title={'login_translate_btn'} sx={styles.label} />
      </Box>
      <Box sx={styles.needHelp}>
        <Label Title={'do_you_need_help'} sx={styles.label}></Label>
        <Link size={LinkSize.Medium} linkText={translate('contact_us')} />
      </Box>
    </Box>
  );
};

export default LoginHeader;
