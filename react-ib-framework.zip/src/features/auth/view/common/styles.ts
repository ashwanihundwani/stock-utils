import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    loginHeaderBox: {
      display: 'flex',
      justifyContent: 'space-between',
    },
    loginHeader: {
      paddingTop: '24px',
      paddingLeft: '16px',
      paddingRight: '16px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    needHelp: {
      paddingTop: '24px',
      paddingLeft: '16px',
      paddingRight: '16px',
      gap: '10px',
    },
    label: {
      paddingLeft: '5px',
      paddingRight: '5px',
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
  };
};
