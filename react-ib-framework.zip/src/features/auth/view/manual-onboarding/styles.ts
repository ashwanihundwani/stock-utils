import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      width: 330,
      height: 244,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: '32px',
    },
    iconWrapper: {
      width: 72,
      height: 72,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      bgcolor: theme.colors['surface-semantic-error-01'],
      borderRadius: '50%',
    },
    icon: {
      color: '#FF3939',
      fontSize: 36,
    },
    textPrimary: {
      fontSize: 18,
      marginTop: 1, // 8px gap
      color: theme.colors['content-primary'],
      fontFamily: fonts.regular,
    },
    textSecondary: {
      fontSize: 14,
      marginTop: 1, // 8px gap
      color: theme.colors['content-secondary'],
      fontFamily: fonts.regular,
    },
    button: {
      marginTop: 2, // 16px gap
    },
    loginBtn: {
      paddingTop: '32px',
      paddingBottom: '16px',
      display: 'flex',
      alignItems: 'flex-start',
    },
    removeTrusted: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
    trustedLabel: {
      color: theme.colors['content-primary'],
      fontFamily: fonts.bold,
      fontSize: '12px',
    },
    trustedBrowser: {
      display: 'flex',
      gap: 1,
    },
    browserLabel: {
      color: theme.colors['content-primary'],
      fontFamily: fonts.bold,
      fontSize: '16px',
    },
    remove: {
      marginLeft: 10,
    },
  };
};
