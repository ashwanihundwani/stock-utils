import {lazy} from 'react';

export const LoginScreen = lazy(() => import('./view/login'));

export const LoginOtpScreen = lazy(() => import('./view/login-otp'));
export const TrustedBrowser = lazy(() => import('./view/trusted-browser'));
export const TrustedDevice = lazy(() => import('./view/trusted-device'));
export const NonTrustedDevice = lazy(() => import('./view/non-trusted-device'));
export const TrustedDeviceLinkedUser = lazy(
  () => import('./view/trusted-device-linked-user'),
);
export const TrustedDeviceLimit = lazy(
  () => import('./view/trusted-device-limit'),
);
export const CreateUserNameSrceen = lazy(
  () => import('./view/create-username'),
);
export const SetPasswordSrceen = lazy(() => import('./view/set-password'));
export const CredentialUpdateSrceen = lazy(
  () => import('./view/credential-updated'),
);
export const SessionTimeout = lazy(() => import('./view/session-timeout'));
// export const MonthlyDepositScreen = lazy(
//   () => import('./view/monthly-deposits'),
// );
export * from './view/forgot-credentials';
export const AuthWrapper = lazy(() => import('./view/auth-wrapper'));
export const CredentialsDisableInfo = lazy(
  () => import('./view/credentials-disable-info'),
);
export const CredentialsDisable = lazy(
  () => import('./view/credentials-disable'),
);
export const CredentialsDisabled = lazy(
  () => import('./view/credentials-disabled'),
);

export const CredentialsDisableOtp = lazy(
  () => import('./view/credentials-disable-otp'),
);
