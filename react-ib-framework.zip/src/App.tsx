import {Suspense} from 'react';
import {Provider} from 'react-redux';
import {Box} from '@mui/material';
import Navigation from './navigation';
import {Loading} from 'components';
import './App.css';
import {usePreventZoom, useWindowSize} from 'constants/hooks';
import {configureStore, persistor} from '../src/redux/store';
import {PersistGate} from 'redux-persist/integration/react';
import {initI18n} from 'react-core';

initI18n();
const {store} = configureStore();

const App = () => {
  usePreventZoom();
  const windowSize = useWindowSize();

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <Box width={windowSize.width} height={windowSize.height}>
          <Suspense fallback={<Loading />}>
            <Navigation />
          </Suspense>
        </Box>
      </PersistGate>
    </Provider>
  );
};

export default App;
