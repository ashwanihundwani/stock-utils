import {ENCRYPTION_KEY} from 'config';
import CryptoJS from 'crypto-js';

const secretKey: any = ENCRYPTION_KEY;

export const appEncryption = {
  encrypt: (originalValue: any) => {
    return CryptoJS.AES.encrypt(
      JSON.stringify(originalValue),
      secretKey,
    ).toString();
  },

  decrypt: (encryptedValue: any) => {
    const bytes = CryptoJS.AES.decrypt(encryptedValue, secretKey);
    return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
  },
};
