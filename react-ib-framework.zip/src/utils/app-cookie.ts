import Cookies from 'js-cookie';

export const AppCookie = {
  setCookie: (cookieName: any, cookieValue: any) => {
    Cookies.set(cookieName, cookieValue, {expires: 1});
  },
  getCookie: (cookieName: any) => {
    return Cookies.get(cookieName);
  },
  clearCookie: (cookieName: any) => {
    return Cookies.remove(cookieName);
  },
};
