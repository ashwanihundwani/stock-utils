import {FC} from 'react';
import {Box} from '@mui/material';
import {Images} from '../constants/images';
import {Image, Label} from 'components';
import {useAppTheme} from 'constants/theme';
import {getStyles} from './styles';

interface HeaderLogoType {}

interface HeaderCancelType {
  onClick: () => void;
}

export const HeaderLogo: FC<HeaderLogoType> = () => {
  const {theme} = useAppTheme();
  const styles = getStyles(theme);
  return (
    <Box sx={styles.headerItems}>
      <Image imageurl={Images.meem} type={'header'} />
    </Box>
  );
};

export const HeaderCancel: FC<HeaderCancelType> = ({onClick}) => {
  const {theme} = useAppTheme();
  const styles = getStyles(theme);

  const handleOnClick = () => {
    onClick();
  };
  return (
    <Box sx={styles.headerItems} onClick={() => handleOnClick()}>
      <Label
        Title={'otp_cancel_label'}
        variant={'md'}
        color={theme.text.heading}
        bold
        onClick={() => handleOnClick()}
      />
    </Box>
  );
};
