import {Theme} from 'constants/theme';
export const getStyles = (_theme: Theme) => {
  return {
    headerItems: {
      padding: '0px 20px',
      display: 'flex',
      justifyContent: 'center',
    },
  };
};
