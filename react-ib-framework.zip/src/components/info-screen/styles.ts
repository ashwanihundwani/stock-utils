import {InfoScreenStyleProps} from './types';

export const getStyles = (props: InfoScreenStyleProps) => {
  const {alignCenter, theme} = props;
  return {
    parentContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
      height: '100%',
      justifyContent: 'center',
    },
    headerContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
      alignItems: alignCenter ? 'center' : 'flex-start',
    },
    headerTitles: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
      alignItems: alignCenter ? 'center' : 'flex-start',
      textAlign: alignCenter ? 'center' : 'flex-start',
    },
    IconIllustratorStyle: {
      borderRadius: '76.82px',
      padding: '10px',
      height: '80px',
      width: '80px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    successIllustrator: {
      backgroundColor: theme.colors['surface-semantic-success-01'],
    },
    errorIllustrator: {
      backgroundColor: theme.colors['surface-semantic-error-01'],
    },
    contentContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
      alignItems: alignCenter ? 'center' : 'flex-start',
    },
    buttonContainer: {
      display: 'flex',
      flexDirection: 'row-reverse',
      gap: '16px',
    },
  };
};
