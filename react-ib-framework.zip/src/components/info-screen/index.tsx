import {FC} from 'react';
import {InfoIconType, InfoScreenProps} from './types';
import {Box} from '@mui/material';
import {Button, Label} from 'components';
import {variants} from 'components/custom-label/types';
import {getStyles} from './styles';
import {Tick02, AlertCircle} from 'assets/svg';
import {useNewTheme, useTranslation} from 'react-core';

const InfoScreen: FC<InfoScreenProps> = props => {
  const {
    title = '',
    subtitle = '',
    children,
    primaryBtn,
    secondaryBtn,
    alignCenter = false,
    Icon,
    iconType,
    illustratorStyle,
  } = props;
  const theme = useNewTheme();
  const styles = getStyles({alignCenter, theme});
  const {t: translate} = useTranslation();

  const getIllustratorStyle = () => {
    if (InfoIconType.success === iconType) {
      return styles.successIllustrator;
    }
    if (InfoIconType.error === iconType) {
      return styles.errorIllustrator;
    }
    return {};
  };

  const getIcon = () => {
    if (Icon) {
      return Icon;
    } else if (iconType === InfoIconType.success) {
      return (
        <Tick02 color={theme.colors['icon-semantic-success-01']} size={'36'} />
      );
    } else if (iconType === InfoIconType.error) {
      return (
        <AlertCircle
          color={theme.colors['icon-semantic-error-01']}
          size={'36'}
        />
      );
    } else {
      return null;
    }
  };

  return (
    <Box sx={styles.parentContainer}>
      <Box sx={styles.headerContainer}>
        <Box
          sx={{
            ...styles.IconIllustratorStyle,
            ...getIllustratorStyle(),
            ...illustratorStyle,
          }}>
          {getIcon()}
        </Box>
        {(title || subtitle) && (
          <Box sx={styles.headerTitles}>
            {title && (
              <Label
                id={'title-text'}
                text={translate(title)}
                variant={variants.titleS}
              />
            )}
            {subtitle && (
              <Label
                id={'subtitle-text'}
                text={translate(subtitle)}
                variant={variants.bodyRegularS}
              />
            )}
          </Box>
        )}
      </Box>
      <Box sx={styles.contentContainer}>
        {children}

        {(primaryBtn || secondaryBtn) && (
          <Box sx={styles.buttonContainer}>
            {primaryBtn && (
              <Button
                variant={primaryBtn.variant}
                type={primaryBtn.type}
                size={primaryBtn.size}
                text={translate(primaryBtn.label)}
                onClick={primaryBtn.onClick}
                disabled={primaryBtn.disabled}
              />
            )}
            {secondaryBtn && (
              <Button
                variant={secondaryBtn.variant}
                type={secondaryBtn.type}
                size={secondaryBtn.size}
                text={translate(secondaryBtn.label)}
                onClick={secondaryBtn.onClick}
                disabled={secondaryBtn.disabled}
              />
            )}
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default InfoScreen;
