import {ScreenContainerStyleProps} from './types';

export const getStyles = (props: ScreenContainerStyleProps) => {
  const {theme} = props;
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
    },
    headerContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      paddingTop: '3rem',
    },
    titeContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    backButton: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      alignItems: 'center',
      cursor: 'pointer',
      width: 'fit-content',
    },
    backLabelStyle: {
      letterSpacing: '0px',
      color: theme.colors['content-interactive-secondary-enabled'],
      cursor: 'pointer',
    },
  };
};
