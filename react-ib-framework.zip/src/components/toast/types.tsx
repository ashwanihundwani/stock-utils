export enum ToastAlginmentType {
  top = 'top',
  bottom = 'bottom',
  right = 'right',
  left = 'left',
  center = 'center',
}

export interface ToastProps {
  vertical?: ToastAlginmentType.top | ToastAlginmentType.bottom;
  horizontal?:
    | ToastAlginmentType.right
    | ToastAlginmentType.left
    | ToastAlginmentType.center;
  message: string;
  startIcon?: React.ReactNode;
  endIcon?: React.ReactNode;
  inverted?: boolean;
  linkText?: string;
}
