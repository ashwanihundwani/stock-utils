import {fonts} from '../../utils/typography';

export const getStyles = () => {
  return {
    modal: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      height: 'fit-content',
    },
    container: {
      padding: '20px 40px 20px 40px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: '10px',
    },
    description: {
      fontSize: '14px',
      textAlign: 'left',
      fontFamily: fonts.regular,
    },
    Title: {
      fontSize: '18px',
      fontWeight: 'bold',
      fontFamily: fonts.bold,
      color: 'black',
    },
    Header: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px 20px 0px 40px',
    },
  };
};
