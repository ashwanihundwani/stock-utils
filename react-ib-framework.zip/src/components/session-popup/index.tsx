import {Box, Dialog, Typography} from '@mui/material';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import {useCallback, useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {useDispatch} from 'react-redux';
import {useIdleTimer} from 'react-idle-timer';
import {authPath} from 'constants/auth/path';
import ButtonList from 'components/button-list';
import {getStyles} from './styles';
import {resetAllStates} from 'service/app-global';
import {Label} from '..';
import {useTranslation} from '../../translations';

const SessionPopup = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {t} = useTranslation();
  const styles = getStyles();
  const [timeLeft, setTimeLeft] = useState(180);
  const [popup, setPopup] = useState<boolean>(false);
  const handleOnIdle = () => {
    setPopup(true);
  };

  const timerId = popup
    ? setInterval(() => {
        setTimeLeft(prevTime => (prevTime > 0 ? prevTime - 1 : 0));
      }, 1000)
    : '';

  const handleOnLogout = useCallback(async () => {
    setPopup(false);
    dispatch(resetAllStates());
    navigate(authPath.Login);
    clearInterval(timerId);
  }, [dispatch, navigate, timerId]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  useEffect(() => {
    return () => {
      clearInterval(timerId);
    };
  }, [popup, handleOnLogout, timerId, timeLeft]);

  const handleOnContinue = () => {
    setPopup(false);
    setTimeLeft(180);
  };

  const popupButtons = [
    {id: 1, label: 'logout_menu', type: 'outlined', onClick: handleOnLogout},
    {
      id: 2,
      label: 'btn_text_continue',
      type: 'filled',
      onClick: handleOnContinue,
    },
  ];
  const useCustomIdleTimer = () => {
    const idleTimer = useIdleTimer({
      timeout: 1000 * 60 * 5,
      onIdle: handleOnIdle,
      debounce: 500,
      events: ['mousemove', 'keydown', 'wheel'],
    });
    return idleTimer;
  };
  useCustomIdleTimer();

  const title = t('session_title').replace(
    /\$\b5\b|\b5\b\$/g,
    formatTime(timeLeft),
  );

  return (
    <Dialog sx={styles.modal} open={popup}>
      <Box sx={styles.Header}>
        <Label Title={'session_expire_warning'} sx={styles.Title} />
        <CloseRoundedIcon onClick={() => handleOnContinue()} />
      </Box>
      <Box sx={styles.container}>
        <Typography sx={styles.description}>{title}</Typography>
        <ButtonList buttons={popupButtons} buttonDirection={'row'} />
      </Box>
    </Dialog>
  );
};
export default SessionPopup;
