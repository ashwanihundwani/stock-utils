import React, {FC} from 'react';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import IconButton from '@mui/material/IconButton';
import {getStyles} from './styles';
import {CancelIcon} from 'assets/svg/cancelIcon';
import {AlertProps, AlertTypes} from './types';
import {
  InfoIcon,
  SuccessIcon,
  WarningIcon,
  ErrorIcon,
} from 'assets/svg/alertIcon';
import {useNewTheme} from 'react-core';

const AlertComponent: FC<AlertProps> = ({label, type}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme, type);

  const [open, setOpen] = React.useState(true);

  const handleOnIcon = () => {
    switch (type) {
      case AlertTypes.Success: {
        return <SuccessIcon />;
      }
      case AlertTypes.Warning: {
        return <WarningIcon />;
      }
      case AlertTypes.Error: {
        return <ErrorIcon />;
      }
      default:
        return <InfoIcon />;
    }
  };
  return (
    <Box>
      {open && (
        <Alert
          icon={handleOnIcon()}
          sx={styles.defaultStyle}
          action={
            <IconButton
              size="small"
              onClick={() => {
                setOpen(false);
              }}>
              <CancelIcon />
            </IconButton>
          }>
          {label}
        </Alert>
      )}
    </Box>
  );
};

export default AlertComponent;
