export enum AlertTypes {
  Success = 'Success',
  Warning = 'Warning',
  Other = 'Other',
  Error = 'Error',
}

export interface AlertProps {
  label: string;
  type?: AlertTypes;
}
