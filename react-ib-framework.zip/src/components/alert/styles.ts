import {fonts} from 'utils/typography';
import {AlertTypes} from './types';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme, type?: AlertTypes) => {
  const handleOnTypes = () => {
    switch (type) {
      case AlertTypes.Success: {
        return {
          backgroundColor: theme.colors['surface-semantic-success-01'],
          color: theme.colors['content-primary'],
        };
      }
      case AlertTypes.Warning: {
        return {
          backgroundColor: theme.colors['surface-semantic-warning-01'],
          color: theme.colors['content-primary'],
        };
      }
      case AlertTypes.Error: {
        return {
          backgroundColor: theme.colors['surface-semantic-error-01'],
          color: theme.colors['content-primary'],
        };
      }
      default:
        return {
          backgroundColor: theme.colors['surface-semantic-info-01'],
          color: theme.colors['content-primary'],
        };
    }
  };
  return {
    defaultStyle: {
      ...handleOnTypes(),
      width: '258px',
      fontFamily: fonts.regular,
    },
  };
};
