import React, {FC, useRef} from 'react';
import {Box, TextField} from '@mui/material';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {OTPInputProps, KeysType, RegularExpression} from './types';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import useOtpPage from 'features/auth/hooks/useOtpPage';
import {InputType} from 'components/text-input/types';
const OtpInput: FC<OTPInputProps> = ({
  length = 4,
  errorText,
  helperText,
  disabled,
  nextScreenPath,
  otp,
  setOtp,
  bgWhite = false,
}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme, bgWhite);

  const {otpForm} = useOtpPage(nextScreenPath);
  const inputs = useRef<HTMLDivElement[]>([]);
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    index: number,
  ) => {
    const {value} = e.target;
    if (value.match(RegularExpression.Expression)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);
      otpForm.setFieldValue('otp', [...newOtp]);
      if (index < length - 1) {
        inputs.current[index + 1].focus();
      }
    }
  };
  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLDivElement>,
    index: number,
  ) => {
    if (e?.key === KeysType.Backspace) {
      const newOtp = [...otp];
      newOtp[index] = '';
      setOtp(newOtp);
      otpForm.setFieldValue('otp', [...newOtp]);
      if (index > 0) {
        inputs.current[index - 1].focus();
      }
    } else if (e?.key === KeysType.ArrowRight && index < length - 1) {
      inputs.current[index + 1].focus();
    } else if (e.key === KeysType.ArrowLeft && index > 0) {
      inputs.current[index - 1].focus();
    }
  };
  return (
    <Box style={styles.defaultBox}>
      {otp?.map((value, index) => (
        <TextField
          key={index}
          type={InputType.Password}
          value={otp[index]}
          sx={styles.defaultInputStyle}
          autoFocus={index === 0}
          variant="filled"
          inputRef={el => (inputs.current[index] = el)}
          onChange={e => handleChange(e, index)}
          onKeyDown={e => handleKeyDown(e, index)}
          disabled={disabled}
          error={Boolean(errorText)}
          slotProps={{
            input: {
              disableUnderline: true,
              maxRows: '1',
            },
          }}
        />
      ))}
      {helperText && (
        <HelperText type={HelperTextType.HelperText} message={helperText} />
      )}
      {errorText && (
        <HelperText type={HelperTextType.ErrorText} message={errorText} />
      )}
    </Box>
  );
};
export default OtpInput;
