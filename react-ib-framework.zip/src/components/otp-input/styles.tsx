import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme, bgWhite: boolean) => {
  return {
    defaultBox: {
      display: 'flex',
      flexDirection: 'row',
      gap: '16px',
      width: '100%',
    },
    defaultInputStyle: {
      width: '100%',
      '& .MuiFilledInput-root': {
        borderRadius: '8px',
        width: 'auto',
        flex: 1,
        height: '64px',
        gap: '8px',
        border: `1px solid transparent`,
        backgroundColor: bgWhite
          ? theme.colors['surface-interactive-primary-inverted-enabled']
          : theme.colors['surface-interactive-secondary-enabled'],
        '&:hover:not(.Mui-disabled)': {
          borderColor: theme.colors['border-focus'],
          borderWidth: '1.5px',
          backgroundColor: bgWhite
            ? theme.colors['surface-interactive-primary-inverted-enabled']
            : theme.colors['surface-interactive-secondary-enabled'],
        },

        '&.Mui-focused': {
          borderColor: theme.colors['surface-interactive-tertiary-active'],
          backgroundColor: bgWhite
            ? theme.colors['surface-interactive-primary-inverted-enabled']
            : theme.colors['surface-interactive-secondary-enabled'],
        },
        '&.MuiFormHelperText-root': {
          marginLeft: '16px',
          color: 'red',
        },
        // errorbox styles

        '&.Mui-error': {
          backgroundColor: theme.colors['surface-semantic-error-01'],
          border: `1px solid ${theme.colors['surface-semantic-error-02']}`,
          '& label': {
            fontSize: '14px',
            fontWeight: 'normal',
            color: theme.colors['content-secondary'],
            transform: 'Titlecase',
            '&.Mui-focused': {
              fontSize: '14px',
              fontWeight: 'normal',
              color: theme.colors['content-secondary'],
            },
          },
        },
      },
      // unfocus label at firs

      // inside label
      '& input': {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        alignContent: 'center',
        fontFamily: fonts.regular,
        fontWeight: '400',
        padding: '15px',
        color: theme.colors['content-primary'],
        height: '24px',
      },
    },
  };
};
