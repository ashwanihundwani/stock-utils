import {FC} from 'react';
import {Box, InputAdornment, TextField} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import {getStyles} from './styles';
import {SearchInputProps} from './types';
import {colors as theme} from 'constants/color';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';

const SearchInput: FC<SearchInputProps> = ({
  placeholder,
  value,
  showIcon,
  handleOnSearch,
  errorText,
  helperText,
  disabled,
}) => {
  const styles = getStyles(theme);

  const handleOnSearchText = (value: string) => {
    handleOnSearch(value);
  };

  return (
    <Box sx={styles.defaultBox}>
      <TextField
        id="search-input"
        data-testid="search-input"
        placeholder={placeholder}
        sx={styles.defaultSearchInput}
        error={Boolean(errorText)}
        value={value}
        disabled={disabled}
        onChange={event => handleOnSearchText(event.target.value)}
        InputProps={{
          startAdornment:
            showIcon && errorText ? (
              <InputAdornment position="start" sx={{marginRight: '8px'}}>
                {
                  <SearchIcon
                    sx={{color: theme['surface-semantic-error-02']}}
                  />
                }
              </InputAdornment>
            ) : (
              <InputAdornment position="start">
                {
                  <SearchIcon
                    sx={{
                      color:
                        value.length >= 1
                          ? theme['content-primary']
                          : theme['content-secondary'],
                    }}
                  />
                }
              </InputAdornment>
            ),
        }}
      />
      {Boolean(helperText) && (
        <HelperText type={HelperTextType.HelperText} message={helperText} />
      )}
      {Boolean(errorText) && (
        <HelperText type={HelperTextType.ErrorText} message={errorText} />
      )}
    </Box>
  );
};

export default SearchInput;
