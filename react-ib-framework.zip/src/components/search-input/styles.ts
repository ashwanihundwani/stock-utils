import {fonts} from 'utils/typography';

export const getStyles = (theme: any) => {
  return {
    defaultBox: {
      '& .MuiTypography-root': {
        marginLeft: '16px',
      },
    },
    defaultSearchInput: {
      // we have given width statically once when the figma designs is given we will change it
      width: '358px',
      '& .MuiOutlinedInput-root': {
        fontFamily: fonts.regular,
        borderRadius: '30px',
        height: '40px',
        paddingLeft: '12px',
        backgroundColor: theme['surface-interactive-secondary-enabled'],
        '& fieldset': {
          borderColor: theme['surface-interactive-secondary-enabled'],
        },
        '&.Mui-disabled fieldset': {
          borderColor: theme['surface-interactive-secondary-enabled'],
        },
        '&:hover:not(.Mui-disabled, .Mui-error) fieldset': {
          borderColor: theme['Accesibility-border-focus'],
          borderWidth: '2px',
        },
        '&.Mui-focused fieldset': {
          borderColor: theme['surface-interactive-secondary-enabled'],
        },

        '&.Mui-error': {
          backgroundColor: theme['surface-semantic-error-01'],
        },

        '& input:-webkit-autofill': {
          WebkitBoxShadow: theme['surface-interactive-secondary-enabled'],
          transition: 'background-color 5000s ease-in-out 0s',
        },
      },
    },
  };
};
