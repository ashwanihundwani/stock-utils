import {appcolors} from 'constants/color';
import {fonts} from 'utils/typography';

export const getStyles = (buttonDirection?: string) => {
  return {
    buttonsList: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: buttonDirection ?? {
        xl: 'row',
        lg: 'row',
        md: 'row',
        sm: 'column',
        xs: 'column',
      },
      width: '100%',
      gap: '10px',
    },
    outlinedButtonDefault: {
      minWidth: '200px',
      textTransform: 'none',
      padding: '10px auto',
      fontFamily: fonts.regular,
      border: '1px solid',
      borderColor: appcolors.light_purple,
      backgroundColor: appcolors.white,
      color: appcolors.light_purple,
      fontSize: '14px',
      '&:hover': {
        borderColor: appcolors.light_purple,
        backgroundColor: appcolors.light_purple,
        color: appcolors.white,
      },
    },
    filledButtonDefault: {
      textTransform: 'none',
      padding: '10px auto',
      fontFamily: fonts.regular,
      border: '1px solid',
      borderColor: appcolors.light_purple,
      backgroundColor: appcolors.light_purple,
      color: appcolors.white,
      fontSize: '14px',
      minWidth: '200px',
      '&:hover': {
        borderColor: appcolors.light_purple,
        backgroundColor: appcolors.light_purple,
        color: appcolors.white,
      },
      '&:disabled': {
        borderColor: appcolors.textgrey,
        backgroundColor: appcolors.textgrey,
        opacity: '0.5',
        color: appcolors.white,
      },
    },
    standardButtonDefault: {
      textTransform: 'none',
      border: 'none',
      fontSize: '14px',
      backgroundColor: appcolors.white,
      fontFamily: fonts.regular,
      color: appcolors.light_purple,
      '&:hover': {
        backgroundColor: appcolors.white,
        color: appcolors.light_purple,
      },
    },
    optionButtonDefault: {
      textTransform: 'none',
      padding: '0px 10px 0px 10px',
      border: '1px solid',
      borderRadius: '50px',
      borderColor: appcolors.light_purple,
      backgroundColor: appcolors.light_purple,
      color: appcolors.white,
      fontSize: '12px',
      '&:hover': {
        borderColor: appcolors.light_purple,
        backgroundColor: appcolors.light_purple,
        color: appcolors.white,
      },
      '&:disabled': {
        borderColor: appcolors.lightgrey,
        backgroundColor: appcolors.light_purple,
        color: appcolors.white,
      },
    },
    option_outline_default: {
      textTransform: 'none',
      padding: '0px 10px 0px 10px',
      border: '1px solid',
      borderRadius: '50px',
      borderColor: appcolors.light_purple,
      backgroundColor: appcolors.white,
      color: appcolors.light_purple,
      fontSize: '12px',
      '&:hover': {
        borderColor: appcolors.light_purple,
        backgroundColor: appcolors.light_purple,
        color: appcolors.white,
      },
      '&:disabled': {
        borderColor: appcolors.lightgrey,
        backgroundColor: appcolors.light_purple,
        color: appcolors.white,
      },
    },
  };
};
