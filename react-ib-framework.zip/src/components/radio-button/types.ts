import {JSX} from 'react';

export interface RadioButtonProps {
  options: {id: number; value: string; label: string}[];
  errorText?: string;
  helperText?: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  id: string;
  icon: JSX.Element;
}
