import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme, error: boolean) => {
  return {
    defaultRadio: {
      width: '24px',
      height: '24px',
      margin: '4px',
      '&.MuiRadio-root': {
        color: theme.colors['surface-interactive-secondary-disabled'],
      },

      '&.Mui-checked': {
        color: error
          ? theme.colors['surface-semantic-error-02']
          : theme.colors['surface-interactive-tertiary-active'],
        backgroundColor: error ? theme.colors['surface-semantic-error-01'] : '',
      },
      '&.Mui-disabled': {
        color: theme.colors['surface-interactive-secondary-disabled'],
      },
      '&:hover': {
        border: error ? 'none' : `2px solid ${theme.colors['border-focus']}`,
        // backgroundColor: error ? theme.colors['surface-semantic-error-01'] : '',
      },
    },
    defaultLabel: {
      '& .MuiFormControlLabel-label': {
        color: theme.colors['content-primary'],
        fontFamily: fonts.regular,
      },
    },
    defaultForm: {
      '& .MuiFormGroup-root': {
        paddingLeft: '4px',
      },
    },
  };
};
