import {appcolors} from 'constants/color';
import {Theme} from 'constants/theme';
import {fonts} from 'utils/typography';
const dir = document.dir;

export const getStyles = (
  theme: Theme,
  value?: string | number,
  placeholder?: string,
  shrink?: boolean,
  InputHelperText?: {type: string; message: string},
  disabled?: boolean,
) => {
  return {
    defaultInputStyle: {
      margin: '13px 0px 5px 0px',
      '& label': {
        margin: value !== '' || shrink ? '3px 10px 0px 10px' : '0px 10px',
        fontSize: '14px',
        fontFamily: value !== '' || placeholder ? fonts.bold : fonts.regular,
        fontWeight: (value !== '' || placeholder) && 'bold',
        color: value !== '' ? appcolors.label : appcolors.unfocused_label,
        transform: 'Titlecase',
        '&.Mui-focused': {
          margin: '3px 10px 0px 10px',
          fontSize: '14px',
          fontWeight: 'bold',
          fontFamily: fonts.bold,
          color: appcolors.focused_label,
        },
      },
      '& input': {
        opacity: '100%',
        fontSize: '14px',
        fontFamily: fonts.regular,
        color: !disabled && appcolors.black,
        margin: '0px 10px',
        height: '30px',
      },
      '.MuiInputAdornment-root': {
        margin: '0px 10px 0px 10px',
      },
      '.css-953pxc-MuiInputBase-root-MuiInput-root:hover:not(.Mui-disabled, .Mui-error):before':
        {
          borderBottom: '1px solid',
          borderBottomColor: appcolors.label,
          opacity: '100%',
        },
      '& .MuiInput-underline:before': {
        borderBottom: '1px solid',
        borderBottomColor: appcolors.unfocused_label,
        opacity: '100%',
      },
      '& .MuiInput-underline:after': {
        borderBottom: '1px solid',
        borderBottomColor: appcolors.focused_label,
        opacity: '100%',
      },
      '& textarea': {
        opacity: '100%',
        fontSize: '16px',
        fontFamily: fonts.regular,
        color: !disabled ? 'black' : appcolors.black,
        margin: '0px 10px 5px 10px',
      },
      '.MuiFormHelperText-root': {
        fontFamily: fonts.regular,
        color: () => {
          if (InputHelperText && InputHelperText.type === 'invalid')
            return 'red';
          if (InputHelperText && InputHelperText.type === 'valid')
            return 'green';
        },
      },
      // Hide Number Spinner if type = numeric
      '& input[type=number]': {
        WebkitAppearance: 'textfield',
      },
      '& input[type=number]::-webkit-outer-spin-button': {
        WebkitAppearance: 'none',
        margin: 0,
      },
      '& input[type=number]::-webkit-inner-spin-button': {
        WebkitAppearance: 'none',
        margin: 0,
      },
    },
    bottomComponent: {
      padding: '5px 10px',
    },
    labelRTLStyle: {
      '& label': {
        transformOrigin: 'right',
        left: 'unset',
        right: '1.5rem',
      },
    },
    hoverInputBox: {
      width: '100%',
      margin: '0px',
      backgroundColor: theme.inputBox.background,
      borderRadius: '8px',
      boxShadow: `0px 8px 10px ${appcolors.grey}`,
      '& input': {
        height: 'auto',
      },
      '& label': {
        display: value && 'none',
        '&.Mui-focused': {
          display: 'none',
        },
        right: dir === 'rtl' && '1.5rem',
      },
      '& .MuiOutlinedInput-root': {
        '& fieldset': {
          borderColor: 'transparent',
        },
        '&:hover fieldset': {
          borderColor: 'transparent',
        },
        '&.Mui-focused fieldset': {
          borderColor: 'transparent',
        },
      },
    },
  };
};
