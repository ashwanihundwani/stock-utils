import React, {
  FC,
  ChangeEvent,
  useEffect,
  useState,
  useCallback,
  useMemo,
} from 'react';
import {Box, TextField, InputAdornment, SxProps} from '@mui/material';
import {useTranslation} from 'translations';
import {NumericFormat} from 'react-number-format';
// import { Theme } from '@material-ui/core';
import {getStyles} from './styles';
import {useAppTheme} from 'constants/theme';

interface InputBoxProps {
  label?: any;
  value?: string | number;
  setValue?: (value: any) => void;
  placeholder?: any;
  variant?: any;
  disabled?: boolean;
  inputStyle?: SxProps<any>;
  startElement?: React.ReactNode;
  endElement?: React.ReactNode;
  multiline?: boolean;
  type?: 'number' | 'text' | 'password' | 'numeric';
  helperText?: {
    type: string;
    message: string;
  };
  bottomComponent?: React.ReactNode;
  maxLength?: number;
  minLength?: number;
  allCaps?: boolean;
  InputBoxStyle?: string;
  shrink?: boolean;
  onBlur?: () => void;
}

const InputBox: FC<InputBoxProps> = ({
  label,
  value,
  setValue,
  placeholder,
  variant,
  disabled,
  inputStyle,
  startElement,
  endElement,
  multiline,
  type,
  helperText,
  bottomComponent,
  maxLength,
  allCaps,
  InputBoxStyle,
  shrink,
  onBlur,
}) => {
  const dir = document.dir;
  const {theme} = useAppTheme();
  const {t: translate} = useTranslation();
  const [inputHelperText, setInputHelperText] = useState<
    {type: string; message: string} | undefined
  >(helperText);

  const handleOnCheckVariant = useCallback((variant: string) => {
    if (variant === 'standard' || variant === 'filled')
      return {disableUnderline: false};
  }, []);

  useEffect(() => {
    setInputHelperText(helperText);
  }, [helperText]);

  const styles = useMemo(
    () =>
      getStyles(theme, value, placeholder, shrink, inputHelperText, disabled),
    [inputHelperText, disabled, placeholder, shrink, value],
  );

  const handleInputChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      let tempValue = event.target.value;
      if (type === 'number') {
        setValue !== undefined &&
          setValue(
            tempValue === '' ? null : Number(tempValue.replace(',', '')),
          );
      } else {
        if (allCaps) tempValue = tempValue.toLocaleUpperCase();
        setValue !== undefined &&
          setValue(
            maxLength !== undefined && tempValue.length > maxLength
              ? value
              : tempValue,
          );
      }
    },
    [allCaps, maxLength, setValue, type, value],
  );

  const handleOnFocus = useCallback((e: any) => {
    e.preventDefault();

    e.target.addEventListener(
      'wheel',
      (e: any) => {
        e.preventDefault();
      },
      {passive: false},
    );
  }, []);

  return (
    <Box width={'100%'} height={'auto'}>
      {(type === undefined || type === 'text') && (
        <TextField
          value={value}
          onChange={handleInputChange}
          label={translate(label)}
          placeholder={translate(placeholder)}
          variant={variant || 'standard'}
          fullWidth
          multiline={multiline}
          error={inputHelperText && inputHelperText.type === 'invalid'}
          helperText={inputHelperText?.message}
          sx={[
            {...styles.defaultInputStyle},
            dir === 'rtl' && {...(styles.labelRTLStyle as object)},
            InputBoxStyle === '3dHoverInput' && {...styles.hoverInputBox},
            {...(inputStyle as object)},
          ]}
          InputLabelProps={{
            shrink,
          }}
          InputProps={{
            ...handleOnCheckVariant(variant || 'standard'),
            spellCheck: 'false',
            autoComplete: 'off',
            autoCapitalize: 'true',
            readOnly: disabled,
            startAdornment: startElement && (
              <InputAdornment position="start">{startElement}</InputAdornment>
            ),
            endAdornment: endElement && (
              <InputAdornment position="end">{endElement}</InputAdornment>
            ),
          }}
        />
      )}

      {type === 'password' && (
        <TextField
          value={value}
          onChange={handleInputChange}
          label={translate(label)}
          placeholder={translate(placeholder)}
          variant={variant || 'standard'}
          fullWidth
          type="password"
          multiline={multiline}
          error={inputHelperText && inputHelperText.type === 'invalid'}
          helperText={inputHelperText?.message}
          sx={[
            {...styles.defaultInputStyle},
            dir === 'rtl' && {...(styles.labelRTLStyle as object)},
            InputBoxStyle === '3dHoverInput' && {...styles.hoverInputBox},
            {...(inputStyle as object)},
          ]}
          InputLabelProps={{
            shrink,
          }}
          InputProps={{
            ...handleOnCheckVariant(variant || 'standard'),
            spellCheck: 'false',
            autoComplete: 'off',
            readOnly: disabled,
            startAdornment: startElement && (
              <InputAdornment position="start">{startElement}</InputAdornment>
            ),
            endAdornment: endElement && (
              <InputAdornment position="end">{endElement}</InputAdornment>
            ),
          }}
        />
      )}

      {type === 'numeric' && (
        <TextField
          value={value}
          onChange={handleInputChange}
          label={translate(label)}
          placeholder={translate(placeholder)}
          variant={variant || 'standard'}
          fullWidth
          type="number"
          multiline={multiline}
          onFocus={e => handleOnFocus(e)}
          onBlur={onBlur}
          error={inputHelperText && inputHelperText.type === 'invalid'}
          helperText={inputHelperText?.message}
          sx={[
            {...styles.defaultInputStyle},
            dir === 'rtl' && {...(styles.labelRTLStyle as object)},
            InputBoxStyle === '3dHoverInput' && {...styles.hoverInputBox},
            {...(inputStyle as object)},
          ]}
          InputLabelProps={{
            shrink,
          }}
          InputProps={{
            ...handleOnCheckVariant(variant || 'standard'),
            spellCheck: 'false',
            autoComplete: 'off',
            readOnly: disabled,
            startAdornment: startElement && (
              <InputAdornment position="start">{startElement}</InputAdornment>
            ),
            endAdornment: endElement && (
              <InputAdornment position="end">{endElement}</InputAdornment>
            ),
          }}
        />
      )}

      {type === 'number' && (
        <NumericFormat
          customInput={TextField}
          thousandSeparator
          value={value}
          onChange={handleInputChange}
          label={translate(label)}
          placeholder={translate(placeholder)}
          variant={variant || 'standard'}
          fullWidth
          error={inputHelperText && inputHelperText.type === 'invalid'}
          helperText={inputHelperText?.message}
          sx={[
            {...styles.defaultInputStyle},
            dir === 'rtl' && {...(styles.labelRTLStyle as object)},
            InputBoxStyle === '3dHoverInput' && {...styles.hoverInputBox},
            {...(inputStyle as object)},
          ]}
          InputLabelProps={{
            shrink,
          }}
          InputProps={{
            ...handleOnCheckVariant(variant),
            spellCheck: 'false',
            autoComplete: 'off',
            readOnly: disabled,
            startAdornment: startElement && (
              <InputAdornment position="start">{startElement}</InputAdornment>
            ),
            endAdornment: endElement && (
              <InputAdornment position="end">{endElement}</InputAdornment>
            ),
          }}
        />
      )}

      {bottomComponent && (
        <Box sx={styles.bottomComponent}>{bottomComponent}</Box>
      )}
    </Box>
  );
};

export default InputBox;
