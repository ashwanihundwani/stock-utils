import React, {useState} from 'react';
import {Box} from '@mui/system';
import {Typography} from '@mui/material';
import {Button} from 'components';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {CancelIcon} from 'assets/svg/cancelIcon';
import IconStar from 'assets/svg/icon-star';
import {useNewTheme} from 'react-core';
import {RatingCardProps} from './types';
import {getStarColor, getStyles} from './styles';

const RatingCard: React.FC<RatingCardProps> = ({
  title,
  question,
  ratingRange = [1, 2, 3, 4, 5],
  selectedRating: externalRating,
  onRatingSelect,
  onClose,
  cancelText = 'Cancel',
  submitText = 'Submit',
}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);

  const [internalRating, setInternalRating] = useState<number>(
    externalRating ?? 0,
  );
  const selectedRating = externalRating ?? internalRating;

  const handleStarClick = (rating: number) => {
    if (!externalRating) setInternalRating(rating);
    onRatingSelect?.(rating);
  };

  return (
    <Box sx={styles.card}>
      <Box sx={styles.header}>
        <Box sx={styles.headerSection}>
          <Typography sx={styles.heading}>{title}</Typography>

          <Button
            variant={ButtonStyle.Ghost}
            size={ButtonSize.Large}
            type={ButtonType.Icon}
            rightIcon={<CancelIcon />}
            disabled={false}
            onClick={onClose}
          />
        </Box>

        <Typography sx={styles.question}>{question}</Typography>
      </Box>

      <Box sx={styles.starsWrapper}>
        {ratingRange.map(num => (
          <Box key={num} onClick={() => handleStarClick(num)}>
            <IconStar
              size="36"
              color={getStarColor(theme, num, selectedRating)}
            />
            <Typography sx={styles.starNumber}>{num}</Typography>
          </Box>
        ))}
      </Box>

      <Box sx={styles.buttonsWrapper}>
        <Button
          variant={ButtonStyle.Secondary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={cancelText}
          disabled={false}
          onClick={onClose}
        />
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={submitText}
          disabled={false}
        />
      </Box>
    </Box>
  );
};
export default RatingCard;
