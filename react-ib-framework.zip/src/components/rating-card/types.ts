export interface RatingCardProps {
  title?: string;
  question?: string;
  ratingRange?: number[];
  selectedRating?: number;
  onRatingSelect?: (rating: number) => void;
  onClose?: () => void;
  cancelText?: string;
  submitText?: string;
}
