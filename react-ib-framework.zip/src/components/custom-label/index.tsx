import {FC} from 'react';
import {getStyles} from './styles';
import {LabelProperties} from './types';
import {Typography} from '@mui/material';
import {useNewTheme} from 'react-core';

const CustomLabel: FC<LabelProperties> = (properties: LabelProperties) => {
  const {id, variant = 'bodyRegularM', text, style} = properties;
  const theme = useNewTheme();
  const styles = getStyles(theme);

  return (
    <Typography key={id} style={{...styles[variant], ...style}}>
      {text}
    </Typography>
  );
};

export default CustomLabel;
