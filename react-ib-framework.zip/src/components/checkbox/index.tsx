import {FC} from 'react';
import {Box} from '@mui/material';
import {CheckboxProps} from './types';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
// import {colors as theme} from 'constants/color';
import {getStyles} from './styles';
import {
  CheckboxErrorIcon,
  CheckboxErrorSelectedIcon,
} from '../../assets/svg/checkbox';
import {useNewTheme} from 'react-core';

const CustomCheckbox: FC<CheckboxProps> = ({
  errorText,
  helperText,
  onChange,
  disabled,
  id,
  icon,
  checkedIcon,
  label,
}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme, Boolean(errorText));
  const handleChange = (value: string) => {
    onChange(value);
  };
  return (
    <FormGroup>
      <FormControlLabel
        sx={styles.defaultLabel}
        control={
          <Checkbox
            id={id}
            data-testid={id}
            onChange={event => handleChange(event.target.value)}
            sx={styles.defaultCheckbox}
            icon={errorText ? <CheckboxErrorIcon /> : icon}
            checkedIcon={
              errorText ? <CheckboxErrorSelectedIcon /> : checkedIcon
            }
          />
        }
        label={label}
        disabled={disabled}
      />
      <Box sx={styles.errorMessage}>
        {Boolean(helperText) && (
          <HelperText type={HelperTextType.HelperText} message={helperText} />
        )}
        {Boolean(errorText) && (
          <HelperText type={HelperTextType.ErrorText} message={errorText} />
        )}
      </Box>
    </FormGroup>
  );
};

export default CustomCheckbox;
