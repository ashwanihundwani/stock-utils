import {ListStyleProperties} from './types';
export const getStyles = (properties: ListStyleProperties) => {
  const {
    isFirstItem,
    isLastItem,
    theme,
    inverted,
    isTitleContainer,
    isDisabled,
  } = properties;
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      borderTopRightRadius: '0.5rem',
      borderTopLeftRadius: '0.5rem',
      borderBottomLeftRadius: '0.5rem',
      borderBottomRightRadius: '0.5rem',
    },
    listContainer: {
      minHeight: '3.5rem',
      display: 'flex',
      gap: '1rem',
      padding: '0.75rem',
      alignItems: 'center',
      '&:hover': {
        backgroundColor: inverted
          ? theme.colors['surface-interactive-secondary-inverted-active']
          : theme.colors['surface-interactive-secondary-active'],
      },
      bgcolor: inverted
        ? theme.colors['surface-inverted-02']
        : theme.colors['surface-02'],
      '&:active': {
        backgroundColor: inverted
          ? theme.colors['surface-interactive-secondary-inverted-active']
          : theme.colors['surface-interactive-secondary-active'],
      },
    },
    compactContainer: {
      borderTopRightRadius: isTitleContainer
        ? 'none'
        : isFirstItem
          ? '0.5rem'
          : 'none',
      borderTopLeftRadius: isTitleContainer
        ? 'none'
        : isFirstItem
          ? '0.5rem'
          : 'none',
      borderBottomLeftRadius: isLastItem ? '0.5rem' : 'none',
      borderBottomRightRadius: isLastItem ? '0.5rem' : 'none',
      borderBottom: isLastItem ? 'none' : '0.0625rem solid',
      borderBottomColor: inverted
        ? theme.colors['surface-overlay-01']
        : theme.colors['border-enabled-01'],
      bgcolor: inverted
        ? theme.colors['surface-inverted-02']
        : theme.colors['surface-02'],
    },
    spacedContainer: {
      borderRadius: '0.5rem',
    },
    spacedGap: {
      gap: '0.5rem',
    },
    label: {
      color: isDisabled
        ? theme.colors['content-disabled']
        : inverted
          ? theme.colors['content-inverted-primary']
          : theme.colors['content-primary'],
    },
    contentContainer: {
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
    },
    titleContainer: {
      display: 'flex',
      justifyContent: 'left',
      alignItems: 'center',
      gap: '0.25rem',
    },
    actionContainer: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
    },
    listTitleContainer: {
      padding: '1rem',
      gap: '0.5rem',
      minHeight: '3.5rem',
      borderTopLeftRadius: '0.5rem',
      borderTopRightRadius: '0.5rem',
      bgcolor: inverted
        ? theme.colors['surface-inverted-02']
        : theme.colors['surface-02'],
    },
    listTitlelabel: {
      color: inverted
        ? theme.colors['content-inverted-primary']
        : theme.colors['content-primary'],
    },
    iconContainer: {
      display: 'flex',
      alignItems: 'left',
    },
  };
};
