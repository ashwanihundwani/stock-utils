import {SxProps} from '@mui/system';
import React from 'react';
import {Theme} from 'react-core';

export enum ListVariants {
  compact = 'compact',
  spaced = 'spaced',
}

export interface ListStyleProperties {
  inverted?: boolean;
  theme: Theme;
  variant?: ListVariants;
  isLastItem?: boolean;
  isFirstItem?: boolean;
  isTitleContainer?: boolean;
  isDisabled?: boolean;
}

export interface ListItemProps {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  actionContent?: React.ReactNode;
  additionalText?: string;
  variant?: ListVariants;
  isLastItem?: boolean;
  isFirstItem?: boolean;
  inverted?: boolean;
  isTitleContainer?: boolean;
  isDisabled?: boolean;
  onClick: () => void;
  customStyle?: SxProps<Theme>;
}
export interface ListProps {
  listTitle?: string;
  listDescription?: string;
  items: ListItemProps[];
  variant?: ListVariants;
  inverted?: boolean;
  disabled?: boolean;
  customStyle?: SxProps<Theme>;
}
