import React from 'react';
import {Box, Theme} from '@mui/material';
import {Label} from 'components';
import {variants} from 'components/custom-label/types';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {ListItemProps, ListProps, ListVariants} from './types';
import {SxProps} from '@mui/system';

const ListItem: React.FC<ListItemProps> = ({
  title,
  description,
  icon,
  actionContent,
  additionalText,
  isLastItem = false,
  isFirstItem = false,
  inverted = false,
  variant = ListVariants.compact,
  isTitleContainer = false,
  isDisabled = false,
  onClick,
  customStyle,
}) => {
  const theme = useNewTheme();
  const styles = getStyles({
    isLastItem,
    isFirstItem,
    theme,
    variant,
    inverted,
    isTitleContainer,
    isDisabled,
  });

  const getBoxstyle = (): SxProps<Theme> => {
    if (customStyle !== undefined) {
      return [
        {...styles.listContainer},
        {...styles[`${variant}Container`]},
        customStyle,
      ] as SxProps<Theme>;
    } else {
      return [
        {...styles.listContainer},
        {...styles[`${variant}Container`]},
      ] as SxProps<Theme>;
    }
  };
  return (
    <Box
      tabIndex={0}
      sx={getBoxstyle()}
      onClick={() => {
        if (isDisabled) return;
        onClick();
      }}>
      {icon && <Box sx={styles.iconContainer}>{icon}</Box>}
      <Box sx={styles.contentContainer}>
        <Box sx={styles.titleContainer}>
          <Label
            text={title}
            id="subtitle"
            variant={variants.bodyMediumM}
            style={styles.label}
          />
        </Box>
        {description && (
          <Label
            text={description}
            id="subtitle"
            variant={variants.bodyRegularS}
            style={styles.label}
          />
        )}
      </Box>
      <Box sx={styles.actionContainer}>
        {actionContent && <Box>{actionContent}</Box>}
        {additionalText && (
          <Label
            text={additionalText}
            id="subtitle"
            variant={variants.bodyRegularM}
            style={styles.label}
          />
        )}
      </Box>
    </Box>
  );
};

const CustomList: React.FC<ListProps> = ({
  listTitle,
  listDescription,
  items,
  variant = ListVariants.compact,
  inverted = false,
  disabled = false,
  customStyle,
}) => {
  const isTitlecontainer = Boolean(listTitle);
  const theme = useNewTheme();
  const styles = getStyles({theme, inverted});
  return (
    <Box
      sx={[
        styles.container,
        variant === ListVariants.spaced && styles.spacedGap,
      ]}>
      {listTitle && (
        <Box sx={styles.listTitleContainer}>
          {/* List Title and Description */}
          <Label
            text={listTitle}
            id="subtitle"
            variant={variants.titleS}
            style={styles.listTitlelabel}
          />
          {listDescription && (
            <Label
              text={listDescription}
              id="subtitle"
              variant={variants.bodyRegularS}
              style={styles.listTitlelabel}
            />
          )}
        </Box>
      )}

      {/* List Items */}
      {items.map((item, index) => (
        <ListItem
          key={index}
          {...item}
          variant={variant}
          isLastItem={index === items.length - 1}
          isFirstItem={index === 0}
          inverted={inverted}
          isTitleContainer={isTitlecontainer}
          isDisabled={disabled}
          customStyle={customStyle}
        />
      ))}
    </Box>
  );
};
export default CustomList;
