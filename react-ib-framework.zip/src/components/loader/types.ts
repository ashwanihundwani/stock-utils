export interface LoaderProps {
  isLoading: boolean;
}
