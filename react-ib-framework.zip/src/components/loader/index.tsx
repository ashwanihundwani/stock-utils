import {FC} from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import {LoaderProps} from './types';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';

const Loader: FC<LoaderProps> = ({isLoading}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  return isLoading && <CircularProgress sx={styles.default} />;
};

export default Loader;
