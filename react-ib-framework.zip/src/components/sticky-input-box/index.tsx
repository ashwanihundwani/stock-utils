import {FC, JSX} from 'react';
import {Box} from '@mui/material';
import {InputBox} from 'components';
import {getStyles} from './styles';
import {useAppTheme} from 'constants/theme';

interface StickyInputBoxProps {
  firstValue: string;
  secondValue: string;
  setFirstValue: (value: string) => void;
  setSecondValue: (value: string) => void;
  firstplaceholder: string;
  secondplaceholder: string;
  secureFirstInput?: boolean;
  secureSecondInput?: boolean;
  firstEndElement?: JSX.Element;
  secondEndElement?: JSX.Element;
}

const StickyInputBox: FC<StickyInputBoxProps> = ({
  firstValue,
  secondValue,
  setFirstValue,
  setSecondValue,
  firstplaceholder,
  secondplaceholder,
  secureFirstInput,
  secureSecondInput,
  firstEndElement,
  secondEndElement,
}) => {
  const {theme} = useAppTheme();

  const styles = getStyles(theme);
  return (
    <Box sx={styles.container}>
      <InputBox
        variant={'outlined'}
        label={firstplaceholder}
        value={firstValue}
        setValue={setFirstValue}
        InputBoxStyle={'3dHoverInput'}
        inputStyle={styles.firstInputDefault}
        type={secureFirstInput ? 'password' : undefined}
        endElement={firstEndElement}
      />
      <InputBox
        variant={'outlined'}
        label={secondplaceholder}
        value={secondValue}
        setValue={setSecondValue}
        InputBoxStyle={'3dHoverInput'}
        inputStyle={styles.secondInputDefault}
        type={secureSecondInput ? 'password' : undefined}
        endElement={secondEndElement}
      />
    </Box>
  );
};

export default StickyInputBox;
