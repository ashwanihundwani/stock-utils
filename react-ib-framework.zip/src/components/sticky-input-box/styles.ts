import {Theme} from 'constants/theme';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
    },
    firstInputDefault: {
      borderRadius: '8px 8px 0px 0px',
      borderBottom: '1px solid',
      borderColor: theme.inputBox.border,
      backgroundColor: theme.inputBox.background,
    },
    secondInputDefault: {
      borderRadius: '0px 0px 8px 8px',
      backgroundColor: theme.inputBox.background,
    },
  };
};
