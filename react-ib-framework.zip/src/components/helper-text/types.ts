export enum HelperTextType {
  ErrorText = 'ErrorText',
  HelperText = 'HelperText',
}

export interface HelperTextProps {
  type: HelperTextType;
  message?: string;
}
