import {fonts} from 'utils/typography';

export const getStyles = (checkType: () => string) => {
  return {
    defaultBox: {
      display: 'flex',
      alignItems: 'center',
      marginTop: '12px',
      gap: '4px',
      color: checkType,
      fontFamily: fonts.regular,
      lineHeight: 'normal',
    },
  };
};
