import {SxProps} from '@mui/material';

export enum InputType {
  Text = 'text',
  Password = 'password',
  Number = 'number',
}

export interface TextInputProps {
  value?: string;
  setValue?: (value: string) => void;
  label?: string;
  type?: InputType;
  startElement?: React.ReactNode;
  endElement?: React.ReactNode;
  errorText?: string;
  helperText?: string;
  disabled?: boolean;
  prefix?: string;
  customStyle?: SxProps;
  errorHeight?: boolean;
  autoComplete?: string;
  autoFocus?: boolean;
  maxLength?: number;
  bgWhite?: boolean;
  maximumLength?: number;
}
