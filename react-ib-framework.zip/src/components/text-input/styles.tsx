import {fonts} from 'utils/typography';
import {Theme} from 'react-core';
export const getStyles = (
  theme: Theme,
  startElement: React.ReactNode,
  endElement: React.ReactNode,
  errorHeight: React.ReactNode,
  bgWhite: boolean,
) => {
  return {
    defaultBox: {
      width: '100%',
      '& .MuiTypography-root': {
        marginLeft: '16px',
      },
      '& input::-ms-reveal': {
        display: 'none',
      },
      '& input::-ms-clear': {
        display: 'none',
      },
    },
    defaultInputStyle: {
      width: '100%',
      '& .MuiFilledInput-root': {
        borderRadius: '8px',
        width: '100%',
        height: '64px',
        border: `1px solid transparent`,
        backgroundColor: bgWhite
          ? theme.colors['surface-01']
          : theme.colors['surface-interactive-secondary-enabled'],
        '&:hover:not(.Mui-disabled)': {
          borderColor: theme.colors['border-focus'],
          borderWidth: '1.5px',
        },

        '&.Mui-focused': {
          borderColor: theme.colors['surface-interactive-tertiary-active'],
        },
        '&.MuiFormHelperText-root': {
          marginLeft: '16px',
          color: 'red',
        },
        '& .MuiTypography-root': {
          marginLeft: '0px',
        },
        '&.Mui-error': {
          backgroundColor: theme.colors['surface-semantic-error-01'],
          border: `1px solid ${theme.colors['surface-semantic-error-02']}`,
          '& label': {
            fontSize: '14px',
            fontWeight: 'normal',
            color: theme.colors['content-secondary'],
            transform: 'Titlecase',
            '&.Mui-focused': {
              fontSize: '14px',
              fontWeight: 'normal',
              color: theme.colors['content-secondary'],
            },
          },
        },
      },
      // unfocus label at first
      '& label': {
        margin: '5px 10px 8px',
        fontSize: '14px',
        fontFamily: fonts.regular,
        fontWeight: 'normal',
        width: '100%',
        color: theme.colors['content-secondary'],
        transform: 'Titlecase',
        '&.Mui-focused': {
          fontSize: '14px',
          fontWeight: 'normal',
          fontFamily: fonts.regular,
          color: theme.colors['content-primary'],
        },
      },
      // inside label
      '& input': {
        fontSize: '14px',
        width: '100%',
        fontFamily: fonts.regular,
        color: theme.colors['content-primary'],
        margin: !startElement ? '5px 10px 2px' : '2px 0px 0px 0px',
        height: '23px',
      },
      '.MuiInputAdornment-root': {
        margin: '0px 10px 0px 10px',
        fontSize: '10px',
        fontFamily: fonts.regular,
        color: theme.colors['content-primary'],
      },

      '& input[type=number]': {
        WebkitAppearance: 'textfield',
      },
      '& input[type=number]::-webkit-outer-spin-button': {
        WebkitAppearance: 'none',
        margin: 0,
      },
      '& input[type=number]::-webkit-inner-spin-button': {
        WebkitAppearance: 'none',
        margin: 0,
      },
    },
    startElementstyle: {
      fontSize: '14px',
      fontFamily: fonts.regular,
      color: theme.colors['content-primary'],
      marginTop: '3px',
    },
    svgIconsStyle: {
      padding: '12px',
      '& .MuiIconButton-edgeEnd': {
        position: 'absolute',
        right: '12px',
      },
      '& .MuiIconButton-root:not(.MuiIconButton-edgeEnd)': {
        position: 'absolute',
        right: !endElement ? '12px' : '32px',
      },
    },
    errorMsgHeight: {
      height: errorHeight ? '20px' : '0px',
      '& span>svg': {
        display: errorHeight ? 'block' : 'none',
      },
    },
  };
};
