import {SxProps} from '@mui/system';

export interface AmountInputProps {
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  errorText?: string;
  helperText?: string;
  disabled: boolean;
  currency: string;
  customStyle?: SxProps;
}
