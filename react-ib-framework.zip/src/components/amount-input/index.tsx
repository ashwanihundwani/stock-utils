import React from 'react';
import {Box, InputAdornment, TextField} from '@mui/material';
import {getStyles} from './styles';
import {AmountInputProps} from './types';
import {Label} from 'components';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {useNewTheme} from 'react-core';
import {SarCurrency} from 'assets/svg/sarCurrency';

const AmountInput: React.FC<AmountInputProps> = ({
  onChange,
  value,
  disabled,
  errorText,
  helperText,
  currency,
  customStyle,
}) => {
  const formatAmount = (value: string) => {
    const hasNumber = /\d/.test(value);
    return hasNumber
      ? new Intl.NumberFormat('en-IN').format(
          parseFloat(value.replace(/,/g, '')),
        )
      : '';
  };

  const handleSetAmont = (value: string) => {
    onChange(value);
  };

  const handleOnBlur = (value: string) => {
    onChange(formatAmount(value));
  };

  const handleKeydown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    const allowedKeys = [
      'Backspace',
      'Delete',
      'ArrowLeft',
      'ArrowRight',
      'Tab',
    ];
    const isNumber = event.key >= '0' && event.key <= '9';
    const isAllowedSymbol = event.key === '.' || event.key === ',';

    if (!isNumber && !isAllowedSymbol && !allowedKeys.includes(event.key)) {
      event?.preventDefault();
    }
  };

  const theme = useNewTheme();
  const styles = getStyles(theme, disabled);
  return (
    <>
      <Box sx={styles.container}>
        <TextField
          variant="outlined"
          placeholder="000,000"
          onKeyDown={(event: React.KeyboardEvent<HTMLDivElement>) => {
            handleKeydown(event);
          }}
          onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
            handleSetAmont(event.target.value);
          }}
          onBlur={(event: React.FocusEvent<HTMLInputElement>) => {
            handleOnBlur(event.target.value);
          }}
          value={value}
          sx={{
            ...styles.defaultText,
            ...customStyle,
          }}
          disabled={disabled}
          slotProps={{
            input: {
              startAdornment: (
                <InputAdornment position="start">
                  <SarCurrency />
                  {/* <Label sx={styles.sarIconStyle} Title={''} /> */}
                </InputAdornment>
              ),
            },
          }}
        />
        <Label sx={styles.sarIconStyle} Title={currency} />
      </Box>
      <Box sx={styles.line} />
      <Box sx={styles.helperTextStyle}>
        {Boolean(helperText) && (
          <HelperText type={HelperTextType.HelperText} message={helperText} />
        )}
        {Boolean(errorText) && (
          <HelperText type={HelperTextType.ErrorText} message={errorText} />
        )}
      </Box>
    </>
  );
};
export default AmountInput;
