import {Theme} from 'react-core';

export const getStyles = (theme: Theme, disabled: boolean) => {
  return {
    container: {
      display: 'flex',
      textAlign: 'right',
      alignItems: 'baseline',
      paddingBottom: 0,
      marginBottom: 0,
    },
    defaultText: {
      paddingBottom: 0,
      marginBottom: 0,
      '& .MuiOutlinedInput-root': {
        '& fieldset': {
          border: 'none',
        },
      },
      '& .MuiInputBase-input': {
        fontSize: '56px',
        fontWeight: '500',
        width: '225px',
        paddingBottom: 0,
        marginBottom: 0,
      },
    },
    sarIconStyle: {
      fontSize: '32px',
      fontWeight: '500',
      color: disabled
        ? theme.colors['content-disabled']
        : theme.colors['content-primary'],
      paddingBottom: 0,
      marginBottom: 0,
    },
    line: {
      borderBottom: '1px solid',
      borderColor: theme.colors['border-enabled-02'],
      width: '100%',
      mb: 5,
    },
    helperTextStyle: {
      display: 'grid',
      justifyContent: 'center',
    },
  };
};
