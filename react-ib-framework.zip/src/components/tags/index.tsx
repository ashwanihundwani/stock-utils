import {FC} from 'react';
import {TagsProps} from './types';
import {Button} from '@mui/material';
import {getStyles} from './styles';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {useNewTheme} from 'react-core';

const Tags: FC<TagsProps> = ({label, type, deleteIcon}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme, type);
  return (
    <Button sx={styles.defaultStyle} endIcon={deleteIcon && <DeleteIcon />}>
      {label}
    </Button>
  );
};

export default Tags;
