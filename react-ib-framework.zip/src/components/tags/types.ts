export enum TagsType {
  Success = 'Success',
  Info = 'Info',
  Warning = 'Warning',
  Other = 'Other',
  Error = 'Error',
}

export interface TagsProps {
  label: string;
  type: TagsType;
  deleteIcon: boolean;
}
