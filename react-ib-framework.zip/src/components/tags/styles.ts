import {fonts} from 'utils/typography';
import {TagsType} from './types';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme, type: TagsType) => {
  const handleOnTypes = () => {
    switch (type) {
      case TagsType.Success: {
        return {
          backgroundColor: theme.colors['surface-semantic-success-01'],
          color: theme.colors['content-semantic-success-02'],
        };
      }
      case TagsType.Info: {
        return {
          backgroundColor: theme.colors['surface-semantic-info-01'],
          color: theme.colors['content-semantic-info-02'],
        };
      }
      case TagsType.Warning: {
        return {
          backgroundColor: theme.colors['surface-semantic-warning-01'],
          color: theme.colors['content-semantic-warning-02'],
        };
      }
      case TagsType.Error: {
        return {
          backgroundColor: theme.colors['surface-semantic-error-01'],
          color: theme.colors['content-semantic-error-02'],
        };
      }
      default:
        return {
          backgroundColor: theme.colors['surface-02'],
          color: theme.colors['content-secondary'],
        };
    }
  };
  return {
    defaultStyle: {
      ...handleOnTypes(),
      borderRadius: '20px',
      textTransform: 'none',
      paddingRight: '16px',
      paddingLeft: '16px',
      minWidth: '70px',
      margin: '8px',
      '&.MuiButton-root': {
        fontSize: '14px',
        fontFamily: fonts.regular,
        fontWeight: '500px',
      },
    },
  };
};
