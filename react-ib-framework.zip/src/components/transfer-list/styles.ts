import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const transferListStyles = (theme: Theme) => {
  return {
    card: {
      width: '802px',
      height: '64px',
      display: 'flex',
      alignItems: 'center',
      padding: '8px 16px 8px 16px',
      backgroundColor: theme.colors['border-enabled-01'],
      borderRadius: '8px',
      gap: '12px',
    },
    textContainer: {
      flexGrow: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: '4px',
    },
    mainText: {
      fontFamily: fonts.regular,
      fontSize: '16px',
      fontWeight: 500,
      color: theme.colors['content-primary'],
    },
    secondaryText: {
      fontFamily: fonts.regular,
      fontWeight: 400,
      fontSize: '14px',
      color: theme.colors['content-secondary'],
    },
    ibanText: {
      fontSize: '14px',
      font: fonts.regular,
      fontWeight: 400,
      color: theme.colors['content-secondary'],
      textAlign: 'right',
      '::before': {
        content: '"..."',
        marginRight: '4px',
      },
    },
  };
};
