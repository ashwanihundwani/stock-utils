import React from 'react';
import {Box, Typography} from '@mui/material';
import {transferListStyles} from './styles';
import Avatar from '../avatar';
import {useNewTheme} from 'react-core/hooks';
import {TransferListProps} from './types';

const TransferList: React.FC<TransferListProps> = ({
  name,
  amount,
  iban,
  ...avatarProps
}) => {
  const theme = useNewTheme();
  const styles = transferListStyles(theme);

  return (
    <Box sx={styles.card}>
      <Avatar {...avatarProps} />

      <Box sx={styles.textContainer}>
        <Typography sx={styles.mainText}>{name}</Typography>
        <Typography sx={styles.secondaryText}>{amount}</Typography>
      </Box>

      <Typography sx={styles.ibanText}>{iban.slice(-4)}</Typography>
    </Box>
  );
};

export default TransferList;
