import {appcolors} from 'constants/color';
import {Theme} from 'constants/theme';
import {fonts} from 'utils/typography';

export const getStyles = (
  theme: Theme,
  onClick: (() => void) | undefined,
  width: string | undefined,
) => {
  return {
    defaultStyle: {
      cursor: onClick ? 'pointer' : 'default',
      fontSize: '12px',
      width: 'auto',
      color: theme.text.heading,
    },
    sm: {
      fontSize: '12px',
      fontFamily: fonts.regular,
    },
    lg: {
      fontSize: '16px',
      fontFamily: fonts.bold,
    },
    md: {
      fontSize: '14px',
      fontFamily: fonts.bold,
    },
    xl: {
      fontSize: '20px',
      fontFamily: fonts.title,
    },
    wrap_text: {
      overflowWrap: 'break-word',
    },
    sar_end: {
      fontSize: '12px',
      fontWeight: 'bold',
      fontFamily: fonts.regular,
      color: appcolors.black,
    },
    skeleton: {
      minWidth: width ?? '100%',
    },
  };
};
