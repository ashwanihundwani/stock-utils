import {FC, useCallback, useMemo} from 'react';
import {Typography, SxProps, Theme} from '@mui/material';
import {useTranslation} from '../../translations';
import {getStyles} from './styles';
import {useAppTheme} from 'constants/theme';

interface LabelProps {
  sx?: SxProps<Theme>;
  Title?: any;
  variant?: 'sm' | 'md' | 'lg' | 'xl' | 'sar_end';
  onClick?: () => void;
  color?: string;
  noWrap?: boolean;
  fontSize?: string;
  bold?: boolean;
  noTranslate?: boolean;
  width?: string;
}

const Label: FC<LabelProps> = ({
  sx,
  Title,
  variant,
  onClick,
  color,
  noWrap,
  fontSize,
  bold,
  noTranslate,
  width,
}) => {
  const {t: translate} = useTranslation();
  const translatedValue = useMemo(() => translate(Title), [Title, translate]);
  const nonTranslatedValue = useMemo(() => {
    return Title;
  }, [Title]);

  const {theme} = useAppTheme();

  const styles = getStyles(theme, onClick, width);

  const getFontStyle = useCallback((): any => {
    const style = [
      {...styles.defaultStyle},
      variant === 'lg' && {...styles.lg},
      variant === 'xl' && {...styles.xl},
      variant === 'md' && {...styles.md},
      variant === 'sm' && {...styles.sm},
      variant === 'sar_end' && {...styles.sar_end},
      {...sx},
      color && {color},
      !noWrap && styles.wrap_text,
      fontSize && {fontSize},
      bold && {fontWeight: 'bold'},
    ];
    return style;
  }, [
    styles.defaultStyle,
    styles.lg,
    styles.xl,
    styles.md,
    styles.sm,
    styles.sar_end,
    styles.wrap_text,
    variant,
    sx,
    color,
    noWrap,
    fontSize,
    bold,
  ]);

  return (
    <Typography component="span" sx={getFontStyle()} onClick={onClick}>
      {noTranslate ? nonTranslatedValue : translatedValue}
    </Typography>
  );
};

export default Label;
