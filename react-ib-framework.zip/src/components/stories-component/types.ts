export interface StoriesProps {
  label?: string;
}
