import {appcolors} from 'constants/color';
import {Theme} from 'constants/theme';

export const getStyles = (headercomponent: any, theme: Theme) => {
  return {
    defaultMainContentStyle: {
      backgroundColor: theme.background.mainContentBackground,
      width: '100%',
      height: '100%',
      overflowY: 'auto',
      margin: '0px auto 0px auto',
      paddingTop: headercomponent ? '0%' : '1%',
    },
    defaultCardStyle: {
      width: '80%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '1%',
      borderRadius: '5px 5px 0px 0px',
      marginLeft: 'auto',
      marginRight: 'auto',
      backgroundColor: theme.background.cardBackground,
      color: appcolors.black,
    },
  };
};
