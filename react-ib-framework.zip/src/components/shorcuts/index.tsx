import {FC} from 'react';
import {Box} from '@mui/material';

import FormControl from '@mui/material/FormControl';
import Typography from '@mui/material/Typography';
import {getStyles} from './styles';
import {ShorcutsProps} from './types';
import {ShorcutsIcon} from '../../assets/svg/shorcuts';
const Shorcuts: FC<ShorcutsProps> = ({label}) => {
  const styles = getStyles();
  return (
    <Box>
      <FormControl>
        <ShorcutsIcon />
        <Typography sx={styles.defaultLabel}>{label}</Typography>
      </FormControl>
    </Box>
  );
};

export default Shorcuts;
