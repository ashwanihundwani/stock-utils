import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const avatarStyles = (
  size: 'Large' | 'Small' | 'Xs',
  inverted: boolean,
  theme: Theme,
) => {
  const sizeMap = {
    Large: 80,
    Small: 64,
    Xs: 32,
  };

  return {
    avatarContainer: {
      position: 'relative',
      width: sizeMap[size],
      height: sizeMap[size],
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: inverted
        ? theme.colors['surface-inverted-04']
        : theme.colors['decorative-03'],
      borderRadius: '50%',
      overflow: 'visible',
    },
    avatarText: {
      fontSize: '28px',
      fontFamily: fonts.regular,
      fontWeight: 500,
      color: inverted
        ? theme.colors['content-primary']
        : theme.colors['content-inverted-primary'],
    },
    avatarImage: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
    },
    itemWrapper: {
      position: 'absolute',
      bottom: '-8px',
      right: '-8px',
      width: '32px',
      height: '32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: '50%',
      border: `2px solid ${inverted ? theme.colors['background-03'] : theme.colors['background-01']}`,
    },
  };
};
