import React from 'react';
import {Box, Typography} from '@mui/material';
import {avatarStyles} from './styles';
import {BankIcon, ButtonIcon, FlagIcon} from 'assets/svg/avatarIcons';
import {AvatarProps} from './types';
import {useNewTheme} from 'react-core/hooks';

const Avatar: React.FC<AvatarProps> = ({
  size,
  type,
  onlyIcon = false,
  itemType,
  initial,
  inverted = false,
  imageUrl,
}) => {
  const theme = useNewTheme();
  const styles = avatarStyles(size, inverted, theme);

  const getItemIcon = () => {
    switch (itemType) {
      case 'button':
        return <ButtonIcon />;
      case 'flag':
        return <FlagIcon />;
      case 'bank':
        return <BankIcon />;
      default:
        return null;
    }
  };

  return (
    <Box sx={styles.avatarContainer}>
      {type === 'filled' ? (
        <Box
          component="img"
          src={imageUrl}
          alt="avatar"
          sx={styles.avatarImage}
        />
      ) : (
        <Typography sx={styles.avatarText}>{initial}</Typography>
      )}

      {!onlyIcon && <Box sx={styles.itemWrapper}>{getItemIcon()}</Box>}
    </Box>
  );
};

export default Avatar;
