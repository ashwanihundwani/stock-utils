import {Theme} from 'react-core';

export interface AvatarProps {
  size: 'Large' | 'Small' | 'Xs';
  type: 'empty' | 'filled';
  onlyIcon?: boolean;
  itemType?: 'button' | 'flag' | 'bank';
  initial?: string;
  inverted?: boolean;
  imageUrl?: string;
}

export interface AvatarStyleProps {
  theme: Theme;
}
