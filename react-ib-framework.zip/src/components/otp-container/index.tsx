import {Box} from '@mui/material';
import {Label, Link, Timer} from 'components';
import {variants} from 'components/custom-label/types';
import {FC, useEffect, useState} from 'react';
import {OtpContainerProps} from './types';
import {getStyles} from './styles';
import OtpInput from 'components/otp-input';
import {useTranslation} from 'react-core';

const OtpContainer: FC<OtpContainerProps> = props => {
  const {
    onResendOtp,
    title = '',
    subtitle = '',
    resendOtpLabel = '',
    requestOtpLabel = '',
    onSubmitOtp,
  } = props;
  const styles = getStyles();
  const [otp, setOtp] = useState(['', '', '', '']);
  const [showResendOtp, setShowResendOtp] = useState(false);
  const {t: translate} = useTranslation();

  const handleOnResendOtp = () => {
    setShowResendOtp(false);
    onResendOtp();
  };

  useEffect(() => {
    const otpInput = otp.join('');
    if (otpInput.length === 4) {
      onSubmitOtp(otpInput);
    }
  }, [otp]);

  return (
    <Box sx={styles.otpContainer}>
      <Box sx={styles.otpHeaderFooterContainer}>
        <Label id={'title'} text={translate(title)} variant={variants.titleS} />
        <Label
          id={'subtitle'}
          text={translate(subtitle) + ' ********019'}
          variant={variants.bodyRegularS}
        />
      </Box>

      <OtpInput otp={otp} setOtp={newOtp => setOtp(newOtp)} />

      <Box sx={styles.otpHeaderFooterContainer}>
        {showResendOtp ? (
          <Link
            linkText={translate(requestOtpLabel)}
            onClick={handleOnResendOtp}
          />
        ) : (
          <Box sx={styles.resendContainer}>
            <Label
              id={'resend-txt'}
              text={translate(resendOtpLabel)}
              variant={variants.bodyRegularS}
            />
            <Timer
              initialTimeInSeconds={60}
              onTimerComplete={() => {
                setShowResendOtp(true);
              }}
            />
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default OtpContainer;
