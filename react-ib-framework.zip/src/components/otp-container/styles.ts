export const getStyles = () => {
  return {
    otpContainer: {
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      gap: '32px',
      justifyContent: 'center',
    },
    otpHeaderFooterContainer: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
    },
    resendContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '4px',
    },
  };
};
