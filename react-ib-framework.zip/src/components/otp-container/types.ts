export type OtpContainerProps = {
  onResendOtp: () => void;
  title: string;
  subtitle: string;
  resendOtpLabel: string;
  requestOtpLabel: string;
  onSubmitOtp: (otp: string) => void;
};
