import {Box, SvgIcon} from '@mui/material';
import {FC} from 'react';
import Dialog from '@mui/material/Dialog';
import {ModalProps} from './types';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {getStyles} from './styles';

const Modal: FC<ModalProps> = ({open, onClose, children, icon}) => {
  const styles = getStyles();
  return (
    <Dialog onClose={onClose} open={open}>
      <Box sx={styles.modalConatiner}>
        {icon && (
          <Box sx={styles.deleteIcon}>
            <SvgIcon onClick={onClose}>
              <DeleteIcon />
            </SvgIcon>
          </Box>
        )}
        {children}
      </Box>
    </Dialog>
  );
};

export default Modal;
