export const getStyles = () => {
  return {
    modalConatiner: {
      // need to remove
      // padding: '16px',
      minWidth: '100px',
      minheight: '100px',
      overflowY: 'scroll',
      overflowX: 'scroll',
      scrollbarWidth: 'none',
    },
    deleteIcon: {
      textAlign: 'right',
    },
  };
};
