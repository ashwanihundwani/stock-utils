import React, {FC} from 'react';
import {Box, Stack, SxProps} from '@mui/material';
import {Label} from 'components';
// import { Theme } from '@material-ui/core';
import {getStyles} from './styles';
import {useAppTheme} from 'constants/theme';

interface ScreenHeaderProps {
  screenName: string;
  containerStyle?: SxProps<any>;
  startComponent?: React.ReactNode;
  endComponent?: React.ReactNode;
  startComponentStyle?: SxProps<any>;
  endComponentStyle?: SxProps<any>;
  topNavigation?: boolean;
}

const ScreenHeader: FC<ScreenHeaderProps> = ({
  screenName,
  containerStyle,
  startComponent,
  endComponent,
  startComponentStyle,
  endComponentStyle,
  topNavigation,
}) => {
  const {theme} = useAppTheme();

  const styles = getStyles(theme);

  return (
    <Stack
      height={topNavigation ? '18%' : '8%'}
      justifyContent={topNavigation ? 'flex-end' : 'center'}
      sx={styles.header}>
      <Box sx={[{...styles.defaultContainer}, {...(containerStyle as object)}]}>
        <Box
          sx={[
            {...styles.defaultStartComponentStyle},
            {...(startComponentStyle as object)},
          ]}>
          {startComponent}
        </Box>
        <Label Title={screenName} variant={'lg'} sx={styles.headerLabel} />
        <Box
          sx={[
            {...styles.defaultEndComponentStyle},
            {...(endComponentStyle as object)},
          ]}>
          {endComponent}
        </Box>
      </Box>
    </Stack>
  );
};

export default ScreenHeader;
