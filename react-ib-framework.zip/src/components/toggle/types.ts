export interface ToggleProps {
  disabled: boolean;
  onChange: (value: boolean) => void;
}
