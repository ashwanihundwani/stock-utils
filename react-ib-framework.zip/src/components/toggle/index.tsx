import {FC} from 'react';
import Switch from '@mui/material/Switch';
import {getStyles} from './styles';
import {colors as theme} from 'constants/color';
import {ToggleProps} from './types';

const Toggle: FC<ToggleProps> = ({disabled, onChange}) => {
  const styles = getStyles(theme, disabled);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.checked);
  };

  return (
    <Switch
      sx={styles.defaultStyle}
      disableRipple
      disabled={disabled}
      onChange={handleChange}
    />
  );
};

export default Toggle;
