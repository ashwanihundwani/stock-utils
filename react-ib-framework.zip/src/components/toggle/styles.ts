export const getStyles = (theme: any, disabled: boolean) => {
  return {
    defaultStyle: {
      '&.MuiSwitch-root': {
        padding: '0px',
        margin: '0px',
        height: '24px',
        width: '48px',
        borderRadius: '20px',
        '&:hover': {
          boxShadow: `0px 0px 0px 2px ${disabled ? 'none' : theme['Accesibility-border-focus']}`,
        },
        '& .MuiButtonBase-root': {
          padding: '0px',
          '&.Mui-checked+.MuiSwitch-track': {
            backgroundColor: disabled
              ? theme['surface-interactive-tertiary-enabled']
              : theme['surface-interactive-tertiary-active'],
            opacity: 1,
          },
          '&.Mui-disabled+.MuiSwitch-track': {
            backgroundColor: theme['surface-interactive-tertiary-enabled'],
            opacity: 0.5,
          },
        },
        '.MuiSwitch-thumb': {
          marginTop: '2px',
          padding: '0px',
          transform: 'translateX(4px)',
        },
      },
      '.MuiSwitch-track': {
        backgroundColor: theme['surface-interactive-tertiary-enabled'],
        opacity: 0.5,
      },
      '.MuiSwitch-thumb': {
        marginTop: '2px',
        padding: '0px',
        color: theme['content-interactive-inverted-enabled'],
      },
      '& .Mui-disabled .MuiSwitch-thumb': {
        color: theme['content-interactive-inverted-disabled'],
      },
    },
  };
};
