import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getButtonStyles = (theme: Theme) => ({
  base: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    textTransform: 'none',
    transition: 'none',
    borderRadius: '28px',
    padding: '0 16px',
    fontSize: '16px',
    fontFamily: fonts.semi_bold,
    width: 'fit-content',
  },
  primary: {
    default: {
      backgroundColor: theme.colors['surface-interactive-primary-enabled'],
      color: theme.colors['background-01'],
      '&:hover': {
        backgroundColor: theme.colors['surface-interactive-primary-active'],
      },
      '&:active': {
        backgroundColor: theme.colors['surface-interactive-primary-active'],
      },
      '&:focus': {
        backgroundColor: theme.colors['surface-interactive-primary-enabled'],
        border: `2px solid ${theme.colors['border-focus']}`,
      },
    },
    inverted: {
      backgroundColor: theme.colors['background-01'],
      color: theme.colors['surface-interactive-primary-enabled'],
      '&:hover': {
        backgroundColor:
          theme.colors['surface-interactive-primary-inverted-active'],
      },
      '&:active': {
        backgroundColor:
          theme.colors['surface-interactive-primary-inverted-active'],
      },
      '&:focus': {
        backgroundColor: theme.colors['background-01'],
        border: `2px solid ${theme.colors['border-focus-inverted']}`,
      },
    },
    disabled: {
      backgroundColor: theme.colors['surface-interactive-primary-disabled'],
      color: theme.colors['background-01'],
      border: 'none',
    },
  },
  secondary: {
    default: {
      border: '1px solid rgba(129,17,199,1)',
      color: theme.colors['surface-interactive-primary-enabled'],
      '&:active': {
        backgroundColor: theme.colors['surface-interactive-primary-active'],
      },
      '&:focus': {
        border: '2px solid rgba(129,17,199,1) ',
        outline: `2px solid ${theme.colors['border-focus']}`,
        outlineOffset: '2px',
      },
    },
    inverted: {
      border: `1px solid ${theme.colors['border-interactive-inverted-enabled']}`,
      color: theme.colors['background-01'],
      '&:hover': {
        backgroundColor:
          theme.colors['surface-interactive-primary-inverted-active'],
      },
      '&:active': {
        backgroundColor:
          theme.colors['surface-interactive-primary-inverted-active'],
      },
      '&:focus': {
        border: '2px solid rgba(129,17,199,1) ',
        outline: `2px solid ${theme.colors['border-focus-inverted']}`,
        outlineOffset: '2px',
      },
    },
    disabled: {
      border: theme.colors['border-interactive-disabled'],
      backgroundColor: theme.colors['background-02'],
      color: theme.colors['content-interactive-inverted-disabled'],
    },
  },
  ghost: {
    default: {
      color: theme.colors['surface-interactive-primary-enabled'],
      '&:focus': {
        border: `2px solid ${theme.colors['border-focus']}`,
      },
    },
    inverted: {
      color: theme.colors['background-01'],
      '&:focus': {
        border: `2px solid ${theme.colors['border-focus-inverted']}`,
      },
    },
    disabled: {
      color: theme.colors['content-interactive-inverted-disabled'],
      border: 'none',
    },
  },
  sizes: {
    textLarge: {
      minWidth: '100px',
      height: '48px',
    },
    textSmall: {
      miWidth: '67px',
      height: '40px',
    },
    iconLarge: {
      width: '48px',
      height: '48px',
      minWidth: '48px',
      borderRadius: '50%',
    },
    iconSmall: {
      width: '40px',
      height: '40px',
      minWidth: '40px',
      borderRadius: '50%',
    },
  },
  iconStyle: {
    display: 'flex',
    alignItems: 'center',
  },
});
