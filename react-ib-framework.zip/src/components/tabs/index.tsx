import React, {useState} from 'react';
import {getStyles, TabVariant, getBaseStyles} from './styles';
import {useNewTheme} from 'react-core';
import {Box} from '@mui/material';

interface Tab {
  id: number;
  label: string;
  content: React.ReactNode;
}

interface TabsProps {
  tabs: Tab[];
  variant?: TabVariant;
  inverted?: boolean;
}

const Tabs: React.FC<TabsProps> = ({
  tabs,
  variant = 'content-switcher',
  inverted = false,
}) => {
  const [activeTab, setActiveTab] = useState(0);
  const theme = useNewTheme();

  const {containerStyle} = getStyles(theme, variant, inverted, false);
  const baseStyles = getBaseStyles(theme);

  return (
    <Box>
      <div style={{...baseStyles.container, ...containerStyle}}>
        {tabs.map((tab, index) => {
          const {tabStyle} = getStyles(
            theme,
            variant,
            inverted,
            activeTab === index,
          );

          return (
            <button
              key={tab.id}
              style={tabStyle}
              onClick={() => setActiveTab(index)}>
              {tab.label}
            </button>
          );
        })}
      </div>
      <Box>{tabs.find(tab => tab.id === activeTab)?.content}</Box>
    </Box>
  );
};

export default Tabs;
