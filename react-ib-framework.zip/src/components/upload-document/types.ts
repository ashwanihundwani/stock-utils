export interface UploadDocumentProps {
  onFileUpload: (fileName: string, fileSize: string) => void;
  errorMessage?: string;
  label?: string;
}

export interface StyleProps {
  theme: any; // to be updated later
  hasError: boolean;
  hasFile: boolean;
}
