import {fonts} from 'utils/typography';
import {StyleProps} from './types';

export const getStyles = (props: StyleProps) => ({
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    fontFamily: fonts.regular,
  },
  uploadBox: {
    width: '358px',
    height: '128px',
    backgroundColor: props.hasError
      ? props.theme['Surface-Semantic-Default-surface-semantic-error-01']
      : props.theme[
          'Surface-Interactive-Secondary-Default-surface-interactive-secondary-enabled'
        ],
    borderRadius: '8px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: 'pointer',
    position: 'relative',
    border: props.hasError
      ? `1px solid ${props.theme['Icon-Semantic-Default-icon-semantic-error-01']}`
      : '2px solid transparent',
    transition: 'none',
    '&:focus-within': {
      border: props.hasError
        ? `1px solid ${props.theme['Icon-Semantic-Default-icon-semantic-error-01']}`
        : `2px solid ${props.theme['Border-Accesibility-border-focus']}`,
    },
  },
  uploadIcon: {
    width: '24px',
    height: '24px',
    marginBottom: '8px',
    color: props.hasError
      ? props.theme['Icon-Semantic-Default-icon-semantic-error-01']
      : props.theme[
          'Icon-Interactive-Primary-icon-interactive-primary-enabled'
        ],
  },
  uploadLabel: {
    color: props.theme['Content-Static-Default-content-primary'],
    fontSize: '16px',
    fontWeight: '600',
    textAlign: 'center',
    fontFamily: fonts.regular,
  },
  fileInput: {
    opacity: 0,
    width: '100%',
    height: '100%',
    position: 'absolute',
    cursor: 'pointer',
    display: 'none',
  },

  fileBox: {
    width: '358px',
    height: '60px',
    backgroundColor:
      props.theme[
        'Surface-Interactive-Secondary-Default-surface-interactive-secondary-enabled'
      ],
    borderRadius: '8px',
    display: 'flex',
    alignItems: 'center',
    padding: '0 16px',
    justifyContent: 'space-between',
    fontFamily: fonts.regular,
    '&:focus-within': {
      border: `2px solid ${props.theme['Border-Accesibility-border-focus']}`,
    },
  },
  fileInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  fileName: {
    color: props.theme['Content-Static-Default-content-primary'],
    fontSize: '16px',
    fontWeight: '500',
    fontFamily: fonts.regular,
  },
  fileSize: {
    color: props.theme['Content-Static-Default-content-secondary'],
    fontSize: '14px',
    marginTop: '2px',
    fontFamily: fonts.regular,
  },
  closeIcon: {
    width: '24px',
    height: '24px',
    color: props.theme['Icon-Semantic-Default-icon-semantic-error-01'],
    transition: 'none',
  },
  errorContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: '4px',
    width: '100%',
    paddingLeft: '16px',
  },
  errorIcon: {
    width: '12px',
    height: '12px',
    color: props.theme['Icon-Semantic-Default-icon-semantic-error-01'],
  },
  errorText: {
    color: props.theme['Icon-Semantic-Default-icon-semantic-error-01'],
    fontSize: '12px',
    fontFamily: fonts.regular,
  },
});
