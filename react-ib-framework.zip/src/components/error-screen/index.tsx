import {FC} from 'react';
import {Box} from '@mui/material';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {buttonTypes} from 'constants/labelvalues';
import {logger} from 'logger';
import Label from 'components/label';
import ButtonList from 'components/button-list';
import {getStyles} from './styles';

interface ErrorScreenProps {
  error: string;
  resetErrorBoundary: () => void;
}

const ErrorScreen: FC<ErrorScreenProps> = ({error}) => {
  const navigate = useNavigate();
  const navigateLogin = () => navigate(AppPath.LoginScreen);
  logger.log('Error Boundary', error);

  const styles = getStyles();
  const errorBtn = [
    {
      id: 1,
      label: 'Home',
      type: buttonTypes.filled,
      onClick: navigateLogin,
    },
  ];
  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Label Title={'Oops, Something went wrong'} variant={'lg'} />
      </Box>
      <Box sx={styles.footer}>
        <ButtonList buttons={errorBtn} />
      </Box>
    </Box>
  );
};

export default ErrorScreen;
