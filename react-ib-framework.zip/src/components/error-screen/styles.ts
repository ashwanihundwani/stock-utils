import {Images} from 'constants/images';

export const getStyles = () => {
  return {
    container: {
      height: '100%',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat',
      backgroundImage: `url(${Images.error_bg_img})`,
      width: '100%',
    },
    mainContent: {
      height: '80%',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    footer: {
      display: 'flex',
      flexDirection: 'row',
      minHeight: '20%',
      gap: '19%',
    },
  };
};
