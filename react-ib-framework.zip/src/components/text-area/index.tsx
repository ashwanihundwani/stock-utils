import React, {FC} from 'react';
import {Box, TextField} from '@mui/material';
import {getStyles} from './styles';
import {TextAreaProps} from './types';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {useNewTheme} from 'react-core/hooks';

const TextArea: FC<TextAreaProps> = ({
  placeholder,
  value,
  onChange,
  errorText,
  helperText,
  disabled,
  id,
  customStyle,
}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  // the search Text is given here to change the icon color when we type the input

  const handleOnSetTextArea = (value: string) => {
    return onChange(value);
  };

  return (
    <Box sx={styles.defaultBox}>
      <TextField
        id={id}
        data-testid={id}
        value={value}
        label={placeholder}
        sx={{...styles.defaultTextArea, ...customStyle}}
        error={Boolean(errorText)}
        variant="filled"
        multiline
        rows={7}
        InputProps={{
          disableUnderline: true,
        }}
        disabled={disabled}
        onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
          handleOnSetTextArea(event.target.value);
        }}
      />
      {Boolean(helperText) && (
        <HelperText type={HelperTextType.HelperText} message={helperText} />
      )}
      {Boolean(errorText) && (
        <HelperText type={HelperTextType.ErrorText} message={errorText} />
      )}
    </Box>
  );
};

export default TextArea;
