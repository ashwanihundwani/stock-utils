import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    defaultBox: {
      '& .MuiTypography-root': {
        marginLeft: '16px',
      },
    },
    defaultTextArea: {
      // we have given width statically once when the figma designs is given we will change it
      // width: '358px',
      border: `1px solid transparent`,

      '& label': {
        fontSize: '16px',
        fontWeight: 'normal',
        color: theme.colors['content-secondary'],
        transform: 'translate(12px, 12px) scale(0.75)',
        paddingLeft: '9px',
        marginBottom: '12px',
        fontFamily: fonts.regular,
        '&.Mui-focused': {
          fontSize: '12px',
          fontWeight: 'normal',
          color: theme.colors['content-secondary'],
          marginBottom: '12px',
        },
        '&.MuiInputLabel-shrink': {
          fontSize: '12px',
        },
      },

      '& .MuiFilledInput-root': {
        border: `1px solid transparent`,
        borderRadius: '10px',
        fontFamily: fonts.regular,
        backgroundColor: theme.colors['surface-interactive-secondary-enabled'],
        color: theme.colors['content-primary'],
        height: '192px',
        alignItems: 'flex-end',
        paddingTop: '12px',
        paddingLeft: '16px',
        marginTop: '3px',
        '&.Mui-focused': {
          border: `1px solid ${theme.colors['surface-interactive-tertiary-active']}`,
        },
        '&:active:not(.Mui-disabled)': {
          border: `1px solid ${theme.colors['surface-interactive-tertiary-active']}`,
        },
        '&:hover:not(.Mui-disabled,:active, .Mui-focused,.Mui-error)': {
          borderColor: theme.colors['border-focus'],
        },
        '&.Mui-disabled': {
          color: theme.colors['surface-interactive-secondary-disabled'],
        },
        '&.Mui-error': {
          backgroundColor: theme.colors['surface-semantic-error-01'],
          border: `1px solid ${theme.colors['surface-semantic-error-02']}`,

          '& label': {
            fontSize: '14px',
            fontWeight: 'normal',
            color: theme.colors['content-secondary'],
            transform: 'translate(12px, 12px) scale(0.75)',
            '&.Mui-focused': {
              fontSize: '14px',
              fontWeight: 'normal',
              color: theme.colors['content-secondary'],
            },
            '&.MuiInputLabel-shrink': {
              fontSize: '12px',
            },
          },
        },
      },
    },
  };
};
