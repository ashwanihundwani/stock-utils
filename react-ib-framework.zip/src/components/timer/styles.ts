import {TimerStyleProps} from './types';

export const getStyles = (properties: TimerStyleProps) => {
  const {theme} = properties;
  return {
    timer: {
      color: theme.colors['content-secondary'],
    },
    timerText: {
      color: theme.colors['content-secondary'],
    },
  };
};
