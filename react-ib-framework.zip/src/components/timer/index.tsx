import React from 'react';
import {useCountdownTimer, useNewTheme} from 'react-core';
import {Label} from 'components';
import {variants} from 'components/custom-label/types';
import {CountdownTimerProps} from './types';
import {getStyles} from './styles';

const Timer: React.FC<CountdownTimerProps> = ({
  initialTimeInSeconds,
  onTimerComplete,
}) => {
  const theme = useNewTheme();
  const styles = getStyles({theme});

  const {timeRemaining, formatTime} = useCountdownTimer({
    initialTimeInSeconds,
    onTimerComplete,
  });

  return (
    <Label
      text={formatTime(timeRemaining)}
      style={styles.timer}
      id={'timer'}
      variant={variants.bodySemiBoldS}
    />
  );
};
export default Timer;
