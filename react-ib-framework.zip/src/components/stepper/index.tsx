import React from 'react';
import {
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  StepIconProps,
} from '@mui/material';

import {stepperStyles} from './styles';
import {IconTick} from 'assets/svg/IconTick';

interface VerticalStepperProps {
  steps: string[];
  activeStep: number;
}

const VerticalStepper: React.FC<VerticalStepperProps> = ({
  steps,
  activeStep,
}) => {
  return (
    <Stepper activeStep={activeStep} orientation="vertical" connector={null}>
      {steps.map((label, index) => (
        <Step
          key={label}
          completed={index < activeStep}
          sx={stepperStyles.step}>
          <StepLabel
            slots={{stepIcon: CustomStepIcon}}
            slotProps={{
              stepIcon: {
                active: index === activeStep,
                completed: index < activeStep,
                icon: index + 1,
              },
            }}>
            {label}
          </StepLabel>

          {index !== steps.length - 1 && (
            <CustomStepConnector index={index} activeStep={activeStep} />
          )}
        </Step>
      ))}
    </Stepper>
  );
};

const CustomStepConnector: React.FC<{index: number; activeStep: number}> = ({
  index,
  activeStep,
}) => {
  const styles = stepperStyles.getConnectorStyles(activeStep, index);

  return <StepConnector sx={styles.line} />;
};

// **🔹 Custom Step Icon**
const CustomStepIcon: React.FC<StepIconProps> = ({completed, active, icon}) => {
  const index = Number(icon) - 1;
  const styles = stepperStyles.getStepIconStyles(completed, index, active);

  return completed ? (
    <div style={styles.completedIcon}>
      <IconTick />
    </div>
  ) : (
    <div style={styles.stepIcon}>{icon}</div>
  );
};

export default VerticalStepper;
