import {fonts} from 'utils/typography';

export const stepperStyles = {
  step: {
    '& .MuiStepLabel-root .MuiStepLabel-label': {
      fontFamily: fonts.regular,
    },
    '& .MuiStepLabel-label': {
      color: '#6C608B',
    },
    '&.Mui-completed .MuiStepLabel-root .MuiStepLabel-label': {
      color: '#7D7495',
      fontWeight: '600',
    },
    '& .MuiStepLabel-root .Mui-active': {
      color: '#6A1CCD',
      fontWeight: '600',
    },
  },
  getStepIconStyles: (
    _completed: boolean | undefined,
    _index: number,
    active: boolean | undefined,
  ) => ({
    stepIcon: {
      width: 24,
      height: 24,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '14px',
      backgroundColor: active ? '#6A1CCD' : '#F7F7FA',
      color: active ? '#FFFFFF' : '#6C608B',
      fontFamily: fonts.regular,
    },
    completedIcon: {
      width: 24,
      height: 24,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#2CA85A',
      color: 'white',
    },
  }),

  getConnectorStyles: (activeStep: number, index: number) => ({
    line: {
      '& .MuiStepConnector-line': {
        borderLeftWidth: '2px',
        minHeight: '100%',
        height: '24px',
        borderColor: index < activeStep ? '#2CA85A' : '#DDDAE4',
      },
    },
  }),
};
