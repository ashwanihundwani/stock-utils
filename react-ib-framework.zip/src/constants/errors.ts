const Errors = {
  api_code_error_401: 'Unauthorize error',
  api_code_error_404: 'Not found error',
  something_went_wrong: 'Bad Request. Something went wrong',
  server_error: 'Server error',
  network_error: 'Network error',
  OnboardingEmploymentDetailsErrorRequiredDdEmployerName:
    'OnboardingEmploymentDetailsErrorRequiredDdEmployerName',
  OnboardingEmploymentdetailsErrorRequiredDdJobTitle:
    'OnboardingEmploymentdetailsErrorRequiredDdJobTitle',
  OnboardingEmploymentDetailsErrorRequiredDdWorkSector:
    'OnboardingEmploymentDetailsErrorRequiredDdWorkSector',
  OnboardingEmploymentDetailsErrorRequiredTxtJoiningDate:
    'OnboardingEmploymentDetailsErrorRequiredTxtJoiningDate',
  OnboardingEmploymentDetailsErrorRequiredDdTotalWorkExperience:
    'OnboardingEmploymentDetailsErrorRequiredDdTotalWorkExperience',
  OnboardingEmploymentDetailsErrorRequiredDdPeriodinCurrentJob:
    'OnboardingEmploymentDetailsErrorRequiredDdPeriodinCurrentJob',
  onboardingEmploymentDetailsErrorRequiredTxtWorkContactNumber:
    'onboardingEmploymentDetailsErrorRequiredTxtWorkContactNumber',
  OnboardingSalaryDetailsErrorRequiredDdSalaryAccountBank:
    'OnboardingSalaryDetailsErrorRequiredDdSalaryAccountBank',
  OnboardingSalaryDetailsErrorRequiredDdWhenAccountOpend:
    'OnboardingSalaryDetailsErrorRequiredDdWhenAccountOpend',
  OnboardingSalaryDetailsErrorRequiredDdAutoPaymentInstructions:
    'OnboardingSalaryDetailsErrorRequiredDdAutoPaymentInstructions',
  OnboardingAdditionalIncomesourceErrorRequiredDdIncomeSource:
    'OnboardingAdditionalIncomesourceErrorRequiredDdIncomeSource',
  OnboardingAdditionalIncomesourceErrorRequiredTxtIncomeSourceDescription:
    'OnboardingAdditionalIncomesourceErrorRequiredTxtIncomeSourceDescription',
  OnboardingTrustedContactErrorRequiredTxtFullName:
    'OnboardingTrustedContactErrorRequiredTxtFullName',
  onboardingTrustedContactErrorRequiredTxtPhoneNumber:
    'onboardingTrustedContactErrorRequiredTxtPhoneNumber',
  OnboardingOfferPreferenceErrorRequiredDdChannel:
    'OnboardingOfferPreferenceErrorRequiredDdChannel',
  OnboardingOfferPreferenceErrorRequiredDdHearAboutMeem:
    'OnboardingOfferPreferenceErrorRequiredDdHearAboutMeem',
  OnboardingCredentialsCreationUsernameErrorRequiredTxtUsername:
    'OnboardingCredentialsCreationUsernameErrorRequiredTxtUsername',
  OnboardingCredentialsCreationPasswordErrorRequiredTxtPassword:
    'OnboardingCredentialsCreationPasswordErrorRequiredTxtPassword',
  OnboardingCredentialsCreationPasswordErrorRequiredTxtRePassword:
    'OnboardingCredentialsCreationPasswordErrorRequiredTxtRePassword',
  OnboardingDisabilitiesErrorRequiredTxtDisability:
    'OnboardingDisabilitiesErrorRequiredTxtDisability',

  OnboardingCredentialsCreationPasswordErrorPasswordMismatch:
    'PasswordMismatch',
  OnboardingTrustedContactErrorRequiredTxtFullname:
    'OnboardingTrustedContactErrorRequiredTxtFullname',
  OnboardingTrustedContactErrorRequiredTxtRelationship:
    'OnboardingTrustedContactErrorRequiredTxtRelationship',
  OnboardingTrustedContactErrorRequiredTxtPhonenumber:
    'OnboardingTrustedContactErrorRequiredTxtPhonenumber',
  OnboardingTrustedContactErrorExactlyTenDigitsTxtPhonenumber:
    'OnboardingTrustedContactErrorExactlyTenDigitsTxtPhonenumber',
  OnboardingTrustedContactErrorMustDigitsTxtPhonenumber:
    'OnboardingTrustedContactErrorMustDigitsTxtPhonenumber',
  OnboardingAffiliatedGibMemberErrorRequiredTxtBoardMemberName:
    'OnboardingAffiliatedGibMemberErrorRequiredTxtBoardMemberName',
  OnboardingTaxDeclarationBirthDetailsErrorRequiredDdCountryOfBirth:
    'OnboardingTaxDeclarationBirthDetailsErrorRequiredDdCountryOfBirth',
  OnboardingTaxDeclarationBirthDetailsErrorRequiredTxtCityOfBirth:
    'OnboardingTaxDeclarationBirthDetailsErrorRequiredTxtCityOfBirth',
  OnboardingTaxDeclarationBirthDetailsErrorRequiredTxtAddress:
    'OnboardingTaxDeclarationBirthDetailsErrorRequiredTxtAddress',
  OnboardingTaxDeclarationTaxResidentErrorRequiredDdCountry:
    'OnboardingTaxDeclarationTaxResidentErrorRequiredDdCountry',
  OnboardingTaxDeclarationTaxResidentErrorRequiredTxtAddress:
    'OnboardingTaxDeclarationTaxResidentErrorRequiredTxtAddress',
  OnboardingTaxDeclarationTaxResidentErrorRequiredTxtState:
    'OnboardingTaxDeclarationTaxResidentErrorRequiredTxtState',
  OnboardingTaxDeclarationTaxResidentErrorRequiredTxtPhoneNumber:
    'OnboardingTaxDeclarationTaxResidentErrorRequiredTxtPhoneNumber',
  OnboardingTaxDeclarationTaxTypeErrorRequiredTxtNumber:
    'OnboardingTaxDeclarationTaxTypeErrorRequiredTxtNumber',
  OnboardingTaxDeclarationCitizenAndResesidencyErrorRequiredDdChooseContry:
    'OnboardingTaxDeclarationCitizenAndResesidencyErrorRequiredDdChooseContry',
  OnboardingTaxDeclarationCitizenAndResesidencyErrorRequiredTxtStateResidency1:
    'OnboardingTaxDeclarationCitizenAndResesidencyErrorRequiredTxtStateResidency1',
  OnboardingTaxDeclarationCitizenAndResesidencyErrorRequiredTxtStateResidency2:
    'OnboardingTaxDeclarationCitizenAndResesidencyErrorRequiredTxtStateResidency2',
  onboarding_comparecreditcard_error_required_ddcreditcard1:
    'onboarding_comparecreditcard_error_required_ddcreditcard1',
  onboarding_comparecreditcard_error_required_ddcreditcard2:
    'onboarding_comparecreditcard_error_required_ddcreditcard2',
  OnboardingEmailErrorRequiredtxtEmail: 'OnboardingEmailErrorRequiredtxtEmail',
  OnboardingEmailErrorRequiredtxtRepeatemail:
    'OnboardingEmailErrorRequiredtxtRepeatemail',
  OnboardingEmailErrorRequiredcheckbox1:
    'OnboardingEmailErrorRequiredcheckbox1',
  OnboardingEmailErrorRequiredcheckbox2:
    'OnboardingEmailErrorRequiredcheckbox2',
  OnboardingEmailErrorMusttxtEmail: 'OnboardingEmailErrorMusttxtEmail',
  OnboardingEmailErrorMusttxtRepeatemail:
    'OnboardingEmailErrorMusttxtRepeatemail',
  OnboardingEmailsErrorMustMatchtxtEmail: 'Emails do not match',
  OnboardingAccountPurposeErrorRequiredTxtOther:
    'OnboardingAccountPurposeErrorRequiredTxtOther',
  OnboardingIdVerificationErrorRequiredTxtNationalIdIqama:
    'OnboardingIdVerificationErrorRequiredTxtNationalIdIqama',
  OnboardingIdVerificationErrorInvalidTxtNationalIdIqama:
    'OnboardingIdVerificationErrorInvalidTxtNationalIdIqama',
  OnboardingIdVerificationErrorRequiredTxtPhoneNumber:
    'OnboardingIdVerificationErrorRequiredTxtPhoneNumber',
  OnboardingIdVerificationErrorInvalidTxtPhoneNumber:
    'OnboardingIdVerificationErrorInvalidTxtPhoneNumber',
  OnboardingMonthlyExpensesErrorRequiredtxteEducation:
    'OnboardingMonthlyExpensesErrorRequiredtxteEducation',
  OnboardingMonthlyExpensesErrorRequiredtxtFood:
    'OnboardingMonthlyExpensesErrorRequiredtxtFood',
  OnboardingMonthlyExpensesErrorRequiredtxtMedical:
    'OnboardingMonthlyExpensesErrorRequiredtxtMedical',
  OnboardingMonthlyExpensesErrorRequiredtxtTransportation:
    'OnboardingMonthlyExpensesErrorRequiredtxtTransportation',
  OnboardingMonthlyExpensesErrorRequiredtxtUtilityBills:
    'OnboardingMonthlyExpensesErrorRequiredtxtUtilityBills',
  OnboardingMonthlyExpensesErrorRequiredtxtDomensticLabor:
    'OnboardingMonthlyExpensesErrorRequiredtxtDomensticLabor',
  OnboardingMonthlyExpensesErrorRequiredtxtFinancial:
    'OnboardingMonthlyExpensesErrorRequiredtxtFinancial',
  OnboardingMonthlyExpensesErrorRequiredtxtExpected:
    'OnboardingMonthlyExpensesErrorRequiredtxtExpected',
  OnboardingMonthlyExpensesErrorRequiredtxtMonthlyRent:
    'OnboardingMonthlyExpensesErrorRequiredtxtMonthlyRent',
  OnboardingTransferMoneyErrorrequiredDdCountries:
    'OnboardingTransferMoneyErrorrequiredDdCountries',
  OnboardingEPromissoryPortalErrorrequiredDdCity:
    'OnboardingEPromissoryPortalErrorrequiredDdCity',
  AuthenticationLoginErrorRequiredTxtId:
    'AuthenticationLoginErrorRequiredTxtId',
  AuthenticationLoginErrorRequiredTxtPassword:
    'AuthenticationLoginErrorRequiredTxtPassword',
  AuthenticationCreatePasscodeErrorRequiredLblPasscode:
    'AuthenticationCreatePasscodeErrorRequiredLblPasscode',
  AuthenticationCreatePasscodeErrorRequiredLblRptPasscode:
    'AuthenticationCreatePasscodeErrorRequiredLblRptPasscode',
  AuthenticationLoginByPwdErrorRequiredTxtPwd:
    'AuthenticationLoginByPwdErrorRequiredTxtPwd',
  AuthenticationEnterOtpErrorRequiredTxtOtp:
    'AuthenticationEnterOtpErrorRequiredTxtOtp',
  OnboardingTaxDeclarationIdentificationErrorRequiredDdReason:
    'OnboardingTaxDeclarationIdentificationErrorRequiredTxtReason',
  OnboardingTaxDeclarationIdentificationNumberErrorRequiredTxtIdentificationNumber:
    'OnboardingTaxDeclarationIdentificationNumberErrorRequiredTxtIdentificationNumber',
  OnboardingTaxDeclarationStatusErrorRequiredDdChooseContry:
    'OnboardingTaxDeclarationStatusErrorRequiredDdChooseContry',
  OnboardingTaxDeclarationStatusErrorRequiredTxtStateResidency:
    'OnboardingTaxDeclarationStatusErrorRequiredTxtStateResidency',
  AuthenticationCredentialsRecoveryTxtAtleasttendigits:
    'AuthenticationCredentialsRecoveryTxtAtleasttendigits',
  AuthenticationCredentialsRecoveryTxtOnlydigitsallowed:
    'AuthenticationCredentialsRecoveryTxtOnlydigitsallowed',
  AuthenticationCredentialsRecoveryTxtErrorrequiredenterid:
    'AuthenticationCredentialsRecoveryTxtErrorrequiredenterid',
  AuthenticationCredentialsRecoveryTxtErrorrequiredemail:
    'AuthenticationCredentialsRecoveryTxtErrorrequiredemail',
  AuthenticationCredentialsRecoveryTxtErrorrequirediban:
    'AuthenticationCredentialsRecoveryTxtErrorrequirediban',
  AuthenticationCredentialsRecoveryTxtErrorrequireddebitcard:
    'AuthenticationCredentialsRecoveryTxtErrorrequireddebitcard',
  OnboardingEnterNameErrorrequiredTxtFirstName:
    'OnboardingEnterNameErrorrequiredTxtFirstName',
  OnboardingEnterNameErrorrequiredTxtSecondName:
    'OnboardingEnterNameErrorrequiredTxtSecondName',
  OnboardingEnterNameErrorrequiredTxtThirdName:
    'OnboardingEnterNameErrorrequiredTxtThirdName',
  OnboardingEnterNameErrorrequiredTxtFamilyName:
    'OnboardingEnterNameErrorrequiredTxtFamilyName',
  OnboardingHomeAddressErrorrequiredTxtStreetAddress:
    'OnboardingHomeAddressErrorrequiredTxtStreetAddress',
  OnboardingHomeAddressErrorrequiredTxtStreetAddress2:
    'OnboardingHomeAddressErrorrequiredTxtStreetAddress2',
  OnboardingHomeAddressErrorrequiredTxtCity:
    'OnboardingHomeAddressErrorrequiredTxtCity',
  OnboardingHomeAddressErrorrequiredTxtZipCode:
    'OnboardingHomeAddressErrorrequiredTxtZipCode',
  OnboardingHomeAddressErrorrequiredDdCountry:
    'OnboardingHomeAddressErrorrequiredDdCountry',
  OnboardingEmploymentDetailsErrorRequiredDdJobTitle:
    'OnboardingEmploymentDetailsErrorRequiredDdJobTitle',
  OnboardingEmploymentDetailsErrorRequiredDdPeriodInCurrentJob:
    'OnboardingEmploymentDetailsErrorRequiredDdPeriodInCurrentJob',
  OnboardingEmploymentDetailsErrorRequiredTxtWorkContactNumber:
    'OnboardingEmploymentDetailsErrorRequiredTxtWorkContactNumber',
  OnboardingAboutAddtionalIncomeErrorRequiredDdMonthlyIncome:
    'OnboardingAboutAddtionalIncomeErrorRequiredDdMonthlyIncome',
  AuthenticationCreatePasswordTxtErrorrequiredpassword:
    'AuthenticationCreatePasswordTxtErrorrequiredpassword',
  AuthenticationCreatePasswordTxtErrorrequiredrepassword:
    'AuthenticationCreatePasswordTxtErrorrequiredrepassword',
  AuthenticationCreatePasswordErrorPasswordMismatch:
    'AuthenticationCreatePasswordErrorPasswordMismatch',
};

// Handling error
const handleApiError = (error: {response: {status: never}}) => {
  if (error?.response) {
    const {status} = error.response;
    if (status === 401) {
      // Handle unauthorized error
      // Example: Redirect to login page
      return {message: Errors.api_code_error_401};
    } else if (status === 404) {
      // Handle not found error
      // Example: Show a custom error message
      return {message: Errors.api_code_error_404};
    } else if (status >= 400 && status < 500) {
      // Handle other client errors
      // Example: Show a generic error message
      // data.error = "400:Bad Request";
      // throw new Error(data.error || 'Something went Wrong');
      return {message: Errors.something_went_wrong};
    } else if (status >= 500) {
      // Handle server errors
      // Example: Show a generic error message
      return {message: Errors.server_error};
    } else {
      return error;
    }
  }
  return {message: Errors.network_error};
};

export {Errors, handleApiError};
