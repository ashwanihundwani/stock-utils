import {useEffect, useState} from 'react';
import {appcolors} from './color';

export const useAppTheme = () => {
  const [mode, setMode] = useState('light');
  const [theme, setTheme] = useState(lightTheme);
  useEffect(() => {
    switch (mode) {
      case 'light':
        setTheme(lightTheme);
        break;
      case 'dark':
        setTheme(darkTheme);
        break;
      default:
        setTheme(lightTheme);
        break;
    }
  }, [mode]);
  return {theme, mode, setMode};
};

export interface Theme {
  text: {
    hightlighted: string;
    hintedTxt: string;
    heading: string;
  };
  background: {
    default: string;
    card: string;
    cardBackground: string;
    mainContentBackground: string;
    header: string;
  };
  inputBox: {
    background: string;
    border: string;
  };
}
// light theme
export const lightTheme: Theme = {
  text: {
    hightlighted: appcolors.light_purple,
    hintedTxt: appcolors.grey,
    heading: appcolors.black,
  },
  background: {
    default: appcolors.white,
    card: appcolors.lightgrey,
    cardBackground: appcolors.white,
    mainContentBackground: appcolors.lightgrey,
    header: appcolors.white,
  },
  inputBox: {
    background: appcolors.lightgrey,
    border: appcolors.grey,
  },
};

// dark theme
export const darkTheme: Theme = {
  text: {
    hightlighted: appcolors.white,
    hintedTxt: appcolors.white,
    heading: appcolors.white,
  },
  background: {
    default: appcolors.card_bg,
    card: appcolors.dark_purple,
    cardBackground: appcolors.card_bg,
    mainContentBackground: appcolors.content_bg,
    header: appcolors.header_bg,
  },
  inputBox: {
    background: appcolors.light_purple,
    border: appcolors.black,
  },
};
