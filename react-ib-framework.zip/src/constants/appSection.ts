export const AppSection = {
  AuthSection: 'AuthSection',
  MainSection: 'MainSection',
};
