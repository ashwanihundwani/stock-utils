const endpoints = {
  userlogin: '/login',
  verifyLoginOtp: '/otp',
};

export default endpoints;
