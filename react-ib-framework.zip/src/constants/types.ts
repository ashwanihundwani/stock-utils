export type IconProps = {
  size?: string;
  color?: string;
};

export const PhoneNumberLength10 = 10;
export const PhoneNumberLength9 = 9;
export const phoneNumberLength15 = 15;
export const MaximumInputLength = 30;
export const MinimumInputLength = 10;
export const MaximumInputLengthPassword = 20;
