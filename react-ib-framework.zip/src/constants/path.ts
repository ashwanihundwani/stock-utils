import {authPath, onboardingDirectDebitPath} from './auth/path';

import {OnBoardingCCPath} from './onboarding-cc/path';
import {OnBoardingDebitCardPath} from './onboarding-debit-card/path';

export const AppPath = {
  ...authPath,
  ...OnBoardingCCPath,
  ...onboardingDirectDebitPath,
  ...OnBoardingDebitCardPath,
};

export const AuthRoutes = {
  AuthWrapper: '/auth',
  LoginScreen: '/auth/login',
  LoginOpt: '/auth/login-otp',
  TrustedBrowser: '/auth/trusted-browser',
  TrustedDeviceScreen: '/auth/trusted-device',
  NonTrustedDevice: '/auth/non-trusted-device',
  TrustedDeviceLinkedUser: '/auth/trusted-device-linke-user',
  TrustedDeviceLimit: '/auth/trusted-device-limit',
  CreateUserNameScreen: '/auth/create-username',
  SetPasswordScreen: '/auth/set-password',
  CredentialUpdateSrceen: '/auth/credential-updated',
  DisableCredentialsInfo: '/auth/disable-credentials-info',
  CredentialsDisableInfo: '/auth/credentials-disable-info',
  CredentialsDisable: '/auth/credentials-disable',
  CredentialsDisabled: '/auth/credentials-disabled',
  CredentialsDisableOtp: '/auth/credentials-disable/otp',
  ResetPassword: '/auth/reset-password',
  ResetPasswordCallback: '/auth/reset-password-callback',
  ResetPasswordSuccess: '/auth/reset-password-success',
  RecoverySelection: '/auth/recovery-selection',
  UsernameRecovery: '/auth/username-recovery',
  UsernameRecoverySuccess: '/auth/username-recovery-success',
  PasswordRecovery: '/auth/password-recovery',
  UsernameRecoveryOtp: '/auth/username-recovery-otp',
  PasswordRecoveryOtp: '/auth/password-recovery-otp',
};
