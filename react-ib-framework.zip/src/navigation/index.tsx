import {useSelector} from 'react-redux';
import {BrowserRouter} from 'react-router-dom';
import {ErrorBoundary} from 'react-error-boundary';
import {ErrorScreen as AppErrorScreen, AppLoader} from 'components';
import {AuthSection} from './auth-routes';
import {getActiveSection} from 'service/app-global';
import {AppSection} from 'constants/appSection';
import {useWindowClose} from 'constants/hooks';
import {MainRoutes} from './main-routes';

const Navigation = () => {
  const activeSection = useSelector(getActiveSection);
  console.log(activeSection, 'activeSection check');
  useWindowClose();

  const AppActiveSection = {
    [AppSection.AuthSection]: <AuthSection />,
    [AppSection.MainSection]: <MainRoutes />,
  };

  return (
    <BrowserRouter>
      <ErrorBoundary FallbackComponent={AppErrorScreen}>
        <AppLoader />
        {activeSection ? AppActiveSection[activeSection] : <AuthSection />}
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Navigation;
