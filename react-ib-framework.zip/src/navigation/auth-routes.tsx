import {Routes, Route} from 'react-router-dom';
import {AppPath, AuthRoutes} from 'constants/path';
import {Suspense} from 'react';
import Loading from 'components/loading';
import {DashboardScreen} from 'features/dashboard';
import {
  LoginScreen,
  LoginOtpScreen,
  TrustedBrowser,
  TrustedDevice,
  NonTrustedDevice,
  TrustedDeviceLinkedUser,
  TrustedDeviceLimit,
  CreateUserNameSrceen,
  SetPasswordSrceen,
  CredentialUpdateSrceen,
  AuthWrapper,
  CredentialsDisableInfo,
  CredentialsDisable,
  CredentialsDisabled,
  ResetPassword,
  ResetPasswordSuccess,
  ResetPasswordCallback,
  RecoverySelection,
  UsernameRecovery,
  UsernameRecoverySuccess,
  PasswordRecovery,
  UsernameRecoveryOtp,
  CredentialsDisableOtp,
  PasswordRecoveryOtp,
} from 'features/auth';
import TrustFailed from 'features/auth/view/manual-onboarding/trust-failed';
import BeforeWeBegin from 'features/onboarding-credit-card/before-we-begin';
import CannotOfferCC from 'features/onboarding-cc/view/cant-offer-credit-card';
import EmploymentDetails from 'features/onboarding-credit-card/employment-details';
import SalaryDetails from 'features/onboarding-credit-card/employment-details/salary-details';
import Layout from 'features/onboarding-cc/view/common/layout';
import SourceOfAdditionalIncome from 'features/onboarding-credit-card/employment-details/source-of-additional-income';
import TellUsAboutAdditionalIncome from 'features/onboarding-credit-card/employment-details/tell-us-about-additional-income';
import {EmployementStatus} from 'features/onboarding-credit-card/employment-status';
import {Disabilities} from 'features/onboarding-credit-card/disabilities';
import {AffiliatedBoardMember} from 'features/onboarding-credit-card/affiliated-board-member';
import {AdditionalMonthlyIncome} from 'features/onboarding-credit-card/additional-monthly-income';
import {EducationLevel} from 'features/onboarding-credit-card/education-level';
import {HousingLevel} from 'features/onboarding-credit-card/housing-level';
import {MaritalStatus} from 'features/onboarding-credit-card/marital-status';
import {NoOfDependents} from 'features/onboarding-credit-card/no-of-dependents';
import {OnboardingCCTitle} from 'features/onboarding-credit-card/onboarding-title';
import {PoliticalyExposedPerson} from 'features/onboarding-credit-card/politically-exposed';
import {PoliticalyExposedRelative} from 'features/onboarding-credit-card/politically-exposed-relative';
import {PurposeOfAccount} from 'features/onboarding-credit-card/purpose-of-account';
import {TaxResident} from 'features/onboarding-credit-card/tax-resident';
import {ShareTruestedDetails} from 'features/onboarding-credit-card/share-trusted-details/indesx';
import GetLatestUpdates from 'features/onboarding-credit-card/get-latest-updates-offer';
import OnboardingMonthlyExpenses from 'features/auth/view/monthly-expenses';
import MonthlyDepositScreen from 'features/auth/view/monthly-amount/monthly-deposit';
import MonthlySalaryScreen from 'features/auth/view/monthly-amount/monthly-salary';
import MonthlyWithdrawScreen from 'features/auth/view/monthly-amount/monthly-withdraw';
import EmailScreen from 'features/onboarding-credit-card/email/email';
import OnboardingIdVerification from 'features/auth/view/id-verify/id-verification';
import NafathAuth from 'features/auth/view/id-verify/nafath-authenticate';
import OtpVerify from 'features/auth/view/otp-verify';
import OnboardingLayout from 'features/onboarding-credit-card/onboardingLayout';
import CompareCreditCard from 'features/onboarding-credit-card/compare-credit-card';
import TaxDecalrationAddCountry from 'features/onboarding-direct-debit/us-flow';
import TypeOfTaxIdentificationNumber from 'features/onboarding-direct-debit/us-flow/type-of-tax-identification-number';
import TaxDeclarationDetails from 'features/onboarding-debit-card/tax-declaration-details';
import TaxIdentificationNum from 'features/onboarding-debit-card/tax-identification-num.tsx';
import CitizenshipDetails from 'features/onboarding-debit-card/citizenship-details';
import CreatCredentialsUserName from 'features/onboarding-credit-card/create-credentials-username';
import CreateCredentialPassword from 'features/onboarding-credit-card/create-credentials-password';
import MoneyTransferCountries from 'features/auth/view/monthly-amount/money-transfer';
import BusinessOwner from 'features/onboarding-debit-card/business-owner';
import HouseWife from 'features/onboarding-debit-card/business-owner/housewife';
import Student from 'features/onboarding-debit-card/business-owner/student';
import {EnterName} from 'features/onboarding-credit-card/enter-name';
import {HomeAddress} from 'features/onboarding-credit-card/home-address/indesx';
import ChooseDebitCard from 'features/onboarding-debit-card/choose-debit-card';
import YourOnePackAccountSetSuccess from 'features/onboarding-cc/view/your-one-pack-account-set';
import DirectDebitPin from 'features/onboarding-direct-debit/common/direct-debit-pin';
import {MonthlyAdditionalIncomeAmount} from 'features/auth/view/monthly-amount/additional-income-amount';

export const AuthSection = () => {
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <>
          <Route
            index
            path={AppPath.OnboardingCreditCard}
            element={<OnboardingLayout />}
          />
          <Route
            index
            path={AppPath.beforeWeBegin}
            element={
              <Layout>
                <BeforeWeBegin />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.EmploymentDetails}
            element={
              <Layout>
                <EmploymentDetails />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.BusinessOwner}
            element={
              <Layout>
                <BusinessOwner />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.HouseWife}
            element={
              <Layout>
                <HouseWife />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.Student}
            element={
              <Layout>
                <Student />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.SalaryDetails}
            element={
              <Layout>
                <SalaryDetails />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.SourceOfAdditionalIncome}
            element={
              <Layout>
                <SourceOfAdditionalIncome />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.TellUsAboutAdditionalIncome}
            element={
              <Layout>
                <TellUsAboutAdditionalIncome />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.CompareCreditCard}
            element={<CompareCreditCard />}
          />
          {/* <Route index path={AppPath.LoginScreen} element={<Login />} /> */}
          <Route path={AppPath.DashboardScreen} element={<DashboardScreen />} />
          <Route index path={AppPath.TrustFailed} element={<TrustFailed />} />

          <Route
            index
            path={AppPath.employmentStatus}
            element={
              <Layout>
                <EmployementStatus />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.CannotOfferCC}
            element={
              <Layout>
                <CannotOfferCC />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.MoneyTransfer}
            element={
              <Layout>
                <MoneyTransferCountries />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.MonthlyDeposits}
            element={
              <Layout>
                <MonthlyDepositScreen />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.MonthlySalary}
            element={
              <Layout>
                <MonthlySalaryScreen />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.MonthlyWithdraw}
            element={
              <Layout>
                <MonthlyWithdrawScreen />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.MonthlyExpenses}
            element={
              <Layout>
                <OnboardingMonthlyExpenses />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.IdVerify}
            element={
              <Layout>
                <OnboardingIdVerification />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.IdOtp}
            element={
              <Layout>
                <OtpVerify screenName={''} nextScreenPath={''} />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.DirectDebitPin}
            element={
              <Layout>
                <DirectDebitPin screenName={''} nextScreenPath={''} />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.Nafath}
            element={
              <Layout>
                <NafathAuth />
              </Layout>
            }
          />
          <Route index path={AppPath.TrustFailed} element={<TrustFailed />} />

          <Route
            index
            path={AppPath.TaxDeclarationAddCountry}
            element={
              <Layout>
                <TaxDecalrationAddCountry />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.EmailScreen}
            element={
              <Layout>
                <EmailScreen />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.TypeOfTaxIdentificationNumber}
            element={
              <Layout>
                <TypeOfTaxIdentificationNumber />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.additionalIncome}
            element={
              <Layout>
                <AdditionalMonthlyIncome />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.boardMember}
            element={
              <Layout>
                <AffiliatedBoardMember />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.disabilities}
            element={
              <Layout>
                <Disabilities />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.housingLevel}
            element={
              <Layout>
                <HousingLevel />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.educationLevel}
            element={
              <Layout>
                <EducationLevel />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.firstNameTitle}
            element={
              <Layout>
                <OnboardingCCTitle />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.maritalStatus}
            element={
              <Layout>
                <MaritalStatus />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.noOfDependents}
            element={
              <Layout>
                <NoOfDependents />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.politicalyExposed}
            element={
              <Layout>
                <PoliticalyExposedPerson />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.politicalyExposedRelative}
            element={
              <Layout>
                <PoliticalyExposedRelative />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.purposeOfAccount}
            element={
              <Layout>
                <PurposeOfAccount />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.shareTrustedDetails}
            element={
              <Layout>
                <ShareTruestedDetails />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.taxResident}
            element={
              <Layout>
                <TaxResident />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.GetLatestUpdates}
            element={
              <Layout>
                <GetLatestUpdates />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.TaxDeclarationDetails}
            element={
              <Layout>
                <TaxDeclarationDetails />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.YourOnePackAccountSetSuccess}
            element={<YourOnePackAccountSetSuccess />}
          />
          <Route
            index
            path={AppPath.TaxIdentificationNumber}
            element={
              <Layout>
                <TaxIdentificationNum />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.CitizenshipDetails}
            element={
              <Layout>
                <CitizenshipDetails />
              </Layout>
            }
          />

          <Route path={AuthRoutes.AuthWrapper} element={<AuthWrapper />}>
            <Route path={AuthRoutes.LoginScreen} element={<LoginScreen />} />
            <Route path={AuthRoutes.LoginOpt} element={<LoginOtpScreen />} />
            <Route
              path={AuthRoutes.TrustedBrowser}
              element={<TrustedBrowser />}
            />
            <Route
              path={AuthRoutes.TrustedDeviceScreen}
              element={<TrustedDevice />}
            />
            <Route
              path={AuthRoutes.NonTrustedDevice}
              element={<NonTrustedDevice />}
            />
            <Route
              path={AuthRoutes.TrustedDeviceLinkedUser}
              element={<TrustedDeviceLinkedUser />}
            />
            <Route
              path={AuthRoutes.TrustedDeviceLimit}
              element={<TrustedDeviceLimit />}
            />
            <Route
              index
              path={AuthRoutes.CreateUserNameScreen}
              element={<CreateUserNameSrceen />}
            />
            <Route
              index
              path={AuthRoutes.SetPasswordScreen}
              element={<SetPasswordSrceen />}
            />
            <Route
              index
              path={AuthRoutes.CredentialUpdateSrceen}
              element={<CredentialUpdateSrceen />}
            />
            <Route
              path={AuthRoutes.CredentialsDisableInfo}
              element={<CredentialsDisableInfo />}
            />
            <Route
              path={AuthRoutes.CredentialsDisable}
              element={<CredentialsDisable />}
            />
            <Route
              path={AuthRoutes.CredentialsDisableOtp}
              element={<CredentialsDisableOtp />}
            />
            <Route
              path={AuthRoutes.CredentialsDisabled}
              element={<CredentialsDisabled />}
            />
            <Route
              path={AuthRoutes.ResetPassword}
              element={<ResetPassword />}
            />
            <Route
              path={AuthRoutes.ResetPasswordCallback}
              element={<ResetPasswordCallback />}
            />
            <Route
              path={AuthRoutes.ResetPasswordSuccess}
              element={<ResetPasswordSuccess />}
            />
            <Route
              path={AuthRoutes.RecoverySelection}
              element={<RecoverySelection />}
            />
            <Route
              path={AuthRoutes.UsernameRecovery}
              element={<UsernameRecovery />}
            />
            <Route
              path={AuthRoutes.UsernameRecoverySuccess}
              element={<UsernameRecoverySuccess />}
            />
            <Route
              path={AuthRoutes.PasswordRecovery}
              element={<PasswordRecovery />}
            />
            <Route
              path={AuthRoutes.UsernameRecoveryOtp}
              element={<UsernameRecoveryOtp />}
            />
            <Route
              path={AuthRoutes.PasswordRecoveryOtp}
              element={<PasswordRecoveryOtp />}
            />
          </Route>

          <Route
            index
            path={AppPath.onboardingCreateUsername}
            element={
              <Layout>
                <CreatCredentialsUserName />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.onboardingcreatePassword}
            element={
              <Layout>
                <CreateCredentialPassword />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.enterName}
            element={
              <Layout>
                <EnterName />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.homeAddress}
            element={
              <Layout>
                <HomeAddress />
              </Layout>
            }
          />
          <Route
            index
            path={AppPath.ChooseDebitCard}
            element={
              <Layout>
                <ChooseDebitCard />
              </Layout>
            }
          />

          <Route
            index
            path={AppPath.monthlyadditionalIncomeAmount}
            element={
              <Layout>
                <MonthlyAdditionalIncomeAmount />
              </Layout>
            }
          />
        </>
      </Routes>
    </Suspense>
  );
};
