import { ContextualThemeKeys } from "./contextual-theme"

export type Colors = Record<ContextualThemeKeys, string>
export type Theme = {
    name: string,
    displayName: string,
    colors: Colors 
    // Border
    // Spacing
}