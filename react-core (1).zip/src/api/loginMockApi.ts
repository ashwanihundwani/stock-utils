import { createApi, BaseQueryFn } from '@reduxjs/toolkit/query/react';
import { FetchBaseQueryError } from '@reduxjs/toolkit/query';

interface LoginResponse {
  success: boolean;
  token?: string;
  message?: string;
}

interface LoginRequest {
  userName: string;
  password: string;
}

interface OtpResponse {
  success: boolean;
  message: string;
}

interface MockQueryArgs {
  url: string;
  method: string;
  body?: unknown;
}

// Mocking the base query for login
const mockBaseQuery: BaseQueryFn<
  MockQueryArgs,
  unknown,
  FetchBaseQueryError
> = async ({ url, method, body }) => {
  await new Promise((resolve) => setTimeout(resolve, 500));
  if (url === '/login' && method === 'POST') {
    const credentials = body as LoginRequest;
    if (
      credentials.userName === 'test' &&
      credentials.password === 'password123'
    ) {
      return { data: { success: true, token: 'mocked-token' } };
    } else {
      return {
        error: { status: 401, data: { message: 'Invalid credentials' } },
      };
    }
  }

  if (url === '/otp' && method === 'POST') {
    return { data: { success: true, message: 'OTP validated successfully' } };
  }

  return { error: { status: 404, data: { message: 'Unknown endpoint' } } };
};

// Create API with mock endpoints
const api = createApi({
  reducerPath: 'api',
  baseQuery: mockBaseQuery, // Using the mock base query
  endpoints: (builder) => ({
    login: builder.mutation<LoginResponse, LoginRequest>({
      query: (credentials) => ({
        url: '/login',
        method: 'POST',
        body: credentials,
      }),
    }),
    validateOtp: builder.mutation<OtpResponse, void>({
      query: () => ({
        url: '/otp',
        method: 'POST',
      }),
    }),
  }),
});

// Export hooks for use in components
export const { useLoginMutation, useValidateOtpMutation } = api;
export default api;
