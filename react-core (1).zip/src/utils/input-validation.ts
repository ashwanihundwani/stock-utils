export const checkMinLength = (value?: string) =>
  !!value && `${value}`.length >= 8;

export const checkMaxLength = (value?: string) =>
  !!value && `${value}`.length >= 8 && `${value}`.length <= 20;

export const checkLowerCase = (value?: string) =>
  !!value && /^(?=.*[a-z])/.test(value);

export const checkUpperCase = (value?: string) =>
  !!value && /^(?=.*[A-Z])/.test(value);

export const checkOneDigit = (value?: string) =>
  !!value && /^(?=.*\d)/.test(value);

export const checkSpecialChar = (value?: string) =>
  !!value && /^(?=.*?[!#$%&*?@^-])/.test(value);
