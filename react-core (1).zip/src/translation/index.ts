/**
 * Translation setup
 * @format
 */

import i18n from 'i18next';
import {
  initReactI18next,
  useTranslation,
  withTranslation,
} from 'react-i18next';

import en from './en.json';
import ar from './ar.json';

type I18nManagerType = {
  isRTL: boolean;
  forceRTL: (isRTL: boolean) => void;
};

let I18nManager: I18nManagerType | undefined;

const resources = {
  en: {
    translation: en,
  },
  ar: {
    translation: ar,
  },
};

/**
 * Initializes i18n with the given I18nManager.
 * @param i18nManager Optional I18nManager for managing RTL settings.
 */
const initI18n = async (i18nManager?: I18nManagerType): Promise<void> => {
  I18nManager = i18nManager;
  try {
    await i18n
      .use(initReactI18next) // Passes i18n down to react-i18next
      .init({
        resources,
        compatibilityJSON: 'v3',
        lng: I18nManager?.isRTL ? 'ar' : 'en',
        fallbackLng: I18nManager?.isRTL ? 'ar' : 'en',
        keySeparator: false, // We do not use keys in form messages.welcome
        interpolation: {
          escapeValue: false, // React already protects against XSS
        },
      });
  } catch (error) {
    console.error('i18n initialization failed:', error);
  }
};

/**
 * Retrieves the current language being used by i18n.
 * @returns The current language code.
 */
const getCurrentLanguage = (): string => {
  return i18n.language || 'en';
};

/**
 * Changes the current language in i18n and updates RTL settings if needed.
 * @param language The language code to switch to (e.g., 'en', 'ar').
 */
const changeI18nLanguage = async (language: string): Promise<void> => {
  try {
    if (I18nManager) {
      I18nManager.forceRTL(i18n.dir(language) === 'rtl');
    }
    await i18n.changeLanguage(language);
  } catch (error) {
    console.error('i18n change language failed:', error);
  }
};

export { initI18n, getCurrentLanguage, changeI18nLanguage };
export { useTranslation, withTranslation };
export default i18n;
