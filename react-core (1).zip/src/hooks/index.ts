import useNewTheme from "./use-new-theme";
import { ConfigProvider, useFeature, useConfiguration } from "./ConfigProvider";
import { ConfigObject } from "./ConfigProvider/types";

export { useNewTheme, ConfigProvider, useFeature, useConfiguration, ConfigObject };