import { Theme } from '../types/theme';
import { useSelector } from 'react-redux';

const useTheme = (): Theme => {
  const themes = useSelector(
    (state: { global: { newThemes: { default: Theme } } }) =>
      state.global.newThemes,
  );
  return themes.default;
};

export default useTheme;
