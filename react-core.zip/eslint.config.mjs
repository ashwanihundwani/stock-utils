

import pluginJs from '@eslint/js';
import globals from 'globals';
import tseslint from 'typescript-eslint';

export default [
  {
    languageOptions: { globals: globals.browser },
  },
  {
    ignores: ['/*', '!/src', '/dist', '**/utils', '**/api', '**/hooks'],
  },
  pluginJs.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ['**/*.ts'],
    rules: {
      '@typescript-eslint/no-empty-function': 'warn',
      "@typescript-eslint/no-explicit-any": "off",
      "@typescript-eslint/no-unused-vars": "warn",
      "@typescript-eslint/no-unused-expressions": "warn",
      "@typescript-eslint/no-empty-object-type": "off",
      "no-unused-vars": "warn",
      "no-undef": "warn",
      "require-yield": "warn",
      // "react/prop-types": "warn",
    },
  },
];