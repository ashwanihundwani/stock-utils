type Primary =
  | 'primary-100'
  | 'primary-90'
  | 'primary-80'
  | 'primary-70'
  | 'primary-60'
  | 'primary-50'
  | 'primary-40'
  | 'primary-30'
  | 'primary-20'
  | 'primary-10'
  | 'primary-00';

type Secondary =
  | 'secondary-100'
  | 'secondary-90'
  | 'secondary-80'
  | 'secondary-70'
  | 'secondary-60'
  | 'secondary-50'
  | 'secondary-40'
  | 'secondary-30'
  | 'secondary-20'
  | 'secondary-10'
  | 'secondary-00';

type Neutral =
  | 'neutral-100'
  | 'neutral-90'
  | 'neutral-80'
  | 'neutral-70'
  | 'neutral-60'
  | 'neutral-50'
  | 'neutral-40'
  | 'neutral-30'
  | 'neutral-20'
  | 'neutral-10'
  | 'neutral-00';

type Grayscale =
  | 'grayscale-100'
  | 'grayscale-90'
  | 'grayscale-80'
  | 'grayscale-70'
  | 'grayscale-60'
  | 'grayscale-50'
  | 'grayscale-40'
  | 'grayscale-30'
  | 'grayscale-20'
  | 'grayscale-10'
  | 'grayscale-00';

type LightOpacity =
  | 'light-opacity-100'
  | 'light-opacity-90'
  | 'light-opacity-80'
  | 'light-opacity-70'
  | 'light-opacity-60'
  | 'light-opacity-50'
  | 'light-opacity-40'
  | 'light-opacity-30'
  | 'light-opacity-20'
  | 'light-opacity-10'
  | 'light-opacity-00';

type DarkOpacity =
  | 'dark-opacity-100'
  | 'dark-opacity-90'
  | 'dark-opacity-80'
  | 'dark-opacity-70'
  | 'dark-opacity-60'
  | 'dark-opacity-50'
  | 'dark-opacity-40'
  | 'dark-opacity-30'
  | 'dark-opacity-20'
  | 'dark-opacity-10'
  | 'dark-opacity-00';

type Semantic =
  | 'semantic-success-100'
  | 'semantic-success-90'
  | 'semantic-success-80'
  | 'semantic-success-70'
  | 'semantic-success-60'
  | 'semantic-success-50'
  | 'semantic-success-40'
  | 'semantic-success-30'
  | 'semantic-success-20'
  | 'semantic-success-10'
  | 'semantic-success-00'
  | 'semantic-info-100'
  | 'semantic-info-90'
  | 'semantic-info-80'
  | 'semantic-info-70'
  | 'semantic-info-60'
  | 'semantic-info-50'
  | 'semantic-info-40'
  | 'semantic-info-30'
  | 'semantic-info-20'
  | 'semantic-info-10'
  | 'semantic-info-00'
  | 'semantic-warning-100'
  | 'semantic-warning-90'
  | 'semantic-warning-80'
  | 'semantic-warning-70'
  | 'semantic-warning-60'
  | 'semantic-warning-50'
  | 'semantic-warning-40'
  | 'semantic-warning-30'
  | 'semantic-warning-20'
  | 'semantic-warning-10'
  | 'semantic-warning-00'
  | 'semantic-error-100'
  | 'semantic-error-90'
  | 'semantic-error-80'
  | 'semantic-error-70'
  | 'semantic-error-60'
  | 'semantic-error-50'
  | 'semantic-error-40'
  | 'semantic-error-30'
  | 'semantic-error-20'
  | 'semantic-error-10'
  | 'semantic-error-00';
type Focus = 'focus-01' | 'focus-02';
type Brand = 'brand-01' | 'brand-02';
type CreditCards = 'credit-card-01' | 'credit-card-02' | 'credit-card-03';
type DebitCards = 'debit-card-01';

export type Color =
  | Primary
  | Secondary
  | Neutral
  | Grayscale
  | LightOpacity
  | DarkOpacity
  | Semantic
  | Focus
  | Brand
  | CreditCards
  | DebitCards;
  
export type BaseTheme = Record<Color, string>;
