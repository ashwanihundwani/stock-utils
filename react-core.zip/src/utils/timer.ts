import { useState, useEffect, useRef } from 'react';

interface UseCountdownTimerProps {
  initialTimeInSeconds: number;
  onTimerComplete?: () => void;
}

const useCountdownTimer = ({
  initialTimeInSeconds,
  onTimerComplete,
}: UseCountdownTimerProps) => {
  const [timeRemaining, setTimeRemaining] =
    useState<number>(initialTimeInSeconds);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setTimeRemaining(initialTimeInSeconds);
  }, [initialTimeInSeconds]);

  //timer logic
  useEffect(() => {
    if (timeRemaining === 0) return;

    intervalRef.current = setInterval(() => {
      setTimeRemaining((prevTime) => {
        if (prevTime <= 1) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
          }
          setTimeout(() => {
            if (onTimerComplete) onTimerComplete();
          }, 0);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timeRemaining, onTimerComplete]);

  const formatTime = (time: number): string => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(
      2,
      '0',
    )}`;
  };

  return { timeRemaining, formatTime };
};

export default useCountdownTimer;
