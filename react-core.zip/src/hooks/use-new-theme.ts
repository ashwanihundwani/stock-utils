import { Theme } from '../types/theme';
import { useSelector } from 'react-redux';

const useTheme = (): Theme => {
    const themes = useSelector((state: any) => state.global.newThemes);
    return themes.default;

    /** Commenting out Theme switcher as part of new theme integration
     * Theme switcher and Theme update from CMS to be implemented
     */
    // const userSegment = 'elite'; //replace with the actual user segment from user data

    // const themes = {
    //   default: defaultTheme,
    // };

    // const filteredThemes = Object.values(themes).filter((themeObject) =>
    //   themeObject.segments.includes(userSegment),
    // );

    // const themePalette = themes[theme] || themes.default;

    // return { themePalette, themeName: theme, filteredThemes };
};

export default useTheme;
