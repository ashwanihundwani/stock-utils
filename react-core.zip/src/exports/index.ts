// Importing from mods
export * as api from '../api';
export * as hooks from '../hooks';
export * as schemas from '../schemas';
export * as translation from '../translation';
export * as constants from '../constants';

/** Translations */
import {
  initI18n,
  useTranslation,
  getCurrentLanguage,
  changeI18nLanguage,
} from '../translation';
export { initI18n, useTranslation, getCurrentLanguage, changeI18nLanguage };

/** Old Theme */
// Deprecated
import { defaultTheme } from '../theme';
export const theme = { defaultTheme };

/** Theme */
import { useNewTheme } from '../hooks';
import { MeemTheme, contextualTheme } from '../new-theme';
import {
  BaseTheme,
  ContextualTheme,
  Theme,
  Color,
  Colors,
} from '../types/theme';
import { mapThemeToColors, useCountdownTimer } from '../utils';

export {
  useNewTheme,
  MeemTheme,
  contextualTheme,
  mapThemeToColors,
  useCountdownTimer,
};
export { BaseTheme, ContextualTheme, Theme, Color, Colors };

/** ConfigProvider */
import {
  ConfigProvider,
  useFeature,
  useConfiguration,
  ConfigObject,
} from '../hooks';

export { ConfigProvider, useFeature, useConfiguration, ConfigObject };
