// src/api/index.ts
import api, { useLoginMutation, useValidateOtpMutation } from "./loginMockApi"; // Import the API from loginMockApi
export { api, useLoginMutation, useValidateOtpMutation }; // Export the api object
export * from "./content-management";
