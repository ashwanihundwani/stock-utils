import { Errors } from "../constants";
import * as yup from "yup";

export const loginSchema = yup.object().shape({
  userName: yup.string().required(Errors.username_required),
  password: yup.string().required(Errors.password_required),
});

export const loginInitialValues = {
  userName: "",
  password: "",
};
