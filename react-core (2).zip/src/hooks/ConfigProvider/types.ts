type SubFeature = {
    name: string;
    enabled: boolean;
};

type Feature = {
    name: string;
    enabled: boolean;
    subFeatures: SubFeature[];
};

type Config = {
    [key: string]: string;
};

type ConfigObject = {
    config: Config;
    features: Feature[];
};

type ConfigContextType = {
    configurations: ConfigObject
    getFeatureStatus: (featureName: string) => boolean;
    getConfigValue: (configName: string) => string;
};

export { ConfigContextType, ConfigObject, SubFeature }