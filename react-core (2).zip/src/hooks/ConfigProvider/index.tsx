import React, { createContext, ReactNode, useContext, useState } from 'react'
import { ConfigContextType, ConfigObject, SubFeature } from './types';

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

export const ConfigProvider = ({ children, configData = { config: {}, features: [] } }: { children: ReactNode, configData: ConfigObject }) => {
    const [configurations] = useState<ConfigObject>(configData)

    const getFeatureStatus = (featureName: string): boolean => {
        const [parentFeatureName, subFeatureName] = featureName.split('.');

        for (const feature of configurations.features) {
            if (feature.name === parentFeatureName) {
                if (!feature.enabled) {
                    return false;
                }
                if (subFeatureName) {
                    const subFeature = feature.subFeatures.find((sub: SubFeature) => sub.name === subFeatureName);
                    return subFeature ? subFeature.enabled : true;
                }
                return feature.enabled;
            }
        }
        return true; // return true if the feature is not found
    };

    const getConfigValue = (configName: string): string => {
        return configurations.config[configName] || '';
    };

    return (
        <ConfigContext.Provider value={{ configurations, getFeatureStatus, getConfigValue }}>
            {children}
        </ConfigContext.Provider>
    );
};

export const useFeature = (featureName: string): boolean => {
    const context = useContext(ConfigContext);
    if (!context) {
        throw new Error('useFeature must be used within a ConfigProvider');
    }
    return context.getFeatureStatus(featureName);
};

export const useConfiguration = (configName: string): string => {
    const context = useContext(ConfigContext);
    if (!context) {
        throw new Error('useConfiguration must be used within a ConfigProvider');
    }
    return context.getConfigValue(configName);
};