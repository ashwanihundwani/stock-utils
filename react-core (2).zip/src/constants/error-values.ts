export const Errors = {
  username_required: "Username is required",
  password_required: "Password is required",
  password_incorrect: "UserName or Password is Incorrect",
  api_code_error_401: "Unauthorized Access",
  api_code_error_404: "Resource Not found",
  something_went_wrong: "Something went wrong",
  server_error: "Internal server error",
  network_error: "Network Error",
};
