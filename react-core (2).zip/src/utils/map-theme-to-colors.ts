import { BaseTheme, Color, ContextualTheme, Colors } from "../types/theme";

const resolveHexCode = (value: string, baseTheme: BaseTheme, visited: Set<string> = new Set()): string => {

    if (value.startsWith("#")) return value

    let colorCode: string = baseTheme[value as Color]
    if (colorCode.startsWith("#")) return colorCode

    if (visited.has(colorCode)) { // Prevent infinite loop due to recursive keys
        return ""
    }

    visited.add(colorCode)
    return resolveHexCode(baseTheme[colorCode], baseTheme, visited)

}

const mapThemeToColors = (baseTheme: BaseTheme, contextualTheme: ContextualTheme): Colors => {

    const themeColors: Record<string, string> = {}

    for (const [key, value] of Object.entries(contextualTheme)) {
        themeColors[key] = resolveHexCode(value, baseTheme)
    }

    return themeColors as Colors

}

export default mapThemeToColors