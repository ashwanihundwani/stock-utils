import mapThemeToColors from "./map-theme-to-colors"

export { mapThemeToColors }