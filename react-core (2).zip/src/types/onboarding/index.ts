export interface TopLevel {
  entityKey: string;
  objects:   Object[];
}

export interface Object {
  id:    string;
  code:  string;
  value: string;
}
