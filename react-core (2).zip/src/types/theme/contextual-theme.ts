import { Color } from './base-theme';

type Background =
  | 'background-01'
  | 'background-02'
  | 'background-03'
  | 'background-04';

type SurfaceBase =
  | 'surface-01'
  | 'surface-02'
  | 'surface-03'
  | 'surface-04'
  | 'surface-05';

type SurfaceInverted =
  | 'surface-inverted-01'
  | 'surface-inverted-02'
  | 'surface-inverted-03'
  | 'surface-inverted-04'
  | 'surface-inverted-05';

type SurfaceInteractivePrimary =
  | 'surface-interactive-primary-enabled'
  | 'surface-interactive-primary-active'
  | 'surface-interactive-primary-disabled'
  | 'surface-interactive-primary-inverted-enabled'
  | 'surface-interactive-primary-inverted-active'
  | 'surface-interactive-primary-inverted-disabled';
type SurfaceInteractiveSecondary =
  | 'surface-interactive-secondary-enabled'
  | 'surface-interactive-secondary-active'
  | 'surface-interactive-secondary-disabled'
  | 'surface-interactive-secondary-inverted-enabled'
  | 'surface-interactive-secondary-inverted-active'
  | 'surface-interactive-secondary-inverted-disabled';
type SurfaceInteractiveTertiary =
  | 'surface-interactive-tertiary-enabled'
  | 'surface-interactive-tertiary-active'
  | 'surface-interactive-tertiary-disabled'
  | 'surface-interactive-tertiary-inverted-enabled'
  | 'surface-interactive-tertiary-inverted-active'
  | 'surface-interactive-tertiary-inverted-disabled';

type SurfaceSemanticSuccess =
  | 'surface-semantic-success-01'
  | 'surface-semantic-success-02'
  | 'surface-semantic-inverted-success-01'
  | 'surface-semantic-inverted-success-02';
type SurfaceSemanticInfo =
  | 'surface-semantic-info-01'
  | 'surface-semantic-info-02'
  | 'surface-semantic-inverted-info-01'
  | 'surface-semantic-inverted-info-02';
type SurfaceSemanticWaning =
  | 'surface-semantic-warning-01'
  | 'surface-semantic-warning-02'
  | 'surface-semantic-inverted-warning-01'
  | 'surface-semantic-inverted-warning-02';
type SurfaceSemanticError =
  | 'surface-semantic-error-01'
  | 'surface-semantic-error-02'
  | 'surface-semantic-inverted-error-01'
  | 'surface-semantic-inverted-error-02';

type SurfaceOverlay =
  | 'surface-overlay-01'
  | 'surface-overlay-02'
  | 'surface-overlay-03'
  | 'surface-overlay-04';

type BorderBase =
  | 'border-enabled-01'
  | 'border-enabled-02'
  | 'border-disabled'
  | 'border-focus'
  | 'border-focus-inverted';
type BorderInverted =
  | 'border-inverted-enabled-01'
  | 'border-inverted-enabled-02'
  | 'border-inverted-disabled';
type BorderInteractive =
  | 'border-interactive-enabled'
  | 'border-interactive-active'
  | 'border-interactive-disabled'
  | 'border-interactive-inverted-enabled'
  | 'border-interactive-inverted-active'
  | 'border-interactive-inverted-disabled';
type BorderSemantic =
  | 'border-semantic-success'
  | 'border-semantic-info'
  | 'border-semantic-warning'
  | 'border-semantic-error'
  | 'border-semantic-success-inverted'
  | 'border-semantic-info-inverted'
  | 'border-semantic-warning-inverted'
  | 'border-semantic-error-inverted';
type BorderOverlay =
  | 'border-overlay-01'
  | 'border-overlay-02'

type ContentBase =
  | 'content-primary'
  | 'content-secondary'
  | 'content-tertiary'
  | 'content-disabled';
type ContentInverted =
  | 'content-inverted-primary'
  | 'content-inverted-secondary'
  | 'content-inverted-tertiary'
  | 'content-inverted-disabled';
type ContentInteractive =
  | 'content-interactive-primary-enabled'
  | 'content-interactive-primary-active'
  | 'content-interactive-primary-disabled'
  | 'content-interactive-secondary-enabled'
  | 'content-interactive-secondary-active'
  | 'content-interactive-secondary-disabled'
  | 'content-interactive-inverted-enabled'
  | 'content-interactive-inverted-active'
  | 'content-interactive-inverted-disabled';
type ContentSemantic =
  | 'content-semantic-success-01'
  | 'content-semantic-success-02'
  | 'content-semantic-info-01'
  | 'content-semantic-info-02'
  | 'content-semantic-warning-01'
  | 'content-semantic-warning-02'
  | 'content-semantic-error-01'
  | 'content-semantic-error-02'
  | 'content-semantic-success-inverted'
  | 'content-semantic-info-inverted'
  | 'content-semantic-warning-inverted'
  | 'content-semantic-error-inverted';

type IconBase =
  | 'icon-primary'
  | 'icon-secondary'
  | 'icon-tertiary'
  | 'icon-disabled';
type IconInverted =
  | 'icon-inverted-primary'
  | 'icon-inverted-secondary'
  | 'icon-inverted-tertiary'
  | 'icon-inverted-disabled';
type IconInterative =
  | 'icon-interactive-primary-enabled'
  | 'icon-interactive-primary-active'
  | 'icon-interactive-primary-disabled'
  | 'icon-interactive-secondary-enabled'
  | 'icon-interactive-secondary-active'
  | 'icon-interactive-secondary-disabled'
  | 'icon-interactive-inverted-enabled'
  | 'icon-interactive-inverted-active'
  | 'icon-interactive-inverted-disabled';
type IconSemantic =
  | 'icon-semantic-success-01'
  | 'icon-semantic-success-02'
  | 'icon-semantic-info-01'
  | 'icon-semantic-info-02'
  | 'icon-semantic-warning-01'
  | 'icon-semantic-warning-02'
  | 'icon-semantic-error-01'
  | 'icon-semantic-error-02'
  | 'icon-semantic-success-inverted'
  | 'icon-semantic-info-inverted'
  | 'icon-semantic-warning-inverted'
  | 'icon-semantic-error-inverted';

type Decorative = 'decorative-01' | 'decorative-02' | 'decorative-03';

type CreditCards = 'ccPlatinum' | 'ccSignature' | 'ccInfinite';

type DebitCards = 'platinum';

type Brand = 'brand-01' | 'brand-02' | 'brand-02';

type Other = 'dark' | 'light';

type SurfaceInteractive =
  | SurfaceInteractivePrimary
  | SurfaceInteractiveSecondary
  | SurfaceInteractiveTertiary;
type SurfaceSemantic =
  | SurfaceSemanticSuccess
  | SurfaceSemanticInfo
  | SurfaceSemanticWaning
  | SurfaceSemanticError;
type Surface =
  | SurfaceBase
  | SurfaceInverted
  | SurfaceInteractive
  | SurfaceSemantic
  | SurfaceOverlay;

type Border = BorderBase | BorderInverted | BorderInteractive | BorderSemantic | BorderOverlay;

type Content =
  | ContentBase
  | ContentInverted
  | ContentInteractive
  | ContentSemantic;

type Icon = IconBase | IconInverted | IconInterative | IconSemantic;

export type ContextualThemeKeys =
  | Background
  | Surface
  | Border
  | Content
  | Icon
  | CreditCards
  | DebitCards
  | Brand
  | Decorative
  | Other;
export type ContextualTheme = Record<ContextualThemeKeys, Color>;
