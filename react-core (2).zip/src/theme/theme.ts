/* App themes */

type Theme = {
  title?: string;
  name?: string;
  segments: string[];
  code: string;
  colors: {
    primary: string;
    secondary: string;
    white: string;
    whiteConst: string;
    black: string;
    blackConst: string;
    grey: string;
    constantgrey: string;
    red?: string;
    graphGreen: string;
    graphLightGreen: string;
    graphOrange: string;
    graphBrown: string;
    lightWhite?: string;
    darkgrey: string;
    extragrey: string;
    border: string;
    background: string;
    backgroundBlue?: string;
    backgroundBrown?: string;
    gold: string;
    gray98: string;
    blue: string;
    activeMenuColor: string;
    lightBlue: string;
    blueLavender: string;
    extraDarkGrey: string;
    textBlue?: string;
    borderBlueShade?: string;
    floatingActionItem: string;
    darkBlue?: string;
    green: string;
    placeholder: string;
    transparent: string;
    progressbar: string;
    lightPurple: string;
    deep_purple: string;
    lightBlue2: string;
    viewBlue: string;
    golden: string;
    light_grey: string;
    light_purple: string;
    dashboardcontainer: string;
    menucolor: string;
    lightGrey?: string;
    ligthGreen?: string;
    errorTextColor: string;
    bannerpurple: string;
    txt_grey: string;
    greyExtra?: string;
    Text: {
      primary: string;
      secondary?: string;
      title: string;
      subTitle: string;
      light_purple?: string;
      remeber_me: string;
      light_txt_grey: string;
      tertiary: string;
      darkGrey: string;
      error: string;
      success: string;
      greyExtra?: string;
      Label?: string;
    };
    txt: {
      primary: string;
      secondary: string;
      tertiary: string;
    };
    Icon: {
      primary: string;
      white?: string;
      light?: string;
      secondary?: string;
    };
    button: {
      purple: string;
      navy_blue: string;
      primary?: string;
      secondary?: string;
      tertiary?: string;
    };
    toggleSwitch: {
      backgroundColor: string;
      activeBackgroundColor: string;
      borderColor: string;
      buttonColor: string;
      activeButtonColor: string;
    };
    transferlabel_grey: string;
    close_lightgrey: string;
    line_grey: string;
    hairline_grey: string;
    purpleLine: string;
    mossGreen: string;
    lightNavy: string;
    Violet: string;
    bluetext: string;
    Temp: {
      primary: string;
      title: string;
      subTitle: string;
      light_purple: string;
      remeber_me: string;
      light_txt_grey: string;
      grey: string;
      lightBlue: string;
    };
    newTheme: {
      background: {
        light: string;
        white: string;
        purple95: string;
        purple: string;
        purple60: string;
      };
      Icon: {
        purple60: string;
        white: string;
        black: string;
        purple: string;
      };
      Text: {
        purple60: string;
        white: string;
        black: string;
        purple: string;
        red: string;
        green: string;
      };
      border: {
        purple70: string;
        light: string;
        white: string;
        purple95: string;
        purple: string;
        purple60: string;
      };
    };
  };
};
const defaultTheme: Theme = {
  segments: ["public", "private", "elite"],
  name: "defaultTheme",
  colors: {
    primary: "#270660",
    secondary: "#F7F3E7",
    white: "#FFFFFF",
    whiteConst: "#FFFFFF",
    black: "#000000",
    blackConst: "#000000",
    grey: "#ededed",
    constantgrey: "#ededed",
    red: "#ea0068",
    graphGreen: "#5ADCA2",
    graphLightGreen: "#B3E1CC",
    graphOrange: "#FD973F",
    graphBrown: "#BC9574",
    lightWhite: "#808080",
    darkgrey: "#c3c3c3",
    extragrey: "#c3c3c3",
    border: "#c3c3c3",
    background: "white",
    backgroundBlue: "#270660",
    backgroundBrown: "#2b1d0e",
    gold: "#270660",
    gray98: "#fafafa",
    blue: "#270660",
    activeMenuColor: "#675B8B",
    lightBlue: "#6e39d6",
    blueLavender: "#CABFCF",
    extraDarkGrey: "#757575",
    textBlue: "#50069b",
    borderBlueShade: "#1b0443",
    floatingActionItem: "#6e39d6",
    darkBlue: "#130330",
    green: "#00C4AC",
    placeholder: "#c3c3c3",
    transparent: "transparent",
    progressbar: "#6e39d6",
    lightPurple: "#DA70D6",
    deep_purple: "#9C27B0",
    lightBlue2: "#F6F6F7",
    viewBlue: "#F0F0F1",
    golden: "#F2CA46",
    light_grey: "#EDE7F6",
    light_purple: "#d1cbd6",
    dashboardcontainer: "#FFFF",
    menucolor: "#CABFCF",
    lightGrey: "#E6E6E6",
    ligthGreen: "#78E6EA",
    errorTextColor: "#ff0033",
    bannerpurple: "#8200FE",
    txt_grey: "#270660",
    greyExtra: "#404040",
    Text: {
      primary: "#FFFFFF",
      secondary: "#000000",
      title: "#232124",
      subTitle: "#686868",
      light_purple: "#d1cbd6",
      remeber_me: "black",
      light_txt_grey: "#270660",
      tertiary: "#000000",
      darkGrey: "darkgrey",
      error: "#ea0068",
      success: "#5ADCA2",
    },
    txt: {
      primary: "#000000",
      secondary: "#1e074c",
      tertiary: "#424242",
    },
    Icon: {
      primary: "black",
      white: "#ffffff",
      light: "#EEEFEF",
    },
    button: {
      purple: "#270660",
      navy_blue: "#1E074C",
      primary: "#270660",
      secondary: "#FFFFFF",
      tertiary: "#270660",
    },
    toggleSwitch: {
      backgroundColor: "#ffffff",
      activeBackgroundColor: "#270660",
      borderColor: "#c3c3c3",
      buttonColor: "#c3c3c3",
      activeButtonColor: "#ffffff",
    },
    transferlabel_grey: "#818589",
    close_lightgrey: "#AA98A9",
    line_grey: "#A2A2A2",
    hairline_grey: "#E8E8E8",
    purpleLine: "#8924E5",
    mossGreen: "#8A9A5B",
    lightNavy: "#323291",
    Violet: "#D4ACFF",
    bluetext: "#3F1887",
    Temp: {
      primary: "#270660",
      title: "#232124",
      subTitle: "#686868",
      light_purple: "#d1cbd6",
      remeber_me: "black",
      light_txt_grey: "#270660",
      grey: "#ededed",
      lightBlue: "#6e39d6",
    },
    newTheme: {
      background: {
        light: "#EEEFEF",
        white: "#ffffff",
        purple95: "#efe7fd",
        purple: "#270660",
        purple60: "#813ff3",
      },
      Icon: {
        purple60: "#813ff3",
        white: "#ffffff",
        black: "black",
        purple: "#270660",
      },
      Text: {
        purple60: "#813ff3",
        white: "#ffffff",
        black: "black",
        purple: "#270660",
        red: "red",
        green: "green",
      },
      border: {
        purple70: "#a16ff6",
        light: "#EEEFEF",
        white: "#ffffff",
        purple95: "#efe7fd",
        purple: "#270660",
        purple60: "#813ff3",
      },
    },
  },
  code: "default",
};

export type themeType = typeof defaultTheme;

export { defaultTheme };
