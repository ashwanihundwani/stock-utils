/**
 * Translation
 * @format
 */

import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import en from './en.json';
import ar from './ar.json';

let I18nManager: any

const resources = {
  en: {
    translation: en,
  },
  ar: {
    translation: ar,
  },
};

const initI18n = (i18nManager?: any) => {
  I18nManager = i18nManager
  i18n
    .use(initReactI18next) // passes i18n down to react-i18next
    .init({
      resources,
      compatibilityJSON: 'v3',
      lng: I18nManager?.isRTL ? 'ar' : 'en',
      fallbackLng: I18nManager?.isRTL ? 'ar' : 'en',
      keySeparator: false, // we do not use keys in form messages.welcome
      interpolation: {
        escapeValue: false, // react already safes from xss
      },
    });
}

const getCurrentLanguage = () => {
  return i18n.languages[0];
};

const changeI18nLanguage = (language: string) => {
  if (I18nManager) {
    I18nManager.forceRTL(i18n.dir(language) === 'rtl');
  }
  i18n.changeLanguage(language);
};

export { initI18n, getCurrentLanguage, changeI18nLanguage };

export { useTranslation, withTranslation } from 'react-i18next';
export { default as i18n, default } from 'i18next';
