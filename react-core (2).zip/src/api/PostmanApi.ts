import { createApi } from "@reduxjs/toolkit/query/react";
import { customFetchBaseQuery, mockBaseQuery } from "./Uitils";
import { Endpoint } from "./mock/mockvalues";

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

interface ApiParams {
  baseUrl: string;
  useMockApi: boolean;
  headers?: Record<string, string>;
}

interface ApiResponses {
  "/get": ApiResponse<any>;
  "/post": ApiResponse<any>;
}

const endpointList: Endpoint[] = [
  {
    url: "/get",
    method: "GET",
  },
  {
    url: "/post",
    method: "POST",
  },
];

const PostmanEchoResponse = {
  message: "Request successful",
};

const PostmanEchoPostResponse = {
  data: "Post request received",
};

export const createPostmanApi = ({
  baseUrl,
  useMockApi,
  headers,
}: ApiParams) => {
  return createApi({
    reducerPath: "postmanApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      const responses: ApiResponses = {
        "/get": { success: true, data: PostmanEchoResponse },
        "/post": { success: true, data: PostmanEchoPostResponse },
      };

      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url], endpointList);
      } else {
        return await customFetchBaseQuery(baseUrl, headers)(
          args,
          api,
          extraOptions
        );
      }
    },
    endpoints: (builder) => ({
      getData: builder.query<any, void>({
        query: () => ({
          url: "/get",
          method: "GET",
        }),
      }),
      postData: builder.mutation<any, { name: string }>({
        query: (body) => ({
          url: "/post",
          method: "POST",
          body,
        }),
      }),
    }),
  });
};

export const { useGetDataQuery, usePostDataMutation } = createPostmanApi({
  baseUrl: "https://postman-echo.com",
  useMockApi: false,
  headers: { "Custom-Header": "CustomValue" },
});
