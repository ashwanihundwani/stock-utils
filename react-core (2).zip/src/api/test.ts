import { createApi } from "@reduxjs/toolkit/query/react";
import { ApiParams, customFetchBaseQuery, mockBaseQuery } from "./Uitils";
import {
  OtpRequest,
  endpointList,
  LoginRequest,
  LoginResponse,
  ApiResponses,
  OtpResponse,
} from "./mock/mockvalues";

export const createLoginApi = ({ baseUrl, useMockApi, headers }: ApiParams) => {
  return createApi({
    reducerPath: "loginApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      const responses: ApiResponses = {
        "/login": { success: true, data: LoginResponse },
        "/otp": { success: true, data: OtpResponse },
      };

      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url], endpointList);
      } else {
        return await customFetchBaseQuery(baseUrl, headers)(
          args,
          api,
          extraOptions
        );
      }
    },
    endpoints: (builder) => ({
      login: builder.mutation<any, typeof LoginRequest>({
        query: (credentials) => {
          return {
            url: "/login",
            method: "POST",
            body: credentials,
          };
        },
      }),
      validateOtp: builder.mutation<any, typeof OtpRequest>({
        query: (otp) => {
          return {
            url: "/otp",
            method: "POST",
            body: otp,
          };
        },
      }),
    }),
  });
};

export const { useLoginMutation, useValidateOtpMutation } = createLoginApi({
  baseUrl: "https://api.example.com",
  useMockApi: false,
  headers: { "Custom-Header": "CustomValue" },
});
