import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

interface Post {
  id: number;
  title: string;
  body: string;
}

interface AddPostResponse {
  data: Post;
}

interface GetPostsResponse {
  data: Post[];
}

export const postsApi = createApi({
  reducerPath: "postsApi",
  baseQuery: fetchBaseQuery({
    baseUrl: "https://jsonplaceholder.typicode.com/",
  }),
  tagTypes: ["Posts"],
  endpoints: (builder) => ({
    getPosts: builder.query<GetPostsResponse, void>({
      query: () => "posts",
      providesTags: ["Posts"],
    }),
    addPost: builder.mutation<AddPostResponse, { title: string; body: string }>(
      {
        query: (newPost) => ({
          url: "posts",
          method: "POST",
          body: newPost,
        }),
        invalidatesTags: ["Posts"],
      }
    ),
    deletePost: builder.mutation<void, number>({
      query: (postId) => ({
        url: `posts/${postId}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Posts"],
    }),
  }),
});

export const { useGetPostsQuery, useAddPostMutation, useDeletePostMutation } =
  postsApi;
