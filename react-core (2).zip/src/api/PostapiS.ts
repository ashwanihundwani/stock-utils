import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

interface Post {
  id: number;
  title: string;
  body: string;
}

interface AddPostResponse {
  data: Post;
}

interface GetPostsResponse {
  data: Post[];
}

export const postsApiS = createApi({
  reducerPath: "postsApiS",
  baseQuery: fetchBaseQuery({
    baseUrl: "https://jsonplaceholder.typicode.com/",
  }),
  tagTypes: ["Posts"],
  endpoints: (builder) => ({
    getTPosts: builder.query<GetPostsResponse, void>({
      query: () => "posts",
      providesTags: ["Posts"],
    }),
    addTPost: builder.mutation<
      AddPostResponse,
      { title: string; body: string }
    >({
      query: (newPost) => ({
        url: "posts",
        method: "POST",
        body: newPost,
      }),

      onQueryStarted: async (newPost, { dispatch, queryFulfilled }) => {
        try {
          await queryFulfilled;
          dispatch(
            postsApiS.util.invalidateTags([{ type: "Posts", id: "LIST" }])
          );
        } catch (error) {
          console.error("Mutation failed:", error);
        }
      },
    }),
    deleteTPost: builder.mutation<void, number>({
      query: (postId) => ({
        url: `posts/${postId}`,
        method: "DELETE",
      }),
      onQueryStarted: async (postId, { dispatch, queryFulfilled }) => {
        try {
          await queryFulfilled;
          dispatch(
            postsApiS.util.invalidateTags([{ type: "Posts", id: "LIST" }])
          );
        } catch (error) {
          console.error("Mutation failed:", error);
        }
      },
    }),
  }),
});

export const {
  useAddTPostMutation,
  useGetTPostsQuery,
  useDeleteTPostMutation,
} = postsApiS;
