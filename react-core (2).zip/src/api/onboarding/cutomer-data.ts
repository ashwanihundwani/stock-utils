export const RetrivedData = [
    {
        "uiState": "Email_Verfication_Completed",
        "data": [
            {
                "fieldKey": "emailAddress",
                "value": "testdata@gmail.com"
            }
        ]
    },
    {
        "uiState": "Personal_Details_Completed",
        "data": [
            {
                "fieldKey": "title",
                "value": "Ms"
            },
            {
                "fieldKey": "familyStatusCode",
                "value": "Single"
            },
            {
                "fieldKey": "numberOfDependents",
                "value": "1"
            },
            {
                "fieldKey": "levelOfEducationId",
                "value": "Graduate"
            },
            {
                "fieldKey": "housingDetails",
                "value": "Family Home"
            }
        ]
    },
    {
        "uiState": "Account_Purpose_Completed",
        "data": [
            {
                "fieldKey": "otherpurpose",
                "value": "Other"
            },
            {
                "fieldKey": "expectedCountryToTransfer1",
                "value": "Afghanistan"
            },
            {
                "fieldKey": "expectedCountryToTransfer2",
                "value": "Albania"
            },
            {
                "fieldKey": "expectedCountryToTransfer3",
                "value": "Angeria"
            },
            {
                "fieldKey": "totalDeposits",
                "value": "100"
            },
            {
                "fieldKey": "educationExpenses",
                "value": "1"
            },
            {
                "fieldKey": "foodBeveragesExpenses",
                "value": "2"
            },
            {
                "fieldKey": "medicalInsuranceExpenses",
                "value": "3"
            },
            {
                "fieldKey": "transportationExpenses",
                "value": "4"
            },
            {
                "fieldKey": "utilitiesBill",
                "value": "5"
            },
            {
                "fieldKey": "domesticLabor",
                "value": "6"
            },
            {
                "fieldKey": "loanFromFriendsRelatives",
                "value": "7"
            },
            {
                "fieldKey": "expectedFutureExpenses",
                "value": "8"
            },
            {
                "fieldKey": "totalMonthlyExpenses",
                "value": "45.00"
            },
            {
                "fieldKey": "housingRent",
                "value": "9"
            }
        ]
    },
    {
        "uiState": "Employment_Details_Completed",
        "data": [
            {
                "fieldKey": "employer",
                "value": "Aramco"
            },
            {
                "fieldKey": "occupationCategory",
                "value": "Value for OCP"
            },
            {
                "fieldKey": "occupationCategoryGroup",
                "value": "Public"
            },
            {
                "fieldKey": "totalWorkExperience",
                "value": "0 - 2"
            },
            {
                "fieldKey": "periodInCurrentEmployment",
                "value": "1 - 2"
            },
            {
                "fieldKey": "validVisaStatus",
                "value": "1234567890"
            },
            {
                "fieldKey": "bankWhereSalaryPaid",
                "value": "Alrajhi"
            },
            {
                "fieldKey": "salaryAccOpenYears",
                "value": "1 - 5"
            },
            {
                "fieldKey": "autoPaymentsType",
                "value": "Others"
            },
            {
                "fieldKey": "monthlySalary",
                "value": "200"
            }
        ]
    },
    {
        "uiState": "Additional_Information_Completed",
        "data": [
            {
                "fieldKey": "additionalIncome",
                "value": "SAR 5,000 and below"
            },
            {
                "fieldKey": "typeOfAdditionalIncome",
                "value": "Self-employed"
            },
            {
                "fieldKey": "fullName",
                "value": "test"
            },
            {
                "fieldKey": "relationship",
                "value": "undefined"
            },
            {
                "fieldKey": "mobileNumber",
                "value": "1234567890"
            }
        ]
    },
    {
        "uiState": "TAXandPEP_Details_Completed",
        "data": [
            {
                "fieldKey": "taxResourcesOutsideKSA",
                "value": "Yes"
            },
            {
                "fieldKey": "declaredCountryOfBirth",
                "value": "Afghanistan"
            },
            {
                "fieldKey": "cityOfBirth",
                "value": "test"
            },
            {
                "fieldKey": "isUSResident",
                "value": "Yes"
            },
            {
                "fieldKey": "waselAddress",
                "value": "data"
            },
            {
                "fieldKey": "taxCountry1",
                "value": "Albania"
            },
            {
                "fieldKey": "taxCountryAddress1",
                "value": "Albania"
            },
            {
                "fieldKey": "taxState1",
                "value": "tax resident"
            },
            {
                "fieldKey": "taxCountry2",
                "value": "Albania"
            },
            {
                "fieldKey": "taxTelehone1",
                "value": "123333333333333"
            },
            {
                "fieldKey": "taxCountryAddress2",
                "value": "resident address"
            },
            {
                "fieldKey": "taxState2",
                "value": "state"
            },
            {
                "fieldKey": "taxTelehone2",
                "value": "123333333333333"
            },
            {
                "fieldKey": "taxIdentificationType",
                "value": "TIN - Tax Identification Number"
            },
            {
                "fieldKey": "taxIdentificationNumber",
                "value": "1111111111"
            },
            {
                "fieldKey": "countryOfCitizenShip1",
                "value": "Andorra"
            },
            {
                "fieldKey": "countryOfImmigrantVisa1",
                "value": "Angeria"
            },
            {
                "fieldKey": "residencyState1",
                "value": "11111111"
            },
            {
                "fieldKey": "residencyState2",
                "value": "2222222222222"
            },
            {
                "fieldKey": "isPoliticallyExposedPerson",
                "value": "Yes"
            },
            {
                "fieldKey": "isSecondDegreePeprelative",
                "value": "Yes"
            },
            {
                "fieldKey": "isPersonWithDisabilities",
                "value": "No"
            }
        ]
    },
    {
        "uiState": "Notification_Preferrance_Completed",
        "data": [
            {
                "fieldKey": "hearAboutMeem",
                "value": "Social media"
            },
            {
                "fieldKey": "channel",
                "value": "undefined"
            }
        ]
    }
]