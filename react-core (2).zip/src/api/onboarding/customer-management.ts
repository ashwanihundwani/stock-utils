import { createApi } from "@reduxjs/toolkit/query/react";
import { ApiParams, customFetchBaseQuery, mockBaseQuery } from "../../utils/api-helper";
 
// interface  definition block
interface Endpoint {
  url: string;
  method: string;
}
 
interface ApiResponse<T> {
  data: T;
}
 
interface EvaluateUserNameRequest {
  userName: string;
}
 
interface EvaluateUserNameResponse {
  isUserNameExists: boolean;
}

interface RegisterUserCredentialsRequest{
  firstName: string,
  lastName: string,
  nationalId: string,
  userName:string,
  password: string,
  mobileNumber: string
}

interface RegisterUserCredentialsResponse{
    id: string,
    isSuccess: boolean
}
 
const EvaluateUserNameResponse = {
  isUserNameExists: true,
};
 
const EvaluateUserNameRequest = {
  userName: "username",
};

const RegisterUserCredentialsRequest={
  firstName: "testUser",
  lastName: "testUser",
  nationalId: "2131356517",
  userName: "ANk7RuFXIcVTFie4u",
  password: "password",
  mobileNumber: "87876768977"
}

const RegisterUserCredentialsResponse={
  id: 'test-id',
  isSuccess: true
}
interface ApiResponses {
  "/evaluate-username": ApiResponse<EvaluateUserNameResponse>;
  "/register-user-credentials":ApiResponse<RegisterUserCredentialsResponse>
}
 
// endpoint registration block
const endpointList: Endpoint[] = [
  {
    url: "/evaluate-username",
    method: "POST",
  },
  {
    url: "/register-user-credentials",
    method: "POST",
  },
];
 
 
export const customerManagementApi = ({
  baseUrl,
  useMockApi,
  headers,
}: ApiParams) => {
  return createApi({
    reducerPath: "customerManagementApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      // Dynamic responses registration
      const responses: ApiResponses = {
        "/evaluate-username": { data: EvaluateUserNameResponse },
        "/register-user-credentials":{data:RegisterUserCredentialsResponse}
      };
 
      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url],endpointList);
      } else {
        return await customFetchBaseQuery(baseUrl, headers)(
          args,
          api,
          extraOptions
        );
      }
    },
    endpoints: (builder) => ({
      evaluateUserName: builder.mutation<any, typeof EvaluateUserNameRequest>({
        query: (entityKey) => {
          return {
            url: "/evaluate-username",
            method: "POST",
            body: entityKey,
          };
        },
      }),
      registerUserCredentials: builder.mutation<any, typeof RegisterUserCredentialsRequest>({
        query: (userData) => {
          return {
            url: "/register-user-credentials",
            method: "POST",
            body: userData,
          };
        },
      }),
    }),
  });
};
export const { useEvaluateUserNameMutation, useRegisterUserCredentialsMutation} = customerManagementApi({
  baseUrl: "",
  useMockApi: false,
  headers: { "Custom-Header": "CustomValue" },
});
 
 