import { createApi } from "@reduxjs/toolkit/query/react";
import { ApiParams, customFetchBaseQuery, mockBaseQuery } from "../../utils/api-helper";
 
// interface  definition block
interface Endpoint {
  url: string;
  method: string;
}
 
interface ApiResponse<T> {
  data: T;
}
 
interface RetriveNafathStatusRequest{
  nationalID:string,
  transID:string
}
 
interface RetriveNafathStatusResponse{
  isExceptionalNationality: boolean,
  dakhliServiceStatus: boolean,
  AuthStatus: string,
  opstatus: boolean,
  CallBackStatus: string
}
 
interface InitiateNafathTokenRequest{
 
}
 
interface InitiateNafathTokenResponse{
 
}
interface InitiateOtpRequest{
 
}
 
interface InitiateOtpResponse{
 
}
interface EvaluateProspectRequest{
  nationalID: string,
    mobileNumber: string,
    otpHash: string,
    transactionName: string,
    transactionReferenceNumber: string,
    IsCCWithOnepack: boolean,
    CustomerChosenCardType: string
}
 
interface EvaluateProspectResponse{
  isApplicationExists: boolean,
  opStatus: boolean,
  isSAMABlackListed: boolean,
  isVerified: boolean,
  isOwner: boolean,
  uiState:string,
  isCCWithOnepack?: boolean,
}
 
const EvaluateProspectRequest = {
  nationalID: "2131356517",
  mobileNumber: "8978966776",
  otpHash: "f56d6351aa71cff0debea014d13525e42036187a",
  transactionName: "CheckProspectAndVerifyPhoneNumber",
  transactionReferenceNumber: "MBR0000000000115023647",
  IsCCWithOnepack: true,
  CustomerChosenCardType: "StandardCreditCard"
}
 
const EvaluateProspectResponse = {
    isApplicationExists: true,
    opStatus: true,
    isSAMABlackListed: true,
    isVerified: true,
    isOwner: true,
    uiState:'Personal_Details_Completed'
}
 
interface ApiResponses {
  "/initiate-nafath-token": ApiResponse<InitiateNafathTokenResponse>,
  "/retrive-nafath-status":ApiResponse<RetriveNafathStatusResponse>,
  "/evaluate-prospect":ApiResponse<EvaluateProspectResponse>,
  '/initiate-otp':ApiResponse<InitiateOtpResponse>
}
 
 
const InitiateNafathTokenRequest = {
 
}
 
const InitiateNafathTokenResponse ={
  data: 'InitiateNafathTokenResponse',
}
 
const RetriveNafathStatusRequest={
  nationalID:'nationalID',
  transID:'transID'
}
 
const RetriveNafathStatusResponse={
  isExceptionalNationality: true,
  dakhliServiceStatus: true,
  AuthStatus: "Na",
  opstatus: true,
  CallBackStatus: "Na"
}
 
const OtpRequest={
 
}
 
const OtpResponse={
 
}
 
 
// endpoint registration block
const endpointList: Endpoint[] = [
  {
    url: "/initiate-otp",
    method: "POST",
  },
  {
    url: "/initiate-nafath-token",
    method: "POST",
  },
  {
    url: "/retrive-nafath-status",
    method: "POST",
  },
  {
    url: "/evaluate-prospect",
    method: "POST",
  }
];
 
// generic mock base query function
// const mockBaseQuery = async (
//   args: { url: string; method: string; body?: any },
//   responseValue: any
// ) => {
//   const normalizeUrl = (url: string) => url.replace(/\/$/, "");
//   for (const endpoint of endpointList) {
//     if (
//       normalizeUrl(endpoint.url) === normalizeUrl(args.url) &&
//       endpoint.method === args.method
//     ) {
//       return { data: responseValue };
//     }
//   }
//   console.error("No mock data found for", args.method, args.url);
//   throw new Error(`Unknown endpoint or method: ${args.method} ${args.url}`);
// };
 
export const lifecycleManagementApi = ({
  baseUrl,
  useMockApi,
  headers
}: ApiParams) => {
  return createApi({
    reducerPath: "lifecycleManagementApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      // Dynamic responses registration
      const responses: ApiResponses = {
        "/initiate-nafath-token": {data: InitiateNafathTokenResponse},
        "/retrive-nafath-status":{ data:RetriveNafathStatusResponse},
        "/evaluate-prospect":{data:EvaluateProspectResponse},
        "/initiate-otp":{data:OtpResponse}
      };
 
      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url], endpointList)
      } else {
       // const fetchbaseQuery = fetchBaseQuery({ baseUrl });
 
       return await customFetchBaseQuery(baseUrl, headers)(
        args,
        api,
        extraOptions
      );
      }
    },
    endpoints: (builder) => ({
     
      initiateNafathToken : builder.mutation<any, typeof InitiateNafathTokenRequest>({
        query: (entityKey) => {
          return {
            url: "/initiate-nafath-token",
            method: "POST",
            body: entityKey,
          };
        },
      }),
      retriveNafathStatus : builder.mutation<any, typeof RetriveNafathStatusRequest>({
        query: (data) => {
          return {
            url: "/retrieve-nafath-status",
            method: "POST",
            body: data,
          };
        },
      }),
      evaluateProspect : builder.mutation<any, typeof EvaluateProspectRequest>({
        query: (userDetails) => {
          return {
            url: "/evaluate-prospect",
            method: "POST",
            body: userDetails,
          };
        },
      }),
      initiateOtp : builder.mutation<any, typeof OtpRequest>({
        query: (otpData) => {
          return {
            url: "/initiate-otp",
            method: "POST",
            body: otpData,
          };
        },
      }),
    }),
  });
};
export const {useInitiateNafathTokenMutation , useRetriveNafathStatusMutation , useEvaluateProspectMutation,
  useInitiateOtpMutation
} =
  lifecycleManagementApi({
    baseUrl: "",
    useMockApi: false,
    headers: { "Custom-Header": "CustomValue" }
  });