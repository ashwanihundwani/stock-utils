import { createApi } from "@reduxjs/toolkit/query/react";
import { ApiParams, customFetchBaseQuery, mockBaseQuery } from "../../utils/api-helper";
import { RetrivedData } from "./cutomer-data";

interface Endpoint {
    url: string;
    method: string;
  }

  interface ApiResponse<T> {
    data: T;
  }

  interface UpdateFeedbackRequest{
    customerID: string,
    serviceName: string,
    rating:string
  }

  interface UpdateFeedbackResponse{
    isSuccess: boolean,
  updateStatus: string
  }

  interface UpdateReferralCodeRequest{
    inviteID: string,
    inviteAction: string,
    inviteeID:string
  }

  interface UpdateReferralCodeResponse{
    isSuccess: boolean,
    updateStatus: string
  }

  export type UpdateOnboardingFieldsRequest = {
    data: UpdateOnboardingFieldItem[];
    token: string;
    uiState: string;
}

export interface UpdateOnboardingFieldItem {
    fieldKey?: string;
    value: string;
    key?: string;
}


  interface UpdateOnboardingFieldsResponse{
    isSuccess: boolean
  }

  interface ValdiateReferralCodeRequest{
    referralCode:string,
    recipientID: string
  }

  interface ValidateReferralCodeResponse{
    isValid: boolean,
    totalCount: number
  }

  interface UIvalue{
    fieldKey:string,
    value:string
  }

  interface UIObject{
    uiState:string;
    data:UIvalue[];

  }

  interface RetriveOnboardingFieldsRequest{
     category?: string;
     uiState: string;
     token: string;
  }
  interface RetriveOnboardingFieldsResponse{
    data:UIObject[];
  }

  const UpdateOnboardingFieldsResponse={
    isSuccess:true
  }

  const UpdateFeedbackRequest = {
    "customerID": "1023445987",
    "serviceName": "ForeignCurrencyAccountCreation",
    "rating": "5"
  }

  const UpdateFeedbackResponse={
    "isSuccess": true,
  "updateStatus": "Success"
  }

  const UpdateReferralCodeRequest={
    inviteID: "c966fd33-c174-ef11-9b4b-0050568096a0",
    inviteAction: "Onboarded",
    inviteeID: "1000658789"
  }

  const UpdateReferralCodeResponse = {
    isSuccess: true,
    updateStatus: "Success"
  }

  const ValdiateReferralCodeRequest={
    referralCode: "JA1001",
    recipientID: "966511348236"
  }

  const ValdiateReferralCodeResponse={
    isValid: true,
    totalCount: 10
  }

  const RetriveOnboardingFieldsRequest : RetriveOnboardingFieldsRequest ={
    uiState: "",
    token: ""
  }

  const RetriveOnboardingFieldsResponseMock:RetriveOnboardingFieldsResponse={
  data:[
    {
      uiState: 'Personal_Details_Completed',
      data: [
        {
          fieldKey: 'title',
          value: 'Mr',
        },
        {
          fieldKey: 'familyStatusCode',
          value: 'Married',
        },
        {
          fieldKey: 'numberOfDependents',
          value: '1',
        },
        {
          fieldKey: 'levelOfEducationId',
          value: 'Graduate',
        },
        {
          fieldKey: 'waselAddress',
          value: 'Rented',
        },
        {
          fieldKey: 'accountPurpose',
          value: 'Receipts',
        },
      ],
    },
    ],
  }


  interface ApiResponses {
    "/update-feedback": ApiResponse<UpdateFeedbackResponse>,
    "/update-referral-code":ApiResponse<UpdateReferralCodeResponse>,
    "/update-onboarding-fields":ApiResponse<UpdateOnboardingFieldsResponse>,
    "/valdiate-referral-code":ApiResponse<ValidateReferralCodeResponse>,
    "/retrieve-onboarding-fields":ApiResponse<RetriveOnboardingFieldsResponse>
  }

  const endpointList: Endpoint[] = [
 
    {
      url: "/update-feedback",
      method: "POST",
    },
    {
        url: "/update-referral-code",
        method: "POST",
    },
    {
        url: "/update-onboarding-fields",
        method: "POST",
    },
    {
        url: "/valdiate-referral-code",
        method: "POST",  
    },
    {
      url: "/retrieve-onboarding-fields",
      method: "POST",  
  }
  ];
  

  
  export const customerRelationshipManagementApi = ({
    baseUrl,
    useMockApi,
    headers
  }: ApiParams) => {
    return createApi({
      reducerPath: "customerRelationshipManagementApi",
      baseQuery: async (
        args: { url: string; method: string; body?: any },
        api: any,
        extraOptions: any
      ) => {
        // Dynamic responses registration
        const responses: ApiResponses = {
          "/update-feedback": {data: UpdateFeedbackResponse},
          '/update-referral-code':{data:UpdateReferralCodeResponse},
          "/update-onboarding-fields":{data:UpdateOnboardingFieldsResponse},
          "/valdiate-referral-code":{data:ValdiateReferralCodeResponse},
          "/retrieve-onboarding-fields":{
            data: (() => {
              if (args.body.category === "Personal_Details_Completed") {
                return { data: [{uiState: 'Personal_Details_Completed', data: RetrivedData[1].data}] };
              } else if (args.body.category === "Email_Verfication_Completed") {
                // Return mock data for "Work_Details_Completed"
                return { data: [{uiState: 'Email_Verfication_Completed', data: RetrivedData[0].data}]};
              } else if (args.body.category === "Account_Purpose_Completed") {
                // Return mock data for "Educational_Details_Completed"
                return {
                  data: [{uiState: 'Account_Purpose_Completed', data: RetrivedData[2].data}],
                };
              } else if (args.body.category === "Employment_Details_Completed") {
                // Return mock data for "Educational_Details_Completed"
                return {
                  data: [{uiState: 'Employment_Details_Completed', data: RetrivedData[3].data}],
                };
              } else if (args.body.category === "Additional_Information_Completed") {
                // Return mock data for "Educational_Details_Completed"
                return {
                  data: [{uiState: 'Additional_Information_Completed', data: RetrivedData[4].data}],
                };
              } else if (args.body.category === "TAXandPEP_Details_Completed") {
                // Return mock data for "Educational_Details_Completed"
                return {
                  data: [{uiState: 'TAXandPEP_Details_Completed', data: RetrivedData[5].data}],
                };
              } else if (args.body.category === "Notification_Preferrance_Completed") {
                // Return mock data for "Educational_Details_Completed"
                return {
                  data: [{uiState: 'Notification_Preferrance_Completed', data: RetrivedData[6].data}],
                };
              } 
              
              else {
                // Default response or handle unrecognized category
                return {
                  data: [
                    {
                      uiState: 'Default',
                      data: [
                        {
                          fieldKey: 'Message',
                          value: 'No category found',
                        },
                      ],
                    },
                  ],
                };
              }
            })(),
          },
        };
  
        if (useMockApi) {
          return await mockBaseQuery(args, responses[args.url],endpointList);
        } else {
         return await customFetchBaseQuery(baseUrl, headers)(
          args,
          api,
          extraOptions
        );
        }
      },
      endpoints: (builder) => ({
        updatefeedback : builder.mutation<any, typeof UpdateFeedbackRequest>({
          query: (feedback) => {
            return {
              url: "/update-feedback",
              method: "POST",
              body: feedback,
            };
          },
        }),
        updateReferralCode : builder.mutation<any, typeof UpdateReferralCodeRequest>({
            query: (referralCode) => {
              return {
                url: "/update-referral-code",
                method: "POST",
                body: referralCode,
              };
            },
          }),
          updateOnboardingFields : builder.mutation<any, UpdateOnboardingFieldsRequest>({
            query: (onboardingfields) => {
              return {
                url: "/update-onboarding-fields",
                method: "POST",
                body: onboardingfields,
              };
            },
          }),
          valdiateReferralCode : builder.mutation<any, typeof ValdiateReferralCodeRequest>({
            query: (referralCode) => {
              return {
                url: "/validate-referral-code",
                method: "POST",
                body: referralCode,
              };
            },
          }),
          retrieveOnboardingFields:builder.mutation<any, typeof RetriveOnboardingFieldsRequest>({
            query: (category) => {
              return {
                url: "/retrieve-onboarding-fields",
                method: "POST",
                body: category
              };
            },
          }),
      }),
    });
  };
  export const {useUpdatefeedbackMutation, useUpdateReferralCodeMutation, useUpdateOnboardingFieldsMutation, useValdiateReferralCodeMutation
    ,useRetrieveOnboardingFieldsMutation
  } =
  customerRelationshipManagementApi({
      baseUrl: "",
      useMockApi: false,
      headers: { "Custom-Header": "CustomValue" }
    });