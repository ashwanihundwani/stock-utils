export enum EntityTypes {
  NAT = "NAT",
  CIT = "CIT",
  MIC = "MIC", //done
  USR = "USR",
  EDU = "EDU", //done
  BNK = "BNK",
  ACP = "ACP", //done
  HST = "HST",
  SEG = "SEG",
  BRH = "BRH",
  NSL = "NSL",
  OCP = "OCP",
  SOI = "SOI",
  UNV = "UNV",
  OCG = "OCG",
  LYS = "LYS",
  EMP = "EMP",
  NAT_DE = "NAT_DE",
  gib_LevelofDelegationDOA = "gib_LevelofDelegationDOA",
  RELATIONSHIPS = "RELATIONSHIPS",
  PRODUCTS = "PRODUCTS",
  REDFCITY = "REDFCITY",
  PRJ = "PRJ",
  ADDCTY = "ADDCTY",
  ADDDIST = "ADDDIST",
  Subjects = "Subjects",
  Channels = "Channels",
  MRS = "MRS", //done
  TIT = "TIT", //done
  TTL = "TTL", //done
  JTL = "JTL",
  WST = "WST",
  BOI = "BOI",
  BAI = "BAI",
  AMI = "AMI",
  KAM = "KAM",
  COB = "COB",
  TINR = "TINR",
  NOD = "NOD",
  HSD = "HSD",
  TWE = "TWE",
  PCJ = "PCJ",
  SAB = "SAB",
  AOP = "AOP",
  API = "API",
}

export const LookUpResponseData = [
  {
    entityKey: EntityTypes.ACP,
    objects: [
      {
        id: "47",
        code: "KR",
        value: "Savings",
      },
      {
        id: "329",
        code: "LA",
        value: "Receipts",
      },

      {
        id: "329",
        code: "LA",
        value: "Payments",
      },
      {
        id: "329",
        code: "LA",
        value: "Other",
      },
    ],
  },
  {
    entityKey: EntityTypes.EDU,
    objects: [
      {
        id: "47",
        code: "KR",
        value: "Under Graduate",
      },
      {
        id: "329",
        code: "LA",
        value: "Graduate",
      },
      {
        id: "329",
        code: "LA",
        value: "Post Graduate",
      },
      {
        id: "329",
        code: "LA",
        value: "Non Student",
      },
    ],
  },
  {
    entityKey: EntityTypes.NAT,
    objects: [
      { id: "0", value: "Palestine", code: "PS" },
      { id: "1", value: "PALESTINIAN EGYPTIAN", code: "PS" },
      { id: "2", value: "PALESTINIAN LEBANESE", code: "PS" },
      { id: "3", value: "PALESTINIAN JORDAN", code: "PS" },
      { id: "4", value: "Palestinian Iraqi", code: "PS" },
      { id: "5", value: "Libya", code: "LY" },
      { id: "6", value: "IRAN", code: "IR" },
      { id: "7", value: "Russia", code: "RU" },
      { id: "8", value: "SOUTH KOREA", code: "KR" },
      { id: "9", value: "Laos", code: "329" },
      { id: "10", value: "East Timor", code: "TP" },
      { id: "11", value: "Tanzania", code: "TZ" },
      { id: "12", value: "SENEGAL", code: "SN" },
      { id: "13", value: "NIGERIA", code: "NG" },
      { id: "14", value: "Comorian island", code: "452" },
      { id: "15", value: "San Moreno", code: "SM" },
      { id: "16", value: "MOLDOVA", code: "MD" },
      { id: "17", value: "MACEDONIA", code: "MK" },
      { id: "18", value: "Kosovo", code: "550" },
      { id: "19", value: "Joanna", code: "608" },
      { id: "20", value: "VENEZUELA", code: "VE" },
      { id: "21", value: "BOLIVIA", code: "BO" },
      { id: "22", value: "BRITISH VIRGIN ISLANDS", code: "VG" },
      { id: "23", value: "ARUBA", code: "AW" },
      { id: "24", value: "WESTERN SAMOA", code: "808" },
      { id: "25", value: "ISLANDS WALLIS", code: "816" },
      { id: "26", value: "Beluchi", code: "333" },
      { id: "27", value: "BOSNIA AND HERZEGOWINA", code: "BA" },
      { id: "28", value: "BURMA RESEDENT", code: "BX" },
      { id: "29", value: "PALESTINIAN IRAQUI", code: "PS" },
      { id: "30", value: "PALESTINIAN TERRITORY", code: "PS" },
      { id: "31", value: "SAINT PIERRE MIGUEL", code: "PM" },
      { id: "32", value: "SAINT THOMAS", code: "442" },
      { id: "33", value: "SAINT VICENT", code: "VC" },
      { id: "34", value: "SYRIA", code: "SY" },
      { id: "35", value: "TAIWAN", code: "TW" },
      { id: "36", value: "VIRGIN ISLAND", code: "653" },
      { id: "37", value: "PALESTINIAN SYRIA", code: "PS" },
      { id: "38", value: "Republic of South Sudan", code: "SS" },
      { id: "39", value: "BAHRAIN", code: "BH" },
      { id: "40", value: "Panama Canal Zone", code: "PZ" },
      { id: "41", value: "Stateless (Bedoun)", code: "S9" },
      { id: "42", value: "ARMENIA", code: "AM" },
      { id: "43", value: "Bangladesh", code: "BD" },
      { id: "44", value: "Myanmar/Resident", code: "351" },
      { id: "45", value: "Myanmar/Pakistan Passport", code: "352" },
      { id: "46", value: "Myanmar/Bangladesh Passport", code: "353" },
      { id: "47", value: "RESIDENT", code: "MQ" },
      { id: "48", value: "Southern Yemen", code: "YS" },
      { id: "49", value: "Balkan", code: "" },
      { id: "50", value: "SOUTH SUDAN", code: "SU" },
      { id: "51", value: "Nahd", code: "823" },
      { id: "52", value: "AlHarth", code: "822" },
      { id: "53", value: "AlNasi", code: "820" },
      { id: "54", value: "Tribal Individual", code: "142" },
      { id: "55", value: "Turkistan", code: "332" },
      { id: "56", value: "TRIBES ADJACENT", code: "821" },
      { id: "57", value: "Balobid", code: "819" },
      { id: "58", value: "ALSAYAR", code: "145" },
      { id: "59", value: "Tribes / Kuwait", code: "133" },
      { id: "60", value: "Tribe/AlHal", code: "131" },
      { id: "61", value: "Tribes Adj to Ataf", code: "119" },
      { id: "62", value: "Saudi Foreign Passport", code: "120" },
      { id: "63", value: "Tribes Men", code: "117" },
      { id: "64", value: "Tribes Displaced", code: "145" },
      { id: "65", value: "ALBANIA", code: "AL" },
      { id: "66", value: "AFGHANISTAN", code: "AF" },
      { id: "67", value: "ALAND ISLANDS", code: "AX" },
      { id: "68", value: "ALGERIA", code: "DZ" },
      { id: "69", value: "AMERICAN SAMOA", code: "AS" },
      { id: "70", value: "ANDORRA", code: "AD" },
      { id: "71", value: "ANGOLA", code: "AO" },
      { id: "72", value: "ANGUILLA", code: "AI" },
      { id: "73", value: "ANTARCTICA", code: "AQ" },
      { id: "74", value: "ANTIGUA AND BARBUDA", code: "AG" },
      { id: "75", value: "ARGENTINA", code: "AR" },
      { id: "76", value: "AUSTRALIA", code: "AU" },
      { id: "77", value: "AUSTRIA", code: "AT" },
      { id: "78", value: "AZERBAIJAN", code: "AZ" },
      { id: "79", value: "BAHAMAS", code: "BS" },
      { id: "80", value: "SAUDI ARABIA", code: "SA" },
      { id: "81", value: "BANGLADESH", code: "BD" },
      { id: "82", value: "BARBADOS", code: "BB" },
      { id: "83", value: "BELARUS", code: "BY" },
      { id: "84", value: "BELGIUM", code: "BE" },
      { id: "85", value: "BELIZE", code: "BZ" },
      { id: "86", value: "BENIN", code: "BJ" },
      { id: "87", value: "BERMUDA", code: "BM" },
      { id: "88", value: "BHUTAN", code: "BT" },
      { id: "89", value: "BOTSWANA", code: "BW" },
      { id: "90", value: "BRAZIL", code: "BR" },
      { id: "91", value: "BRITISH INDIAN OCEAN TERRITORY", code: "IO" },
      { id: "92", value: "BRUNEI DARUSSALAM", code: "BN" },
      { id: "93", value: "BULGARIA", code: "BG" },
      { id: "94", value: "BURKINA FASO", code: "BF" },
      { id: "95", value: "BURUNDI", code: "BI" },
      { id: "96", value: "CAMBODIA", code: "KH" },
      { id: "97", value: "CAMEROON", code: "CM" },
      { id: "98", value: "CANADA", code: "CA" },
      { id: "99", value: "CAPE VERDE", code: "CV" },
      { id: "100", value: "CAYMAN ISLANDS", code: "KY" },
      { id: "101", value: "CENTRAL AFRICAN REPUBLIC", code: "CF" },
      { id: "102", value: "CHAD", code: "TD" },
      { id: "103", value: "CHILE", code: "CL" },
      { id: "104", value: "CHINA", code: "CN" },
      { id: "105", value: "CHRISTMAS ISLAND", code: "CX" },
      { id: "106", value: "COCOS (KEELING) ISLANDS", code: "CC" },
      { id: "107", value: "…EIN", code: "LI" },
      { id: "179", value: "LITHUANIA", code: "LT" },
      { id: "180", value: "LUXEMBOURG", code: "LU" },
      { id: "181", value: "MACAO", code: "MO" },
      { id: "182", value: "MADAGASCAR", code: "MG" },
      { id: "183", value: "MALAWI", code: "MW" },
      { id: "184", value: "MALAYSIA", code: "MY" },
      { id: "185", value: "MALDIVES", code: "MV" },
      { id: "186", value: "MALI", code: "ML" },
      { id: "187", value: "MALTA", code: "MT" },
      { id: "188", value: "MARSHALL ISLANDS", code: "MH" },
      { id: "189", value: "MARTINIQUE", code: "MQ" },
      { id: "190", value: "MAURITANIA", code: "MR" },
      { id: "191", value: "MAURITIUS", code: "MU" },
      { id: "192", value: "MAYOTTE", code: "YT" },
      { id: "193", value: "MEXICO", code: "MX" },
      { id: "194", value: "MONACO", code: "MC" },
      { id: "195", value: "MONGOLIA", code: "MN" },
      { id: "196", value: "MONTENEGRO", code: "ME" },
      { id: "197", value: "MONTSERRAT", code: "MS" },
      { id: "198", value: "MOROCCO", code: "MA" },
      { id: "199", value: "MOZAMBIQUE", code: "MZ" },
      { id: "200", value: "MYANMAR", code: "MM" },
      { id: "201", value: "NAMIBIA", code: "NA" },
      { id: "202", value: "NAURU", code: "NR" },
      { id: "203", value: "NEPAL", code: "NP" },
      { id: "204", value: "NETHERLANDS", code: "NL" },
      { id: "205", value: "NETHERLANDS ANTILLES", code: "AN" },
      { id: "206", value: "NEW CALEDONIA", code: "NC" },
      { id: "207", value: "NEW ZEALAND", code: "NZ" },
      { id: "208", value: "NICARAGUA", code: "NI" },
      { id: "209", value: "NIGER", code: "NE" },
      { id: "210", value: "NIUE", code: "NU" },
      { id: "211", value: "NORFOLK ISLAND", code: "NF" },
      { id: "212", value: "NORTHERN MARIANA ISLANDS", code: "MP" },
      { id: "213", value: "NORWAY", code: "NO" },
      { id: "214", value: "OMAN", code: "OM" },
      { id: "215", value: "PAKISTAN", code: "PK" },
      { id: "216", value: "PALAU", code: "PW" },
      { id: "217", value: "PANAMA", code: "PA" },
      { id: "218", value: "PAPUA NEW GUINEA", code: "PG" },
      { id: "219", value: "PARAGUAY", code: "PY" },
      { id: "220", value: "PERU", code: "PE" },
      { id: "221", value: "PHILIPPINES", code: "PH" },
      { id: "222", value: "PITCAIRN", code: "PN" },
      { id: "223", value: "POLAND", code: "PL" },
      { id: "224", value: "PORTUGAL", code: "PT" },
      { id: "225", value: "PUERTO RICO", code: "PR" },
      { id: "226", value: "QATAR", code: "QA" },
      { id: "227", value: "ROMANIA", code: "RO" },
      { id: "228", value: "RUSSIAN FEDERATION", code: "RU" },
      { id: "229", value: "RWANDA", code: "RW" },
      { id: "230", value: "SAINT BARTHÉLEMY", code: "BL" },
      { id: "231", value: "SAINT HELENA", code: "SH" },
      { id: "232", value: "SAINT KITTS AND NEVIS", code: "KN" },
      { id: "233", value: "SAINT LUCIA", code: "LC" },
      { id: "234", value: "SAINT MARTIN", code: "MF" },
      { id: "235", value: "SAINT PIERRE AND MIQUELON", code: "PM" },
      { id: "236", value: "SAINT VINCENT AND THE GRENADINES", code: "VC" },
      { id: "237", value: "SAMOA", code: "WS" },
      { id: "238", value: "SERBIA", code: "RS" },
      { id: "239", value: "SAN MARINO", code: "SM" },
      { id: "240", value: "SAO TOME AND PRINCIPE", code: "ST" },
      { id: "241", value: "SEYCHELLES", code: "SC" },
      { id: "242", value: "SIERRA LEONE", code: "SL" },
      { id: "243", value: "SINGAPORE", code: "SG" },
      { id: "244", value: "SLOVAKIA", code: "SK" },
      { id: "245", value: "SLOVENIA", code: "SI" },
      { id: "246", value: "SOLOMON ISLANDS", code: "SB" },
      { id: "247", value: "SOMALIA", code: "SO" },
      { id: "248", value: "SOUTH AFRICA", code: "ZA" },
      {
        id: "249",
        value: "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS",
        code: "GS",
      },
      { id: "250", value: "SPAIN", code: "ES" },
      { id: "251", value: "SRI LANKA", code: "LK" },
      { id: "252", value: "SUDAN", code: "SD" },
      { id: "253", value: "SURINAME", code: "SR" },
      { id: "254", value: "SVALBARD AND JAN MAYEN", code: "SJ" },
      { id: "255", value: "SWAZILAND", code: "SZ" },
      { id: "256", value: "SWEDEN", code: "SE" },
      { id: "257", value: "SWITZERLAND", code: "CH" },
      { id: "258", value: "TAJIKISTAN", code: "TJ" },
      { id: "259", value: "THAILAND", code: "TH" },
      { id: "260", value: "TIMOR-LESTE", code: "TL" },
      { id: "261", value: "TOGO", code: "TG" },
      { id: "262", value: "TOKELAU", code: "TK" },
      { id: "263", value: "TONGA", code: "TO" },
      { id: "264", value: "TRINIDAD AND TOBAGO", code: "TT" },
      { id: "265", value: "TUNISIA", code: "TN" },
      { id: "266", value: "TURKEY", code: "TR" },
      { id: "267", value: "TURKMENISTAN", code: "TM" },
      { id: "268", value: "TURKS AND CAICOS ISLANDS", code: "TC" },
      { id: "269", value: "TUVALU", code: "TV" },
      { id: "270", value: "UGANDA", code: "UG" },
      { id: "271", value: "UKRAINE", code: "UA" },
      { id: "272", value: "UNITED ARAB EMIRATES", code: "AE" },
      { id: "273", value: "UNITED KINGDOM", code: "GB" },
      { id: "274", value: "UNITED STATES", code: "US" },
      { id: "275", value: "UNITED STATES MINOR OUTLYING ISLANDS", code: "UM" },
      { id: "276", value: "URUGUAY", code: "UY" },
      { id: "277", value: "UZBEKISTAN", code: "UZ" },
      { id: "278", value: "VANUATU", code: "VU" },
      { id: "279", value: "VIETNAM", code: "VN" },
      { id: "280", value: "VIRGIN ISLANDS, U.S.", code: "VI" },
      { id: "281", value: "WALLIS AND FUTUNA", code: "WF" },
      { id: "282", value: "YEMEN", code: "YE" },
      { id: "283", value: "ZAMBIA", code: "ZM" },
      { id: "284", value: "ZIMBABWE", code: "ZW" },
      { id: "285", value: "Yugoslavia", code: "YU" },
    ],
  },
  {
    entityKey: EntityTypes.NAT_DE,
    objects: [
      {
        id: "329",
        code: "LA",
        value: "Employed",
      },
      {
        id: "47",
        code: "KR",
        value: "Salary",
      },
      {
        id: "329",
        code: "LA",
        value: "Business",
      },
      {
        id: "329",
        code: "LA",
        value: "Housewife",
      },
      {
        id: "329",
        code: "LA",
        value: "Student",
      },
      {
        id: "329",
        code: "LA",
        value: "Unemployed",
      },
    ],
  },
  {
    entityKey: EntityTypes.CIT,
    objects: [
      {
        id: "47",
        code: "KR",
        value: "Single",
      },
      {
        id: "329",
        code: "LA",
        value: "Married",
      },
      {
        id: "329",
        code: "LA",
        value: "Divorced",
      },
      {
        id: "329",
        code: "LA",
        value: "Widowed",
      },
    ],
  },
  {
    entityKey: EntityTypes.MIC,
    objects: [
      {
        id: "47",
        code: "KR",
        value: "SAR 5,000 and below",
      },
      {
        id: "329",
        code: "LA",
        value: "SAR 5,000 to SAR 15,000",
      },
      {
        id: "329",
        code: "LA",
        value: "SAR 15,000 to SAR 30,000",
      },
      {
        id: "329",
        code: "LA",
        value: "SAR 30,000 to SAR 50,000",
      },
      {
        id: "329",
        code: "LA",
        value: "SAR 50,000 to SAR 100,000",
      },
      {
        id: "329",
        code: "LA",
        value: "SAR 100,000 to SAR 500,000",
      },
      {
        id: "329",
        code: "LA",
        value: "SAR 500,000 and above",
      },
    ],
  },
  {
    entityKey: EntityTypes.USR,
    objects: [
      {
        id: "3",
        code: "A3",
        value: "Value for USR",
      },
    ],
  },
  {
    entityKey: EntityTypes.BNK,
    objects: [
      {
        id: "5",
        code: "A5",
        value: "Value for BNK",
      },
    ],
  },
  {
    entityKey: EntityTypes.HST,
    objects: [
      {
        id: "7",
        code: "A7",
        value: "",
      },
    ],
  },
  {
    entityKey: EntityTypes.SEG,
    objects: [
      {
        id: "8",
        code: "A8",
        value: "Value for SEG",
      },
    ],
  },
  {
    entityKey: EntityTypes.BRH,
    objects: [
      {
        id: "9",
        code: "A9",
        value: "Value for BRH",
      },
    ],
  },
  {
    entityKey: EntityTypes.NSL,
    objects: [
      {
        id: "10",
        code: "A10",
        value: "Value for NSL",
      },
    ],
  },
  {
    entityKey: EntityTypes.OCP,
    objects: [
      {
        id: "11",
        code: "A11",
        value: "Value for OCP",
      },
    ],
  },
  {
    entityKey: EntityTypes.SOI,
    objects: [
      {
        id: "12",
        code: "A12",
        value: "Investments",
      },
      {
        id: "12",
        code: "A12",
        value: "Self- Employed",
      },
      {
        id: "12",
        code: "A12",
        value: "Freelancing",
      },
      {
        id: "12",
        code: "A12",
        value: "part-time-job",
      },
      {
        id: "12",
        code: "A12",
        value: "Family-support",
      },
    ],
  },
  {
    entityKey: EntityTypes.UNV,
    objects: [
      {
        id: "13",
        code: "A13",
        value: "Anna University",
      },
      {
        id: "13",
        code: "A13",
        value: "SRM university",
      },
      {
        id: "13",
        code: "A13",
        value: "Govt university",
      },
      {
        id: "13",
        code: "A13",
        value: "Other",
      },
    ],
  },
  {
    entityKey: EntityTypes.OCG,
    objects: [
      {
        id: "329",
        code: "LA",
        value: "Employed",
      },
      {
        id: "14",
        code: "A14",
        value: "Salary",
      },
      {
        id: "14",
        code: "A14",
        value: "Business",
      },
      {
        id: "14",
        code: "A14",
        value: "Housewife",
      },
      {
        id: "14",
        code: "A14",
        value: "Student",
      },
      {
        id: "14",
        code: "A14",
        value: "Unemployed",
      },
    ],
  },
  {
    entityKey: EntityTypes.LYS,
    objects: [
      {
        id: "15",
        code: "A15",
        value: "Value for LYS",
      },
    ],
  },
  {
    entityKey: EntityTypes.EMP,
    objects: [
      {
        id: "16",
        code: "A16",
        value: "Aramco",
      },
      {
        id: "16",
        code: "A16",
        value: "Emily",
      },
      {
        id: "16",
        code: "A16",
        value: "David",
      },
      {
        id: "16",
        code: "A16",
        value: "John",
      },
      {
        id: "16",
        code: "A16",
        value: "Sarah",
      },
      {
        id: "16",
        code: "A16",
        value: "Other",
      },
    ],
  },
  {
    entityKey: EntityTypes.gib_LevelofDelegationDOA,
    objects: [
      {
        id: "18",
        code: "A18",
        value: "Value for gib_LevelofDelegationDOA",
      },
    ],
  },
  {
    entityKey: EntityTypes.RELATIONSHIPS,
    objects: [
      {
        id: "19",
        code: "A19",
        value: "Value for RELATIONSHIPS",
      },
    ],
  },
  {
    entityKey: EntityTypes.PRODUCTS,
    objects: [
      {
        id: "20",
        code: "A20",
        value: "Value for PRODUCTS",
      },
    ],
  },
  {
    entityKey: EntityTypes.REDFCITY,
    objects: [
      {
        id: "21",
        code: "A21",
        value: "Value for REDFCITY",
      },
    ],
  },
  {
    entityKey: EntityTypes.PRJ,
    objects: [
      {
        id: "22",
        code: "A22",
        value: "Value for PRJ",
      },
    ],
  },
  {
    entityKey: EntityTypes.ADDCTY,
    objects: [
      {
        id: "23",
        code: "A23",
        value: "Value for ADDCTY",
      },
    ],
  },
  {
    entityKey: EntityTypes.ADDDIST,
    objects: [
      {
        id: "24",
        code: "A24",
        value: "Value for ADDDIST",
      },
    ],
  },
  {
    entityKey: EntityTypes.Subjects,
    objects: [
      {
        id: "25",
        code: "A25",
        value: "Value for Subjects",
      },
    ],
  },
  {
    entityKey: EntityTypes.Channels,
    objects: [
      {
        id: "26",
        code: "A25",
        value: "Email",
      },
      {
        id: "26",
        code: "A25",
        value: "SMS",
      },
      {
        id: "26",
        code: "A25",
        value: "Push Notification",
      },
      {
        id: "26",
        code: "A25",
        value: "Phone Call",
      },
      {
        id: "26",
        code: "A25",
        value: "Live Chat",
      },
    ],
  },
  {
    entityKey: EntityTypes.MRS,
    objects: [
      {
        value: "Single",
        code: "A23",
        id: "23",
      },
      {
        value: "Married",
        code: "A23",
        id: "23",
      },
      {
        value: "Divorced",
        code: "A23",
        id: "23",
      },
      {
        value: "Widowed",
        code: "A23",
        id: "23",
      },
    ],
  },
  {
    entityKey: EntityTypes.MRS,
    objects: [
      {
        value: "Single",
        code: "A23",
        id: "23",
      },
      {
        value: "Married",
        code: "A23",
        id: "23",
      },
      {
        value: "Divorced",
        code: "A23",
        id: "23",
      },
      {
        value: "Widowed",
        code: "A23",
        id: "23",
      },
    ],
  },
  {
    entityKey: EntityTypes.TIT,
    objects: [
      {
        value: "TIN - Tax Identification Number",
        code: "A23",
        id: "1",
      },
      {
        value: "SSN - Social Security Number",
        code: "A23",
        id: "2",
      },
      {
        value: "ITIN-Individual Taxpayer Identification Number",
        code: "A23",
        id: "3",
      },
      {
        value: "Not applicable",
        code: "A23",
        id: "23",
      },
    ],
  },
  {
    entityKey: EntityTypes.TTL,
    objects: [
      {
        value: "Mr",
        code: "A23",
        id: "1",
      },
      {
        value: "Ms",
        code: "A23",
        id: "2",
      },
      {
        value: "Minister",
        code: "A23",
        id: "3",
      },
      {
        value: "Prince",
        code: "A23",
        id: "4",
      },
      {
        value: "Princess",
        code: "A23",
        id: "5",
      },
    ],
  },
  {
    entityKey: EntityTypes.JTL,
    objects: [
      {
        value: "Software ENgineer",
        code: "A23",
        id: "23",
      },
      {
        value: "Marketing Manager",
        code: "A23",
        id: "23",
      },
      {
        value: "Financial Advisor",
        code: "A23",
        id: "23",
      },
      {
        value: "Graphic Designer",
        code: "A23",
        id: "23",
      },
      {
        value: "Analyst",
        code: "A23",
        id: "23",
      },
    ],
  },
  {
    entityKey: EntityTypes.WST,
    objects: [
      {
        value: "Private",
        code: "A23",
        id: "23",
      },
      {
        value: "Public",
        code: "A24",
        id: "24",
      },
      {
        value: "Government",
        code: "A23",
        id: "28",
      },
      {
        value: "Other",
        code: "A23",
        id: "27",
      },
    ],
  },
  {
    entityKey: EntityTypes.BOI,
    objects: [
      {
        value: "HealthCare",
        code: "A23",
        id: "23",
      },
      {
        value: "Finance & Insurance",
        code: "A24",
        id: "24",
      },
      {
        value: "Retail & E-Commerce",
        code: "A23",
        id: "28",
      },
      {
        value: "Software",
        code: "A23",
        id: "27",
      },
    ],
  },
  {
    entityKey: EntityTypes.BAI,
    objects: [
      {
        value: "1,00,000 to  5,00,000",
        code: "A23",
        id: "23",
      },
      {
        value: "5,00,000 to  7,00,000",
        code: "A24",
        id: "24",
      },
      {
        value: "7,00,000 to  10,00,000",
        code: "A23",
        id: "28",
      },
    ],
  },
  {
    entityKey: EntityTypes.AMI,
    objects: [
      {
        value: "15,000 SAR",
        code: "A23",
        id: "23",
      },
      {
        value: "20,000 SAR",
        code: "A24",
        id: "24",
      },
      {
        value: "60000 SAR",
        code: "A23",
        id: "28",
      },
    ],
  },
  {
    entityKey: EntityTypes.KAM,
    objects: [
      {
        value: "Social Media",
        code: "A23",
        id: "23",
      },
      {
        value: "Friends or Family",
        code: "A24",
        id: "24",
      },
      {
        value: "Online Ads",
        code: "A23",
        id: "28",
      },
      {
        value: "Bank Employee",
        code: "A23",
        id: "29",
      },
      {
        value: "Others",
        code: "A23",
        id: "21",
      },
    ],
  },
  {
    entityKey: EntityTypes.COB,
    objects: [
      {
        value: "United States",
        code: "A23",
        id: "23",
      },
      {
        value: "Canada",
        code: "A24",
        id: "24",
      },
      {
        value: "United Kingdom",
        code: "A23",
        id: "28",
      },
      {
        value: "Australia",
        code: "A23",
        id: "29",
      },
      {
        value: "India",
        code: "A23",
        id: "21",
      },
    ],
  },
  {
    entityKey: EntityTypes.TINR,
    objects: [
      {
        value: "Pending Application",
        code: "A23",
        id: "23",
      },
      {
        value: "Foreign National",
        code: "A24",
        id: "24",
      },
      {
        value: "Not Required",
        code: "A23",
        id: "28",
      },
      {
        value: "Others",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.NOD,
    objects: [
      {
        value: "1",
        code: "A23",
        id: "23",
      },
      {
        value: "2",
        code: "A24",
        id: "24",
      },
      {
        value: "3",
        code: "A23",
        id: "28",
      },
      {
        value: "+4",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.HSD,
    objects: [
      {
        value: "Owned",
        code: "A23",
        id: "23",
      },
      {
        value: "Rented",
        code: "A24",
        id: "24",
      },
      {
        value: "Family Home",
        code: "A23",
        id: "28",
      },
      {
        value: "Company Housing",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.TWE,
    objects: [
      {
        value: "1 Year",
        code: "A23",
        id: "23",
      },
      {
        value: "2 Year",
        code: "A24",
        id: "24",
      },
      {
        value: "3 Years",
        code: "A23",
        id: "28",
      },
      {
        value: "+4 Years",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.PCJ,
    objects: [
      {
        value: "1 year",
        code: "A23",
        id: "23",
      },
      {
        value: "2 Years",
        code: "A24",
        id: "24",
      },
      {
        value: "3 years",
        code: "A23",
        id: "28",
      },
      {
        value: "+4 Years",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.SAB,
    objects: [
      {
        value: "ABC bank",
        code: "A23",
        id: "23",
      },
      {
        value: "A Bank",
        code: "A24",
        id: "24",
      },
      {
        value: "B Bank",
        code: "A23",
        id: "28",
      },
      {
        value: "other",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.AOP,
    objects: [
      {
        value: " 1 year ",
        code: "A23",
        id: "23",
      },
      {
        value: "2 year",
        code: "A24",
        id: "24",
      },
      {
        value: "3 year",
        code: "A23",
        id: "28",
      },
      {
        value: "+4 Year",
        code: "A23",
        id: "29",
      },
    ],
  },
  {
    entityKey: EntityTypes.API,
    objects: [
      {
        value: "Salary Direct Deposit",
        code: "A23",
        id: "23",
      },
      {
        value: "Automatic Payroll Deduction",
        code: "A24",
        id: "24",
      },
      {
        value: "Bank Transfer Processed",
        code: "A23",
        id: "28",
      },
      {
        value: "others",
        code: "A23",
        id: "29",
      },
    ],
  },
];
