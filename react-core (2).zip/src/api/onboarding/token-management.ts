import { createApi } from "@reduxjs/toolkit/query/react";
import {
  ApiParams,
  customFetchBaseQuery,
  mockBaseQuery,
} from "../../utils/api-helper";

interface TokenRequest {}

interface TokenResponse {}

const TokenRequest = {};
const TokenResponse = {};

interface Endpoint {
  url: string;
  method: string;
}

interface ApiResponse<T> {
  data: T;
}

interface ApiResponses {
  "/token": ApiResponse<TokenResponse>;
}

// endpoint registration block
const endpointList: Endpoint[] = [
  {
    url: "/token",
    method: "POST",
  },
];

export const tokenManagementApi = ({
  baseUrl,
  useMockApi,
  headers,
}: ApiParams) => {
  return createApi({
    reducerPath: "tokenManagementApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      // Dynamic responses registration
      const responses: ApiResponses = {
        "/token": { data: TokenResponse },
      };

      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url], endpointList);
      } else {
        return await customFetchBaseQuery(baseUrl, headers)(
          args,
          api,
          extraOptions
        );
      }
    },
    endpoints: (builder) => ({
      OauthToken: builder.mutation<any, any>({
        query: (body) => {
          const params = new URLSearchParams();
          params.append("grant_type", body.grant_type);
          console.log(params, "PARAMS", body, "BODY", body.grant_type, "GRANT");
          return {
            url: "/token",
            method: "POST",
            body: params.toString(),
          };
        },
      }),
    }),
  });
};

export const { useOauthTokenMutation } = tokenManagementApi({
  baseUrl: "https://api.example.com",
  useMockApi: false,
  headers: { "Custom-Header": "CustomValue" },
});
