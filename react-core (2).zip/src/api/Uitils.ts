import {
  FetchArgs,
  FetchBaseQueryError,
  fetchBaseQuery,
  BaseQueryFn,
} from "@reduxjs/toolkit/query";

interface CustomFetchBaseQueryArgs extends FetchArgs {
  headers?: Record<string, string>;
  [key: string]: any;
}

export interface ApiParams {
  baseUrl: string;
  useMockApi: boolean;
  headers?: Record<string, string>;
}

export const handleApiError = (error: FetchBaseQueryError) => {
  if (!error) return;

  switch (error.status) {
    case 400:
      console.error(
        "Bad Request: The request could not be understood by the server."
      );
      break;
    case 401:
      console.error("Unauthorized: Authentication is required.");
      break;
    case 403:
      console.error(
        "Forbidden: You don't have permission to access this resource."
      );
      break;
    case 404:
      console.error("Not Found: The requested resource could not be found.");
      break;
    case 500:
      console.error("Server Error: Something went wrong on the server.");
      break;
    default:
      console.error(`Unexpected Error: ${error.status}`);
      break;
  }
};

export const customFetchBaseQuery = (
  baseUrl: string,
  headers?: Record<string, string>,
  token?: string
): BaseQueryFn<CustomFetchBaseQueryArgs, unknown, FetchBaseQueryError> => {
  const baseQuery = fetchBaseQuery({ baseUrl });

  return async (args, api, extraOptions) => {
    const modifiedArgs: CustomFetchBaseQueryArgs = {
      ...args,
      headers: {
        ...args.headers,
        ...headers,
        Authorization: token ? `Bearer ${token}` : undefined,
      },
    };
    const result = await baseQuery(modifiedArgs, api, extraOptions);
    if (result.error) {
      handleApiError(result.error);
    }
    return result;
  };
};

export const mockBaseQuery = async (
  args: { url: string; method: string; body?: any },
  responseValue: any,
  endpointList: any
) => {
  const normalizeUrl = (url: string) => url.replace(/\/$/, "");
  for (const endpoint of endpointList) {
    if (
      normalizeUrl(endpoint.url) === normalizeUrl(args.url) &&
      endpoint.method === args.method
    ) {
      return { data: responseValue };
    }
  }
  console.error("No mock data found for", args.method, args.url);
  throw new Error(`Unknown endpoint or method: ${args.method} ${args.url}`);
};
