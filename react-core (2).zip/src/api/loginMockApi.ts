import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// interface  definition block
interface Endpoint {
  url: string;
  method: string;
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

interface ApiResponses {
  "/login": ApiResponse<typeof LoginResponse>;
  "/otp": ApiResponse<typeof OtpResponse>;
}

interface CreateLoginApiParams {
  baseUrl: string;
  useMockApi: boolean;
}

// constant definition block
const LoginResponse = {
  data: "Test data",
};
const OtpResponse = { data: "Test data" };

const LoginRequest = {
  data: "Test data",
};
const OtpRequest = { data: "Test data" };

// endpoint registration block
const endpointList: Endpoint[] = [
  {
    url: "/login",
    method: "POST",
  },
  {
    url: "/otp",
    method: "POST",
  },
];

// generic mock base query function
const mockBaseQuery = async (
  args: { url: string; method: string; body?: any },
  responseValue: any
) => {
  const normalizeUrl = (url: string) => url.replace(/\/$/, "");
  for (const endpoint of endpointList) {
    if (
      normalizeUrl(endpoint.url) === normalizeUrl(args.url) &&
      endpoint.method === args.method
    ) {
      return { data: responseValue };
    }
  }
  console.error("No mock data found for", args.method, args.url);
  throw new Error(`Unknown endpoint or method: ${args.method} ${args.url}`);
};

export const createLoginApi = ({
  baseUrl,
  useMockApi,
}: CreateLoginApiParams) => {
  return createApi({
    reducerPath: "loginApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      // Dynamic responses registration
      const responses: ApiResponses = {
        "/login": { success: true, data: LoginResponse },
        "/otp": { success: true, data: OtpResponse },
      };

      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url]);
      } else {
        const fetchbaseQuery = fetchBaseQuery({ baseUrl });
        return await fetchbaseQuery(args, api, extraOptions);
      }
    },
    endpoints: (builder) => ({
      login: builder.mutation<any, typeof LoginRequest>({
        query: (credentials) => {
          return {
            url: "/login",
            method: "POST",
            body: credentials,
          };
        },
      }),
      validateOtp: builder.mutation<any, typeof OtpRequest>({
        query: (otp) => {
          return {
            url: "/otp",
            method: "POST",
            body: otp,
          };
        },
      }),
    }),
  });
};
export const { useLoginMutation, useValidateOtpMutation } = createLoginApi({
  baseUrl: "",
  useMockApi: false,
});
