import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// Define interfaces for the mock responses
interface Beneficiary {
  id: number;
  name: string;
  age: number;
}

interface BeneficiaryResponse {
  data: Beneficiary[];
}

interface AddBeneficiaryResponse {
  data: Beneficiary;
}

interface EditBeneficiaryResponse {
  data: Beneficiary;
}

interface DeleteBeneficiaryResponse {
  data: Beneficiary;
}

// Mock responses
const BeneficiaryResponseMock: BeneficiaryResponse = {
  data: [{ id: 1, name: "John Doe", age: 30 }],
};
const AddBeneficiaryResponseMock: AddBeneficiaryResponse = {
  data: { id: 2, name: "Jane Doe", age: 25 },
};
const EditBeneficiaryResponseMock: EditBeneficiaryResponse = {
  data: { id: 1, name: "John Smith", age: 31 },
};
const DeleteBeneficiaryResponseMock: DeleteBeneficiaryResponse = {
  data: { id: 1, name: "John Doe", age: 30 },
};

const endpointList = [
  { url: "/beneficiaries", method: "GET" },
  { url: "/beneficiary", method: "POST" },
  { url: "/beneficiary/edit", method: "PUT" },
  { url: "/beneficiary/delete", method: "DELETE" },
];

// Mock base query function
const mockBaseQuery = async (
  args: { url: string; method: string; body?: any },
  responseValue: any
) => {
  const normalizeUrl = (url: string) => url.replace(/\/$/, "");
  for (const endpoint of endpointList) {
    if (
      normalizeUrl(endpoint.url) === normalizeUrl(args.url) &&
      endpoint.method === args.method
    ) {
      return { data: responseValue };
    }
  }
  console.error("No mock data found for", args.method, args.url);
  throw new Error(`Unknown endpoint or method: ${args.method} ${args.url}`);
};

interface CreateBeneficiaryApiOptions {
  baseUrl: string;
  useMockApi: boolean;
}

export const createBeneficiaryApi = ({
  baseUrl,
  useMockApi,
}: CreateBeneficiaryApiOptions) => {
  return createApi({
    reducerPath: "beneficiaryApi",
    baseQuery: async (args, api, extraOptions) => {
      // Mock responses registration
      const responses: Record<string, any> = {
        "/beneficiaries": { success: true, data: BeneficiaryResponseMock },
        "/beneficiary": { success: true, data: AddBeneficiaryResponseMock },
        "/beneficiary/edit": {
          success: true,
          data: EditBeneficiaryResponseMock,
        },
        "/beneficiary/delete": {
          success: true,
          data: DeleteBeneficiaryResponseMock,
        },
      };

      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url]);
      } else {
        const fetchbaseQuery = fetchBaseQuery({ baseUrl });
        return await fetchbaseQuery(args, api, extraOptions);
      }
    },
    tagTypes: ["Beneficiaries"],
    endpoints: (builder) => ({
      getAllBeneficiaries: builder.query<BeneficiaryResponse, void>({
        query: () => ({
          url: "/beneficiaries",
          method: "GET",
          providesTags: ["Beneficiaries"],
        }),
      }),
      addBeneficiary: builder.mutation<AddBeneficiaryResponse, Beneficiary>({
        query: (beneficiaryData) => ({
          url: "/beneficiary",
          method: "POST",
          body: beneficiaryData,
        }),
        invalidatesTags: ["Beneficiaries"],
      }),
      updateBeneficiary: builder.mutation<EditBeneficiaryResponse, Beneficiary>(
        {
          query: (beneficiaryData) => ({
            url: "/beneficiary/edit",
            method: "PUT",
            body: beneficiaryData,
          }),
          invalidatesTags: ["Beneficiaries"],
        }
      ),
      deleteBeneficiary: builder.mutation<DeleteBeneficiaryResponse, number>({
        query: (beneficiaryId) => ({
          url: "/beneficiary/delete",
          method: "DELETE",
          body: beneficiaryId,
        }),
        invalidatesTags: [{ type: "Beneficiaries", id: 1 }],
      }),
    }),
  });
};

export const {
  useGetAllBeneficiariesQuery,
  useAddBeneficiaryMutation,
  useUpdateBeneficiaryMutation,
  useDeleteBeneficiaryMutation,
} = createBeneficiaryApi({
  baseUrl: "",
  useMockApi: false,
});
