import { createApi } from "@reduxjs/toolkit/query/react";
import {
  ApiParams,
  customFetchBaseQuery,
  mockBaseQuery,
} from "../utils/api-helper";
import { EntityTypes, LookUpResponseData } from "./onboarding/LookUpData";

interface Endpoint {
  url: string;
  method: string;
}

export interface TopLevel {
  entityKey: EntityTypes;
  objects: Object[];
}

export interface Object {
  id: string;
  code: string;
  value: string;
}

const endpointList: Endpoint[] = [
  {
    url: "/retrieve-configs",
    method: "POST",
  },
  {
    url: "/retrive-lookup-data",
    method: "POST",
  },
  {
    url: "/retrieve-contents",
    method: "POST",
  },
];

interface config {
  key: string;
  value: string;
}

interface screenContents {
  localizationKey: string;
  value: string;
}

interface ApiResponse<T> {
  data: T;
}

interface ConfigResponse {
  configs: Array<config>;
}

interface LookUpResponse {
  objects: TopLevel[];
}

interface ContentResponse {
  screenContents: Array<screenContents>;
}

interface RetrieveResponse<T> {
  data: {
    screenContents: Array<T>;
  };
}

const ConfigResponse = {
  configs: [
    {
      key: "AUTO_SWEEP_MAX_LIMIT",
      value: "5000",
    },
    {
      key: "DEFAULT_CURRENCY",
      value: "SAR",
    },
    {
      key: "MODULUS",
      value: "n3kUYfBDZyks",
    },
    {
      key: "EXPONENT",
      value: "AQAB",
    },
    {
      key: "SWIFT_CODE",
      value: "GULFSARI",
    },
    {
      key: "ACCOUNTS_MODULE",
      value: "true",
    },
    {
      key: "CARDS_MODULE",
      value: "true",
    },
    {
      key: "FCY_MODULE",
      value: "true",
    },
    {
      key: "PAYMENTS_MODULE",
      value: "true",
    },
    {
      key: "TRANSFERS_MODULE",
      value: "true",
    },
    {
      key: "BENEFICIARIES_MODULE",
      value: "true",
    },
  ],
};
const LookUpResponse = {
  LookUpResponseData
};
const ContentResponse = {
  screenContents: [
    {
      localizationKey: "TimeoutLoginImgCancel",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "TimeoutLoginLblBtmtitle",
      value: "Session expired",
    },
    {
      localizationKey: "TimeoutLoginLblBtmsubtitle",
      value:
        "For your security, your session has ended. \r\nPlease log in again to continue.",
    },
    {
      localizationKey: "TimeoutLoginBtnLogin",
      value: "Log in ",
    },
    {
      localizationKey: "AuthenticationLoginLblWelcome",
      value: "Welcome to meem \r\nBanking made simple",
    },
    {
      localizationKey: "AuthenticationLoginTxtId",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationLoginTxtIdplc",
      value: "National ID or Username",
    },
    {
      localizationKey: "AuthenticationLoginTxtPassword",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationLoginTxtPasswordplc",
      value: "Password",
    },
    {
      localizationKey: "AuthenticationLoginLblForgotpass",
      value: "Forgot your credentials?",
    },
    {
      localizationKey: "AuthenticationLoginBtnExploremeem",
      value: "Explore meem",
    },
    {
      localizationKey: "AuthenticationLoginBtnOpenaccount",
      value: "Open an account",
    },
    {
      localizationKey: "AuthenticationLoginBtnLogin",
      value: "Login",
    },
    {
      localizationKey: "AuthenticationLoginImgMorehorizontal",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationLoginImgMeemtxt",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationLoginImgArabictranslate",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationEnterOtpLblTitle",
      value: "Enter OTP to confirm",
    },
    {
      localizationKey: "AuthenticationEnterOtpLblSubtitle",
      value: "Code sent to *******019",
    },
    {
      localizationKey: "AuthenticationEnterOtpLblTimer",
      value: "Resend code in 00:00",
    },
    {
      localizationKey: "AuthenticationEnterOtpLblLinkcode",
      value: "Didn’t receive the code?",
    },
    {
      localizationKey: "AuthenticationEnterOtpBtnConfirm",
      value: "Confirm",
    },
    {
      localizationKey: "AuthenticationEnterOtpImgCancel",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLblTitle",
      value: "Trusted device",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLblSubtitle",
      value:
        "To keep your account secure we need to \r\nregister this device as trusted. Request a\r\n call back and follow the instructions",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceBtnRequestcall",
      value: "Request callback",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLblTimer",
      value: "Resend another callback in 00:41",
    },
    {
      localizationKey: "AuthenticationPasscodeLblTrusted",
      value: "Trusted device registered",
    },
    {
      localizationKey: "AuthenticationPasscodeLblTitle",
      value: "Create your passcode",
    },
    {
      localizationKey: "AuthenticationPasscodeLblSubtitle",
      value:
        "Create a pattern that’s easy for you to remember,\r\n but hard for others to guess.",
    },
    {
      localizationKey: "AuthenticationPasscodeLblPasscode",
      value: "New passcode",
    },
    {
      localizationKey: "AuthenticationPasscodeLblRptpasscode",
      value: "Repeat your new passcode",
    },
    {
      localizationKey: "AuthenticationPasscodeBtnConfirm",
      value: "Confirm",
    },
    {
      localizationKey: "AuthenticationFaceIdLblTitle",
      value: "Activate Face ID",
    },
    {
      localizationKey: "AuthenticationFaceIdLblSubtitle",
      value: "Enable Face ID for quick and secure access.",
    },
    {
      localizationKey: "AuthenticationFaceIdBtnIgnore",
      value: "I’ll do it later",
    },
    {
      localizationKey: "AuthenticationFaceIdBtnEnable",
      value: "Enable Face ID",
    },
    {
      localizationKey: "AuthenticationFaceIdImgFaceid",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationTouchIdLblTitle",
      value: "Activate Touch ID",
    },
    {
      localizationKey: "AuthenticationTouchIdLblSubtitle",
      value: "Enable Touch ID for quick and secure access.",
    },
    {
      localizationKey: "AuthenticationTouchIdBtnIgnore",
      value: "I’ll do it later",
    },
    {
      localizationKey: "AuthenticationTouchIdBtnEnable",
      value: "Enable Touch ID",
    },
    {
      localizationKey: "AuthenticationTouchIdImgTouchid",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationRequestInProcessLblTitle",
      value: "You already have a request in process",
    },
    {
      localizationKey: "AuthenticationRequestInProcessLblSubtitle",
      value: "Hang tight, we’ll call you shortly.",
    },
    {
      localizationKey: "AuthenticationRequestInProcessBtnDone",
      value: "Done",
    },
    {
      localizationKey: "AuthenticationRequestInProcessImgWarning",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitLblTitle",
      value: "You have reached the limit of trusted device",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitLblSubtitle",
      value:
        "If you want to add this one, you need to remove one from the following list.",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitLblRemove",
      value: "Remove",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitImgWarning",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitImgDevice",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitLblUsername",
      value: "Zahra’s iPhone",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitLblRmtitle",
      value: "Are you sure you want to remove this device?",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitLblRmsubtitle",
      value: "You’ll need to re-add it as trusted to log in again",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitBtnCancel",
      value: "Cancel",
    },
    {
      localizationKey: "AuthenticationTrustedDeviceLimitBtnRmdevice",
      value: "Remove Device",
    },
    {
      localizationKey: "AuthenticationTrusteDeviceSecureLblUsermessage",
      value: "Zahra’s iPhone is no longer a trusted device",
    },
    {
      localizationKey: "AuthenticationTrusteDeviceSecureLblTitle",
      value: "Trusted device",
    },
    {
      localizationKey: "AuthenticationTrusteDeviceSecureLblSubtitle",
      value:
        "To keep your account secure we need to \r\nregister this device as trusted. Request a\r\n call back and follow the instructions",
    },
    {
      localizationKey: "AuthenticationTrusteDeviceSecureBtnRequestcall",
      value: "Request callback",
    },
    {
      localizationKey: "AuthenticationTrusteDeviceSecureImgDevice",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationLinkedDeviceLblTitle",
      value: "This device is already linked to another user",
    },
    {
      localizationKey: "AuthenticationLinkedDeviceLblSubtitle",
      value:
        "Log in to remove it from the trusted list before adding a new user.",
    },
    {
      localizationKey: "AuthenticationLinkedDeviceBtnDone",
      value: "Done",
    },
    {
      localizationKey: "AuthenticationLinkedDeviceImgWarning",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationDeviceLimitLblTitle",
      value: "You’ve reached the limit of devices per day",
    },
    {
      localizationKey: "AuthenticationDeviceLimitLblSubtitle",
      value: "You can only add 2 devices per day. \r\nTry again tomorrow",
    },
    {
      localizationKey: "AuthenticationDeviceLimitBtnDone",
      value: "Done",
    },
    {
      localizationKey: "AuthenticationDeviceLimitImgWarning",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationSuccessfullUpdateCredentialsLblTitle",
      value: "You have successfully updated your credentials",
    },
    {
      localizationKey: "AuthenticationSuccessfullUpdateCredentialsLblSubtitle",
      value: "Please log in using your new username and password ",
    },
    {
      localizationKey: "AuthenticationSuccessfullUpdateCredentialsBtnHome",
      value: "Go to Home",
    },
    {
      localizationKey: "AuthenticationSuccessfullUpdateCredentialsImgTick",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationUntrustedDeviceLblTitle",
      value: "Your device could not be registered as trusted",
    },
    {
      localizationKey: "AuthenticationUntrustedDeviceLblSubtitle",
      value: "Please log in and try again ",
    },
    {
      localizationKey: "AuthenticationUntrustedDeviceBtnLogin",
      value: "Login",
    },
    {
      localizationKey: "AuthenticationUntrustedDeviceImgWarning",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationLoginByPasswordLblWelcome",
      value: "Welcome",
    },
    {
      localizationKey: "AuthenticationLoginByPasswordTxtPwd",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationLoginByPasswordTxtPwdplc",
      value: "Password",
    },
    {
      localizationKey: "AuthenticationLoginByPasswordLblForgotpwd",
      value: "Forgot your credentials?",
    },
    {
      localizationKey: "AuthenticationLoginByPasswordBtnAccessbycode",
      value: "Access with passcode",
    },
    {
      localizationKey: "AuthenticationLoginByPasswordBtnLogin",
      value: "Login",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeLblWelcome",
      value: "Welcome",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeTxtPasscode",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeBtnAccesswithpwd",
      value: "Access with password",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeTxtPasscodeerror",
      value: "Incorrect passcode. You have 2 attempts remaining.",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeLblCannotlogin",
      value: "Can't Login ?",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeLblQuicklogindescr",
      value:
        "Quick login is temporarily disabled for your security because you exceeded the login attempts. Log in with your username and password to continue.",
    },
    {
      localizationKey: "AuthenticationLoginByPasscodeBtnLogin",
      value: "Login",
    },
    {
      localizationKey: "SettingsProfileSettingImgProfile",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingImgAdd",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingBtnCancel",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingImgMicrophone",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingLblNeedsupport",
      value: "Need Support",
    },
    {
      localizationKey: "SettingsProfileSettingLblNeedsupportdescrip",
      value: "meem cares",
    },
    {
      localizationKey: "SettingsProfileSettingLblInvitefriend",
      value: "Invite Friend",
    },
    {
      localizationKey: "SettingsProfileSettingLblInvitefrienddescrip",
      value: "Enjoy meem together",
    },
    {
      localizationKey: "SettingsProfileSettingImgAccountprofile",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingLblAccount",
      value: "Account",
    },
    {
      localizationKey: "SettingsProfileSettingLblNotifications",
      value: "Notification",
    },
    {
      localizationKey: "SettingsProfileSettingImgBell",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingImgKey",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingLblLogin&Access",
      value: "Log in & Access",
    },
    {
      localizationKey: "SettingsProfileSettingImgSecurityicon",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingImgArrow",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingLblSecurity",
      value: "Security",
    },
    {
      localizationKey: "SettingsProfileSettingImgLangicon",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "SettingsProfileSettingLblLanguage",
      value: "Language",
    },
    {
      localizationKey: "SettingsProfileSettingBtnLogout",
      value: "Log out",
    },
    {
      localizationKey: "SettingsProfileSettingLblWanttologout",
      value: "Want to log out?",
    },
    {
      localizationKey: "SettingsProfileSettingLblAnychangeyouhave",
      value: "Any changes you've made will not be saved.",
    },
    {
      localizationKey: "SettingsProfileSettingBtnCancel",
      value: "Cancel",
    },
    {
      localizationKey: "SettingsProfileSettingBtnLogout",
      value: "Log out",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblTitle",
      value: "Create your username",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblSubtitle",
      value:
        "Once you create a username, you can still log in with your ID number.",
    },
    {
      localizationKey: "AuthenticationCreateUserNameTxtUsername",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationCreateUserNameTxtUsernameplc",
      value: "Enter your username",
    },
    {
      localizationKey: "AuthenticationCreateUserNameTxtErrorrequiredusername",
      value: "Username is required",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListtitle",
      value: "Your username must have:",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListrequirement1",
      value: "One lowercase letter (a-z)",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListrequirement2",
      value: "One uppercase letter (A-Z)",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListrequirement3",
      value: "One number (0-9)",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListrequirement4",
      value: "One special character (!@#$%^&*?_-)",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListrequirement5",
      value: "Minimum 8 characters long",
    },
    {
      localizationKey: "AuthenticationCreateUserNameLblListrequirement6",
      value: "Maximum 20 characters long",
    },
    {
      localizationKey: "AuthenticationCreateUserNameBtnConfirm",
      value: "Confirm",
    },
    {
      localizationKey: "AuthenticationCreateUserNameImgArrowback",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblTitle",
      value: "Set up your password",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblSubtitle",
      value: "Create a secure password.",
    },
    {
      localizationKey: "AuthenticationCreatePasswordTxtPassword",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationCreatePasswordTxtPasswordplac",
      value: "Enter your password",
    },
    {
      localizationKey: "AuthenticationCreatePasswordTxtErrorrequiredpassword",
      value: "Password is required",
    },
    {
      localizationKey: "AuthenticationCreatePasswordTxtRepassword",
      value: "Dummy_value",
    },
    {
      localizationKey: "AuthenticationCreatePasswordTxtReppasswordplac",
      value: "Reapeat your password",
    },
    {
      localizationKey: "AuthenticationCreatePasswordTxtErrorrequiredrepassword",
      value: "Reapeat password is required",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblListtitle",
      value: "Your password must have at least:",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblListrequirement1",
      value: "Minimum 12 characters long",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblListrequirement2",
      value: "Include at least one uppercase letter (A-Z)",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblListrequirement3",
      value: "Include at least one lowercase letter (a-z)",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblListrequirement4",
      value: "Include at least one special character (e.g., @, #, $, %)",
    },
    {
      localizationKey: "AuthenticationCreatePasswordLblListrequirement5",
      value: "Include at least one number (0-9)",
    },
    {
      localizationKey: "AuthenticationCreatePasswordBtnConfirm",
      value: "Confirm",
    },
    {
      localizationKey: "AuthenticationCreatePasswordImgArrowback",
      value: "https://www.google.com/",
    },
    {
      localizationKey: "AuthenticationCreatePasswordImgCancel",
      value: "https://www.google.com/",
    },
  ],
};

interface ApiResponses {
  "/retrieve-configs": ApiResponse<ConfigResponse>;
  "/retrive-lookup-data": ApiResponse<LookUpResponse>;
  "/retrieve-contents": ApiResponse<ContentResponse>;
}


export const createContentApi = ({
  baseUrl,
  useMockApi,
  headers,
}: ApiParams) => {
  return createApi({
    reducerPath: "contentApi",
    baseQuery: async (
      args: { url: string; method: string; body?: any },
      api: any,
      extraOptions: any
    ) => {
      const responses: ApiResponses = {
        "/retrieve-configs": { data: ConfigResponse },
        "/retrive-lookup-data": { data: { objects : LookUpResponseData}},
        "/retrieve-contents": { data: ContentResponse },
      };

      if (useMockApi) {
        return await mockBaseQuery(args, responses[args.url], endpointList);
      } else {
        return await customFetchBaseQuery(baseUrl, headers)(
          args,
          api,
          extraOptions
        );
      }
    },
    endpoints: (builder) => ({
      retrieveConfig: builder.mutation<RetrieveResponse<ConfigResponse>, any>({
        query: (requestBody) => ({
          url: "/retrieve-configs",
          method: "POST",
          body: requestBody,
        }),
      }),

      retrieveLookup: builder.mutation<RetrieveResponse<LookUpResponse>, any>({
        query: (requestBody) => ({
          url: "/retrive-lookup-data",
          method: "POST",
          body: requestBody,
        }),
      }),

      retrieveContent: builder.mutation<RetrieveResponse<ContentResponse>, any>(
        {
          query: (requestBody) => ({
            url: "/retrieve-contents",
            method: "POST",
            body: requestBody,
          }),
        }
      ),
    }),
  });
};

export const {
  useRetrieveConfigMutation,
  useRetrieveContentMutation,
  useRetrieveLookupMutation,
} = createContentApi({
  baseUrl: "https://api.example.com",
  useMockApi: false,
  headers: { "Custom-Header": "CustomValue" },
});
