interface Endpoint {
  url: string;
  method: string;
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

interface ApiResponses {
  "/login": ApiResponse<typeof LoginResponse>;
  "/otp": ApiResponse<typeof OtpResponse>;
}

interface CreateLoginApiParams {
  baseUrl: string;
  useMockApi: boolean;
  headers?: Record<string, string>;
}

const LoginResponse = {
  data: "Test data",
};
const OtpResponse = { data: "Test data" };

const LoginRequest = {
  data: "Test data",
};
const OtpRequest = { data: "Test data" };

const endpointList: Endpoint[] = [
  {
    url: "/login",
    method: "POST",
  },
  {
    url: "/otp",
    method: "POST",
  },
];

export {
  OtpRequest,
  OtpResponse,
  endpointList,
  LoginRequest,
  LoginResponse,
  ApiResponses,
  Endpoint,
};
