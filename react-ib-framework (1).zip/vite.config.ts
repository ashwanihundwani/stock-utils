import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
  },
  resolve: {
    alias: {
      src: '/src',
      components: '/src/components',
      constants: '/src/constants',
      features: '/src/features',
      service: '/src/service',
      translations: '/src/translations',
      utils: '/src/utils',
      logger: '/src/logger',
      common: '/src/common',
      assets: '/src/assets',
    },
  },
});
