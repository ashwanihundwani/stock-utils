export const logger = {
  log: (message: string, data: object | string) => {
    if (process.env.NODE_ENV === 'development') console.log(message, data);
  },
  error: (message: string, data: object | string) => {
    if (process.env.NODE_ENV === 'development') console.error(message, data);
  },
  warn: (message: string, data: object | string) => {
    if (process.env.NODE_ENV === 'development') console.warn(message, data);
  },
  debug: (message: string, data: object | string) => {
    if (process.env.NODE_ENV === 'development') console.debug(message, data);
  },
  info: (message: string, data: object | string) => {
    if (process.env.NODE_ENV === 'development') console.info(message, data);
  },
};
