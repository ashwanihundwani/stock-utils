export const getStyles = () => {
  return {
    headerItems: {
      padding: '0px 20px',
      display: 'flex',
      justifyContent: 'center',
    },
  };
};
