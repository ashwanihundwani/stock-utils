import {FC} from 'react';
import {Box} from '@mui/material';
import {Images} from '../constants/images';
import {Image, CustomLabel} from 'components';
import {getStyles} from './styles';

interface HeaderCancelType {
  onClick: () => void;
}

export const HeaderLogo: FC = () => {
  const styles = getStyles();
  return (
    <Box sx={styles.headerItems}>
      <Image imageurl={Images.meem} type={'header'} />
    </Box>
  );
};

export const HeaderCancel: FC<HeaderCancelType> = ({onClick}) => {
  const styles = getStyles();

  const handleOnClick = () => {
    onClick();
  };
  return (
    <Box sx={styles.headerItems} onClick={() => handleOnClick()}>
      <CustomLabel
        id="otp_cancel_label"
        text={'otp_cancel_label'}
        onClick={() => handleOnClick()}
      />
    </Box>
  );
};
