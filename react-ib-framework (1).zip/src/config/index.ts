export const AppName = import.meta.env.VITE_NAME;
export const AppURL = import.meta.env.VITE_BASE_URL;
export const API_BASEURL = import.meta.env.VITE_API_BASE_URL;
export const API_TIMEOUT = Number(import.meta.env.VITE_API_TIMEOUT);
export const ENCRYPTION_KEY = import.meta.env.VITE_ENCRYPTION_KEY;
