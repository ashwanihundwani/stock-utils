import {SettingsRoutes} from 'constants/path';
import {
  ChangePassword,
  SettingsWrapper,
  LoginAndAccess,
  ChangePasswordOtp,
  ChangePasswordCallback,
  Security,
  ChangeTPin,
  ChangeTPinOtp,
  RegisteredDevices,
  RegisteredDevicesOtp,
} from 'features/settings';
import {Route} from 'react-router-dom';

const SettingsSection = () => {
  return (
    <Route path={SettingsRoutes.SettingsWrapper} element={<SettingsWrapper />}>
      <Route
        path={SettingsRoutes.LoginAndAccess}
        element={<LoginAndAccess />}
      />
      <Route
        path={SettingsRoutes.ChangePassword}
        element={<ChangePassword />}
      />
      <Route
        path={SettingsRoutes.ChangePasswordOtp}
        element={<ChangePasswordOtp />}
      />
      <Route
        path={SettingsRoutes.ChangePasswordCallback}
        element={<ChangePasswordCallback />}
      />
      <Route path={SettingsRoutes.Security} element={<Security />} />
      <Route path={SettingsRoutes.ChangeTPin} element={<ChangeTPin />} />
      <Route path={SettingsRoutes.ChangeTPinOtp} element={<ChangeTPinOtp />} />
      <Route
        path={SettingsRoutes.RegisteredDevices}
        element={<RegisteredDevices />}
      />
      <Route
        path={SettingsRoutes.RegisteredDevicesOtp}
        element={<RegisteredDevicesOtp />}
      />
    </Route>
  );
};

export default SettingsSection;
