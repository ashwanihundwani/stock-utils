import {BrowserRouter, Route, Routes} from 'react-router-dom';
import {ErrorBoundary} from 'react-error-boundary';
import {ErrorScreen as AppErrorScreen, AppLoader} from 'components';
import {AppSection} from 'constants/appSection';
import {useWindowClose} from 'constants/hooks';
import SettingsSection from './setting-routes';
import {DashboardWrapper} from 'features/common';
import {DashboardRoutes} from 'constants/path';
import {AuthSection} from './auth-routes';
import OnboardingSection from './onboarding-routes';

const Navigation = () => {
  const activeSection = AppSection.AuthSection;
  useWindowClose();

  const AppActiveSection = {
    [AppSection.AuthSection]: <PreLoginSection />,
    [AppSection.MainSection]: <PostLoginSection />,
  };

  return (
    <BrowserRouter>
      <ErrorBoundary FallbackComponent={AppErrorScreen}>
        <AppLoader />
        {activeSection ? AppActiveSection[activeSection] : <PreLoginSection />}
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Navigation;

const PreLoginSection = () => {
  return (
    <Routes>
      {/* Pre Login Routes */}
      {AuthSection()}
      {OnboardingSection()}
    </Routes>
  );
};

const PostLoginSection = () => {
  return (
    <Routes>
      {/* Post Login Routes */}
      <Route
        path={DashboardRoutes.DashboardWrapper}
        element={<DashboardWrapper />}>
        {SettingsSection()}
      </Route>
    </Routes>
  );
};
