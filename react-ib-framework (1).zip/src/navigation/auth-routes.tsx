import {Route} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
import {
  LoginScreen,
  LoginOtpScreen,
  TrustedBrowser,
  TrustedDevice,
  NonTrustedDevice,
  TrustedDeviceLinkedUser,
  TrustedDeviceLimit,
  CreateUserNameSrceen,
  SetPasswordSrceen,
  CredentialUpdateSrceen,
  AuthWrapper,
  CredentialsDisableInfo,
  CredentialsDisable,
  CredentialsDisabled,
  ResetPassword,
  ResetPasswordSuccess,
  ResetPasswordCallback,
  RecoverySelection,
  UsernameRecovery,
  UsernameRecoverySuccess,
  PasswordRecovery,
  UsernameRecoveryOtp,
  CredentialsDisableOtp,
  PasswordRecoveryOtp,
} from 'features/auth';

export const AuthSection = () => {
  return (
    <Route path={AuthRoutes.AuthWrapper} element={<AuthWrapper />}>
      <Route path={AuthRoutes.LoginScreen} element={<LoginScreen />} />
      <Route path={AuthRoutes.LoginOpt} element={<LoginOtpScreen />} />
      <Route path={AuthRoutes.TrustedBrowser} element={<TrustedBrowser />} />
      <Route
        path={AuthRoutes.TrustedDeviceScreen}
        element={<TrustedDevice />}
      />
      <Route
        path={AuthRoutes.NonTrustedDevice}
        element={<NonTrustedDevice />}
      />
      <Route
        path={AuthRoutes.TrustedDeviceLinkedUser}
        element={<TrustedDeviceLinkedUser />}
      />
      <Route
        path={AuthRoutes.TrustedDeviceLimit}
        element={<TrustedDeviceLimit />}
      />
      <Route
        index
        path={AuthRoutes.CreateUserNameScreen}
        element={<CreateUserNameSrceen />}
      />
      <Route
        index
        path={AuthRoutes.SetPasswordScreen}
        element={<SetPasswordSrceen />}
      />
      <Route
        index
        path={AuthRoutes.CredentialUpdateSrceen}
        element={<CredentialUpdateSrceen />}
      />
      <Route
        path={AuthRoutes.CredentialsDisableInfo}
        element={<CredentialsDisableInfo />}
      />
      <Route
        path={AuthRoutes.CredentialsDisable}
        element={<CredentialsDisable />}
      />
      <Route
        path={AuthRoutes.CredentialsDisableOtp}
        element={<CredentialsDisableOtp />}
      />
      <Route
        path={AuthRoutes.CredentialsDisabled}
        element={<CredentialsDisabled />}
      />
      <Route path={AuthRoutes.ResetPassword} element={<ResetPassword />} />
      <Route
        path={AuthRoutes.ResetPasswordCallback}
        element={<ResetPasswordCallback />}
      />
      <Route
        path={AuthRoutes.ResetPasswordSuccess}
        element={<ResetPasswordSuccess />}
      />
      <Route
        path={AuthRoutes.RecoverySelection}
        element={<RecoverySelection />}
      />
      <Route
        path={AuthRoutes.UsernameRecovery}
        element={<UsernameRecovery />}
      />
      <Route
        path={AuthRoutes.UsernameRecoverySuccess}
        element={<UsernameRecoverySuccess />}
      />
      <Route
        path={AuthRoutes.PasswordRecovery}
        element={<PasswordRecovery />}
      />
      <Route
        path={AuthRoutes.UsernameRecoveryOtp}
        element={<UsernameRecoveryOtp />}
      />
      <Route
        path={AuthRoutes.PasswordRecoveryOtp}
        element={<PasswordRecoveryOtp />}
      />
    </Route>
  );
};
