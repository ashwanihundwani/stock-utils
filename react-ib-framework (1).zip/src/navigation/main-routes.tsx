import {AppPath} from 'constants/path';
import {Route, Routes} from 'react-router-dom';
import {DashboardScreen} from 'features/dashboard';
import {SessionTimeout} from 'features/auth';
export const MainRoutes = () => {
  return (
    <>
      <SessionTimeout />
      <Routes>
        <Route path={AppPath.DashboardScreen} element={<DashboardScreen />} />
      </Routes>
    </>
  );
};
