import {useEffect} from 'react';

const usePreventZoom = (
  scrollCheck: boolean = true,
  keyboardCheck: boolean = true,
): void => {
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent): void => {
      if (
        keyboardCheck &&
        e.ctrlKey &&
        (e.key === '=' || // Zoom in key
          e.key === '+' || // Zoom in key (alternative)
          e.key === '-' || // Zoom out key
          e.key === '_' || // Zoom out key (alternative)
          e.key === 'Add' || // Numeric keypad + key
          e.key === 'Subtract') // Numeric keypad - key
      ) {
        e.preventDefault();
      }
    };

    const handleWheel = (e: WheelEvent): void => {
      if (scrollCheck && e.ctrlKey) {
        e.preventDefault();
      }
    };

    document.addEventListener('keydown', handleKeydown);
    document.addEventListener('wheel', handleWheel, {passive: false});

    return () => {
      document.removeEventListener('keydown', handleKeydown);
      document.removeEventListener('wheel', handleWheel);
    };
  }, [scrollCheck, keyboardCheck]);
};

export {usePreventZoom};
