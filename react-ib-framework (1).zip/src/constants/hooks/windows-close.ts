import {useEffect} from 'react';
import {useDispatch} from 'react-redux';
import {resetAllStates} from 'service/app-global';

const useWindowClose = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    const handleCloseWindow = () => {
      dispatch(resetAllStates());
    };
    window.addEventListener('unload', handleCloseWindow);
    return () => window.removeEventListener('unload', handleCloseWindow);
  }, [dispatch]);
};

export {useWindowClose};
