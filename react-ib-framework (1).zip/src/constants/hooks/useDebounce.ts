import {useState, useEffect} from 'react';

const useDebounce = (inputValue: string) => {
  const [debouncedValue, setDebouncedValue] = useState(inputValue);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(inputValue);
    }, 3000);

    return () => {
      clearTimeout(handler);
    };
  }, [inputValue]);

  return debouncedValue;
};

export {useDebounce};
