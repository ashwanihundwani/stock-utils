export const Images = {
  meem: new URL('../assets/images/meem.PNG', import.meta.url).href,
  loading: new URL('../assets/images/loading.gif', import.meta.url).href,
  error_404_img: new URL('../assets/images/error_images.png', import.meta.url)
    .href,
  error_bg_img: new URL('../assets/images/error_bg.png', import.meta.url).href,
  meem_login_logo: new URL(
    '../assets/images/meem_login_logo.png',
    import.meta.url,
  ).href,
  platinum_card: new URL('../assets/images/platinum_card.png', import.meta.url)
    .href,
  signature_card: new URL(
    '../assets/images/signature_card.png',
    import.meta.url,
  ).href,
  al_nasar_card: new URL('../assets/images/al_nasar_card.png', import.meta.url)
    .href,
  debit_card: new URL('../assets/images/debit_card.png', import.meta.url).href,
  nafath_img: new URL('../assets/images/nafath_app.png', import.meta.url).href,
  loginBg: new URL('../assets/images/loginBg.png', import.meta.url).href,
  ios_device: new URL('../assets/images/ios-device.png', import.meta.url).href,
  chrome_modern_1: new URL(
    '../assets/images/chrome-modern-1.png',
    import.meta.url,
  ).href,
  security_tip_illustration: new URL(
    '../assets/images/security-tip-illustration.png',
    import.meta.url,
  ).href,
};
