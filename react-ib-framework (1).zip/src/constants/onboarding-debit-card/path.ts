export const OnBoardingDebitCardPath = {
  TaxDeclarationDetails: '/tax-details',
  TaxIdentificationNumber: '/tax-details/info',
  CitizenshipDetails: '/tax-details/citizenship',
  BusinessOwner: '/business-owner',
  HouseWife: '/house-wife',
  UnEmployed: '/un-employed',

  Student: '/student',
  ChooseDebitCard: '/choose-debit-card',
};
