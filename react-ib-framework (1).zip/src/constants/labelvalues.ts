export const Values = {
  en: 'en',
  ar: 'ar',
  ltr: 'ltr',
  rtl: 'rtl',
  topmenu_cnt_lbl: 'topmenu-content-label',
  topmenu_cnt: 'topmenu-content',
};

export const buttonTypes = {
  filled: 'filled',
  outlined: 'outlined',
  standard: 'standard',
  option: 'option',
  optionOutlined: 'option_outlined',
} as const;

export const navigationProps = {
  goBack: -1,
};
