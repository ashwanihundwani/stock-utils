import {FC, useState} from 'react';

import {Box} from '@mui/material';
import {useNewTheme} from 'react-core';
import {headerStyles} from './styles';
import {MeemLogo} from 'assets/svg/headerIcons';
import {CancelIcon} from 'assets/svg/cancelIcon';
import Modal from 'components/modal';
import {HeaderSessionPopUp} from './header-session-popup';

interface HeaderTypesProps {
  headerOnClick?: () => void;
}
const Header: FC<HeaderTypesProps> = () => {
  const theme = useNewTheme();
  const styles = headerStyles(theme);

  const [headerCancelIconLOopen, setHeaderCancelIconLOopen] = useState(false);

  const headerCancelIconClick = () => {
    setHeaderCancelIconLOopen(true);
  };

  return (
    <Box sx={styles.header}>
      <Box sx={styles.logo}>
        <MeemLogo />
      </Box>
      <Box sx={styles.closeIcon} onClick={headerCancelIconClick}>
        <CancelIcon />
      </Box>
      <Modal
        open={headerCancelIconLOopen}
        onClose={() => setHeaderCancelIconLOopen(false)}>
        <HeaderSessionPopUp />
      </Modal>
    </Box>
  );
};

export default Header;
