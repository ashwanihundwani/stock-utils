export interface ModalTypeProps {
  value?: string;
  modalClose?: () => void;
}
