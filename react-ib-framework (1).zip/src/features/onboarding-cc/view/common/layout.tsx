import React from 'react';
import {Box} from '@mui/material';
import {useNewTheme} from 'react-core';
import {layoutStyles} from './styles';
import Sidebar from './sidebar';
import Header from './header';
import Grid from '@mui/material/Grid2';
import {useLocation} from 'react-router-dom';
import {getActiveStep} from 'utils/stepMapping';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({children}) => {
  const theme = useNewTheme();
  const styles = layoutStyles(theme);
  const location = useLocation();
  const activeStep = getActiveStep(location.pathname);

  return (
    <Box sx={styles.layout}>
      <Header />
      <Grid container columns={12} sx={styles.container}>
        <Grid sx={styles.rowStyle}>
          <Grid size={3}>
            <Sidebar activeStep={activeStep} />
          </Grid>

          <Grid container columns={9} size={9} sx={styles.content}>
            {children}
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Layout;
