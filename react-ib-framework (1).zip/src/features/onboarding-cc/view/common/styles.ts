import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const headerStyles = (theme: Theme) => ({
  header: {
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: '10%',
    padding: '0 16px',
    backgroundColor: theme.colors['surface-01'],
    borderBottom: `1px solid ${theme.colors['border-enabled-01']} `,
  },
  logo: {
    pl: 1,
  },
  closeIcon: {
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    pr: 4,
  },
});

export const layoutStyles = (theme: Theme) => ({
  layout: {
    height: '100vh',
  },
  container: {
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: theme.colors['surface-02'],
  },
  rowStyle: {display: 'flex', flexDirection: 'row'},
  content: {
    marginTop: '4.5rem',
    display: 'flex',
    justifyContent: 'center',
  },
});

export const sidebarStyles = (theme: Theme) => ({
  container: {
    display: 'flex',
    flexDirection: 'column',
    minHeight: 'calc( 100vh - 64px)', // Full height of the viewport
    padding: '0 16px',
    backgroundColor: theme.colors['background-01'],
  },
  title: {
    fontSize: 14,
    fontFamily: fonts.figtree_medium,
  },
  subTitle: {
    fontSize: 14,
    fontFamily: fonts.regular,
    color: theme.colors['content-secondary'],
  },
  contact: {
    pt: 1,
    pb: 1,
  },
  stepperWrapper: {
    flexGrow: 1,
    mt: 1,
  },
  supportSection: {
    textAlign: 'left',
  },
});

export const CannotOfferCCStyles = (theme: Theme) => ({
  container: {
    backgroundColor: theme.colors['background-01'],
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    top: 2,
  },
  innerGrid: {
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'center',

    gap: '1rem',
  },
  btnRowStyle: {display: 'flex', flexDirection: 'row', gap: '.5rem'},

  circleIcon: {
    borderRadius: '50%',
    backgroundColor: theme.colors['surface-semantic-error-01'],
    height: '104px',
    width: '104px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  successIcon: {
    borderRadius: '50%',
    backgroundColor: theme.colors['surface-semantic-success-01'],
    height: '104px',
    width: '104px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  listItems: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '1rem',
    paddingLeft: '16px',
    borderRadius: '0.625rem',
    width: '448px',
    minHeight: '100px',
    backgroundColor: theme.colors['surface-02'],
  },
  containerRow: {
    display: 'flex',
    padding: '1rem',
    flexDirection: 'row',
  },
  icons: {
    width: '42px',
    height: '32px',
    backgroundColor: theme.colors['surface-03'],
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '8px',
  },
  iconText: {
    textAlign: 'left',
    paddingLeft: '16px',
  },
  iconBox: {
    width: '60px',
  },
  overallOnePackAccountSet: {
    fontFamily: fonts.regular,
    weight: '500',
    fontSize: '28px',
    color: theme.colors['content-primary'],
    paddingTop: '32px',
    paddingBottom: '32px',
  },
  buttonPadding: {
    paddingTop: '32px',
  },
});
