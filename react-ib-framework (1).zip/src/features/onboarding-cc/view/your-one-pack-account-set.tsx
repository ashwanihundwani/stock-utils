import {FC, useState} from 'react';
import {useNewTheme, translation} from 'react-core';
import Grid from '@mui/material/Grid2';
import {CannotOfferCCStyles} from './common/styles';
import {Box} from '@mui/material';
import {Tick02} from 'assets/svg/tick02';
import {DeployedCode} from 'assets/svg/deployed-code';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {CreditCard} from 'assets/svg/credit-card';
import {Button} from 'components';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import RatingCard from 'components/rating-card';
// import {useUpdatefeedbackMutation} from '../../../redux/root-reducer';

const YourOnePackAccountSetSuccess: FC = () => {
  const theme = useNewTheme();
  const styles = CannotOfferCCStyles(theme);
  const {t} = translation.useTranslation();
  const [ratingValue, setRatingValue] = useState(0);
  // const [updateFeedbackService] = useUpdatefeedbackMutation();

  console.log(ratingValue, 'Rating value');

  const onPressSubmit = () => {
    // updateFeedbackService({
    //   customerID: '1023445987',
    //   serviceName: 'ForeignCurrencyAccountCreation',
    //   rating: ratingValue.toString(),
    // });
  };

  return (
    <Grid container size={12} sx={styles.container}>
      <Grid size={4} sx={styles.innerGrid}>
        <Grid sx={styles.successIcon}>
          <Tick02 color={theme.colors['icon-semantic-success-01']} size="52" />
        </Grid>
        <CustomLabel
          id={t(
            'OnboardingApplicationOnePackDebitCardSubmitSuccessLblTitleWeb',
          )}
          variant={variants.titleXL}
          style={styles.overallOnePackAccountSet}
          text={t(
            'OnboardingApplicationOnePackDebitCardSubmitSuccessLblTitleWeb',
          )}
        />
        <Box sx={styles.listItems}>
          <Box sx={styles.containerRow}>
            <Box sx={styles.iconBox}>
              <Box sx={styles.icons}>
                <DeployedCode />
              </Box>
            </Box>
            <Box sx={styles.iconText}>
              <CustomLabel
                id={t('OnboardingJoinMeemLblOnepackTitle')}
                variant={variants.bodyMediumM}
                text={t('OnboardingJoinMeemLblOnepackTitle')}
              />
              <CustomLabel
                id={t(
                  'OnboardingApplicationSubmitSuccessCreditCardLblSubtitle',
                )}
                variant={variants.bodyRegularS}
                text={t(
                  'OnboardingApplicationSubmitSuccessCreditCardLblSubtitle',
                )}
              />
            </Box>
          </Box>
          <Box sx={styles.containerRow}>
            <Box sx={styles.iconBox}>
              <Box sx={styles.icons}>
                <CreditCard />
              </Box>
            </Box>
            <Box sx={styles.iconText}>
              <CustomLabel
                id={t('AuthenticationDetailsForRecoveryTxtDebitcard')}
                variant={variants.bodyMediumM}
                text={t('AuthenticationDetailsForRecoveryTxtDebitcard')}
              />
              <CustomLabel
                id={t('OnboardingCardWillBeDeliveredAtAlkhobarWeb')}
                variant={variants.bodyRegularS}
                text={t('OnboardingCardWillBeDeliveredAtAlkhobarWeb')}
              />
            </Box>
          </Box>
        </Box>

        <Box sx={styles.buttonPadding}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('AuthenticationLoginByPasscodeBtnLogin')}
            disabled={false}
          />
        </Box>
        <RatingCard
          title={'helllo'}
          question={''}
          selectedRating={ratingValue}
          onRatingSelect={setRatingValue}
          // onClose={onClose}
          cancelText="Cancel"
          submitText="Submit"
          onSubmit={onPressSubmit}
        />
      </Grid>
    </Grid>
  );
};

export default YourOnePackAccountSetSuccess;
