import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {AlertCircle} from 'assets/svg';
import {Box} from '@mui/material';
import {CannotOfferCCStyles} from './common/styles';
import {useNewTheme, translation} from 'react-core';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {setCardType} from 'utils/localStorage';
import Header from 'features/onboarding-cc/view/common/header';

const CannotOfferCC: FC = () => {
  const {t} = translation.useTranslation();
  const theme = useNewTheme();
  const styles = CannotOfferCCStyles(theme);
  const navigate = useNavigate();

  const goToInitalScreen = () => {
    navigate(AppPath.OnboardingCreditCard);
  };

  const goToOnePack = () => {
    setCardType('debit');
    navigate(AppPath.BeforeWeBegin);
  };

  return (
    <>
      <Header />
      <Grid container columns={12} sx={styles.container}>
        <Grid size={4} columns={4} sx={styles.innerGrid}>
          <Box sx={styles.circleIcon}>
            <AlertCircle size="43" />
          </Box>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              flexDirection: 'column',
              gap: '.5rem',
            }}>
            <CustomLabel
              id="idCreditCardTitle"
              variant={variants.titleXL}
              text={t('OnboardingCannotOfferCreditCardLblTitle')}
            />

            <CustomLabel
              id="idCreditCardSubTitle"
              variant={variants.bodyRegularM}
              text={t('OnboardingCannotOfferCreditCardLblSubtitle')}
            />

            <CustomLabel
              id="idCreditCardcontent"
              variant={variants.bodyRegularM}
              text={t('OnboardingCannotOfferCreditCardLblOpenOnePack')}
            />
          </Box>

          <Box sx={styles.btnRowStyle}>
            <Button
              variant={ButtonStyle.Secondary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              text={t('OnboardingCannotOfferCreditCardBtnMaybeLater')}
              inverted={false}
              onClick={goToInitalScreen}
            />
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              text={t('OnboardingCannotOfferCreditCardBtnOpenOnePack')}
              inverted={false}
              onClick={goToOnePack}
            />
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default CannotOfferCC;
