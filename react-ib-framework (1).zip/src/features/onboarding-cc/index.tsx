// import {lazy} from 'react';

// export const MonthlyDepositScreen = lazy(
//   () => import('../auth/view/monthly-deposits'),
// );
