import {lazy} from 'react';

export const DashboardScreen = lazy(() => import('./view/dashboard'));
