import {useDispatch} from 'react-redux';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {resetAllStates, setAppSection} from 'service/app-global';
import {AppSection} from 'constants/appSection';

export const useDashboardPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const goBack = () => {
    dispatch(resetAllStates());
    dispatch(setAppSection(AppSection.AuthSection));
    navigate(AppPath.LoginScreen);
  };
  return {goBack};
};
