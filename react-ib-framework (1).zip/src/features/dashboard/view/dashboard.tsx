import {useState} from 'react';
import {ScreenContent} from 'components';
import {Box, Typography} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme} from 'react-core/hooks';
import Avatar from 'components/avatar';
import Header from 'components/header';
import Grid from '@mui/material/Grid2';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import Stories from 'components/stories-component';
import InfoPopup from 'components/info-popup';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
import {useDispatch} from 'react-redux';
import {AppSection} from 'constants/appSection';
import {setAppSection} from 'service/app-global';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
const Dashboard = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleLogout = () => {
    dispatch(setAppSection(AppSection.AuthSection));
    navigate(AuthRoutes.LoginScreen);
  };
  const listData = [
    {
      id: 1,
      title: 'Account',
    },
    {
      id: 2,
      title: 'Notifications',
    },
    {
      id: 3,
      title: 'Log in & Access',
    },
    {
      id: 4,
      title: 'Security',
    },
  ];
  return (
    <>
      <Grid container columns={12} spacing={1}>
        <Header />
        <Grid size={3} sx={styles.leftPanel}>
          <Avatar
            size="Small"
            type="empty"
            initial="Z"
            onlyIcon
            itemType="button"
          />
          <Typography sx={styles.primaryText}>Zahra Al-Harbi </Typography>
          <Typography sx={styles.secondaryText}>2,985 Ajeeb Points</Typography>
          <Box sx={styles.listItems}>
            <List>
              {listData?.map((listitem, index) => (
                <ListItem key={index} sx={styles.listItemsStyle}>
                  <ListItemText key={index}>{listitem.title}</ListItemText>
                </ListItem>
              ))}
            </List>
          </Box>
          <Box sx={styles.logoutBtn}>
            <Link
              size={LinkSize.Large}
              linkText="Log out"
              onClick={() => setOpen(true)}
            />
          </Box>
          <Box>
            <Typography sx={styles.inviteFriend}>Invite a friend </Typography>
          </Box>
        </Grid>
        <Grid size={7} sx={styles.rightPanel}>
          <ScreenContent>
            <Box sx={styles.content}>
              <Stories label="Label" />
            </Box>
          </ScreenContent>
        </Grid>
      </Grid>
      <InfoPopup open={open} onClose={() => setOpen(false)} icon={true}>
        <Box sx={styles.modalStyle}>
          <Box sx={styles.modaleTitle}>
            <Typography id="modal-modal-title">Want to Log out?</Typography>
          </Box>
          <Box>
            <Typography id="modal-modal-description" sx={{mt: 2}}>
              Any changes you made won’t be saved.
            </Typography>
          </Box>
          <Box sx={styles.modalButtons}>
            <Box sx={styles.modalCancelbtn}>
              <Button
                variant={ButtonStyle.Secondary}
                size={ButtonSize.Large}
                type={ButtonType.Text}
                text="Cancel"
                inverted={false}
                onClick={() => setOpen(false)}
              />
            </Box>
            <Box sx={styles.modalLogoutbtn}>
              <Button
                variant={ButtonStyle.Primary}
                size={ButtonSize.Large}
                type={ButtonType.Text}
                text="Log out"
                inverted={false}
                onClick={() => handleLogout()}
              />
            </Box>
          </Box>
        </Box>
      </InfoPopup>
    </>
  );
};

export default Dashboard;
