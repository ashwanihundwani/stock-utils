import React, {useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../styles';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Box} from '@mui/system';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {Typography} from '@mui/material';
import {Dropdown} from 'components';
import Chip from 'components/chip-component';
import TextInput from 'components/text-input';
import {useFormik} from 'formik';
import {
  OnboardingStatusInitialValues,
  OnboardingStatusSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-status';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';
import {InputType} from 'components/text-input/types';
import {getCardType} from 'utils/localStorage';

const CitizenshipDetails: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();
  const cardType = getCardType();

  const [residentStatus, setResidentStatus] = useState('yes');
  const [citizenStatus, setCitizenStatus] = useState('yes');

  const ddlOptions = [
    {
      id: '1',
      value: 'Spain',
      label: 'Spain',
    },

    {
      id: '2',
      value: 'India',
      label: 'India',
    },

    {
      id: '3',
      value: 'Germany',
      label: 'Germany',
    },
  ];

  const formik = useFormik({
    initialValues: OnboardingStatusInitialValues,
    validateOnBlur: true,
    validateOnChange: false,
    validationSchema: OnboardingStatusSchema(residentStatus, citizenStatus), // ✅ Pass residentStatus
    onSubmit: () => {
      if (cardType === 'debit') {
        navigate(AppPath.politicalyExposed);
      } else if (cardType === 'credit') {
        navigate(AppPath.boardMember);
      }
    },
  });

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingBackLblTitleWeb')}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingTaxDeclarationBirthDetailsLblTitle')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingStatusLblSubtitle')}
        </Typography>
        <Typography sx={styles.chipLabel}>
          {t('OnboardingStatusLblCitizenship')}
        </Typography>
        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={citizenStatus === 'yes'}
            onClick={() => {
              setCitizenStatus('yes');
              formik.validateForm();
            }}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={citizenStatus === 'no'}
            onClick={() => {
              setCitizenStatus('no');
              formik.setErrors({});
            }}
          />
        </Box>
        {citizenStatus === 'yes' ? (
          <Dropdown
            id="select-dropdown"
            labelId="select-dropdown-lablel"
            placeholder={t('OnboardingStatusDdCountries')}
            options={ddlOptions}
            customstyle={styles.dropdown}
            disabled={false}
            selectedValues={formik.values.citizenshipCountries}
            onSelectionChange={values =>
              formik.setFieldValue('citizenshipCountries', values)
            }
            errorText={t(
              formik.touched.citizenshipCountries &&
                typeof formik.errors.citizenshipCountries === 'string'
                ? formik.errors.citizenshipCountries
                : '',
            )}
            multiple={true}
          />
        ) : (
          ''
        )}
        <Typography sx={styles.chipLabel}>
          {t('OnboardingStatusLblVisa')}
        </Typography>
        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={residentStatus === 'yes'}
            onClick={() => {
              setResidentStatus('yes');
              formik.validateForm();
            }}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={residentStatus === 'no'}
            onClick={() => {
              setResidentStatus('no');
              formik.setErrors({});
            }}
          />
        </Box>
        {residentStatus === 'yes' ? (
          <>
            <Box>
              <Dropdown
                id="select-dropdown"
                labelId="select-dropdown-lablel"
                placeholder={t('OnboardingStatusDdCountries')}
                options={ddlOptions}
                customstyle={styles.dropdown}
                selectedValues={formik.values.immigrationCountries}
                onSelectionChange={values =>
                  formik.setFieldValue('immigrationCountries', values)
                }
                errorText={t(
                  formik.touched.immigrationCountries &&
                    typeof formik.errors.immigrationCountries === 'string'
                    ? formik.errors.immigrationCountries
                    : '',
                )}
                multiple={true}
                disabled={false}
              />
            </Box>
            <Typography sx={styles.chipLabel}>
              {t('OnboardingStatusLblSelectedCountries')}
            </Typography>
            <Grid container spacing={2}>
              {formik.values.immigrationCountries.map(country => (
                <Box key={country} mt={2}>
                  <TextInput
                    value={formik.values.residencyStates[country] || ''}
                    setValue={value =>
                      formik.setFieldValue(`residencyStates.${country}`, value)
                    }
                    label={`State of Residency (${country})`}
                    type={InputType.Text}
                    customStyle={styles.sharedTrustedInputStyles}
                  />
                </Box>
              ))}
            </Grid>
          </>
        ) : (
          ''
        )}
        <Grid sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingSalaryDetailsBtnNext')}
            disabled={false}
            onClick={formik.handleSubmit}
          />
        </Grid>
      </Box>
    </Grid>
  );
};

export default CitizenshipDetails;
