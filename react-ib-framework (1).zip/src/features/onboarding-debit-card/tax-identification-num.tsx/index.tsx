import React from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../styles';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Box} from '@mui/system';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {Typography} from '@mui/material';
import {Dropdown} from 'components';
import Chip from 'components/chip-component';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import {useFormik} from 'formik';
import {
  TaxIdentificationInitialValues,
  TaxIdentificationSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-tax-identification-number';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {PhoneNumberLength9} from 'constants/types';

const TaxIdentificationNum: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const ddlOptions = [
    {
      id: '1',
      value: 'US',
      label: 'US',
    },

    {
      id: '2',
      value: 'India',
      label: 'India',
    },

    {
      id: '3',
      value: 'Germany',
      label: 'Germany',
    },
  ];

  const formik = useFormik({
    initialValues: TaxIdentificationInitialValues,
    validationSchema: TaxIdentificationSchema,
    validateOnBlur: true,
    onSubmit: () => {
      navigate(AppPath.CitizenshipDetails);
    },
  });

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingBackLblTitleWeb')}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingTaxDeclarationBirthDetailsLblTitle')}
        </Typography>
        <Typography sx={styles.subTitle}>
          {t('OnboardingTaxDeclarationBirthDetailsLblSubtitle')}
        </Typography>
        <Typography sx={styles.chipLabel}>
          {t('OnboardingTaxIdentificationNumberLblNumber')}
        </Typography>
        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={formik.values.activeChip === 'yes'}
            onClick={() => formik.setFieldValue('activeChip', 'yes')}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={formik.values.activeChip === 'no'}
            onClick={() => formik.setFieldValue('activeChip', 'no')}
          />
        </Box>
        {formik.values.activeChip === 'yes' ? (
          <Box sx={styles.tId}>
            <TextInput
              label={t('OnboardingTaxIdentificationNumberTxtNumber')}
              value={formik.values.ksaAddress}
              setValue={val => formik.setFieldValue('ksaAddress', val)}
              type={InputType.Text}
              customStyle={styles.sharedTrustedInputStyles}
              maximumLength={PhoneNumberLength9}
              errorText={`${t(
                formik.touched.ksaAddress && formik.errors.ksaAddress
                  ? formik.errors.ksaAddress
                  : '',
              )}`}
            />
          </Box>
        ) : (
          <Box sx={styles.tId}>
            <Dropdown
              id="select-dropdown"
              labelId="select-dropdown-lablel"
              placeholder={t('OnboardingTaxIdentificationNumberDdReason')}
              options={ddlOptions}
              customstyle={styles.dropdown}
              disabled={false}
              value={formik.values.selectedReason}
              setValue={() =>
                formik.setFieldValue(
                  'selectedReason',
                  formik.values.selectedReason,
                )
              }
              errorText={
                formik.touched.selectedReason && formik.errors.selectedReason
                  ? formik.errors.selectedReason
                  : ''
              }
            />
          </Box>
        )}

        <Grid sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={t('OnboardingSalaryDetailsBtnNext')}
            disabled={false}
            onClick={formik.handleSubmit}
          />
        </Grid>
      </Box>
    </Grid>
  );
};

export default TaxIdentificationNum;
