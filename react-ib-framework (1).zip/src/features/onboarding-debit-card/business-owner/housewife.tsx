import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {getStyles} from 'features/onboarding-credit-card/employment-details/styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import Dropdown from 'components/select-dropdown';
import {monthlyIncome, sourceIncomeDropdown} from './utility';
import {Button, TextInput} from 'components';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {
  OnboardingHousewifeInitialValues,
  OnboardingHousewifeSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-housewife';
import {Screenprops} from './types';
import {useFormik} from 'formik';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';

const HouseWife: FC<Screenprops> = ({ScreenTitle}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const navigate = useNavigate();

  const {t} = useTranslation();
  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingHousewifeInitialValues,
    validationSchema: OnboardingHousewifeSchema,
    onSubmit: () => {
      navigate(AppPath.additionalIncome);
    },
  });
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingHousewifeLblTitle')}
          variant={variants.titleXL}
          text={
            ScreenTitle === 'Housewife'
              ? t('OnboardingHousewifeLblTitle')
              : t('OnboardingUnemployedLblTitle')
          }
        />
      </Grid>
      <Grid sx={styles.listGrid}>
        <Grid>
          <Dropdown
            id={
              ScreenTitle === 'Housewife'
                ? t('OnboardingHousewifeDdSourceOfIncome')
                : t('OnboardingUnemployedDdSourceOfIncome')
            }
            labelId={
              ScreenTitle === 'Housewife'
                ? t('OnboardingHousewifeDdSourceOfIncome')
                : t('OnboardingUnemployedDdSourceOfIncome')
            }
            placeholder={
              ScreenTitle === 'Housewife'
                ? t('OnboardingHousewifeDdSourceOfIncome')
                : t('OnboardingUnemployedDdSourceOfIncome')
            }
            options={sourceIncomeDropdown}
            errorText={`${t(formik.errors.sourceOfIncome ?? '')}`}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.sourceOfIncome}
            setValue={formik.handleChange('sourceOfIncome')}
          />
        </Grid>
        <Grid>
          <Dropdown
            id={t('OnboardingHousewifeDdMonthlyIncome')}
            labelId={t('OnboardingHousewifeDdMonthlyIncome')}
            placeholder={t('OnboardingHousewifeDdMonthlyIncome')}
            options={monthlyIncome}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.monthlyIncome}
            setValue={formik.handleChange('monthlyIncome')}
            errorText={`${t(formik.errors.monthlyIncome ?? '')}`}
          />
        </Grid>
        <Grid>
          <TextInput
            label={t('OnboardingBusinessOwnerTxtIncomeDescription')}
            customStyle={styles.textInput}
            value={formik.values.incomeDescription}
            setValue={formik.handleChange('incomeDescription')}
            errorText={`${t(formik.errors.incomeDescription ?? '')}`}
          />
        </Grid>
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingEmploymentDetailsBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={formik.handleSubmit}
        />
      </Grid>
    </Grid>
  );
};

export default HouseWife;
