export interface Screenprops {
  ScreenTitle: string;
}
