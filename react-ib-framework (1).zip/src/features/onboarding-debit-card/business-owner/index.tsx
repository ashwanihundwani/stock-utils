import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {getStyles} from 'features/onboarding-credit-card/employment-details/styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import Dropdown from 'components/select-dropdown';
import {AnnualIncome, industryDropdown} from './utility';
import {Button, TextInput} from 'components';
import {useFormik} from 'formik';
import {
  OnboardingBusinessOwnerInitialValues,
  OnboardingBusinessOwnerSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-business-owner';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';
import {MaximumInputLength} from 'constants/types';
import {InputType} from 'components/text-input/types';
const BusinessOwner: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingBusinessOwnerInitialValues,
    validationSchema: OnboardingBusinessOwnerSchema,
    onSubmit: () => {
      navigate(AppPath.additionalIncome);
    },
  });
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingBusinessOwnerLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingBusinessOwnerLblTitle')}
        />
      </Grid>
      <Grid>
        <CustomLabel
          id={t('OnboardingBusinessOwnerLblBusinessName')}
          variant={variants.bodyRegularM}
          text={t('OnboardingBusinessOwnerLblBusinessName')}
        />
      </Grid>
      <Grid sx={styles.listGrid}>
        <Grid>
          <Dropdown
            id={t('OnboardingBusinessOwnerDdIndustry')}
            labelId={t('OnboardingBusinessOwnerDdIndustry')}
            placeholder={t('OnboardingBusinessOwnerDdIndustry')}
            options={industryDropdown}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.industry}
            setValue={formik.handleChange('industry')}
            errorText={`${t(formik.errors.industry ?? '')}`}
          />
        </Grid>
        <Grid>
          <TextInput
            label={t('OnboardingBusinessOwnerTxtBusinessName')}
            customStyle={styles.textInput}
            value={formik.values.businessName}
            type={InputType.Text}
            setValue={formik.handleChange('businessName')}
            errorText={`${t(formik.errors.businessName ?? '')}`}
            maximumLength={MaximumInputLength}
          />
        </Grid>
        <Grid>
          <Dropdown
            id={t('OnboardingBusinessOwnerDdAnnualIncome')}
            labelId={t('OnboardingBusinessOwnerDdAnnualIncome')}
            placeholder={t('OnboardingBusinessOwnerDdAnnualIncome')}
            options={AnnualIncome}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.annualIncome}
            setValue={formik.handleChange('annualIncome')}
            errorText={`${t(formik.errors.annualIncome ?? '')}`}
          />
        </Grid>
        <Grid>
          <TextInput
            label={t('OnboardingBusinessOwnerTxtIncomeDescription')}
            customStyle={styles.textInput}
            type={InputType.Text}
            value={formik.values.incomeDescription}
            setValue={formik.handleChange('incomeDescription')}
            errorText={`${t(formik.errors.incomeDescription ?? '')}`}
            maximumLength={MaximumInputLength}
          />
        </Grid>
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingEmploymentDetailsBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={formik.handleSubmit}
        />
      </Grid>
    </Grid>
  );
};

export default BusinessOwner;
