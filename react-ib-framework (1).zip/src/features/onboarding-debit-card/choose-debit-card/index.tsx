import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from './styles';
import {useTranslation, useNewTheme} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Images} from 'constants/images';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import Button from 'components/button';
import {Tick02} from 'assets/svg/tick02';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
const ChooseDebitCard: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const meemDebitCardData = [
    {
      id: '1',
      name: 'Easy point-of-sale purchases and cash withdrawls',
    },
    {id: '2', name: 'Access to your money anytim, anywhere'},
    {id: '3', name: 'All your accounts on one card'},
  ];
  const debitCardData = [
    {
      id: '1',
      name: '15% Discount on Al Nasar merchandise',
    },
    {id: '2', name: '24/7 access to your account'},
    {id: '3', name: 'All your accounts on one card'},
  ];

  const chooseBtnClick = () => {
    navigate(AppPath.DirectDebitPin);
  };
  return (
    <Grid size={7} sx={styles.gridContainer}>
      <Box sx={styles.titleContainer}>
        <CustomLabel
          id="idChooseDebitCard"
          variant={variants.titleXL}
          text={t('OnboardingDebitCardChooseLblTitleWeb')}
        />
      </Box>
      <Box sx={styles.cardsContainers}>
        <Box sx={styles.cardsRowContainers}>
          <Box sx={styles.centerAlignment}>
            <img
              alt="img"
              style={styles.imgStyle}
              src={Images.debit_card}></img>
            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.titleS}
              text={t('OnboardingDebitCardChooseMeemCardLblTitle')}
            />
          </Box>
          {meemDebitCardData.map(value => {
            return (
              <Box key={value.id} sx={styles.textAlignment}>
                <Box sx={styles.tickIconGreenStyle}>
                  <Tick02
                    color={theme.colors['icon-inverted-primary']}
                    size="8"
                  />
                </Box>
                <CustomLabel
                  id="idChooseDebitCard"
                  variant={variants.bodyRegularS}
                  text={value.name}
                />
              </Box>
            );
          })}

          <Box sx={styles.chooseBtnStyle}>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.XLarge}
              type={ButtonType.Text}
              text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
              onClick={() => {
                chooseBtnClick();
              }}
            />
          </Box>
        </Box>
        <Box sx={styles.cardsRowContainers}>
          <Box sx={styles.centerAlignment}>
            <img
              alt="img"
              style={styles.imgStyle}
              src={Images.al_nasar_card}></img>

            <CustomLabel
              id="idChooseDebitCard"
              variant={variants.titleS}
              text={t('OnboardingDebitCardChooseDeibitCardLblTitle')}
            />
          </Box>
          {debitCardData.map(value => {
            return (
              <Box key={value.id} sx={styles.textAlignment}>
                <Box sx={styles.tickIconGreenStyle}>
                  <Tick02
                    color={theme.colors['icon-inverted-primary']}
                    size="8"
                  />
                </Box>
                <CustomLabel
                  id="idChooseDebitCard"
                  variant={variants.bodyRegularS}
                  text={value.name}
                />
              </Box>
            );
          })}
          {/* <Box sx={styles.chooseBtnStyle}> */}
          {/* <Box sx={styles.nextBtnStyle}> */}
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.XLarge}
            type={ButtonType.Text}
            text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
            onClick={() => console.log('Button Clicked')}
          />
          {/* </Box> */}
        </Box>
      </Box>
    </Grid>
  );
};

export default ChooseDebitCard;
