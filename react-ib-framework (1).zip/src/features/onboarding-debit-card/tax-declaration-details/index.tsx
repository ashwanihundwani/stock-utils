import React, {useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../styles';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Box} from '@mui/system';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {Dropdown} from 'components';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import Chip from 'components/chip-component';
import CustomCheckbox from 'components/checkbox';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import {useFormik} from 'formik';
import {
  OnboardingTaxDeclarationBirthDetailsInitialValues,
  OnboardingTaxDeclarationBirthDetailsSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-tax-declaration-birthdetails';

import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {setCitizenshipDetails} from 'utils/localStorage';
const TaxDeclarationDetails: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();
  const [activeChip, setActiveChip] = useState('yes');
  const [checkboxValue, setCheckboxValue] = useState(false);

  const onChange = () => {
    setCheckboxValue(!checkboxValue);
  };

  const ddlOptions = [
    {
      id: '1',
      value: 'US',
      label: 'US',
    },

    {
      id: '2',
      value: 'India',
      label: 'India',
    },

    {
      id: '3',
      value: 'Germany',
      label: 'Germany',
    },
  ];
  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingTaxDeclarationBirthDetailsInitialValues,
    validationSchema: OnboardingTaxDeclarationBirthDetailsSchema,
    onSubmit: () => {
      navigate(AppPath.TaxDeclarationAddCountry);
    },
  });

  const handleCitizenship = (value: string) => {
    setActiveChip(value);
    if (value === 'yes') {
      setCitizenshipDetails('US');
    } else if (value === 'no') {
      setCitizenshipDetails('NonUS');
    }
  };

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingBackLblTitleWeb')}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <CustomLabel
          id="idLblTiletaxBirth"
          variant={variants.titleXL}
          text={t('OnboardingTaxDeclarationBirthDetailsLblTitle')}
        />
        <CustomLabel
          id="idLblSubTiletaxBirth"
          variant={variants.bodyRegularM}
          text={t('OnboardingTaxDeclarationBirthDetailsLblSubtitle')}
        />
        <Grid sx={styles.birthDetails}>
          <Dropdown
            id="select-dropdown"
            labelId="select-dropdown-lable"
            placeholder={t('OnboardingTransferMoneyDdCountries')}
            options={ddlOptions}
            customstyle={styles.dropdown}
            disabled={false}
            value={formik.values.countryOfBirth}
            setValue={formik.handleChange('countryOfBirth')}
            errorText={`${t(formik.errors.countryOfBirth ?? '')}`}
            helperText={''}
          />
          <TextInput
            label={t('OnboardingTaxDeclarationBirthDetailsTxtCityOfBirth')}
            value={formik.values.cityOfBirth}
            setValue={formik.handleChange('cityOfBirth')}
            errorText={`${t(formik.errors.cityOfBirth ?? '')}`}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
        </Grid>
        <TextInput
          label={t('OnboardingTaxDeclarationBirthDetailsTxtAddress')}
          value={formik.values.Address}
          setValue={formik.handleChange('Address')}
          errorText={`${t(formik.errors.Address ?? '')}`}
          type={InputType.Text}
          customStyle={styles.sharedTrustedInputStyles}
        />
        <Grid sx={styles.UScitizenGrid}>
          <CustomLabel
            id="idLnlChipTitle"
            variant={variants.bodyMediumM}
            text={t('OnboardingTaxDeclarationBirthDetailsLblChipTitle')}
          />
        </Grid>

        <Box style={styles.chipContainer}>
          <Chip
            label={t('OnboardingStatusBtnChip1')}
            isActive={activeChip === 'yes'}
            onClick={() => handleCitizenship('yes')}
          />
          <Chip
            label={t('OnboardingStatusBtnChip2')}
            isActive={activeChip === 'no'}
            onClick={() => handleCitizenship('no')}
          />
        </Box>
        <Box sx={styles.checkbox}>
          <CustomCheckbox
            id="checkbox-cmp"
            errorText={''}
            helperText={''}
            disabled={false}
            onChange={onChange}
            icon={<CheckboxDefaultIcon />}
            checkedIcon={<CheckboxSelectedIcon />}
          />
          <CustomLabel
            id="lblIAccept"
            variant={variants.bodyRegularM}
            text={t('OnboardingCardDetailsChkAccept')}
          />

          <Link linkText=" Terms & Conditions" size={LinkSize.Large} />
        </Box>
        <Grid sx={styles.button}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            onClick={formik.handleSubmit}
            disabled={!(formik.isValid && formik.dirty)}
            text={t('OnboardingTaxDeclarationTaxResidentBtnConfirm')}
          />
        </Grid>
      </Box>
    </Grid>
  );
};

export default TaxDeclarationDetails;
