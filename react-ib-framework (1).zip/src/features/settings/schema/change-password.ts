import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const ChangePasswordInitialValues = {
  currentPassword: '',
  newPassword: '',
  repeatPassword: '',
};

export const ChangePasswordSchema = yup.object({
  currentPassword: yup
    .string()
    .required(Errors.SettingsChangepasswordTxtErrorRequiredCurrentpwd),
  newPassword: yup
    .string()
    .required()
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&*@^])(?=.{12,})/, ''),
  repeatPassword: yup
    .string()
    .oneOf([yup.ref('newPassword'), ''], Errors.CommonPasswordsetupTxtPwdmatch),
});
