import {lazy} from 'react';

export const SettingsWrapper = lazy(() => import('./view/setting-wrapper'));
export const ChangePassword = lazy(() => import('./view/change-password'));
export const LoginAndAccess = lazy(() => import('./view/login-and-access'));
export const ChangePasswordOtp = lazy(
  () => import('./view/change-password-otp'),
);
export const ChangePasswordCallback = lazy(
  () => import('./view/change-password-callback'),
);
export const Security = lazy(() => import('./view/security'));
export const ChangeTPin = lazy(() => import('./view/change-tpin'));
export const ChangeTPinOtp = lazy(() => import('./view/change-tpin-otp'));
export const RegisteredDevices = lazy(
  () => import('./view/registered-devices'),
);
export const RegisteredDevicesOtp = lazy(
  () => import('./view/registered-devices-otp'),
);
