import {RegisteredDevicesStyleProps} from './types';

export const getStyles = (props: RegisteredDevicesStyleProps) => {
  const {theme} = props;
  return {
    customScreenContainer: {
      backgroundColor: theme.colors['surface-01'],
      padding: '1rem',
      borderRadius: '0.5rem',
    },
    container: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1.5rem',
      paddingTop: '2rem',
    },
    registerDeviceListStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    deviceDetailsStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    subCategoryStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    actionContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1.5rem',
    },
    deviceNameStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      flex: 1,
    },
  };
};
