import {Box} from '@mui/material';
import {useNewTheme, useTranslation} from 'react-core';
import {CustomLabel, Link, ScreenContainer} from 'components';
import {useNavigate} from 'react-router-dom';
import {getStyles} from './styles';
import {variants} from 'components/custom-label/types';
import {LinkSize} from 'components/link/types';
import {Images} from 'constants/images';
import {SettingsRoutes} from 'constants/path';

const RegisteredDevices = () => {
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const {t: translate} = useTranslation();
  const navigate = useNavigate();
  const trustedDevices = [
    {
      id: 1,
      deviceType: 'mobile',
      deviceName: 'iPhone 13 Pro Max iOS 16',
      location: 'Riyadh, Saudi Arabia',
      state: 'Mobily',
      lastSignIn: '23 Dec, 2024 · 13:27',
      ip: '1234567890',
      img: Images.ios_device,
    },
    {
      id: 2,
      deviceType: 'browser',
      deviceName: 'Google Chrome 13.0',
      location: 'Riyadh, Saudi Arabia',
      state: 'Mobily',
      lastSignIn: '23 Dec, 2024 · 13:27',
      ip: '1234567890',
      img: Images.chrome_modern_1,
    },
  ];

  return (
    <ScreenContainer
      backLabel={translate('SettingsRegisteredDeviceLblBackWeb')}
      title={translate('SettingsRegisteredDeviceLblTitleWeb')}
      subtitle={
        translate('SettingsRegisteredDeviceLblSubtitlePrefixWeb') +
        2 +
        translate('SettingsRegisteredDeviceLblSubtitleSuffixWeb')
      }
      containerStyle={styles.customScreenContainer}>
      <Box sx={styles.container}>
        {trustedDevices.map(item => {
          return (
            <Box key={item.id} sx={styles.registerDeviceListStyle}>
              <CustomLabel
                id={'content-title'}
                text={
                  item.deviceType === 'mobile'
                    ? translate('SettingsRegisteredDeviceLblDeviceTitleWeb')
                    : translate('SettingsRegisteredDeviceLblBrowserTitleWeb')
                }
                variant={variants.bodySemiboldXS}
              />
              <Box sx={styles.deviceDetailsStyle}>
                <Box sx={styles.actionContainer}>
                  <Box sx={styles.deviceNameStyle}>
                    <img src={item.img} />
                    <CustomLabel
                      id={'devicename'}
                      text={item.deviceName}
                      variant={variants.bodyMediumM}
                    />
                  </Box>
                  <Link
                    linkText={translate('SettingsRegisteredDeviceLblRemoveWeb')}
                    size={LinkSize.Medium}
                    onClick={() =>
                      navigate(SettingsRoutes.RegisteredDevicesOtp)
                    }
                  />
                </Box>

                <Box sx={styles.subCategoryStyle}>
                  <CustomLabel
                    id={'location-title'}
                    text={translate('SettingsRegisteredDeviceLblDetailsWeb')}
                    variant={variants.bodyRegularXS}
                  />
                  <CustomLabel
                    id={'location'}
                    text={item.location}
                    variant={variants.bodyRegularS}
                  />
                  <CustomLabel
                    id={'state'}
                    text={item.state}
                    variant={variants.bodyRegularS}
                  />
                </Box>
                <Box sx={styles.subCategoryStyle}>
                  <CustomLabel
                    id={'location-title'}
                    text={translate(
                      'SettingsRegisteredDeviceLblLastSignedInWeb',
                    )}
                    variant={variants.bodyRegularXS}
                  />
                  <CustomLabel
                    id={'location'}
                    text={item.lastSignIn}
                    variant={variants.bodyRegularS}
                  />
                  <CustomLabel
                    id={'state'}
                    text={item.ip}
                    variant={variants.bodyRegularS}
                  />
                </Box>
              </Box>
            </Box>
          );
        })}
      </Box>
    </ScreenContainer>
  );
};

export default RegisteredDevices;
