import {Theme} from 'react-core';

export type RegisteredDevicesStyleProps = {
  theme: Theme;
};
