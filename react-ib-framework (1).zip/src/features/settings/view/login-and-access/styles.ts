import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    mainContainer: {
      display: 'flex',
      flexDirection: 'column',
      borderRadius: '0.5rem',
      backgroundColor: theme.colors['surface-01'],
      marginTop: '3rem',
    },
    loginAccessContainer: {
      display: 'flex',
      gap: '0.5rem',
      padding: '1rem',
    },
    passwordContainer: {
      display: 'flex',
      gap: '1rem',
      padding: '0.75rem',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderBottom: `0.063rem solid ${theme.colors['background-02']}`,
    },
    biometricsContainer: {
      display: 'flex',
      gap: '1rem',
      padding: '0.75rem',
      justifyContent: 'space-between',
    },
  };
};
