import {FC, useState} from 'react';
import {Box} from '@mui/material';
import {useTranslation, useNewTheme} from 'react-core';
import {useNavigate} from 'react-router-dom';
import {CustomLabel, Link, Toggle} from 'components';
import {variants} from 'components/custom-label/types';
import {LinkSize} from 'components/link/types';
import {getStyles} from './styles';
import {SettingsRoutes} from 'constants/path';

const LoginAndAccess: FC = () => {
  const {t: translate} = useTranslation();
  const theme = useNewTheme();
  const [enableBiometrics, setEnableBiometrics] = useState(false);
  const navigate = useNavigate();
  const styles = getStyles(theme);

  const handleBiometricsOption = () => {
    setEnableBiometrics(!enableBiometrics);
  };

  return (
    <Box sx={styles.mainContainer}>
      <Box sx={styles.loginAccessContainer}>
        <CustomLabel
          text={translate('SettingsLoginaccessLblTitle')}
          id="loginandaccess"
          variant={variants.titleS}
        />
      </Box>
      <Box sx={styles.passwordContainer}>
        <CustomLabel
          text={translate('SettingsLoginaccessLblPasswordMenu')}
          id="password"
          variant={variants.bodyMediumM}
        />
        <Link
          linkText={translate('SettingsLoginaccessLblPasswordOption')}
          size={LinkSize.Large}
          onClick={() => navigate(SettingsRoutes.ChangePassword)}
        />
      </Box>
      <Box sx={styles.biometricsContainer}>
        <CustomLabel
          text={translate('SettingsLoginaccessLblBiometricMenu')}
          id="biometrics"
          variant={variants.bodyMediumM}
        />
        <Toggle disabled={false} onChange={handleBiometricsOption} />
      </Box>
    </Box>
  );
};

export default LoginAndAccess;
