import {Theme} from 'react-core';

export type ChangePasswordOtpStyleProps = {
  theme: Theme;
};
