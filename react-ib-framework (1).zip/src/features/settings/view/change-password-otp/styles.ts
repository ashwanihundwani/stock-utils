import {ChangePasswordOtpStyleProps} from './types';

export const getStyles = (props: ChangePasswordOtpStyleProps) => {
  const {theme} = props;
  return {
    container: {
      borderRadius: '0.5rem',
      padding: '1rem',
      backgroundColor: theme.colors['surface-01'],
      marginTop: '3rem',
    },
  };
};
