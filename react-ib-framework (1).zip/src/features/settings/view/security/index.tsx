import {Box} from '@mui/material';
import {useNavigate} from 'react-router-dom';
import {useNewTheme, useTranslation} from 'react-core';
import {CustomLabel, Stories} from 'components';
import {variants} from 'components/custom-label/types';
import {ListArrow} from 'assets/svg';
import {Images} from 'constants/images';
import {getStyles} from './styles';
import {SettingsRoutes} from 'constants/path';

const Security = () => {
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const {t: translate} = useTranslation();
  const navigate = useNavigate();

  const devicesOptions = [
    {
      id: 1,
      title: 'SettingsSecurityLblSubHeaderTitle',
      description: `2 ${translate('SettingsSecurityLblDevicesCountWeb')}`,
      onClick: () => navigate(SettingsRoutes.RegisteredDevices),
    },
  ];

  const accountAccessOptions = [
    {
      id: 1,
      title: 'SettingsSecurityLblTPin',
      description: 'Last modification: 1 sept 2024',
      onClick: () => navigate(SettingsRoutes.ChangeTPin),
    },
    {
      id: 2,
      title: 'SettingsSecurityLblDisableCredentials',
      description: '',
      onClick: () => {},
    },
    {
      id: 3,
      title: 'SettingsSecurityLblRestrictedCountries',
      description: '',
      onClick: () => {},
    },
  ];

  const stories = [
    {
      id: 1,
      storyName: 'SettingsSecurityLblStory1',
      storyImg: Images.debit_card,
    },
    {
      id: 2,
      storyName: 'SettingsSecurityLblStory1',
      storyImg: Images.debit_card,
    },
    {
      id: 3,
      storyName: 'SettingsSecurityLblStory1',
      storyImg: Images.debit_card,
    },
  ];

  return (
    <Box sx={styles.container}>
      <Box sx={styles.securityTipsContainer}>
        <CustomLabel
          id={'security-tips-title'}
          text={translate('SettingsSecurityLblSubheader')}
          variant={variants.titleS}
        />
        <Stories data={stories} />
      </Box>

      <Box sx={styles.listContainer}>
        <Box sx={styles.headerTitle}>
          <CustomLabel
            id={'title'}
            text={'Devices'}
            variant={variants.titleS}
          />
        </Box>
        {devicesOptions.map(item => {
          return (
            <Box
              sx={styles.listItemContainer}
              key={item.id}
              onClick={item.onClick}>
              <CustomLabel
                id={'option'}
                text={translate(item.title)}
                variant={variants.bodyMediumM}
                style={styles.listItemTitle}
              />
              <CustomLabel
                id={'option'}
                text={item.description}
                variant={variants.bodyMediumM}
                style={styles.listItemDescription}
              />
              <ListArrow />
            </Box>
          );
        })}
      </Box>

      <Box sx={styles.listContainer}>
        <Box sx={styles.headerTitle}>
          <CustomLabel
            id={'title'}
            text={translate('SettingsSecurityLblAccountAccess')}
            variant={variants.titleS}
          />
        </Box>
        {accountAccessOptions.map(item => {
          return (
            <Box
              sx={styles.listItemContainer}
              key={item.id}
              onClick={item.onClick}>
              <CustomLabel
                id={'option'}
                text={translate(item.title)}
                variant={variants.bodyMediumM}
                style={styles.listItemTitle}
              />
              <CustomLabel
                id={'option'}
                text={item?.description}
                variant={variants.bodyMediumM}
                style={styles.listItemDescription}
              />
              <ListArrow />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default Security;
