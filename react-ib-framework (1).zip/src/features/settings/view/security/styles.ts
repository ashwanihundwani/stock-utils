import {SecurityStyleProps} from './types';

export const getStyles = (props: SecurityStyleProps) => {
  const {theme} = props;
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      marginTop: '3rem',
    },
    securityTipsContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
      padding: '1rem',
      backgroundColor: theme.colors['surface-01'],
      borderRadius: '0.5rem',
    },
    listContainer: {
      display: 'flex',
      flexDirection: 'column',
      borderRadius: '0.5rem',
      backgroundColor: theme.colors['surface-01'],
    },
    headerTitle: {
      padding: '1rem',
    },
    listItemContainer: {
      display: 'flex',
      flexDirection: 'row',
      padding: '0.75rem',
      gap: '1rem',
      alignItems: 'center',
      borderBottom: `0.063rem solid ${theme.colors['border-enabled-01']}`,
      cursor: 'pointer',
    },
    listItemTitle: {
      flex: 1,
    },
    listItemDescription: {
      color: theme.colors['content-secondary'],
    },
  };
};
