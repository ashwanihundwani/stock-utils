import {Theme} from 'react-core';

export type SecurityStyleProps = {
  theme: Theme;
};
