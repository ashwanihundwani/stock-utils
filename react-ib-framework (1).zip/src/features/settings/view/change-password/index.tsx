import {Grid2 as Grid} from '@mui/material';
import {useNavigate} from 'react-router-dom';
import {useFormik} from 'formik';
import {Button, ScreenContainer, TextInput, PasswordRules} from 'components';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {getStyles} from './styles';
import {
  ChangePasswordInitialValues,
  ChangePasswordSchema,
} from 'features/settings/schema/change-password';
import {useNewTheme, useTranslation} from 'react-core';
import {SettingsRoutes} from 'constants/path';

const ChangePassword = () => {
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const navigate = useNavigate();
  const {t: translate} = useTranslation();
  const formik = useFormik({
    initialValues: ChangePasswordInitialValues,
    validationSchema: ChangePasswordSchema,
    onSubmit: () => {
      navigate(SettingsRoutes.ChangePasswordOtp);
    },
  });
  return (
    <ScreenContainer
      backLabel="SettingsChangepasswordBtnBackWeb"
      title="SettingsChangepasswordLblTitle"
      containerStyle={styles.customScreenContainer}>
      <Grid container columns={7} sx={styles.mainContainer}>
        <Grid size={4} sx={styles.inputContainer}>
          <TextInput
            label={translate('SettingsChangepasswordTxtCurrentPwd')}
            value={formik.values.currentPassword}
            setValue={formik.handleChange('currentPassword')}
            errorText={formik.errors.currentPassword}
          />
          <TextInput
            label={translate('CommonPasswordSetupTxtNewPassword')}
            value={formik.values.newPassword}
            setValue={formik.handleChange('newPassword')}
          />
          <TextInput
            label={translate('CommonPasswordSetupTxtRepeatPassword')}
            value={formik.values.repeatPassword}
            setValue={formik.handleChange('repeatPassword')}
            errorText={
              formik.errors.repeatPassword
                ? translate(formik.errors.repeatPassword)
                : ''
            }
          />
        </Grid>
        <PasswordRules value={formik.values.newPassword} />
      </Grid>
      <Button
        text={translate('SettingsChangePasswordBtnChangePwd')}
        variant={ButtonStyle.Primary}
        type={ButtonType.Text}
        size={ButtonSize.Large}
        onClick={formik.handleSubmit}
      />
    </ScreenContainer>
  );
};

export default ChangePassword;
