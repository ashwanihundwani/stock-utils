import {ChangePasswordStyleProps} from './types';

export const getStyles = (props: ChangePasswordStyleProps) => {
  const {theme} = props;
  return {
    customScreenContainer: {
      backgroundColor: theme.colors['surface-01'],
      padding: '1rem',
      borderRadius: '0.5rem',
    },
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    rulesContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    mainContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1.5rem',
      margin: '2rem 0rem',
    },
  };
};
