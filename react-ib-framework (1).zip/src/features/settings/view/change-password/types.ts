import {Theme} from 'react-core';

export type ChangePasswordStyleProps = {
  theme: Theme;
};
