import {SettingWrapperStyleProps} from './types';

export const getStyles = (props: SettingWrapperStyleProps) => {
  const {theme} = props;
  return {
    container: {
      height: '100%',
      display: 'flex',
      flexDirection: 'row',
    },
    sideBarContainer: {
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: theme.colors['surface-01'],
      justifyContent: 'space-between',
      padding: '1.5rem',
      overFlowY: 'auto',
    },
    contentStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2.5rem',
    },
    profileContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1.5rem',
    },
    profileDetails: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.25rem',
    },
    settingsOptions: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    separatorStyle: {
      border: `0.063rem solid ${theme.colors['border-enabled-01']}`,
    },
    mainContentContainer: {
      backgroundColor: theme.colors['surface-02'],
      display: 'flex',
      justifyContent: 'center',
    },
  };
};
