import {Box, Grid2 as Grid} from '@mui/material';
import {useNewTheme} from 'react-core';
import {Outlet, useLocation, useNavigate} from 'react-router-dom';
import {getStyles} from './styles';
import {CustomLabel, Link, Avatar} from 'components';
import {variants} from 'components/custom-label/types';
import {LinkSize, LinkType} from 'components/link/types';
import {SettingsRoutes} from 'constants/path';

const SettingWrapper = () => {
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const location = useLocation();
  const navigate = useNavigate();
  const user = {name: 'Zahra Al-Harbi', adjeebPts: '2,985'};

  const settingOptions = [
    {
      id: 1,
      name: 'SettingsProfileSettingLblAccount',
      route: SettingsRoutes.Account,
    },
    {
      id: 2,
      name: 'SettingsProfileSettingLblNotifications',
      route: SettingsRoutes.Notifications,
    },
    {
      id: 3,
      name: 'SettingsProfileSettingLblLogin&Access',
      route: SettingsRoutes.LoginAndAccess,
    },
    {
      id: 4,
      name: 'SettingsProfileSettingLblSecurity',
      route: SettingsRoutes.Security,
    },
  ];

  const otherOptions = [
    {
      id: 1,
      name: 'SettingsProfileSettingLblInviteFriend',
      route: SettingsRoutes.InviteFriends,
    },
  ];

  return (
    <Grid container sx={styles.container}>
      {/* Side Bar */}
      <Grid size={3} sx={styles.sideBarContainer}>
        <Box sx={styles.contentStyle}>
          <Box sx={styles.profileContainer}>
            <Avatar size={'Large'} type={'empty'} onlyIcon initial="Z" />
            <Box sx={styles.profileDetails}>
              <CustomLabel
                text={user.name}
                id={'profileIcon'}
                variant={variants.titleL}
              />
              <CustomLabel
                text={`${user.adjeebPts} Ajeeb Points`}
                id={'profileIcon'}
                variant={variants.bodyRegularS}
              />
            </Box>
          </Box>
          <Box sx={styles.settingsOptions}>
            {settingOptions.map(item => {
              return (
                <Link
                  key={item.id}
                  linkText={item.name}
                  type={
                    item.route === location.pathname
                      ? LinkType.Primary
                      : LinkType.Secondary
                  }
                  onClick={() => navigate(item.route)}
                  size={LinkSize.Large}
                />
              );
            })}
            <Box sx={styles.separatorStyle} />
            {otherOptions.map(item => {
              return (
                <Link
                  key={item.id}
                  linkText={item.name}
                  type={
                    item.route === location.pathname
                      ? LinkType.Primary
                      : LinkType.Secondary
                  }
                  onClick={() => navigate(item.route)}
                  size={LinkSize.Large}
                />
              );
            })}
          </Box>
        </Box>
        <Link
          linkText={'SettingsProfileSettingBtnLogout'}
          type={LinkType.Primary}
          size={LinkSize.Large}
        />
      </Grid>
      {/* Main Content */}
      <Grid container size={9} columns={9} sx={styles.mainContentContainer}>
        <Grid size={7}>
          <Outlet />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default SettingWrapper;
