import {Theme} from 'react-core';

export type SettingWrapperStyleProps = {
  theme: Theme;
};
