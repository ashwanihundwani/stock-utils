import {FC} from 'react';
import {Grid2 as Grid} from '@mui/material';
import {useNewTheme} from 'react-core';
import {useNavigate} from 'react-router-dom';
import {OtpContainer} from 'components';
import {SettingsRoutes} from 'constants/path';
import {getStyles} from './styles';

const RegisteredDevicesOtp: FC = () => {
  const navigate = useNavigate();
  const theme = useNewTheme();
  const styles = getStyles({theme});

  return (
    <Grid columns={7} sx={styles.container}>
      <Grid size={4}>
        <OtpContainer
          onResendOtp={() => {}}
          title={'AuthenticationEnterOtpLblTitle'}
          subtitle={'AuthenticationEnterOtpLblSubtitle'}
          resendOtpLabel={'AuthenticationEnterOtpLblTimer'}
          requestOtpLabel={'AuthenticationEnterOtpLblLinkCode'}
          onSubmitOtp={() => {
            navigate(SettingsRoutes.Security);
          }}
          backLabel={'SettingsRegisteredDeviceOtpLblBackWeb'}
        />
      </Grid>
    </Grid>
  );
};

export default RegisteredDevicesOtp;
