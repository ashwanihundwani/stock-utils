import {Theme} from 'react-core';

export type RegisteredDevicesOtpStyleProps = {
  theme: Theme;
};
