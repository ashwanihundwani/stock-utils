import {ChangePasswordCallbackStyleProps} from './types';

export const getStyles = (props: ChangePasswordCallbackStyleProps) => {
  const {theme} = props;
  return {
    container: {
      marginTop: '3rem',
      padding: '1rem',
      backgroundColor: theme.colors['surface-01'],
      borderRadius: '0.5rem',
    },
    resetPasswordCallbackTimerContainer: {
      display: 'flex',
      gap: '0.25rem',
    },
  };
};
