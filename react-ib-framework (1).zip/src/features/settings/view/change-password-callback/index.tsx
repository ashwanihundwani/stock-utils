import {FC, useEffect, useState} from 'react';
import {Box} from '@mui/material';
import {useNavigate} from 'react-router-dom';
import {useNewTheme, useTranslation} from 'react-core';
import {CustomLabel, Timer, InfoScreen} from 'components';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {variants} from 'components/custom-label/types';
import {InfoIconType} from 'components/info-screen/types';
import {SettingsRoutes} from 'constants/path';
import {getStyles} from './styles';

const ChangePasswordCallback: FC = () => {
  const navigate = useNavigate();
  const {t: translate} = useTranslation();
  const theme = useNewTheme();
  const styles = getStyles({theme});

  const [initialTime, setInitialTime] = useState<number>(60);
  const [disabled, setDisabled] = useState<boolean>(true);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      navigate(SettingsRoutes.LoginAndAccess);
    }, 5000);

    return () => clearTimeout(timeoutId);
  }, []);
  const startNewTimer = () => {
    setDisabled(true);
    setInitialTime(60);
  };
  const handleTimerComplete = () => {
    setDisabled(false);
  };

  return (
    <Box sx={styles.container}>
      <InfoScreen
        title="SettingsChangePwdCallbackLblTitle"
        subtitle="SettingsChangePwdCallbackLblSubtitle"
        iconType={InfoIconType.success}
        primaryBtn={{
          label: 'SettingsChangepwdCallbackBtnLabel',
          size: ButtonSize.Large,
          variant: ButtonStyle.Primary,
          type: ButtonType.Text,
          onClick: () => startNewTimer(),
          disabled,
        }}>
        <Box sx={styles.resetPasswordCallbackTimerContainer}>
          <CustomLabel
            text={translate('SettingsChangePwdCallbackLblReset')}
            id="timerTitle"
            variant={variants.bodyRegularS}
          />
          <Timer
            initialTimeInSeconds={initialTime}
            onTimerComplete={() => handleTimerComplete()}
          />
        </Box>
      </InfoScreen>
    </Box>
  );
};

export default ChangePasswordCallback;
