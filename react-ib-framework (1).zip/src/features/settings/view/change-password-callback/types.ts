import {Theme} from 'react-core';

export type ChangePasswordCallbackStyleProps = {
  theme: Theme;
};
