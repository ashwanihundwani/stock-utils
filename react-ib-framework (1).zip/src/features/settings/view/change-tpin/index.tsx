import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {Box, Grid2 as Grid} from '@mui/material';
import {useNewTheme, useTranslation} from 'react-core';
import {Button, CustomLabel, OtpInput, ScreenContainer} from 'components';
import {getStyles} from './styles';
import {variants} from 'components/custom-label/types';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {SettingsRoutes} from 'constants/path';

const ChangeTPin = () => {
  const [tpin, setTpin] = useState(['', '', '', '']);
  const [repeatTpin, setRepeatTpin] = useState(['', '', '', '']);
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const {t: translate} = useTranslation();
  const navigate = useNavigate();

  return (
    <ScreenContainer
      backLabel={translate('SettingsChangeTPinBtnBackWeb')}
      title={translate('SettingsChangeTPinLblTitle')}
      containerStyle={styles.customScreenContainer}>
      <Grid container columns={7} sx={styles.contentContainer}>
        <Grid size={4} sx={styles.inputContainer}>
          <Box sx={styles.pinContainer}>
            <CustomLabel
              id={''}
              text={translate('SettingsChangeTPinTxtNewPin')}
              variant={variants.bodyRegularM}
            />
            <OtpInput otp={tpin} setOtp={setTpin} />
          </Box>
          <Box sx={styles.pinContainer}>
            <CustomLabel
              id={''}
              text={translate('SettingsChangeTPinTxtRptPin')}
              variant={variants.bodyRegularM}
            />
            <OtpInput otp={repeatTpin} setOtp={setRepeatTpin} />
          </Box>
        </Grid>
        <Button
          variant={ButtonStyle.Primary}
          type={ButtonType.Text}
          size={ButtonSize.Large}
          text={translate('SettingsChangeTPinBtnNext')}
          onClick={() => navigate(SettingsRoutes.ChangeTPinOtp)}
        />
      </Grid>
    </ScreenContainer>
  );
};

export default ChangeTPin;
