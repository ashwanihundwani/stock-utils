import {Theme} from 'react-core';

export type ChangeTPinStyleProps = {
  theme: Theme;
};
