import {ChangeTPinStyleProps} from './types';

export const getStyles = (props: ChangeTPinStyleProps) => {
  const {theme} = props;
  return {
    customScreenContainer: {
      backgroundColor: theme.colors['surface-01'],
      padding: '1rem',
      borderRadius: '0.5rem',
    },
    contentContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
      paddingTop: '2rem',
    },
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
    },
    pinContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
  };
};
