import {ChangeTPinOtpStyleProps} from './types';

export const getStyles = (props: ChangeTPinOtpStyleProps) => {
  const {theme} = props;
  return {
    container: {
      borderRadius: '0.5rem',
      padding: '1rem',
      backgroundColor: theme.colors['surface-01'],
      marginTop: '3rem',
    },
  };
};
