import {Theme} from 'react-core';

export type ChangeTPinOtpStyleProps = {
  theme: Theme;
};
