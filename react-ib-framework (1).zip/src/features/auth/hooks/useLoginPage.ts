import {useNavigate} from 'react-router-dom';
import {i18n, useTranslation} from 'translations';
import {buttonTypes, Values} from 'constants/labelvalues';
import {useEffect} from 'react';
import {AuthRoutes} from 'constants/path';
import {useFormik} from 'formik';
import {loginInitialValues, loginValidation} from '../schemas/login-form';
import {useLoginMutation} from 'react-core/api';

const useLoginPage = () => {
  const navigate = useNavigate();
  const {t: translate} = useTranslation();
  const langDir = (document.dir =
    i18n.dir() === Values.ltr ? Values.ltr : Values.rtl);
  const [loginService, {isSuccess}] = useLoginMutation();
  const loginForm = useFormik({
    initialValues: loginInitialValues,
    validateOnBlur: true,
    validateOnChange: true,
    validateOnMount: false,
    validationSchema: loginValidation,
    onSubmit: async values => {
      const loginServicePayload = {
        userName: values.username,
        password: values.password,
      };
      console.log(loginServicePayload);
      try {
        await loginService(loginServicePayload).unwrap();
      } catch (err) {
        console.log(err);
      }
    },
  });

  useEffect(() => {
    if (isSuccess === true) navigate(AuthRoutes.LoginOpt);
  }, [isSuccess, navigate]);

  const changeUserLang = () => {
    i18n.changeLanguage(langDir === Values.ltr ? Values.ar : Values.en);
  };

  const loginBtn = [
    {
      id: 1,
      label: translate('login_label_btn'),
      onClick: loginForm.handleSubmit,
      type: buttonTypes.filled,
      disabled: !(loginForm.isValid && loginForm.dirty),
    },
  ];

  return {loginBtn, changeUserLang, loginForm, translate, langDir};
};

export default useLoginPage;
