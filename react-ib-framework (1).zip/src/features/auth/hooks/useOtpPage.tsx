import {buttonTypes} from 'constants/labelvalues';
import {useDispatch} from 'react-redux';
import {useTranslation} from 'translations';
import {useFormik} from 'formik';
import {otpFormInitialValue, otpFormValidation} from '../schemas/otp-form';
import {useNavigate} from 'react-router-dom';
import {setUserData} from 'service/auth-services';
import {AppPath} from 'constants/path';
import {setAppSection} from 'service/app-global';
import {AppSection} from 'constants/appSection';
import {useEffect} from 'react';

const useOtpPage = (nextScreenPath: string) => {
  const {t: translate} = useTranslation();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const otpForm = useFormik({
    initialValues: otpFormInitialValue,
    validateOnChange: true,
    validateOnBlur: true,
    validateOnMount: false,
    validationSchema: otpFormValidation,

    onSubmit: values => {
      console.log('nextScreenPath', nextScreenPath);

      // const OtpCheckPayload = {otp: values.otp};
      dispatch(setAppSection(AppSection.MainSection));
      navigate(nextScreenPath);
      console.log(values);
    },
  });
  console.log('isdirty', otpForm.dirty);
  console.log('isvalid', otpForm.isValid);

  useEffect(() => {}, [otpForm.isValid, otpForm.dirty]);

  const goBack = () => {
    dispatch(setUserData(null));
    navigate(AppPath.LoginScreen);
  };

  const otpBtns = [
    {
      id: 1,
      label: translate('otp_back_button'),
      type: buttonTypes.outlined,
      onClick: () => goBack(),
    },
    {
      id: 2,
      label: translate('otp_continue_button'),
      type: buttonTypes.filled,
      disabled: otpForm.dirty && otpForm.isValid,
      onClick: () => otpForm.handleSubmit,
    },
  ];

  return {otpBtns, translate, otpForm, goBack};
};

export default useOtpPage;
