import {createApi} from '@reduxjs/toolkit/query/react';

interface LoginResponse {
  success: boolean;
  token?: string;
  message?: string;
}

interface LoginRequest {
  userName: string;
  password: string;
}

// Mocking the base query for login
/* eslint-disable  @typescript-eslint/no-explicit-any */
const mockBaseQuery = async ({url, method, body}: any) => {
  if (url === '/login' && method === 'POST') {
    if (body.userName === 'test' && body.password === 'password123') {
      return {data: {success: true, token: 'mocked-token'}};
    }
  }

  throw new Error('Unknown endpoint');
};

// Mock Login API with Mock Endpoints

const api = createApi({
  reducerPath: 'api',
  baseQuery: mockBaseQuery, // Using the mock base query
  endpoints: builder => ({
    login: builder.mutation<LoginResponse, LoginRequest>({
      query: credentials => ({
        url: '/login',
        method: 'POST',
        body: credentials,
      }),
    }),
    validateOtp: builder.mutation<{success: boolean; message: string}, void>({
      query: () => ({
        url: '/otp',
        method: 'POST',
      }),
    }),
  }),
});

export const {useLoginMutation, useValidateOtpMutation} = api;
export default api;
