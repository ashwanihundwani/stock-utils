import Box from '@mui/material/Box';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import TextInput from 'components/text-input';
import {FC} from 'react';
import {getStyles} from './style';
import {CustomLabel} from 'components';
import {variants} from 'components/custom-label/types';
import {translation, Theme, useNewTheme} from 'react-core';
import {Typography} from '@mui/material';
import {SarCurrency} from 'assets/svg/sarCurrency';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';
import {useFormik} from 'formik';
import {
  OnboardingMonthlyExpensesInitialValues,
  OnboardingMonthlyExpensesSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-monthly-expense';
import {InputType} from 'components/text-input/types';

const OnboardingMonthlyExpenses: FC = () => {
  const theme: Theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingMonthlyExpensesInitialValues,
    validationSchema: OnboardingMonthlyExpensesSchema,
    onSubmit: () => {
      if (formik.isValid) {
        navigate(AppPath.EmploymentDetails);
      }
    },
  });

  const formatNumber = (value: string | number) => {
    if (typeof value !== 'string') value = value.toString();
    value = value.replace(/,/g, '');
    const num = parseFloat(value);
    return isNaN(num) ? 0 : num;
  };

  const total = Object.values(formik.values)
    .filter(val => val !== undefined && val !== null && val !== '')
    .map(formatNumber)
    .reduce((acc, num) => acc + num, 0)
    .toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

  return (
    <Box id="boxbody" sx={styles.body}>
      <Box id="boxheader" sx={styles.header}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingBackLblTitleWeb')}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Box id="boxcontent1" sx={styles.content1}>
          <CustomLabel
            id="idBack"
            variant={variants.titleXL}
            text={t('OnboardingMonthlyExpensesLblTitle')}
          />
          <CustomLabel
            id="idBack"
            variant={variants.bodyRegularM}
            text={t('OnboardingMonthlyExpensesLblSubtitle')}
          />
        </Box>
      </Box>
      <Typography sx={styles.total}>
        <SarCurrency />
        {total}
      </Typography>
      <Box id="boxsection1" sx={styles.section1}>
        <Box id="boxframe1739333900" sx={styles.frame1739333900}>
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtEducation')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.education}
            setValue={formik.handleChange('education')}
            errorText={t(formik.errors.education ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtFood')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.food}
            setValue={formik.handleChange('food')}
            errorText={t(formik.errors.food ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtMedical')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.medical}
            setValue={formik.handleChange('medical')}
            errorText={t(formik.errors.medical ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtTransportation')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.transportation}
            setValue={formik.handleChange('transportation')}
            errorText={t(formik.errors.transportation ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtUtilityBills')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.utilitybills}
            setValue={formik.handleChange('utilitybills')}
            errorText={t(formik.errors.utilitybills ?? '')}
          />
        </Box>
        <Box id="boxframe1739333901" sx={styles.frame1739333901}>
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtDomesticLabor')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.domensticlabor}
            setValue={formik.handleChange('domensticlabor')}
            errorText={t(formik.errors.domensticlabor ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtFinancial')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.financial}
            setValue={formik.handleChange('financial')}
            errorText={t(formik.errors.financial ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtExpected')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.expected}
            setValue={formik.handleChange('expected')}
            errorText={t(formik.errors.expected ?? '')}
          />
          <TextInput
            type={InputType.Number}
            label={t('OnboardingMonthlyExpensestxtMonthlyRent')}
            customStyle={styles.sharedTrustedInputStyles}
            value={formik.values.monthlyrent}
            setValue={formik.handleChange('monthlyrent')}
            errorText={t(formik.errors.monthlyrent ?? '')}
          />
        </Box>
      </Box>
      <Box id="boxactions" sx={styles.actions}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={'Next'}
          onClick={formik.handleSubmit}
          disabled={!(formik.isValid && formik.dirty)}
        />
      </Box>
    </Box>
  );
};

export default OnboardingMonthlyExpenses;
