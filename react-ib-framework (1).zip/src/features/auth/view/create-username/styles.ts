import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    defaultContainer: {
      paddingTop: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
    },
    title: {
      fontFamily: fonts.regular,
      fontSize: '20px',
      fontWeight: '600',
      color: theme.colors['content-primary'],
      paddingBottom: '16px',
    },
    subtitle: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
      width: '100%',
      paddingBottom: '16px',
    },
    validationBox: {
      display: 'flex',
      alignItems: 'center',
      paddingTop: '4px',
      gap: '4px',
    },
    validationLabel: {
      fontFamily: fonts.regular,
      fontSize: '14px',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
    },
    usernameBox: {
      display: 'grid',
    },
    backNavigationBox: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      paddingBottom: '8px',
    },
    backNavigation: {
      fontFamily: fonts.regular,
      fontSize: '16px',
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
  };
};
