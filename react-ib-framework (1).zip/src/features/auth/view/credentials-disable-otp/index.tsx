import {OtpContainer} from 'components';

const CredentialsDisableOtp = () => {
  return (
    <OtpContainer
      title={'AuthenticationEnterOtpLblTitle'}
      subtitle={'AuthenticationEnterOtpLblSubtitle'}
      resendOtpLabel={'AuthenticationEnterOtpLblTimer'}
      requestOtpLabel={'AuthenticationEnterOtpLblLinkCode'}
      onResendOtp={() => {
        // Logic
      }}
      onSubmitOtp={() => {
        // Logic
      }}
    />
  );
};
export default CredentialsDisableOtp;
