import {FC} from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid2';
import {getStyles} from '../login/styles';
import {useNewTheme} from 'react-core/hooks';
import SideBanner from '../banner';
// import RemoveTrusted from './remove-trusted';
import NonTrustedDevice from './non-trusted-device';

const TrustFailed: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  return (
    <Box sx={styles.loginContainer}>
      {/* LHS */}
      <SideBanner />
      {/* RHS */}
      <Grid>
        <NonTrustedDevice />
        {/* <RemoveTrusted /> */}
      </Grid>
    </Box>
  );
};

export default TrustFailed;
