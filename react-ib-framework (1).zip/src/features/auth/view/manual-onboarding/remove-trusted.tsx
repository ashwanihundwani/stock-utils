import {FC} from 'react';
import Box from '@mui/material/Box';
import {getStyles} from './styles';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import {Typography} from '@mui/material';
import Header from '../common/login-header';
import {ChromeIcon} from 'assets/svg/onboarding';
import Link from 'components/link';
import {useNewTheme} from 'react-core';

const RemoveTrusted: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  return (
    <>
      <Header />
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="100vh">
        <Box sx={styles.container}>
          {/* Container 1 */}
          <Box display="flex" flexDirection="column" alignItems="flex-start">
            <Box sx={styles.iconWrapper}>
              <ErrorOutlineIcon sx={styles.icon} />
            </Box>
            <Typography sx={styles.textPrimary}>
              You can only have one trusted browser per account
            </Typography>
            <Typography sx={styles.textSecondary}>
              To continue, remove the existing one and register this browser
              instead.
            </Typography>
          </Box>

          {/* Container 2 */}
          <Box sx={styles.removeTrusted}>
            <Typography sx={styles.trustedLabel}>Trusted Browser</Typography>
            <Box sx={styles.trustedBrowser}>
              <ChromeIcon />
              <Typography sx={styles.browserLabel}>
                Google Chrome 13.0
              </Typography>
              <Box sx={styles.remove}>
                <Link linkText={'Remove'} />
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default RemoveTrusted;
