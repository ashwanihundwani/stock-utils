import {FC} from 'react';
import Box from '@mui/material/Box';
import {getStyles} from './styles';
import useLoginPage from '../../hooks/useLoginPage';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import {Typography} from '@mui/material';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import Header from '../common/login-header';
import {useNewTheme} from 'react-core/hooks';

const NonTrustedDevice: FC = () => {
  const {loginForm, translate} = useLoginPage();
  const theme = useNewTheme();
  const styles = getStyles(theme);
  return (
    <>
      <Header />
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="100vh">
        <Box sx={styles.container}>
          {/* Container 1 */}
          <Box display="flex" flexDirection="column" alignItems="flex-start">
            <Box sx={styles.iconWrapper}>
              <ErrorOutlineIcon sx={styles.icon} />
            </Box>
            <Typography sx={styles.textPrimary}>
              Could not register your device as trusted.
            </Typography>
            <Typography sx={styles.textSecondary}>
              Please login and try again.
            </Typography>
          </Box>

          {/* Container 2 */}
          <Box sx={styles.loginBtn}>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Small}
              type={ButtonType.Text}
              text={translate('login_btn')}
              onClick={loginForm.handleSubmit}
            />
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default NonTrustedDevice;
