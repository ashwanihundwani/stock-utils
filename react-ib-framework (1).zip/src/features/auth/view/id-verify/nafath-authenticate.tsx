import {FC, useState} from 'react';

import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';
import {translation, useNewTheme} from 'react-core';
import {getStyles} from './style';
import {NafathIcon} from 'assets/svg/nafathIcon';
import {NafathfailPopUp} from './nafath-popup';
import Modal from 'components/modal';
import Grid from '@mui/material/Grid2';
import {CustomLabel} from 'components';
import {variants} from 'components/custom-label/types';

const NafathAuth: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const [nafathFailOpen, setNafathFailOpen] = useState(false);

  const popupOpen = () => {
    setNafathFailOpen(true);
  };
  return (
    <Grid container columns={7} size={7} sx={styles.mainContent}>
      <Grid sx={styles.backButton}>
        <Link
          size={LinkSize.Large}
          linkText={t('OnboardingBackLblTitleWeb')}
          showIcon
          onClick={popupOpen}
          type={LinkType.Secondary}
        />
      </Grid>
      <Grid sx={styles.nafathContentStyle}>
        <NafathIcon />

        <CustomLabel
          id="idNafathFailedTitle"
          variant={variants.titleXL}
          text={t('OnboardingNafathAuthenticateLblTitle')}
        />
        <CustomLabel
          id="idNafathFailedTitle"
          variant={variants.bodyRegularM}
          text={t('OnboardingNafathAuthenticateLblSubtitle')}
        />
      </Grid>

      <CustomLabel
        id="idNafathFailedTitle"
        variant={variants.bodyRegularM}
        style={styles.code}
        text={t('OnboardingNafathAuthenticateLblAuthValue')}
      />

      <Modal open={nafathFailOpen} onClose={() => setNafathFailOpen(false)}>
        <NafathfailPopUp />
      </Modal>
    </Grid>
  );
};

export default NafathAuth;
