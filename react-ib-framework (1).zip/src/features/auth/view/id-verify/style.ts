import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      position: 'absolute',
      gap: '2rem',
      top: '15%',
      left: '20%',
      padding: '2rem',
    },
    nafathPopUpTileStyle: {
      gap: '8px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    },

    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },

    backButton: {
      display: 'flex',
      flexDirection: 'column',
      // mb: 3,
    },
    nafathContentStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      // mb: 3,
    },

    section1: {
      display: 'flex',
      flexDirection: 'column',
      // alignItems: 'flex-start',
      gap: '1rem',
      mb: 4,
    },

    inputStyle: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '24.56rem',
        borderRadius: '0.62rem',
        '&.Mui-focused, &:hover': {
          fontSize: '0.875rem',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '0.625rem',
        fontSize: '0.875rem',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '0.3125rem 0.625rem 0.125rem',
        height: '1.4375rem',
      },
    },

    code: {
      fontFamily: fonts.regular,
      fontWeight: 400,
      fontSize: '4rem',
      marginTop: '3rem',
      color: theme.colors['content-primary'],
    },
    popupContainer: {
      display: 'flex',
      width: '100%',
      height: 'fit-content',
      borderRadius: '0.5rem',
      padding: '1.5rem',
      gap: '1.5rem',
      flexDirection: 'column',
    },
    titleContainer: {
      width: '100%',
      height: 'fit-content',
      display: 'flex',
      gap: '1.5rem',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    },

    iconContainer: {
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      display: 'flex',
    },
    circleIcon: {
      borderRadius: '50%',
      backgroundColor: theme.colors['surface-semantic-error-01'],
      height: '3rem',
      width: '3rem',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'row',
      justifyContent: 'center',
    },
    button: {
      display: 'flex',
      gap: '1rem',
      flexDirection: 'column',
      width: '100%',
      alignItems: 'center',
      justifyContent: 'center',
    },
  };
};
