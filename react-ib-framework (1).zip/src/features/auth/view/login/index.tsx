import {FC, useState} from 'react';
import {Box, IconButton} from '@mui/material';
import {getStyles} from './styles';
import {LinkSize} from 'components/link/types';
import TextInput from 'components/text-input';
import Link from 'components/link';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import useLoginPage from '../../hooks/useLoginPage';
import {CustomLabel} from 'components';
import {EyeOpenComponent} from 'assets/svg/eye-open';
import {EyeCloseComponent} from 'assets/svg/eye-close';
import {InputType} from 'components/text-input/types';
import {useNewTheme, useTranslation} from 'react-core';
import {variants} from 'components/custom-label/types';
const LoginScreen: FC = () => {
  const theme = useNewTheme();
  const {t: translate} = useTranslation();
  const styles = getStyles(theme);
  const {loginForm} = useLoginPage();
  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  return (
    <Box>
      <Box sx={styles.mainContainer}>
        <Box sx={styles.wecomeContainer}>
          <Box sx={styles.meemHeading}>
            <CustomLabel
              text={translate('AuthenticationLoginLblWelcomeWeb')}
              id="welcome"
              variant={variants.bodyMediumM}
              style={styles.welcomeHeading}
            />
            <CustomLabel
              text={translate('AuthenticationLoginLblWelcomeMeemLblWeb')}
              id="meem"
              variant={variants.bodyMediumM}
              style={styles.meemLabel}
            />
          </Box>
          <CustomLabel
            text={translate('AuthenticationLoginLblWelcomeBankingLblWeb')}
            id="banking"
            variant={variants.bodyMediumM}
            style={styles.welcomeHeading}
          />
        </Box>
        <Box sx={styles.loginContainer}>
          <Box sx={styles.nationalId}>
            <TextInput
              label={translate('AuthenticationLoginTxtIdPlc')}
              value={loginForm.values.username}
              autoComplete={'off'}
              autoFocus={true}
              setValue={value => {
                loginForm.setFieldValue('username', value);
              }}
              errorText={
                loginForm.touched.username ? loginForm.errors.username : ''
              }
            />
          </Box>
          <Box sx={styles.password}>
            <TextInput
              label={translate('AuthenticationLoginTxtPasswordPlc')}
              value={loginForm.values.password}
              autoComplete={'off'}
              setValue={value => {
                loginForm.setFieldValue('password', value);
              }}
              type={showPassword ? InputType.Text : InputType.Password}
              endElement={
                <>
                  {loginForm.values.password.length > 0 ? (
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      edge="end">
                      {showPassword ? (
                        <EyeCloseComponent
                          color={
                            theme.colors['surface-interactive-primary-enabled']
                          }
                        />
                      ) : (
                        <EyeOpenComponent
                          color={
                            theme.colors['surface-interactive-primary-enabled']
                          }
                        />
                      )}
                    </IconButton>
                  ) : null}
                </>
              }
              errorText={
                loginForm?.touched?.password ? loginForm?.errors?.password : ''
              }
            />
          </Box>
          <Box sx={styles.forgotCredentials}>
            <Link
              size={LinkSize.Medium}
              linkText={translate('AuthenticationLoginBtnForgotPass')}
            />
          </Box>
        </Box>
        <Box sx={styles.loginSection}>
          <Box sx={styles.loginBtn}>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              text={translate('AuthenticationLoginBtnLogin')}
              onClick={loginForm.handleSubmit}
            />
          </Box>
          <Box sx={styles.joinMeem}>
            <CustomLabel
              text={translate('AuthenticationLoginLblDontAccountYetWeb')}
              id="account"
              variant={variants.bodyMediumM}
              style={styles.label}
            />
            <Link
              size={LinkSize.Medium}
              linkText={translate('AuthenticationLoginLblJoinMeemWeb')}
            />
          </Box>
        </Box>
      </Box>
      <Box sx={styles.loginFooter}>
        <CustomLabel
          text={translate('AuthenticationLoginLblSupportWeb')}
          id="support"
          variant={variants.bodyMediumM}
          style={styles.label}
        />
        <CustomLabel
          text={translate('AuthenticationLoginLblDisableCredentialWeb')}
          id="credential"
          variant={variants.bodyMediumM}
          style={styles.label}
        />
        <CustomLabel
          text={translate('AuthenticationLoginLblComplaintsWeb')}
          id="complaint"
          variant={variants.bodyMediumM}
          style={styles.label}
        />
      </Box>
    </Box>
  );
};

export default LoginScreen;
