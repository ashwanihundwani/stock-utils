import {Box} from '@mui/material';
import {TranslationIcon} from 'assets/svg/translationIcon';
import {CustomLabel} from 'components';

import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {FC} from 'react';
import useLoginPage from 'features/auth/hooks/useLoginPage';
import {useNewTheme} from 'react-core/hooks';
import {getStyles} from './styles';

const LoginHeader: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {changeUserLang, translate} = useLoginPage();

  return (
    <Box sx={styles.loginHeaderBox}>
      <Box sx={styles.loginHeader} onClick={changeUserLang}>
        <TranslationIcon />
        <CustomLabel
          id={'login_translate_btn'}
          text={translate('login_translate_btn')}
          style={styles.label}
        />
      </Box>
      <Box sx={styles.needHelp}>
        <CustomLabel
          id={'do_you_need_help'}
          text={translate('do_you_need_help')}
          style={styles.label}
        />
        <Link size={LinkSize.Medium} linkText={translate('contact_us')} />
      </Box>
    </Box>
  );
};

export default LoginHeader;
