import {CustomLabel} from 'components';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {variants} from 'components/custom-label/types';
import InfoScreen from 'components/info-screen';
import {InfoIconType} from 'components/info-screen/types';
import {useTranslation} from 'react-core';

const CredentialsDisabled = () => {
  const {t: translate} = useTranslation();
  return (
    <InfoScreen
      title={'AuthenticationCredentialsDisabledLblTitleWeb'}
      subtitle={'AuthenticationCredentialsDisabledLblSubtitle'}
      iconType={InfoIconType.success}
      primaryBtn={{
        label: 'AuthenticationCredentialsDisabledBtnLoginWeb',
        type: ButtonType.Text,
        size: ButtonSize.Large,
        variant: ButtonStyle.Primary,
        onClick: () => {},
      }}
      secondaryBtn={{
        label: 'AuthenticationCredentialsDisabledBtnForgotpwd',
        type: ButtonType.Text,
        size: ButtonSize.Large,
        variant: ButtonStyle.Secondary,
        onClick: () => {},
      }}>
      <CustomLabel
        id={'description'}
        text={translate('AuthenticationCredentialsDisabledLblDescription')}
        variant={variants.bodyRegularS}
      />
    </InfoScreen>
  );
};

export default CredentialsDisabled;
