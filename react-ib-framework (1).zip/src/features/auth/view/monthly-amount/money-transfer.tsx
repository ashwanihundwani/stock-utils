import React from 'react';
import {Box, Typography} from '@mui/material';
import Link from 'components/link';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {LinkSize, LinkType} from 'components/link/types';
import {translation, useNewTheme} from 'react-core';
import {getStyles} from './style';
import {Dropdown} from 'components';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {useFormik} from 'formik';
import {
  OnboardingTransferMoneyInitialValues,
  OnboardingTransferMoneySchema,
} from 'features/onboarding-credit-card/schemas/onboarding-transfer-money';
import Grid from '@mui/material/Grid2';

const MoneyTransferCountries: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingTransferMoneyInitialValues,
    validationSchema: OnboardingTransferMoneySchema,
    onSubmit: () => {
      if (formik.isValid) {
        navigate(AppPath.MonthlyDeposits);
      }
    },
  });

  const ddlOptions = [
    {
      id: '1',
      value: 'US',
      label: 'US',
    },

    {
      id: '2',
      value: 'India',
      label: 'India',
    },

    {
      id: '3',
      value: 'Germany',
      label: 'Germany',
    },
  ];
  const isValid = () => {
    if (formik.dirty && formik.isValid) return true;
    return false;
  };

  return (
    <Grid container columns={7} size={7} sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingBackLblTitleWeb')}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Grid size={7}>
          <Typography sx={styles.title}>
            {t('OnboardingTransferMoneyLblTitle')}
          </Typography>
          <Typography sx={styles.subTitle}>
            {t('OnboardingTransferMoneyLblSubtitle')}
          </Typography>
        </Grid>
        <Grid size={4} sx={styles.list}>
          <Dropdown
            id="select-dropdown"
            labelId="select-dropdown-lable"
            options={ddlOptions}
            placeholder={t('OnboardingTransferMoneyDdCountries')}
            customstyle={styles.dropdown}
            value={formik.values.countries}
            errorText={formik.errors.countries}
            setValue={formik.handleChange('countries')}
            //   helperText={'Select dropdown value'}
            disabled={false}
          />
        </Grid>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingMonthlyDepositBtnNext')}
          disabled={!isValid()}
          onClick={formik.handleSubmit}
        />
      </Box>
    </Grid>
  );
};

export default MoneyTransferCountries;
