import React, {useState} from 'react';
import {Box, Typography} from '@mui/material';
import Link from 'components/link';
import AmountInput from 'components/amount-input';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {LinkSize, LinkType} from 'components/link/types';
import {translation, useNewTheme} from 'react-core';
import {getStyles} from './style';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {PhoneNumberLength10} from 'constants/types';

const MonthlySalaryScreen: React.FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const navigate = useNavigate();
  const {t} = translation.useTranslation();

  const [amount, setAmount] = useState('');

  const handleSubmit = () => {
    navigate(AppPath.additionalIncome);
  };

  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <Box sx={styles.backButton}>
          {/* <BackArrow /> */}
          <Link
            size={LinkSize.Large}
            linkText={t('OnboardingBackLblTitleWeb')}
            showIcon
            type={LinkType.Secondary}
          />
        </Box>
        <Typography sx={styles.title}>
          {t('OnboardingMonthlySalaryAmountLblTitle')}
        </Typography>
        <AmountInput
          value={amount}
          onChange={(value: string) => setAmount(value)}
          disabled={false}
          currency={''}
          maximumLength={PhoneNumberLength10}
        />
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Small}
          type={ButtonType.Text}
          disabled={!amount}
          text={t('OnboardingMonthlyDepositBtnNext')}
          onClick={handleSubmit}
        />
      </Box>
    </Box>
  );
};

export default MonthlySalaryScreen;
