// style.ts
import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
    },

    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      textAlign: 'left',
      gap: '0.5rem',
    },

    backButton: {
      display: 'flex',
      mb: 2,
    },
    backNavGrid: {
      display: 'flex',
      flexDirection: 'column',
    },
    rowStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
    },
    backLblstyle: {
      width: '2.25rem',
      height: '1.5rem',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    title: {
      fontSize: 28,
      fontWeight: 500,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-primary'],
    },

    subTitle: {
      fontSize: 16,
      fontFamily: fonts.regular,
      mt: 1,
      color: theme.colors['content-secondary'],
    },
    list: {
      mt: 2,
      mb: 4,
      backgroundColor: 'red',
    },
    dropdown: {
      background: theme.colors['surface-01'],
      width: '24.5625rem',
    },
    btnStyle: {
      mt: 3,
    },
  };
};
