import {Theme} from 'react-core';

export type PasswordSetupOnSubmitType = {
  password?: string;
  repassword?: string;
};

export enum PasswordSetupDirection {
  row = 'row',
  column = 'column',
}

export type PasswordSetupProps = {
  title?: string;
  subtitle?: string;
  btnLabel?: string;
  firstInputPlc?: string;
  secondInputPlc?: string;
  lowerCaseTitle?: string;
  upperCaseTitle?: string;
  oneNumberTitle?: string;
  oneSpecialTitle?: string;
  minLengthTitle?: string;
  maxLengthTitle?: string;
  passwordNotMatchLabel?: string;
  onSubmit?: (values: PasswordSetupOnSubmitType) => void;
  backLabel?: string;
  contentDirection?: PasswordSetupDirection;
};

export type PasswordSetupStyleProps = {
  contentDirection: PasswordSetupDirection;
  theme: Theme;
};
