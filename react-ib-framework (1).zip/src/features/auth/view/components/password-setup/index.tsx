import {Box} from '@mui/material';
import {Button, PasswordRules, ScreenContainer, TextInput} from 'components';
import {FC} from 'react';
import {getStyles} from './styles';
import {Theme, translation, useNewTheme} from 'react-core';
import * as yup from 'yup';
import {useFormik} from 'formik';
import {InputType} from 'components/text-input/types';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {PasswordSetupDirection, PasswordSetupProps} from './types';

const PasswordSetup: FC<PasswordSetupProps> = ({
  title,
  backLabel = '',
  btnLabel = '',
  firstInputPlc = 'CommonPasswordSetupTxtNewPassword',
  secondInputPlc = 'CommonPasswordSetupTxtRepeatPassword',
  passwordNotMatchLabel = 'CommonPasswordSetupTxtPwdMatch',
  contentDirection = PasswordSetupDirection.column,
  onSubmit,
}) => {
  const theme: Theme = useNewTheme();
  const styles = getStyles({contentDirection, theme});
  const {t: translate} = translation.useTranslation();

  const PasswordSetupInitialValues = {
    password: '',
    repassword: '',
  };

  const PasswordSetupSchema = yup.object().shape({
    password: yup
      .string()
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&*@-^])(?=.{8,})/, '')
      .required(),

    repassword: yup
      .string()
      .oneOf([yup.ref('password'), ''], passwordNotMatchLabel)
      .required(),
  });

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: PasswordSetupInitialValues,
    validationSchema: PasswordSetupSchema,
    onSubmit: values => {
      onSubmit?.(values);
    },
  });

  return (
    <ScreenContainer title={title} backLabel={translate(backLabel)}>
      <Box sx={styles.passwordContainer}>
        <Box sx={styles.inputContainer}>
          <TextInput
            label={translate(firstInputPlc)}
            type={InputType.Password}
            value={formik.values.password}
            setValue={formik.handleChange('password')}
          />
          <TextInput
            label={translate(secondInputPlc)}
            type={InputType.Password}
            value={formik.values.repassword}
            setValue={formik.handleChange('repassword')}
            errorText={formik.errors.repassword}
          />
        </Box>
        <PasswordRules value={formik.values.password} />
      </Box>
      <Button
        text={translate(btnLabel)}
        variant={ButtonStyle.Primary}
        type={ButtonType.Text}
        size={ButtonSize.Large}
        disabled={!(formik.dirty && formik.isValid)}
      />
    </ScreenContainer>
  );
};

export default PasswordSetup;
