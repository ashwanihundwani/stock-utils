export const getStyles = () => {
  return {
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    tabContainer: {
      marginTop: '16px',
    },
  };
};
