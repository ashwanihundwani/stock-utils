export type CredentialRecoveryFormState = {
  idOrIqama: string;
  email: string;
  iBan: string;
  debitCard: string;
};

export type CredentialsRecoveryProps = {
  title?: string;
  subtitle?: string;
  backLabel?: string;
  onFormSubmit?: (formState: CredentialRecoveryFormState) => void;
};

export type TabComponentProps = {
  formikValue: string;
  formikSetValue: (e: string) => void;
  formikError?: string;
};
