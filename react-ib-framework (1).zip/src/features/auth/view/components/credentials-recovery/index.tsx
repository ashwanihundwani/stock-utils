import {Button, ScreenContainer, TextInput} from 'components';
import {FC} from 'react';
import {CredentialsRecoveryProps, TabComponentProps} from './types';
import {Box} from '@mui/material';
import {useFormik} from 'formik';
import {
  CredentialsRecoveryInitialState,
  CredentialsRecoverySchema,
} from 'features/auth/schemas/credentials-recovery';
import Tabs from 'components/tabs';
import {getStyles} from './styles';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useTranslation} from 'react-core';

const CredentialsRecovery: FC<CredentialsRecoveryProps> = props => {
  const {title, subtitle, backLabel, onFormSubmit} = props;
  const {t: translate} = useTranslation();
  const styles = getStyles();

  const formik = useFormik({
    initialValues: CredentialsRecoveryInitialState,
    validationSchema: CredentialsRecoverySchema,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: values => {
      onFormSubmit?.(values);
    },
  });

  const tabContent = [
    {
      id: 0,
      label: translate('AuthenticationCredentialsRecoveryLblIbanTabWeb'),
      content: (
        <IBanComponent
          formikValue={formik.values.iBan}
          formikSetValue={formik.handleChange('iBan')}
          formikError={formik.errors.iBan}
        />
      ),
    },
    {
      id: 1,
      label: translate('AuthenticationCredentialsRecoveryLblDebitCardTabWeb'),
      content: (
        <DebitCardComponent
          formikValue={formik.values.debitCard}
          formikSetValue={formik.handleChange('debitCard')}
          formikError={formik.errors.debitCard}
        />
      ),
    },
  ];
  return (
    <ScreenContainer backLabel={backLabel} title={title} subtitle={subtitle}>
      <Box sx={styles.inputContainer}>
        <TextInput
          value={formik.values.idOrIqama}
          setValue={formik.handleChange('idOrIqama')}
          label={translate('AuthenticationDetailsForRecoveryTxtEnterId')}
          errorText={translate(formik.errors.idOrIqama)}
        />
        <TextInput
          value={formik.values.email}
          setValue={formik.handleChange('email')}
          label={translate('AuthenticationCredentialsRecoveryTxtEmail')}
          errorText={translate(formik.errors.email)}
        />
      </Box>
      <Tabs tabs={tabContent} />
      <Button
        variant={ButtonStyle.Primary}
        type={ButtonType.Text}
        size={ButtonSize.Large}
        text={translate('AuthenticationCredentialsRecoveryBtnNext')}
        onClick={formik.handleSubmit}
      />
    </ScreenContainer>
  );
};

const IBanComponent: FC<TabComponentProps> = props => {
  const {formikValue, formikSetValue, formikError} = props;
  const styles = getStyles();
  const {t: translate} = useTranslation();
  return (
    <Box sx={styles.tabContainer}>
      <TextInput
        label={translate('AuthenticationCredentialsRecoveryTxtIban')}
        value={formikValue}
        setValue={formikSetValue}
        errorText={translate(formikError)}
      />
    </Box>
  );
};

const DebitCardComponent: FC<TabComponentProps> = props => {
  const {formikValue, formikSetValue, formikError} = props;
  const styles = getStyles();
  const {t: translate} = useTranslation();
  return (
    <Box sx={styles.tabContainer}>
      <TextInput
        label={translate('AuthenticationCredentialsRecoveryTxtDebitcard')}
        value={formikValue}
        setValue={formikSetValue}
        errorText={translate(formikError)}
      />
    </Box>
  );
};

export default CredentialsRecovery;
