import {lazy} from 'react';

export const PasswordSetup = lazy(() => import('./password-setup'));
export const CredentialsRecovery = lazy(() => import('./credentials-recovery'));
