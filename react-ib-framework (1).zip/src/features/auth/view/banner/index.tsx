import {FC} from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid2';
import {QRIcon} from 'assets/svg/qrIcon';
import {getStyles} from './styles';
import {MeemIcon} from 'assets/svg/meemIcon';
import {useNewTheme} from 'react-core/hooks';
import {Images} from 'constants/images';

const SideBanner: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  return (
    <Box sx={styles.loginContainer}>
      <Grid>
        <Box sx={styles.meemIcon}>
          <MeemIcon />
        </Box>
        <Box sx={styles.leftSideBox}>
          {/* <LoginIcon /> */}
          <img
            src={Images.meem_login_logo}
            alt="meem_login_logo"
            style={styles.meemLoginLogo}></img>
        </Box>
        <Box sx={styles.qrIcon}>
          <QRIcon />
        </Box>
      </Grid>
    </Box>
  );
};

export default SideBanner;
