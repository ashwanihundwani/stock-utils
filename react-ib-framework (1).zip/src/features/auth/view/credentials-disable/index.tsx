import {Box} from '@mui/material';
import {ScreenContainer, Button, TextInput, CustomCheckbox} from 'components';
import {getStyles} from './styles';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useTranslation} from 'react-core';

const CredentialsDisable = () => {
  const styles = getStyles();
  const {t: translate} = useTranslation();

  return (
    <ScreenContainer
      title={translate('AuthenticationDisableCredentialsLblTitle')}
      subtitle={translate('AuthenticationDisableCredentialsLblSubtitle')}
      backLabel={translate('AuthenticationDisableCredentialsLblGoBack')}>
      <Box sx={styles.contentStyle}>
        <Box sx={styles.inputContainer}>
          <TextInput
            label={translate('AuthenticationDisableCredentialsTxtUsername')}
          />
          <TextInput
            label={translate('AuthenticationDisableCredentialsTxtNationalId')}
          />
          <TextInput
            label={translate('AuthenticationDisableCredentialsTxtDob')}
          />
        </Box>
        <CustomCheckbox
          onChange={() => {
            throw new Error('Function not implemented.');
          }}
          id={'checkbox'}
          label={translate('AuthenticationDisableCredentialsLblTerms')}
        />

        <Button
          variant={ButtonStyle.Primary}
          type={ButtonType.Text}
          size={ButtonSize.Large}
          text={translate('AuthenticationDisableCredentialsBtnConfirmWeb')}
        />
      </Box>
    </ScreenContainer>
  );
};

export default CredentialsDisable;
