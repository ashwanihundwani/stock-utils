export const getStyles = () => {
  return {
    contentStyle: {
      paddingTop: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
    },
    inputContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
  };
};
