import {Values} from 'constants/labelvalues';
import useLoginPage from 'features/auth/hooks/useLoginPage';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  const {langDir}: {langDir: string} = useLoginPage();
  return {
    authContainer: {
      backgroundColor: theme.colors['background-03'],
      width: '100%',
      height: '100vh',
    },
    outletContainer: {
      backgroundColor: theme.colors['surface-01'],
      padding: '24px',
      height: '100vh',
      borderStartStartRadius: '16px',
      borderEndStartRadius: '16px',
      position: 'fixed',
      right: '0',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      alignItems: 'center',
      zIndex: 3,
    },
    outletHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      width: '100%',
    },
    langContainer: {
      display: 'flex',
      gap: '8px',
      cursor: 'pointer',
      alignItems: 'center',
    },
    needHelpContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '8px',
      alignItems: 'center',
    },
    contactUsLabel: {
      letterSpacing: '0px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    outletContent: {
      flex: 1,
      width: '100%',
      justifyContent: 'center',
    },
    loginContainer: {
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      flexWrap: 'wrap',
    },
    meemIcon: {
      padding: document.dir === Values.ltr ? '24px' : '',
    },
    qrIcon: {
      position: 'fixed',
      bottom: '10px',
      left: document.dir === Values.ltr ? '24px' : '',
      right: langDir === Values.rtl ? '24px' : '',
      zIndex: '1000',
    },
    backgroundImgStyle: {
      width: '100%',
      height: 'inherit',
      margin: 0,
      padding: 0,
    },
    backgroundImgContainer: {
      position: 'fixed',
      display: 'flex',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
      margin: 'auto',
      zIndex: 2,
      alignItems: 'center',
    },
    backgroundGradient: {
      position: 'fixed',
      filter: 'blur(249.98px)',
      width: '221%',
      height: '221%',
      top: '41%',
      left: '22%',
      background:
        'radial-gradient(circle, rgba(255,100,226,1) 30%, rgba(255,100,226,0) 100%)',
    },
    outletTranslateLabel: {
      letterSpacing: '0px',
      color: theme.colors['content-interactive-secondary-enabled'],
      cursor: 'pointer',
    },
  };
};
