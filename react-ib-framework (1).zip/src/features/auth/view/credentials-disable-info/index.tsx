import {Box} from '@mui/material';
import {CustomLabel, ScreenContainer, Button} from 'components';
import {getStyles} from './styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ReactElement} from 'react';
import {CustomerSupport, SquarePassword} from 'assets/svg';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {variants} from 'components/custom-label/types';

const CredentialsDisableInfo = () => {
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const {t: translate} = useTranslation();

  const disableCredentialsList: {
    id: number;
    icon: ReactElement;
    content: string;
  }[] = [
    {
      id: 1,
      icon: <SquarePassword />,
      content: 'AuthenticationDisableInfoLblItem1',
    },
    {
      id: 2,
      icon: <CustomerSupport />,
      content: 'AuthenticationDisableInfoLblItem2Web',
    },
  ];

  return (
    <ScreenContainer
      title={translate('AuthenticationDisableInfoLblScreenname')}
      subtitle={translate('AuthenticationDisableInfoLblDescription')}
      backLabel={translate('AuthenticationDisableInfoLblGoBack')}>
      <Box sx={styles.contentStyle}>
        <Box sx={styles.infoListContainer}>
          {disableCredentialsList.map(item => {
            return (
              <Box key={item.id} sx={styles.infoItemStyle}>
                <Box sx={styles.iconDecoratorStyle}> {item.icon}</Box>
                <CustomLabel
                  text={translate(item.content)}
                  id="itemname"
                  variant={variants.bodyMediumM}
                  style={styles.listContentStyle}
                />
              </Box>
            );
          })}
        </Box>
        <Button
          variant={ButtonStyle.Primary}
          type={ButtonType.Text}
          size={ButtonSize.Large}
          text={translate('AuthenticationDisableInfoBtnNext')}
        />
      </Box>
    </ScreenContainer>
  );
};

export default CredentialsDisableInfo;
