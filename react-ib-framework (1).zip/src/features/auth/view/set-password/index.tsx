import {FC, useState} from 'react';
import {Box, IconButton} from '@mui/material';

import {getStyles} from './styles';
import {TextInput, CustomLabel} from 'components';

import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useFormik} from 'formik';
import {
  AuthenticationCredentialsCreationUsernameInitialValues,
  AuthenticationgCredentialsCreationUsernameSchema,
} from '../../../auth/schemas/set-password';
import {
  ListRequirementsCompleted,
  ListRequirementsEnabled,
  ListRequirementsError,
} from 'assets/svg/listRequirements';
import {EyeOpenComponent} from 'assets/svg/eye-open';
import {EyeCloseComponent} from 'assets/svg/eye-close';
import {useNewTheme, useTranslation} from 'react-core';
import {InputType} from 'components/text-input/types';
import {
  ONEDIGIT,
  ONELOWERCASE,
  ONEUPPERCASE,
  ONESPECIALCHAR,
  MINLENEIGHT,
  MAXLENTWENTY,
} from 'utils/text-input-validation';
import Button from 'components/button';
import {BackArrow} from 'assets/svg/backArrow';
import {useNavigate} from 'react-router-dom';
import {AuthRoutes} from 'constants/path';
const SetPassword: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const navigate = useNavigate();
  const {t: translate} = useTranslation();
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const handleClickShowRePassword = () => {
    setShowRePassword(!showRePassword);
  };
  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: AuthenticationCredentialsCreationUsernameInitialValues,
    validationSchema: AuthenticationgCredentialsCreationUsernameSchema,
    onSubmit: () => {
      navigate(AuthRoutes.CredentialUpdateSrceen);
    },
  });
  const renderValidationListItem = (
    validationType: (value: string | undefined) => boolean,
    text: string,
  ) => {
    return (
      <Box id={`vw${text}`} sx={styles.validationBox}>
        {validationType(formik.values.password) ? (
          <ListRequirementsCompleted />
        ) : formik.values.password !== undefined ? (
          <ListRequirementsError />
        ) : (
          <ListRequirementsEnabled />
        )}
        <CustomLabel
          id={'validationLabel'}
          text={text}
          style={styles.validationLabel}
        />
      </Box>
    );
  };
  return (
    <Box sx={styles.defaultContainer}>
      <Box sx={styles.usernameBox}>
        <Box sx={styles.backNavigationBox}>
          <BackArrow />
          <CustomLabel
            id={'AuthenticationCreatePasswordBtnBackWeb'}
            text={'AuthenticationCreatePasswordBtnBackWeb'}
            style={styles.backNavigation}
          />
        </Box>
        <CustomLabel
          style={styles.title}
          id={'AuthenticationCreatePasswordLblTitle'}
          text={'AuthenticationCreatePasswordLblTitle'}
        />
        <CustomLabel
          style={styles.subtitle}
          id={'AuthenticationCreatePasswordLblSubtitle'}
          text={'AuthenticationCreatePasswordLblSubtitle'}
        />
        <Box sx={styles.passwordField}>
          <TextInput
            label={translate(
              'AuthenticationCreatePasswordTxtPasswordPlaceholderWeb',
            )}
            value={formik.values.password}
            setValue={formik.handleChange('password')}
            autoFocus={true}
            autoComplete={'off'}
            maxLength={20}
            type={showPassword ? InputType.Text : InputType.Password}
            endElement={
              <>
                {formik.values.password.length > 0 ? (
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    edge="end">
                    {showPassword ? (
                      <EyeCloseComponent
                        color={
                          theme.colors['surface-interactive-primary-enabled']
                        }
                      />
                    ) : (
                      <EyeOpenComponent
                        color={
                          theme.colors['surface-interactive-primary-enabled']
                        }
                      />
                    )}
                  </IconButton>
                ) : (
                  ''
                )}
              </>
            }
          />
        </Box>
        <Box sx={styles.repeatPasswordField}>
          <TextInput
            label={translate(
              'AuthenticationCreatePasswordTxtRepeatPasswordPlaceholderWeb',
            )}
            value={formik.values.repassword}
            setValue={formik.handleChange('repassword')}
            errorText={formik.errors.repassword}
            autoComplete={'off'}
            errorHeight={true}
            maxLength={20}
            type={showRePassword ? InputType.Text : InputType.Password}
            endElement={
              <>
                {formik.values.repassword.length > 0 ? (
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowRePassword}
                    edge="end">
                    {showRePassword ? (
                      <EyeCloseComponent
                        color={
                          theme.colors['surface-interactive-primary-enabled']
                        }
                      />
                    ) : (
                      <EyeOpenComponent
                        color={
                          theme.colors['surface-interactive-primary-enabled']
                        }
                      />
                    )}
                  </IconButton>
                ) : (
                  ''
                )}
              </>
            }
          />
        </Box>
        <Box id="vwList">
          {renderValidationListItem(
            ONELOWERCASE,
            'AuthenticationCreatePasswordLblListrequirement1Web',
          )}
          {renderValidationListItem(
            ONEUPPERCASE,
            'AuthenticationCreatePasswordLblListrequirement2Web',
          )}
          {renderValidationListItem(
            ONEDIGIT,
            'AuthenticationCreatePasswordLblListrequirement3Web',
          )}
          {renderValidationListItem(
            ONESPECIALCHAR,
            'AuthenticationCreatePasswordLblListrequirement4Web',
          )}
          {renderValidationListItem(
            MINLENEIGHT,
            'AuthenticationCreatePasswordLblListrequirement5Web',
          )}
          {renderValidationListItem(
            MAXLENTWENTY,
            'AuthenticationCreatePasswordLblListrequirement6Web',
          )}
        </Box>
        <Box sx={styles.comfirmBtn}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            text={translate('AuthenticationCreatePasswordBtnConfirm')}
            disabled={!(formik.isValid && formik.dirty)}
            onClick={() => formik.handleSubmit()}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default SetPassword;
