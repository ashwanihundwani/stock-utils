import {lazy} from 'react';

export const RecoverySelection = lazy(
  () => import('./view/recovery-selection'),
);
export const UsernameRecovery = lazy(() => import('./view/username-recovery'));
export const UsernameRecoverySuccess = lazy(
  () => import('./view/username-recovery-success'),
);
export const PasswordRecovery = lazy(() => import('./view/password-recovery'));
export const UsernameRecoveryOtp = lazy(
  () => import('./view/username-recovery-otp'),
);
export const PasswordRecoveryOtp = lazy(
  () => import('./view/password-recovery-otp'),
);
export const ResetPassword = lazy(() => import('./view/reset-password'));
export const ResetPasswordCallback = lazy(
  () => import('./view/reset-password-callback'),
);
export const ResetPasswordSuccess = lazy(
  () => import('./view/reset-password-success'),
);
