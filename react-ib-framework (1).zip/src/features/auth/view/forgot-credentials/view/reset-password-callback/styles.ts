export const getStyles = () => {
  return {
    resetPasswordCallbackTimerContainer: {
      display: 'flex',
      gap: '0.25rem',
    },
  };
};
