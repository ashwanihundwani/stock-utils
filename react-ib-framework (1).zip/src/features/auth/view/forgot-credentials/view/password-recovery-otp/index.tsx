import {OtpContainer} from 'components';
import {AuthRoutes} from 'constants/path';
import {useNavigate} from 'react-router-dom';

const PasswordRecoveryOtp = () => {
  const navigate = useNavigate();
  return (
    <OtpContainer
      onResendOtp={() => {}}
      title={'AuthenticationEnterOtpLblTitle'}
      subtitle={'AuthenticationEnterOtpLblSubtitle'}
      resendOtpLabel={'AuthenticationEnterOtpLblTimer'}
      requestOtpLabel={'AuthenticationEnterOtpLblLinkCode'}
      onSubmitOtp={() => {
        navigate(AuthRoutes.AuthWrapper);
      }}
    />
  );
};

export default PasswordRecoveryOtp;
