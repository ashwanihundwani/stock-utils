import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import InfoScreen from 'components/info-screen';
import {InfoIconType} from 'components/info-screen/types';
import {AuthRoutes} from 'constants/path';
import {useNavigate} from 'react-router-dom';

const UsernameRecoverySuccess = () => {
  const navigate = useNavigate();
  return (
    <InfoScreen
      iconType={InfoIconType.success}
      title={'AuthenticationUsernameRecoverySuccessLblTitle'}
      primaryBtn={{
        label: 'AuthenticationUsernameRecoverySuccessBtnLoginWeb',
        type: ButtonType.Text,
        variant: ButtonStyle.Primary,
        size: ButtonSize.Large,
        onClick: () => {
          navigate(AuthRoutes.AuthWrapper);
        },
      }}
    />
  );
};

export default UsernameRecoverySuccess;
