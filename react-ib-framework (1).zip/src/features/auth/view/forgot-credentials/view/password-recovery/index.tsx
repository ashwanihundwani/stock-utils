import {AuthRoutes} from 'constants/path';
import {CredentialsRecovery} from 'features/auth/view/components';
import {useNavigate} from 'react-router-dom';

const PasswordRecovery = () => {
  const navigate = useNavigate();
  return (
    <CredentialsRecovery
      title="AuthenticationPasswordRecoveryLblTitle"
      subtitle="AuthenticationPasswordRecoveryLblSubtitle"
      backLabel="AuthenticationPasswordRecoveryLblGoBackWeb"
      onFormSubmit={() => {
        navigate(AuthRoutes.PasswordRecoveryOtp);
      }}
    />
  );
};

export default PasswordRecovery;
