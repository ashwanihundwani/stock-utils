import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const AuthenticationCredentialsCreationUsernameInitialValues = {
  username: undefined,
};

export const AuthenticationgCredentialsCreationUsernameSchema = yup
  .object()
  .shape({
    username: yup
      .string()
      .required(
        Errors.OnboardingCredentialsCreationUsernameErrorRequiredTxtUsername,
      )
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!#$%&*@^])(?=.{8,20})/),
  });
