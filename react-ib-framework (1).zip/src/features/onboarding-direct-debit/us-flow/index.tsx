import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {getCitizenshipDetails} from 'utils/localStorage';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Button, Dropdown} from 'components';
import TextInput from 'components/text-input';
import {LinkSize} from 'components/link/types';
import Link from 'components/link';
import {AddCircle} from 'assets/svg/addCircle';
import Divider from '@mui/material/Divider';
import {Delete03Icon} from 'assets/svg/delete-03';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Typography} from '@mui/material';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {useNavigate} from 'react-router-dom';
import {useFormik} from 'formik';
import {
  OnboardingTaxDeclarationTaxResidentInitialValues,
  OnboardingTaxDeclarationTaxResidentSchema,
} from 'features/onboarding-credit-card/schemas/onboarding-taxdeclarationtaxresidents';

const TaxDecalrationAddCountry: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();
  const citizenshipDetails = getCitizenshipDetails();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingTaxDeclarationTaxResidentInitialValues,
    validationSchema: OnboardingTaxDeclarationTaxResidentSchema,
    onSubmit: () => {},
  });

  const handleOnAdd = () => {
    if (formik.values.countriesData.length < 3) {
      formik.setValues(prevValues => ({
        id: prevValues.id + 1,
        countriesData: [
          ...prevValues.countriesData,
          {
            countryOfTax: '',
            address: '',
            state: '',
            phoneNumber: '',
            mail: '',
            id: prevValues.countriesData.length + 1,
          },
        ],
      }));
    }
    console.log(formik.values.countriesData, 'the list dataa');
  };

  const handleOnDelete = (id: number) => {
    if (formik.values.countriesData.length !== 1) {
      formik.setFieldValue(
        'countriesData',
        formik.values.countriesData.filter((_, ind) => ind !== id),
      );
    }
  };

  const handleOnClick = () => {
    navigate('/tax-identification-number');
  };

  const employerName = [
    {
      id: '1',
      value: 'aramco',
      label: 'Aramco',
    },

    {
      id: '2',
      value: 'sabic',
      label: 'Sabic',
    },
  ];

  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingTaxIdentificationNumberLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingTaxIdentificationNumberLblTitle')}
        />
      </Grid>
      <Grid>
        <CustomLabel
          id={t('OnboardingDebitCardDetailsTaxDetailsSubTitleWeb')}
          variant={variants.bodyMediumM}
          text={t('OnboardingDebitCardDetailsTaxDetailsSubTitleWeb')}
        />
      </Grid>

      {formik.values.countriesData.map((field, index) => (
        <Grid key={field.id}>
          <Grid size={12} sx={styles.incomeSourceDropdownGrid}>
            <Dropdown
              id={t('OnboardingTaxDeclarationTaxResidentDdCountry')}
              labelId={t('OnboardingTaxDeclarationTaxResidentDdCountry')}
              placeholder={t('OnboardingTaxDeclarationTaxResidentDdCountry')}
              options={employerName}
              helperText={''}
              disabled={false}
              customstyle={styles.dropdown}
              labelstyle={styles.labelStyle}
              value={formik.values.countriesData[index].countryOfTax}
              setValue={formik.handleChange(
                `countriesData[${index}].countryOfTax`,
              )}
              errorText={
                formik.errors.countriesData !== undefined
                  ? `${formik.errors.countriesData[index]?.countryOfTax ?? ''}`
                  : ''
              }
            />
          </Grid>
          <Grid sx={styles.listGrid}>
            <TextInput
              label={t('OnboardingTaxDeclarationTaxResidentTxtAddress')}
              customStyle={styles.textInput}
              value={formik.values.countriesData[index].address}
              setValue={formik.handleChange(`countriesData[${index}].address`)}
              errorText={
                formik.errors.countriesData !== undefined
                  ? `${formik.errors.countriesData[index]?.address ?? ''}`
                  : ''
              }
            />
            <TextInput
              label={t('OnboardingTaxDeclarationTaxResidentTxtState')}
              customStyle={styles.textInput}
              value={formik.values.countriesData[index].state}
              setValue={formik.handleChange(`countriesData[${index}].state`)}
              errorText={
                formik.errors.countriesData !== undefined
                  ? `${formik.errors.countriesData[index]?.state ?? ''}`
                  : ''
              }
            />
          </Grid>
          <Grid sx={styles.listGrid}>
            <TextInput
              label={t('OnboardingTaxDeclarationTaxResidentTxtPhoneNumber')}
              customStyle={styles.textInput}
              value={formik.values.countriesData[index].phoneNumber}
              setValue={formik.handleChange(
                `countriesData[${index}].phoneNumber`,
              )}
              errorText={
                formik.errors.countriesData !== undefined
                  ? `${formik.errors.countriesData[index]?.phoneNumber ?? ''}`
                  : ''
              }
            />
            <TextInput
              label={t(
                'OnboardingTaxDeclarationTaxResidentTxtMail handling instructions (optional)',
              )}
              customStyle={styles.textInput}
              value={formik.values.countriesData[index].mail}
              setValue={formik.handleChange(`countriesData[${index}].mail`)}
              errorText={
                formik.errors.countriesData !== undefined
                  ? `${formik.errors.countriesData[index]?.mail ?? ''}`
                  : ''
              }
            />
          </Grid>

          {index !== 0 && (
            <Grid>
              <Grid
                sx={styles.deleteCountryIcon}
                onClick={() => handleOnDelete(index)}>
                <Delete03Icon />
                <Typography sx={styles.deleteText}>
                  {t('OnboardingTaxDeclarationTaxResidentLinkDeleteCountryWeb')}
                </Typography>
              </Grid>

              <Divider sx={styles.divider} />
            </Grid>
          )}
        </Grid>
      ))}
      {formik.values.countriesData.length !== 3 &&
        citizenshipDetails === 'US' && (
          <Grid sx={styles.giftIcon}>
            <AddCircle />
            <Link
              size={LinkSize.Large}
              linkText={t('OnboardingTaxDeclarationTaxResidentLinkAddCountry')}
              onClick={handleOnAdd}
            />
          </Grid>
        )}
      {formik.values.countriesData.length === 3 && (
        <HelperText
          type={HelperTextType.HelperText}
          message={`${t('OnboardingTaxDeclarationYouHaveReachedLimitOfCountriesWeb')}`}
        />
      )}
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingSalaryDetailsBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={handleOnClick}
        />
      </Grid>
    </Grid>
  );
};

export default TaxDecalrationAddCountry;
