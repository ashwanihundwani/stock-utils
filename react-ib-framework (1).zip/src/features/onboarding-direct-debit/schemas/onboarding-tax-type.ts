import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingTaxDeclarationTaxTypeSchema = yup.object().shape({
  Number: yup
    .string()
    .required(Errors.OnboardingTaxDeclarationTaxTypeErrorRequiredTxtNumber),
});

export const OnboardingTaxDeclarationTaxTypeInitialValues = {
  Number: undefined,
};
