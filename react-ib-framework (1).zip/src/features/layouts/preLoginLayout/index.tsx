import Grid from '@mui/material/Grid2';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {QRCodeIcon} from 'assets/svg/qrcode-icon';
import {MeemIcon} from 'assets/svg/meem-icon';
import PreLoginLayoutProps from './types';
import Image from 'components/image';
import {Images} from 'constants/images';

const PreLoginLayout = (props: PreLoginLayoutProps) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);

  const {rightContent} = props;

  return (
    <div style={styles.container}>
      <div style={styles.imageContainer}>
        <Image
          styles={styles.bgImage}
          imageurl={Images.loginBg}
          type={'header'}
        />
      </div>
      <Grid container columns={12} sx={{position: 'relative'}}>
        <Grid size={7} sx={styles.leftSideGrid}>
          <div style={styles.meemLoginLogo}>
            <MeemIcon />
          </div>
          <div style={styles.qrGrid}>
            <QRCodeIcon />
          </div>
        </Grid>
        <Grid size={5} columns={5} container sx={styles.rightSideGrid}>
          {rightContent}
        </Grid>
      </Grid>
    </div>
  );
};

export default PreLoginLayout;
