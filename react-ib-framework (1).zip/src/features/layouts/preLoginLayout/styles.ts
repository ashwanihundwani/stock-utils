import {Theme} from 'react-core';
export const getStyles = (theme: Theme) => {
  return {
    container: {
      height: '100vh',
      backgroundColor: theme.colors['background-03'],
    },
    meemLoginLogo: {
      paddingTop: '1.5rem',
      paddingLeft: '1.5rem',
    },
    leftSideGrid: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
    },
    qrGrid: {
      paddingLeft: '1.5rem',
      paddingBottom: '1.5rem',
    },
    rightSideGrid: {
      height: '100vh',
      borderRadius: '1rem 0 0 1rem',
      backgroundColor: theme.colors['background-01'],
      padding: '1.5rem',
    },
    imageContainer: {
      display: 'flex',
      height: '100%',
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      position: 'absolute' as const, // https://github.com/microsoft/TypeScript/issues/11465
    },
    bgImage: {
      display: 'flex',
      height: '70%',
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
    },
  };
};
