type PreLoginLayoutProps = {
  rightContent: React.ReactElement;
};

export default PreLoginLayoutProps;
