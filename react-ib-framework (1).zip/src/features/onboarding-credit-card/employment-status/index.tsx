import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';
import {getCardType} from 'utils/localStorage';
const EmployementStatus: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();
  const cardType = getCardType();

  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );

  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);

    switch (item.name) {
      case t('OnboardingEmploymentStatusBtnEmployed'):
        if (cardType === 'debit') {
          navigate(AppPath.EmploymentDetails);
        } else {
          navigate(AppPath.IdVerify);
        }

        break;
      case t('OnboardingEmploymentStatusBusinessOwner'):
        if (cardType === 'debit') {
          navigate(AppPath.BusinessOwner);
        } else {
          navigate(AppPath.CannotOfferCC);
        }
        break;
      case t('OnboardingEmploymentStatusHousewife'):
        if (cardType === 'debit') {
          navigate(AppPath.HouseWife);
        } else {
          navigate(AppPath.CannotOfferCC);
        }
        break;
      case t('OnboardingEmploymentStatusStudent'):
        if (cardType === 'debit') {
          navigate(AppPath.Student);
        } else {
          navigate(AppPath.CannotOfferCC);
        }
        break;
      case t('OnboardingEmploymentStatusUnemployed'):
        if (cardType === 'debit') {
          navigate(AppPath.UnEmployed);
        } else {
          navigate(AppPath.CannotOfferCC);
        }
        break;
    }
  };

  const data = [
    {
      id: '1',
      name: t('OnboardingEmploymentStatusBtnEmployed'),
    },
    {id: '2', name: t('OnboardingEmploymentStatusBusinessOwner')},
    {id: '3', name: t('OnboardingEmploymentStatusHousewife')},
    {id: '4', name: t('OnboardingEmploymentStatusStudent')},
    {id: '5', name: t('OnboardingEmploymentStatusUnemployed')},
  ];
  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingInstructionLblYourEmploymentStatus')}
        />
      </Box>
      <Grid size={4} sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
          optBtnBgWhite
        />
      </Grid>
    </Grid>
  );
};

export {EmployementStatus};
