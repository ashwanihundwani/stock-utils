import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    backNavGrid: {
      display: 'flex',
    },
    tellAboutlblStyle: {
      width: '802px',
      minHeight: '64px',
      gap: '8px',
      color: theme.colors['background-01'],
    },
  };
};
