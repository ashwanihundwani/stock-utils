import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import Button from 'components/button';
import {useFormik} from 'formik';
import {EnterNameInitialValues, EnterNameSchema} from '../schemas/enter-name';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {Link} from 'components';
import {LinkSize, LinkType} from 'components/link/types';
const EnterName: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: EnterNameInitialValues,
    validationSchema: EnterNameSchema,
    onSubmit: () => {},
  });

  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Box sx={styles.backNavGrid}>
        <Link
          size={LinkSize.Large}
          linkText={t('OnboardingBackLblTitleWeb')}
          showIcon
          type={LinkType.Secondary}
        />
      </Box>

      <Grid size={7} color={'red'} sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingEnterNameLblTitle')}
        />
        <Box sx={styles.tellAboutlblStyle}>
          <CustomLabel
            id="idEmploymentStatus"
            variant={variants.bodyRegularM}
            text={t('OnboardingEnterNameLblSubtitle')}
          />
        </Box>
      </Grid>
      <Grid sx={styles.listGrid}>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingEnterNameTxtFirstName')}
            value={formik.values.firstName}
            setValue={formik.handleChange('firstName')}
            bgWhite
            // errorText={`${t(formik.errors.firstName) ?? '')}`}
            errorText={`${t(formik.errors.firstName ?? '')}`}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
          <TextInput
            label={t('OnboardingEnterNameTxtSecondName')}
            value={formik.values.secondName}
            setValue={formik.handleChange('secondName')}
            errorText={t(`${formik.errors.secondName ?? ''}`)}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
        </Grid>
        <Grid sx={styles.listrow}>
          <TextInput
            label={t('OnboardingEnterNameTxtThirdName')}
            value={formik.values.thirdName}
            setValue={formik.handleChange('thirdName')}
            errorText={t(`${formik.errors.thirdName ?? ''}`)}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
          <TextInput
            label={t('OnboardingEnterNameTxtFamilyName')}
            value={formik.values.familyName}
            setValue={formik.handleChange('familyName')}
            errorText={t(`${formik.errors.familyName ?? ''}`)}
            type={InputType.Text}
            customStyle={styles.sharedTrustedInputStyles}
          />
        </Grid>
        <Box sx={styles.nextBtnStyle}>
          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            type={ButtonType.Text}
            disabled={!(formik.isValid && formik.dirty)}
            text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
            onClick={() => console.log('Button Clicked')}
          />
        </Box>
      </Grid>
    </Grid>
  );
};

export {EnterName};
