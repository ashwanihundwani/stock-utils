import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      gap: '2rem',
      display: 'flex',
      flexDirection: 'column',
    },
    container: {
      backgroundColor: theme.colors['background-02'],
    },
    listGrid: {
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: '1rem',
    },
    listItems: {
      display: 'flex',
      alignItems: 'center',
      gap: '1rem',
      height: '80px',
      width: '389px',
      backgroundColor: theme.colors['surface-01'],
      paddingLeft: '16px',
      borderRadius: '0.625rem',
    },
    listItemsLast: {
      display: 'flex',
      alignItems: 'center',
      gap: '1rem',
      height: '80px',
      width: '802px',
      backgroundColor: theme.colors['surface-01'],
      paddingLeft: '16px',
      borderRadius: '0.625rem',
    },
    listItemRoot: {
      height: '32px',
      width: '32px',
      borderRadius: '0.625rem',
      backgroundColor: theme.colors['background-02'],
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    title: {
      paddingTop: '16px',
    },
    checkbox: {
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      mt: 2,
    },
    button: {
      paddingTop: '16px',
    },
    beforeWebeginTitle: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '28px',
      color: theme.colors['content-primary'],
    },
    beforeWebeginSubTitle: {
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '16px',
      color: theme.colors['content-secondary'],
    },
    listItemText: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '16px',
      color: theme.colors['content-primary'],
      display: 'grid',
    },
    urlContent: {
      width: '100%',
      backgroundColor: 'violet',
      height: '448px',
    },
    nafathTitle: {
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '12px',
      color: theme.colors['content-primary'],
      paddingTop: '16px',
      paddingBottom: '32px',
    },
    IacceptTitle: {
      fontFamily: fonts.figtree_regular,
      fontWeight: '400',
      fontSize: '16px',
      color: theme.colors['content-primary'],
      paddingRight: '4px',
    },
    modalContainer: {
      height: 'fit-content',
      padding: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '24px',
    },
    cancelIconStyle: {
      textAlign: 'right',
    },
  };
};
