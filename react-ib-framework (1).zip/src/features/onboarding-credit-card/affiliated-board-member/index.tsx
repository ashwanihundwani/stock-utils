import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import TextInput from 'components/text-input';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import Button from 'components/button';
import {InputType} from 'components/text-input/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';

const AffiliatedBoardMember: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );
  const [otherValue, setOtherValue] = useState('');

  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);
    navigate(item.name === 'No' ? AppPath.politicalyExposed : '');
  };
  const data = [
    {id: '1', name: t('OnboardingAffiliatedGibMemberBtnChip1')},
    {id: '2', name: t('OnboardingAffiliatedGibMemberBtnChip2')},
  ];

  const handleSubmit = () => {
    navigate(AppPath.politicalyExposed);
  };
  // need to check mobile flow
  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Grid size={7} sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingAffiliatedGibMemberLblTitle')}
        />
      </Grid>
      <Grid size={4} sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
          optBtnBgWhite
        />

        {selectedValue?.name === t('OnboardingAffiliatedGibMemberBtnChip2') && (
          <Box sx={styles.inputStyles}>
            <TextInput
              label={t('OnboardingAffiliatedGibMemberTxtBoardMemberName')}
              value={otherValue}
              setValue={setOtherValue}
              type={InputType.Text}
              bgWhite
            />
            <Box sx={styles.nextBtnStyle}>
              <Button
                variant={ButtonStyle.Primary}
                size={ButtonSize.Large}
                type={ButtonType.Text}
                text={t('OnboardingAffiliatedGibMemberBtnNextLabel')}
                onClick={handleSubmit}
              />
            </Box>
          </Box>
        )}
      </Grid>
    </Grid>
  );
};

export {AffiliatedBoardMember};
