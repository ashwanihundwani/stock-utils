import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import {useNavigate} from 'react-router-dom';
import TextArea from 'components/text-area';
import {useFormik} from 'formik';
import {
  OnboardingDisabilitiesInitialValues,
  OnboardingDisabilitiesSchema,
} from '../schemas/disability';
import Button from 'components/button';
import {ButtonStyle, ButtonType, ButtonSize} from 'components/button/types';
import {AppPath} from 'constants/path';
import {MaximumInputLength} from 'constants/types';

const Disabilities: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );
  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);

    if (selectedValue?.name === 'No') {
      navigate(AppPath.GetLatestUpdates);
    }
  };
  const data = [
    {id: '1', name: t('OnboardingAdditionalincomeBtnOptionNo')},
    {id: '2', name: t('OnboardingAdditionalIncomeBtnOptionYes')},
  ];

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingDisabilitiesInitialValues,
    validationSchema: OnboardingDisabilitiesSchema,
    onSubmit: () => {
      navigate(AppPath.GetLatestUpdates);
    },
  });

  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingDisabilitiesLblTitle')}
        />
      </Box>

      <Grid size={4} sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
          optBtnBgWhite
        />
        {selectedValue?.name === 'Yes' && (
          <Box sx={{gap: '8px', display: 'flex', flexDirection: 'column'}}>
            <TextArea
              id={t(
                'OnboardingAdditionalIncomesourceTxtIncomeSourceDescription',
              )}
              placeholder={t('OnboardingDisabilitiesTxtDisability')}
              value={formik.values.disability}
              onChange={formik.handleChange('disability')}
              errorText={formik.errors.disability}
              disabled={false}
              maximumLength={MaximumInputLength}
              customStyle={styles.textArea}></TextArea>
            <Button
              variant={ButtonStyle.Primary}
              size={ButtonSize.Large}
              type={ButtonType.Text}
              disabled={!(formik.isValid && formik.dirty)}
              text={t('OnboardingDisabilitiesBtnNext')}
              onClick={formik.handleSubmit}
              // disabled={isDisabled()}
              // onClick={() => {
              //   if (selectedValue.name === 'No' || isFormikValid) {
              //     navigate(AppPath.GetLatestUpdates);
              //   }
              // }}
            />
          </Box>
        )}
      </Grid>
    </Grid>
  );
};

export {Disabilities};
