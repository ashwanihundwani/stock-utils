import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';
import CustomLabel from 'components/custom-label';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import {variants} from 'components/custom-label/types';
import Chip from 'components/chip-component';
import Dropdown from 'components/select-dropdown';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {useFormik} from 'formik';
import {
  OnboardingAboutAddtionalIncomeInitialValues,
  OnboardingAboutAddtionalIncomeSchema,
} from '../schemas/onboarding-aboutus-additional-income';
import {getCardType} from 'utils/localStorage';

const TellUsAboutAdditionalIncome: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();
  const [monthlyChip, setMonthlyChip] = useState(true);
  const [annualChip, setAnnualChip] = useState(false);
  const cardType = getCardType();

  const handleOnBtn = (name: string, value: boolean) => {
    if (name === 'monthly') {
      setMonthlyChip(value);
      setAnnualChip(false);
    } else {
      setAnnualChip(value);
      setMonthlyChip(false);
    }
  };

  const IncomeAmount = [
    {
      id: '1',
      value: '15000-30000_SAR',
      label: '15000-30000 SAR',
    },
    {
      id: '2',
      value: '30000-60000_SAR',
      label: '30000-60000 SAR',
    },
  ];

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingAboutAddtionalIncomeInitialValues,
    validationSchema: OnboardingAboutAddtionalIncomeSchema,
    onSubmit: () => {
      navigate(AppPath.shareTrustedDetails);
    },
  });

  const handleOnClick = () => {
    if (cardType === 'debit') {
      navigate(AppPath.monthlyadditionalIncomeAmount);
    } else if (cardType === 'credit') {
      navigate(AppPath.shareTrustedDetails);
    }
  };
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id="idBack"
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingTellUsAboutAdditionalIncomeWeb')}
          variant={variants.titleXL}
          text={t('OnboardingTellUsAboutAdditionalIncomeWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingAboutAddtionalIncomeLblMonthlyAnnual')}
          variant={variants.bodyMediumM}
          text={t('OnboardingAboutAddtionalIncomeLblMonthlyAnnual')}
        />
      </Grid>
      <Grid sx={styles.monthlyAnnualChip}>
        <Chip
          label={t('OnboardingAboutAddtionalIncomeBtnChipMonthly')}
          isActive={monthlyChip}
          isInverted={!monthlyChip}
          onClick={() => handleOnBtn('monthly', true)}
        />
        <Chip
          label={t('OnboardingAboutAddtionalIncomeBtnChipAnnual')}
          // isActive={true}
          // isInverted={true}
          isActive={annualChip}
          isInverted={!annualChip}
          onClick={() => handleOnBtn('annual', true)}
        />
      </Grid>
      <Grid sx={styles.rangeOfmonthlyIncome}>
        <CustomLabel
          id={t('OnboardingAboutAddtionalIncomeLblRangeIncome')}
          variant={variants.bodyMediumM}
          text={t('OnboardingAboutAddtionalIncomeLblRangeIncome')}
        />
      </Grid>
      <Grid sx={styles.incomeAmountDropdown}>
        <Dropdown
          id={t('OnboardingAboutAddtionalIncomeDdMonthlyIncome')}
          labelId={t('OnboardingAboutAddtionalIncomeDdMonthlyIncome')}
          placeholder={t('OnboardingAboutAddtionalIncomeDdMonthlyIncome')}
          options={IncomeAmount}
          helperText={''}
          disabled={false}
          customstyle={styles.dropdown}
          labelstyle={styles.labelStyle}
          value={formik.values.monthlyIncome}
          errorText={`${t(formik.errors.monthlyIncome ?? '')}`}
          setValue={formik.handleChange('monthlyIncome')}
        />
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingAboutAddtionalIncomeBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={handleOnClick}
        />
      </Grid>
    </Grid>
  );
};

export default TellUsAboutAdditionalIncome;
