export const salaryAccountBankData = [
  {id: 'alrajhi', value: 'Alrajhi', label: 'Alrajhi'},
  {id: 'meem', value: 'Meem', label: 'Meem'},
];
export const whenAccountOpenedData = [
  {id: 'oneToFiveYears', value: '1 - 5', label: '1 - 5'},
  {id: 'sixToTenYears', value: '6 - 10', label: '6 - 10'},
];
export const autoPaymentInstructionsData = [
  {id: 'none', value: 'None', label: 'None'},
  {id: 'others', value: 'Others', label: 'Others'},
];

export const employerName = [
  {
    id: '1',
    value: 'aramco',
    label: 'Aramco',
  },

  {
    id: '2',
    value: 'sabic',
    label: 'Sabic',
  },
  {
    id: '3',
    value: 'other',
    label: 'Other',
  },
];

export const jobTitleData = [
  {
    id: 'softwareEngineer',
    label: 'Software Engineer',
    value: 'Software Engineer',
  },
  {id: 'developer', label: 'Developer', value: 'Developer'},
];

export const workSecterData = [
  {id: 'public', label: 'Public', value: 'Public'},
  {id: 'private', label: 'Private', value: 'Private'},
];
export const workExperienceData = [
  {id: 'zeroToTwoExp', label: '0 - 2', value: '0 - 2'},
  {id: 'threeToFiveExp', label: '3 - 5', value: '3 - 5'},
];
export const periodInCurrentJobData = [
  {id: 'oneToTwoYears', label: '1 - 2', value: '1 - 2'},
  {id: 'threeToFiveYears', label: '3 - 5', value: '3 - 5'},
];

export const incomeSourceDropdown = [
  {
    id: '1',
    value: 'self-employed',
    label: 'self-employed',
  },
  {
    id: '2',
    value: 'employed',
    label: 'employed',
  },
];
