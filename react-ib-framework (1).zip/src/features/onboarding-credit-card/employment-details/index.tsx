import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {getStyles} from './styles';
import {useNewTheme, translation} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import Dropdown from 'components/select-dropdown';
import TextInput from 'components/text-input';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import {
  employerName,
  jobTitleData,
  periodInCurrentJobData,
  workExperienceData,
  workSecterData,
} from './utility';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {getCardType} from 'utils/localStorage';
import {useFormik} from 'formik';
import {
  OnboardingEmploymentDetailsInitialValues,
  OnboardingEmploymentDetailsSchema,
} from '../schemas/onboarding-employementDetails';
import {PhoneNumberLength9} from 'constants/types';
import {InputType} from 'components/text-input/types';

const EmploymentDetails: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const navigate = useNavigate();
  const cardType = getCardType();
  const {t} = translation.useTranslation();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingEmploymentDetailsInitialValues,
    validationSchema: OnboardingEmploymentDetailsSchema,
    onSubmit: () => {},
  });
  const handleOnClick = () => {
    if (cardType === 'credit') {
      navigate(AppPath.SalaryDetails);
    } else if (cardType === 'debit') {
      navigate(AppPath.additionalIncome);
    }
  };
  return (
    <Grid size={8} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <ArrowLeft />
        <CustomLabel
          id={t('OnboardingBackLblTitleWeb')}
          variant={variants.bodySemiBoldM}
          style={styles.backLblstyle}
          text={t('OnboardingBackLblTitleWeb')}
        />
      </Grid>
      <Grid sx={styles.title}>
        <CustomLabel
          id={t('OnboardingEmploymentDetailsLblTitle')}
          variant={variants.titleXL}
          text={t('OnboardingEmploymentDetailsLblTitle')}
        />
      </Grid>

      <Grid>
        <CustomLabel
          id={t('OnboardingEmploymentDetailsLblSubtitle')}
          variant={variants.bodyMediumM}
          text={t('OnboardingEmploymentDetailsLblSubtitle')}
        />
      </Grid>
      <Grid sx={styles.listGrid}>
        <Grid>
          <Dropdown
            id={t('OnboardingEmploymentDetailsDdEmployerName')}
            labelId={t('OnboardingEmploymentDetailsDdEmployerName')}
            placeholder={t('OnboardingEmploymentDetailsDdEmployerName')}
            options={employerName}
            errorText={`${t(formik.errors.employerName ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            // value={employerNameValue}
            value={formik.values.employerName}
            // setValue={setEmployerNameValue}
            setValue={formik.handleChange('employerName')}
            // setValue(prev => ({...prev, employerName: !prev.employerName}))
          />
        </Grid>
        {formik.values.employerName === 'Other' && (
          <Grid>
            <TextInput
              label={t('OnboardingEmployedtxtOtherEmployer')}
              customStyle={styles.textInput}
              value={formik.values.otherEmployerName}
              setValue={formik.handleChange('otherEmployerName')}
            />
          </Grid>
        )}
        <Grid>
          <Dropdown
            id={t('OnboardingEmploymentDetailsDdJobTitle')}
            labelId={t('OnboardingEmploymentDetailsDdJobTitle')}
            placeholder={t('OnboardingEmploymentDetailsDdJobTitle')}
            options={jobTitleData}
            errorText={`${t(formik.errors.jobTitle ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.jobTitle}
            setValue={formik.handleChange('jobTitle')}
          />
        </Grid>

        <Grid>
          <Dropdown
            id={t('OnboardingEmploymentDetailsDdWorkSector')}
            labelId={t('OnboardingEmploymentDetailsDdWorkSector')}
            placeholder={t('OnboardingEmploymentDetailsDdWorkSector')}
            options={workSecterData}
            errorText={`${t(formik.errors.workSector ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            // value={formik.values.workSector}
            // setValue={formik.handleChange('workSector')}
          />
        </Grid>
        <Grid>
          {/* <Dropdown
            id={t('OnboardingEmploymentDetailsTxtJoiningDate')}
            labelId={t('OnboardingEmploymentDetailsTxtJoiningDate')}
            placeholder={t('OnboardingEmploymentDetailsTxtJoiningDate')}
            options={employerName}
            errorText={''}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
          /> */}
          <Grid>
            <TextInput
              label={t('OnboardingEmploymentDetailsTxtJoiningDate')}
              customStyle={styles.textInput}
              value={'22 Aug, 2024'}
              setValue={formik.handleChange('joiningDate')}
              errorText={`${t(formik.errors.joiningDate ?? '')}`}
            />
          </Grid>
        </Grid>
        <Grid>
          <Dropdown
            id={t('OnboardingEmploymentDetailsDdTotalWorkExperience')}
            labelId={t('OnboardingEmploymentDetailsDdTotalWorkExperience')}
            placeholder={t('OnboardingEmploymentDetailsDdTotalWorkExperience')}
            options={workExperienceData}
            errorText={`${t(formik.errors.totalWorkExperience ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.totalWorkExperience}
            setValue={formik.handleChange('totalWorkExperience')}
          />
        </Grid>
        <Grid>
          <Dropdown
            id={t('OnboardingEmploymentDetailsDdPeriodInCurrentJob')}
            labelId={t('OnboardingEmploymentDetailsDdPeriodInCurrentJob')}
            placeholder={t('OnboardingEmploymentDetailsDdPeriodInCurrentJob')}
            options={periodInCurrentJobData}
            errorText={`${t(formik.errors.periodInCurrentJob ?? '')}`}
            helperText={''}
            disabled={false}
            customstyle={styles.dropdown}
            labelstyle={styles.labelStyle}
            value={formik.values.periodInCurrentJob}
            setValue={formik.handleChange('periodInCurrentJob')}
          />
        </Grid>
        <Grid>
          <TextInput
            label={t('OnboardingEmploymentDetailsTxtWorkContactNumber')}
            customStyle={styles.textInput}
            type={InputType.Number}
            value={formik.values.workContactNumber}
            setValue={formik.handleChange('workContactNumber')}
            errorText={`${t(
              formik.touched.workContactNumber &&
                formik.errors.workContactNumber
                ? formik.errors.workContactNumber
                : '',
            )}`}
            maximumLength={PhoneNumberLength9}
          />
        </Grid>
      </Grid>
      <Grid sx={styles.button}>
        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingEmploymentDetailsBtnNext')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={handleOnClick}
        />
      </Grid>
    </Grid>
  );
};

export default EmploymentDetails;
