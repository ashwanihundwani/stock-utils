import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      display: 'grid',
      paddingTop: '2rem',
      ml: 6,
      alignItems: 'center',
    },

    listGrid: {
      paddingTop: '2rem',
      display: 'flex',
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: '1rem',
    },
    dropdown: {
      background: theme.colors['surface-01'],
      width: '24.56rem',
    },
    incomeSourceDropdown: {
      background: theme.colors['surface-01'],
      width: '28rem',
    },
    incomeSourceDropdownGrid: {
      paddingTop: '2rem',
    },
    labelStyle: {
      fontFamily: fonts.figtree_regular,
      color: theme.colors['content-secondary'],
    },

    backLblstyle: {
      width: '2.25rem',
      height: '1.5rem',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    textInput: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '24.56rem',
        borderRadius: '0.625rem',
        '&.Mui-focused, &:hover': {
          fontSize: '0.8rem',
          fontWeight: 'normal',
          fontFamily: fonts.regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },

      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '0.625rem',
        fontSize: '0.8rem',
        width: '100%',
        fontFamily: fonts.regular,
        color: theme.colors['content-primary'],
        margin: '0.31rem 0.62rem 0.12rem',
        height: '1.4rem ',
      },
    },
    button: {
      paddingTop: '2rem',
    },
    title: {
      paddingTop: '1rem',
    },
    backNavGrid: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.5rem',
    },
    textArea: {
      width: '440.5rem',
      backgroundColor: theme.colors['surface-01'],
      borderRadius: '0.625rem',
      '&:hover': {
        // borderColor: theme.colors['border-focus'],
        backgroundColor: theme.colors['surface-01'],
      },
      '& .MuiFilledInput-root': {
        border: `1px solid transparent`,
        borderRadius: '0.625rem',

        fontFamily: fonts.regular,
        backgroundColor: theme.colors['surface-01'],
        color: theme.colors['content-primary'],
        height: '12rem',
        alignItems: 'flex-end',
        paddingTop: '0.75rem',
        paddingLeft: '1rem',
        marginTop: '0.18rem',
        '&:hover': {
          // borderColor: theme.colors['border-focus'],
          backgroundColor: theme.colors['surface-01'],
        },
        '&.Mui-focused': {
          backgroundColor: theme.colors['surface-01'],
        },
      },
    },
    textAreaGrid: {
      paddingTop: '1rem',
    },
    incomeAmountDropdown: {
      paddingTop: '1rem',
    },
    rangeOfmonthlyIncome: {
      paddingTop: '2rem',
    },
    monthlyAnnualChip: {
      display: 'flex',
      paddingTop: '1rem',
      gap: '1rem',
    },
    giftIcon: {
      display: 'flex',
      paddingTop: '2rem',
      gap: '0.5rem',
    },
    popupCloseIcon: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    popupText: {
      marginTop: '1rem',
      width: '25rem',
    },
    popupGrid: {
      padding: '1.5rem',
      display: 'flex',
      flexDirection: 'column',
    },
    popupButton: {
      display: 'flex',
      padding: '1rem',
      gap: '1rem',
      justifyContent: 'flex-end',
    },
    listItems: {
      display: 'flex',
      alignItems: 'center',
      gap: '1rem',
      height: '5rem',
      width: '24.3rem',
      backgroundColor: theme.colors['surface-01'],
      paddingLeft: '1rem',
      borderRadius: '0.625rem',
    },
  };
};
