export const data = [
  {id: '0', label: 'Option1', value: 'Option1'},
  {id: '1', label: 'Option2', value: 'Option2'},
];
