import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from '../employment-details/styles';
import {variants} from 'components/custom-label/types';
import CustomLabel from 'components/custom-label';
import {TextInput} from 'components';
import Chip from 'components/chip-component';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {SvgIcon} from '@mui/material';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {PopupChildrenProps} from './types';

const Popupchildren: FC<PopupChildrenProps> = ({onClose}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();

  return (
    <Grid>
      <Grid size={4} sx={styles.popupGrid}>
        <Grid sx={styles.popupCloseIcon}>
          <CustomLabel
            id={t('OnboardingOfferPreferenceLblReferralCodeLink')}
            variant={variants.bodyMediumM}
            text={t('OnboardingOfferPreferenceLblReferralCodeLink')}
          />
          <SvgIcon onClick={onClose}>
            <DeleteIcon />
          </SvgIcon>
        </Grid>
        <CustomLabel
          id={t('OnboardingOfferPreferenceLblBsReferralCodeSubtitle')}
          variant={variants.bodyRegularM}
          text={t('OnboardingOfferPreferenceLblBsReferralCodeSubtitle')}
        />
        <TextInput
          label="Placeholder"
          value={''}
          customStyle={styles.popupText}
        />
        <TextInput
          label="Placeholder"
          value={''}
          customStyle={styles.popupText}
        />
        <TextInput
          label="Placeholder"
          value={''}
          customStyle={styles.popupText}
        />
      </Grid>
      <Grid sx={styles.popupButton}>
        <Button
          variant={ButtonStyle.Secondary}
          size={ButtonSize.Small}
          type={ButtonType.Text}
          text={t('cancel')}
          disabled={false}
          onClick={onClose}
        />

        <Chip
          label={t('OnboardingOfferPreferenceBtnBSApplyCode')}
          isActive={true}
          onClick={onClose}
        />
      </Grid>
    </Grid>
  );
};
export default Popupchildren;
