export interface PopupChildrenProps {
  onClose?: () => void;
}

export interface ListitemProps {
  id: string;
  value: string;
  name: string;
}
