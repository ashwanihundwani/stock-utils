import {FC} from 'react';
import {Box} from '@mui/material';
import Grid from '@mui/material/Grid2';

import {getStyles} from '../styles';
import TextInput from 'components/text-input';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {useFormik} from 'formik';
import {ArrowLeft} from 'assets/svg/arrow-left-02';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {
  OnboardingCredentialsCreationUsernameInitialValues,
  OnboardingCredentialsCreationUsernameSchema,
} from '../schemas/create-credentails-username';
import {useNavigate} from 'react-router-dom';

import {Tick02} from 'assets/svg/tick02';
import {
  ONEDIGIT,
  ONELOWERCASE,
  ONEUPPERCASE,
  ONESPECIALCHAR,
  MINLENEIGHT,
  MAXLENTWENTY,
} from 'utils/text-input-validation';
import Button from 'components/button';
import {useNewTheme, useTranslation} from 'react-core';
import {AppPath} from 'constants/path';

const CreatCredentialsUserName: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingCredentialsCreationUsernameInitialValues,
    validationSchema: OnboardingCredentialsCreationUsernameSchema,
    onSubmit: () => {
      navigate(AppPath.onboardingcreatePassword);
    },
  });

  console.log(formik.values.username, 'validationType(formik.values.username)');
  const renderValidationListItem = (
    validationType: (value: string | undefined) => boolean,
    text: string,
  ) => {
    return (
      <Box id={`vw${text}`} sx={styles.validationBox}>
        {validationType(formik.values.username) && (
          <Box sx={styles.tickIconGreenStyle}>
            <Tick02 color={theme.colors['icon-inverted-primary']} size="8" />
          </Box>
        )}
        {!validationType(formik.values.username) &&
          formik.values.username !== '' && (
            <Box sx={styles.tickIconRedStyle}>
              <Tick02 color={theme.colors['icon-inverted-primary']} size="8" />
            </Box>
          )}
        {!validationType(formik.values.username) &&
          formik.values.username === '' && (
            <Box sx={styles.tickIconWhitetyle}>
              <Tick02 color={theme.colors['icon-secondary']} size="8" />
            </Box>
          )}
        <CustomLabel
          id="lblSubtitle"
          variant={variants.bodyRegularM}
          style={styles.validationLabel}
          text={text}
        />
      </Box>
    );
  };
  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Grid sx={styles.backNavGrid}>
        <Box sx={styles.rowStyle}>
          <ArrowLeft />
          <CustomLabel
            id="idBack"
            variant={variants.bodySemiBoldM}
            style={styles.backLblstyle}
            text={t('OnboardingBackLblTitleWeb')}
          />
        </Box>
      </Grid>

      <Box sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="lblTitle"
          variant={variants.titleXL}
          text={t('OnboardingCredentialsCreationUsernameLblTitleWeb')}
        />
        <CustomLabel
          id="lblSubtitle"
          variant={variants.bodyRegularM}
          text={t('OnboardingCredentialsCreationUsernameLblSubtitle')}
        />

        <Grid sx={styles.crendentialStyle}>
          <Grid size={3.4}>
            <TextInput
              label={t('OnboardingCredentialsCreationUsernameTxtUsername')}
              value={formik.values.username}
              bgWhite
              setValue={formik.handleChange('username')}
            />
          </Grid>

          <Grid size={3.4}>
            {renderValidationListItem(
              ONELOWERCASE,
              'OnboardingCredentialsCreationUsernameLblOneLowerCase',
            )}
            {renderValidationListItem(
              ONEUPPERCASE,
              'OnboardingCredentialsCreationUsernameLblOneUpperCase',
            )}
            {renderValidationListItem(
              ONEDIGIT,
              'OnboardingCredentialsCreationUsernameLblOneNumber',
            )}
            {renderValidationListItem(
              ONESPECIALCHAR,
              'OnboardingCredentialsCreationUsernameLblOneSpecialChar',
            )}
            {renderValidationListItem(
              MINLENEIGHT,
              'OnboardingCredentialsCreationUsernameLblMinLengthEight',
            )}
            {renderValidationListItem(
              MAXLENTWENTY,
              'OnboardingCredentialsCreationUsernameLblMaxLengthTwenty',
            )}
          </Grid>
        </Grid>

        <Button
          variant={ButtonStyle.Primary}
          size={ButtonSize.Large}
          type={ButtonType.Text}
          text={t('OnboardingCredentialsCreationUsernameBtnConfirm')}
          disabled={!(formik.isValid && formik.dirty)}
          onClick={() => formik.handleSubmit()}
        />
      </Box>
      {/* </Box> */}
    </Grid>
  );
};

export default CreatCredentialsUserName;
