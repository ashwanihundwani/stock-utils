import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {Typography} from '@mui/material';
import ProductSelction from '../product-selction/productselection';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {LanguageSkill} from 'assets/svg/language-skill';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import PreLoginLayout from 'features/layouts/preLoginLayout';

const OnboardingLayout: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);

  const content = (
    <>
      <Grid size={12} style={styles.headerContainer}>
        <Grid style={styles.languageSkillIcon}>
          <LanguageSkill />
          <Typography sx={styles.languageBtn}>عربي</Typography>
        </Grid>
        <Grid style={styles.needHelpTextGrid}>
          <Typography sx={styles.needhelpText}> Do you need help?</Typography>{' '}
          &nbsp;
          <Link linkText="Contact us" size={LinkSize.Medium} />
        </Grid>
      </Grid>
      <Grid size={1}></Grid>
      <Grid sx={styles.dynamicContent} size={3}>
        <ProductSelction />
      </Grid>
      <Grid size={1}></Grid>
    </>
  );

  return <PreLoginLayout rightContent={content} />;
};

export default OnboardingLayout;
