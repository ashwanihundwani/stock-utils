import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    dynamicContent: {
      display: 'flex',
      alignItems: 'center',
    },
    needhelpText: {
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontSize: '0.875rem',
      alignItems: 'center',
      display: 'flex',
    },
    languageSkillIcon: {
      display: 'flex',
    },
    languageBtn: {
      fontFamily: fonts.regular,
      fontSize: '0.875rem',
      fontWeight: '600px',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    needHelpTextGrid: {
      display: 'flex',
      height: '1.5rem',
    },
    headerContainer: {
      display: 'flex',
      justifyContent: 'space-between',
    },
  };
};
