import {OtpContainer} from 'components';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import Grid from '@mui/material/Grid2';
import {getStyles} from '../styles';
import {useNewTheme} from 'react-core';

const OtpOnboarding = () => {
  const theme = useNewTheme();
  const navigate = useNavigate();
  const styles = getStyles(theme);

  return (
    <Grid container columns={7} sx={styles.outerGrid}>
      <Grid size={4}>
        <OtpContainer
          onResendOtp={() => {}}
          backLabel="Back"
          title={'AuthenticationEnterOtpLblTitle'}
          subtitle={'AuthenticationEnterOtpLblSubtitle'}
          resendOtpLabel={'AuthenticationEnterOtpLblTimer'}
          requestOtpLabel={'AuthenticationEnterOtpLblLinkCode'}
          onSubmitOtp={() => {
            navigate(AppPath.Nafath);
          }}
        />
      </Grid>
    </Grid>
  );
};

export default OtpOnboarding;
