import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
      padding: '1rem',
    },
    container: {
      display: 'flex',
      flexDirection: 'column',
      mt: 3,
    },

    emailTitle: {
      fontFamily: fonts.regular,
      fontWeight: '500',
      fontSize: '1.75rem',
      color: theme.colors['content-primary'],
    },
    emailContent: {
      display: 'flex',
      FlexDirection: 'row',
      gap: '0.5rem',
      mt: 4,
      margin: '0.125rem',
      // color: theme.colors['content-secondary'],
    },
    contents: {
      fontFamily: fonts.regular,
      fontWeight: '400',
      fontSize: '1rem',
      color: theme.colors['content-secondary'],
      paddingRight: '0.25rem',
    },

    emailGrid: {
      paddingBottom: '1rem',
      paddingTop: '1rem',
    },
    checkBoxGrid: {
      display: 'flex',
      mt: 1,
    },
  };
};
