import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';
import TextInput from 'components/text-input';
import {InputType} from 'components/text-input/types';
import CustomCheckbox from 'components/checkbox';
import {CheckboxDefaultIcon, CheckboxSelectedIcon} from 'assets/svg/checkbox';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {variants} from 'components/custom-label/types';

import {useFormik} from 'formik';
import {
  OnboardingEmailInitialValues,
  OnboardingEmailSchema,
} from '../schemas/onboarding-email';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {CustomLabel} from 'components';
import {getCardType, getNationalId} from 'utils/localStorage';
import {AppPath} from 'constants/path';
import {useNavigate} from 'react-router-dom';

const EmailScreen: FC = () => {
  const cardType = getCardType();
  const nationalid = getNationalId();
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [ischeckBoxConsent, setCheckBoxConsent] = useState(false);
  const [ischeckBoxAccept, setCheckBoxAccept] = useState(false);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const disableButton = () => {
    if (cardType === 'credit') {
      if (
        formik.isValid &&
        formik.dirty &&
        ischeckBoxConsent &&
        ischeckBoxAccept
      ) {
        return false;
      } else return true;
    } else if (cardType === 'debit') {
      if (formik.isValid && formik.dirty) return false;
      else return true;
    }
  };
  const formik = useFormik({
    validateOnChange: true,
    validateOnBlur: true,
    initialValues: OnboardingEmailInitialValues,
    validationSchema: OnboardingEmailSchema,
    onSubmit: () => {
      if (nationalid === 'Expart') {
        navigate(AppPath.homeAddress);
      } else {
        navigate(AppPath.firstNameTitle);
      }
    },
  });

  const checkConsent = () => {
    setCheckBoxConsent(!ischeckBoxConsent);
    formik.handleChange('checkbox');
  };
  const checkAcceptSimah = () => {
    setCheckBoxAccept(!ischeckBoxAccept);
    formik.handleChange('checkbox1');
  };

  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Grid>
        <CustomLabel
          id="lblTitle"
          variant={variants.titleXL}
          style={styles.emailTitle}
          text={t('OnboardingEmailLblTitle')}
        />
        <CustomLabel
          id="lblSubTitle"
          style={styles.emailContent}
          variant={variants.bodyRegularM}
          text={t('OnboardingEmailLblSubtitle')}
          numberOfLines={2}
        />

        <Grid container columns={4} size={4} sx={styles.container}>
          <TextInput
            value={formik.values.email}
            setValue={formik.handleChange('email')}
            label={t('OnboardingEmailLblTitle')}
            type={InputType.Text}
            bgWhite
            // customStyle={styles.emailStyle}
          />
          <HelperText
            type={HelperTextType.ErrorText}
            message={`${t(formik.errors.email ?? '')}`}
          />

          <TextInput
            value={formik.values.repeatemail}
            setValue={formik.handleChange('repeatemail')}
            label={t('OnboardingEmailLblRepeatEmail')}
            type={InputType.Text}
            bgWhite
          />
          <HelperText
            type={HelperTextType.ErrorText}
            message={`${t(formik.errors.repeatemail ?? '')}`}
          />
        </Grid>
        <Box sx={{display: 'flex', flexDirection: 'column', gap: '1.5rem'}}>
          {cardType === 'credit' ? (
            <Grid columns={4} size={3}>
              <Box sx={styles.checkBoxGrid}>
                <CustomCheckbox
                  id="checkbox-cmp"
                  errorText={''}
                  helperText={''}
                  disabled={false}
                  onChange={checkConsent}
                  icon={<CheckboxDefaultIcon />}
                  checkedIcon={<CheckboxSelectedIcon />}
                />

                <CustomLabel
                  id="lblEmailCondition"
                  variant={variants.bodyRegularM}
                  text={t('OnboardingEmailChkTermsAndCondition')}
                />
              </Box>

              <Box sx={styles.checkBoxGrid}>
                <Box>
                  <CustomCheckbox
                    id="checkbox-cmp"
                    errorText={''}
                    helperText={''}
                    disabled={false}
                    onChange={checkAcceptSimah}
                    icon={<CheckboxDefaultIcon />}
                    checkedIcon={<CheckboxSelectedIcon />}
                  />
                </Box>

                <CustomLabel
                  id="lblEmailConditionTwo"
                  variant={variants.bodyRegularM}
                  text={t('OnboardingEmailChkSimahDisclaimer')}
                />

                <Link
                  size={LinkSize.Medium}
                  linkText={t('OnboardingEmailLblDisclaimer')}
                />
              </Box>
            </Grid>
          ) : null}

          <Button
            variant={ButtonStyle.Primary}
            size={ButtonSize.Large}
            disabled={disableButton()}
            type={ButtonType.Text}
            text={t('OnboardingEmailBtnNext')}
            onClick={formik.handleSubmit}
          />
        </Box>
      </Grid>
    </Grid>
  );
};

export default EmailScreen;
