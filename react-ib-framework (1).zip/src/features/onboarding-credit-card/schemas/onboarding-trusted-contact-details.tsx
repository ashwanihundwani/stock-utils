import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const TrustedContactDetailsSchema = yup.object().shape({
  fullname: yup
    .string()
    .required(Errors.OnboardingTrustedContactErrorRequiredTxtFullname),
  relationship: yup
    .string()
    .required(Errors.OnboardingTrustedContactErrorRequiredTxtRelationship),
  phonenumber: yup
    .string()
    .matches(
      /^[0-9]+$/,
      Errors.OnboardingTrustedContactErrorMustDigitsTxtPhonenumber,
    )
    .min(10, Errors.OnboardingTrustedContactErrorExactlyTenDigitsTxtPhonenumber)
    .max(10, Errors.OnboardingTrustedContactErrorExactlyTenDigitsTxtPhonenumber)
    .required(Errors.OnboardingTrustedContactErrorRequiredTxtPhonenumber),
});

export const TrustedContactDetailsInitialValues = {
  fullname: '',
  relationship: '',
  phonenumber: '',
  homephonenumber: '',
};
