import * as Yup from 'yup';
import {Errors} from 'constants/errors';

export const OnboardingStatusInitialValues = {
  immigrationCountries: [],
  citizenshipCountries: [],
  residencyStates: {},
};

export const OnboardingStatusSchema = (
  immigrationStatus: string,
  citizenshipStatus: string,
) =>
  Yup.object().shape({
    immigrationCountries: Yup.array().when([], {
      is: () => immigrationStatus === 'yes',
      then: schema =>
        schema
          .min(
            1,
            Errors.OnboardingTaxDeclarationStatusErrorRequiredDdChooseContry,
          )
          .required('Required'),
      otherwise: schema => schema.notRequired(),
    }),
    citizenshipCountries: Yup.array().when([], {
      is: () => citizenshipStatus === 'yes',
      then: schema =>
        schema
          .min(
            1,
            Errors.OnboardingTaxDeclarationStatusErrorRequiredDdChooseContry,
          )
          .required('Required'),
      otherwise: schema => schema.notRequired(),
    }),
  });
