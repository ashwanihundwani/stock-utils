import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingAccountPurposeSchema = yup.object().shape({
  other: yup
    .string()
    .required(Errors.OnboardingAccountPurposeErrorRequiredTxtOther),
});

export const OnboardingAccountPurposeInitialValues = {
  other: '',
};
