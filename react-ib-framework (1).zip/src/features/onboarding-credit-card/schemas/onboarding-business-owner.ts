import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingBusinessOwnerSchema = yup.object().shape({
  industry: yup
    .string()
    .required(Errors.OnboardingBusinessOwnerErrorrequiredDdIndustry),
  businessName: yup
    .string()
    .required(Errors.OnboardingBusinessOwnerErrorrequiredTxtBusinessName),
  annualIncome: yup
    .string()
    .required(Errors.OnboardingBusinessOwnerErrorrequiredDdAnnualIncome),
  incomeDescription: yup
    .string()
    .required(Errors.OnboardingBusinessOwnerErrorrequiredTxtIncomeDescription),
});

export const OnboardingBusinessOwnerInitialValues = {
  industry: '',
  businessName: '',
  annualIncome: '',
  incomeDescription: '',
};
