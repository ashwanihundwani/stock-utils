import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const HomeAddressSchema = yup.object().shape({
  StreetAddress: yup
    .string()
    .required(Errors.OnboardingHomeAddressErrorrequiredTxtStreetAddress),
  StreetAddress2: yup
    .string()
    .required(Errors.OnboardingHomeAddressErrorrequiredTxtStreetAddress2),
  City: yup.string().required(Errors.OnboardingHomeAddressErrorrequiredTxtCity),
  ZipCode: yup
    .number()
    .required(Errors.OnboardingHomeAddressErrorrequiredTxtZipCode),
  Country: yup
    .string()
    .required(Errors.OnboardingHomeAddressErrorrequiredDdCountry),
});

export const HomeAddressInitialValues = {
  StreetAddress: '',
  StreetAddress2: '',
  City: '',
  ZipCode: '',
  Country: '',
  StreetDistrict: '',
};
