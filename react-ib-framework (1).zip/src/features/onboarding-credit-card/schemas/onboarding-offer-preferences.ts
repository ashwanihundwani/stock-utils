import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingOfferpreferenceSchema = yup.object().shape({
  hearaboutmeem: yup
    .string()
    .required(Errors.OnboardingOfferPreferenceErrorRequiredDdHearAboutMeem),
  channel: yup
    .string()
    .required(Errors.OnboardingOfferPreferenceErrorRequiredDdChannel),
  code: yup
    .string()
    .required(Errors.OnboardingOfferPreferenceErrorRequiredDdChannel),
});

export const OnboardingOfferpreferenceInitialValues = {
  hearaboutmeem: '',
  channel: '',
  code: '',
};
