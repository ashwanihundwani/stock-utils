import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingIdVerificationSchema = yup.object().shape({
  nationalIdiqama: yup
    .string()
    .required(Errors.OnboardingIdVerificationErrorRequiredTxtNationalIdIqama)
    .matches(
      /^[12]\d{9}$/,
      Errors.OnboardingIdVerificationErrorInvalidTxtNationalIdIqama,
    ),
  phoneNumber: yup
    .string()
    .required(Errors.OnboardingIdVerificationErrorRequiredTxtPhoneNumber)
    .matches(
      /^5\d{8}$/,
      Errors.OnboardingIdVerificationErrorInvalidTxtPhoneNumber,
    ),
});

export const OnboardingIdverificationInitialValues = {
  nationalIdiqama: '',
  phoneNumber: '',
};
