import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const EnterNameSchema = yup.object().shape({
  firstName: yup
    .string()
    .required(Errors.OnboardingEnterNameErrorrequiredTxtFirstName),
  secondName: yup
    .string()
    .required(Errors.OnboardingEnterNameErrorrequiredTxtSecondName),
  thirdName: yup
    .string()
    .required(Errors.OnboardingEnterNameErrorrequiredTxtThirdName),
  familyName: yup
    .string()
    .required(Errors.OnboardingEnterNameErrorrequiredTxtFamilyName),
});

export const EnterNameInitialValues = {
  firstName: '',
  secondName: '',
  thirdName: '',
  familyName: '',
};
