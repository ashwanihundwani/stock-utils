import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingHousewifeSchema = yup.object().shape({
  sourceOfIncome: yup
    .string()
    .required(Errors.OnboardingHousewifeErrorrequiredDdSourceOfIncome),
  monthlyIncome: yup
    .string()
    .required(Errors.OnboardingHousewifeErrorrequiredDdMonthlyIncome),
  incomeDescription: yup
    .string()
    .required(Errors.OnboardingHousewifeErrorrequiredTxtIncomeDescription),
});

export const OnboardingHousewifeInitialValues = {
  sourceOfIncome: '',
  monthlyIncome: '',
  incomeDescription: '',
};
