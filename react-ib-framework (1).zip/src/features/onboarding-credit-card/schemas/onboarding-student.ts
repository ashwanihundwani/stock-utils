import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const OnboardingStudentSchema = yup.object().shape({
  universityName: yup
    .string()
    .required(Errors.OnboardingStudentErrorrequiredDdUniversityName),
  sourceOfIncome: yup
    .string()
    .required(Errors.OnboardingStudentErrorrequiredDdSourceOfIncome),
});

export const OnboardingStudentInitialValues = {
  universityName: '',
  sourceOfIncome: '',
};
