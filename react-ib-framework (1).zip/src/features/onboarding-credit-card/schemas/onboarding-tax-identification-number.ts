import {Errors} from 'constants/errors';
import * as yup from 'yup';

export const TaxIdentificationSchema = yup.object().shape({
  activeChip: yup.string().oneOf(['yes', 'no']).required(),

  ksaAddress: yup.string().when('activeChip', {
    is: 'yes',
    then: schema =>
      schema
        .matches(
          /^[a-zA-Z0-9]+$/,
          Errors.OnboardingTaxDeclarationIdentificationNumberErrorRequiredTxtIdentificationNumber,
        )
        .required(
          Errors.OnboardingTaxDeclarationIdentificationNumberErrorRequiredTxtIdentificationNumber,
        ),
    otherwise: schema => schema.notRequired(),
  }),

  selectedReason: yup.string().when('activeChip', {
    is: 'no',
    then: schema =>
      schema.required(
        Errors.OnboardingTaxDeclarationIdentificationErrorRequiredDdReason,
      ),
    otherwise: schema => schema.notRequired(),
  }),
});

export const TaxIdentificationInitialValues = {
  activeChip: 'yes',
  ksaAddress: '',
  selectedReason: '',
};
