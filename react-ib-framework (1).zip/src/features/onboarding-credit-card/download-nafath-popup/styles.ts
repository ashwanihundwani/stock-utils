import {Images} from 'constants/images';
import {Theme} from 'react-core';
export const getStyles = (theme: Theme) => {
  return {
    popupContainer: {
      display: 'flex',
      borderRadius: '8px',
      gap: '10px',
      width: '447px',
      flexDirection: 'column',
    },
    boxContainer: {
      height: '252px',
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: `url(${Images.nafath_img})`,
    },

    cancelIconStyle: {
      display: 'flex',
      justifyContent: 'flex-end',
      textAlign: 'right',
      mt: 3,
      mr: 1,
    },
    storeStyles: {
      width: '255px',
      height: 'fit-content',
      borderRadius: '8px',
      padding: '16px',
      gap: '24px',
      backgroundColor: theme.colors['background-04'],
      display: 'flex',
      position: 'absolute',
      top: '180px',
      left: '80px',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'row',
    },
    qrContainer: {
      padding: '24px',
      gap: '24px',
      display: 'flex',
      flexDirection: 'row',
    },
    qrLabelStyles: {
      display: 'flex',
      flexDirection: 'column',
      gap: '24px',
      justifyContent: 'space-between',
    },
  };
};
