import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useTranslation, useNewTheme} from 'react-core';
import {getStyles} from './styles';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {Box, SvgIcon} from '@mui/material';
import {ModalTypeProps} from '../terms-n-condition/types';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {Qr} from 'assets/svg/qr';
import {AppStore} from 'assets/svg/app-store';
import {PlayStore} from 'assets/svg/play-store';
const DownloadNafathPopUP: FC<ModalTypeProps> = ({modalClose}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);

  const {t} = useTranslation();

  return (
    <Grid container columns={4} sx={styles.popupContainer}>
      <Box sx={styles.boxContainer}>
        <Box sx={styles.cancelIconStyle}>
          <SvgIcon onClick={modalClose}>
            <DeleteIcon />
          </SvgIcon>
        </Box>

        <Box sx={styles.storeStyles}>
          <AppStore />
          <PlayStore />
        </Box>
      </Box>

      <Box sx={styles.qrContainer}>
        <Box>
          <Qr />
        </Box>
        <Box sx={styles.qrLabelStyles}>
          <CustomLabel
            id="lblTitle"
            variant={variants.titleS}
            text={t('OnboardingDebitCardQRLblTitleWeb')}
          />
          <CustomLabel
            id="lblTitle"
            variant={variants.bodyRegularS}
            text={t('OnboardingDebitCardQRLblSubTitleWeb')}
          />
        </Box>
      </Box>
    </Grid>
  );
};

export {DownloadNafathPopUP};
