import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import {Box} from '@mui/material';
import {getStyles} from '../styles';
import {useNewTheme, useTranslation} from 'react-core';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import OptionButton from 'components/option-button';
import {OptionButtonData} from 'components/option-button/types';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import Link from 'components/link';
import {LinkSize, LinkType} from 'components/link/types';

const NoOfDependents: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();
  const navigate = useNavigate();
  const [selectedValue, setSelectedValue] = useState<OptionButtonData | null>(
    null,
  );

  const handleButtonClick = (item: OptionButtonData) => {
    setSelectedValue(item);
    navigate(AppPath.educationLevel);
  };
  const data = [
    {id: '1', name: t('OnboardingDependantsBtn1')},
    {id: '2', name: t('OnboardingDependantsBtn2')},
    {id: '3', name: t('OnboardingDependantsBtn3')},
    {id: '4', name: t('OnboardingDependantsBtn4')},
    {id: '5', name: t('OnboardingDependantsBtn5')},
  ];
  return (
    <Grid container columns={7} size={7} sx={styles.outerGrid}>
      <Box>
        <Link
          size={LinkSize.Large}
          linkText={t('OnboardingBackLblTitleWeb')}
          showIcon
          type={LinkType.Secondary}
        />
      </Box>
      <Grid size={7} sx={styles.tellAboutlblStyle}>
        <CustomLabel
          id="idEmploymentStatus"
          variant={variants.titleXL}
          text={t('OnboardingDependantsLblTitle')}
        />
        <Box sx={styles.tellAboutlblStyle}>
          <CustomLabel
            id="idEmploymentStatus"
            variant={variants.bodyRegularM}
            text={t('OnboardingDependantsLblSubtitle')}
          />
        </Box>
      </Grid>
      <Grid size={4} sx={styles.optionBtnContainerStyle}>
        <OptionButton
          options={data}
          value={selectedValue}
          onSelected={handleButtonClick}
          optBtnBgWhite
        />
      </Grid>
    </Grid>
  );
};

export {NoOfDependents};
