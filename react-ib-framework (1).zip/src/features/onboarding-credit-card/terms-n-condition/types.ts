export interface ModalTypeProps {
  modalClose?: () => void;
}
