export const getStyles = () => {
  return {
    tc_Container: {
      display: 'flex',
      borderRadius: '8px',
      gap: '1.5rem',
      padding: '1.2rem',
      flexDirection: 'column',
    },
    titleContainer: {
      // gap: '.5rem',
      // padding: '1rem',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    urlContent: {
      width: '100%',
      height: '250px',
    },
    buttonContainer: {
      display: 'flex',
      justifyContent: 'center',
      backgroundColor: 'yellow',
      padding: '10px',
      width: '100%',
      height: '100%',
    },
    checkboxContainer: {
      display: 'flex',
      flexDirection: 'row',
      mt: 2,
    },
    checkboxTitleStyle: {
      display: 'flex',
      alignItems: 'center',
    },
    button: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      paddingTop: '16px',
      gap: '1rem',
    },
    cancelIconStyle: {
      // textAlign: 'right',
      display: 'flex',
      justifyContent: 'flex-end',
    },
  };
};
