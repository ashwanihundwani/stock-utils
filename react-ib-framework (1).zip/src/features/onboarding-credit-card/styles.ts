import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme) => {
  return {
    outerGrid: {
      display: 'flex',
      flexDirection: 'column',
    },
    backNavGrid: {
      display: 'flex',
      flexDirection: 'column',
    },
    rowStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
    },
    tellAboutlblStyle: {
      mt: 1,
      // overflow: 'hidden',
    },

    backLblstyle: {
      width: '2.2rem',
      height: '1.5rem',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    optionBtnContainerStyle: {
      mt: 2,
    },

    inputStyles: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      marginTop: '10px',
    },
    nextBtnStyle: {width: '100px', mt: 2},
    listGrid: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1.5rem',
      mt: 3,
    },
    listrow: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1rem',
    },
    button: {
      mt: 4,
    },
    sharedTrustedInputStyles: {
      '& .MuiFilledInput-root': {
        backgroundColor: theme.colors['surface-01'],
        width: '393px',
        borderRadius: '10px',
        '&.Mui-focused, &:hover': {
          fontSize: '0.87rem',
          fontWeight: 'normal',
          fontFamily: fonts.figtree_regular,
          color: theme.colors['content-primary'],
          backgroundColor: theme.colors['surface-01'],
        },
      },
      '& input': {
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '10px',
        fontSize: '0.87rem',
        width: '100%',
        fontFamily: fonts.figtree_regular,
        color: theme.colors['content-primary'],
        margin: '5px 10px 2px',
        height: '23px',
      },
    },

    defaultContainer: {
      display: 'flex',
      justifyContent: 'center',
      width: '60.87rem',
    },
    title: {
      fontFamily: fonts.regular,
      fontSize: '1.25rem',
      fontWeight: '600',
      color: theme.colors['content-primary'],
      paddingBottom: '16px',
    },
    textBoxStyle: {
      display: 'flex',
      flexDirection: 'column',
      mt: 2,
    },
    subtitle: {
      fontFamily: fonts.regular,
      fontSize: '0.87rem',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
      width: '31.87rem',
      paddingBottom: '16px',
    },
    validationBox: {
      display: 'flex',
      alignItems: 'center',
      paddingTop: '4px',
      gap: '4px',
    },
    validationLabel: {
      fontFamily: fonts.regular,
      fontSize: '0.87rem',
      fontWeight: '400',
      color: theme.colors['content-secondary'],
    },
    usernameBox: {
      display: 'grid',
    },
    backNavigationBox: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.5rem',
      paddingBottom: '8px',
    },
    backNavigation: {
      fontFamily: fonts.regular,
      fontSize: '16px',
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
    },
    crendentialStyle: {
      flexDirection: 'row',
      gap: '24px',
      display: 'flex',
      mt: '2',
      paddingTop: '1.25rem',
    },
    tickIconGreenStyle: {
      borderRadius: '999px',
      width: '16px',
      height: '16px',
      backgroundColor: theme.colors['surface-semantic-success-02'],
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
    },
    tickIconRedStyle: {
      borderRadius: '999px',
      width: '16px',
      height: '16px',
      backgroundColor: theme.colors['surface-semantic-error-02'],
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
    },
    tickIconWhitetyle: {
      borderRadius: '999px',
      width: '16px',
      height: '16px',
      backgroundColor: theme.colors['surface-01'],
      alignItems: 'center',
      display: 'flex',
      justifyContent: 'center',
    },
    passwordContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
    userNameContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '16px',
    },

    credentialStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
    dropdown: {
      background: theme.colors['surface-01'],
      // width: '393px',
      // mr: 6,
    },
    labelStyle: {
      fontFamily: fonts.figtree_regular,
      color: theme.colors['content-secondary'],
    },
    checkBoxAcceptGrid: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1px',
    },
    checkboxLabel: {
      display: 'flex',
      flexDirection: 'row',
      gap: '5px',
      margin: '2px',
    },
    textArea: {
      width: '100%',
      gap: '0.5rem',
      mt: 2,

      backgroundColor: theme.colors['surface-01'],
      borderRadius: '10px',
      '&:hover': {
        // borderColor: theme.colors['border-focus'],
        backgroundColor: theme.colors['surface-01'],
      },
      '& .MuiFilledInput-root': {
        border: '1px solid transparent',
        borderRadius: '10px',
        mt: 6,

        fontFamily: fonts.regular,
        backgroundColor: theme.colors['surface-01'],
        color: theme.colors['content-primary'],
        height: '192px',
        alignItems: 'flex-end',
        paddingTop: '12px',
        paddingLeft: '16px',
        marginTop: '3px',
        '&:hover': {
          // borderColor: theme.colors['border-focus'],
          backgroundColor: theme.colors['surface-01'],
        },
        '&.Mui-focused': {
          backgroundColor: theme.colors['surface-01'],
        },
        '& label': {
          margin: '5px 10px 8px',
          fontSize: '0.87rem',
          fontFamily: fonts.regular,
          fontWeight: 'normal',
          // width: '100%',
          minWidth: '100%',
          whiteSpace: 'normal',
          overflow: 'visible',

          display: 'block',
          color: theme.colors['content-secondary'],
          transform: 'Titlecase',
          '&.Mui-focused': {
            fontSize: '0.87rem',
            fontWeight: 'normal',
            backgroundColor: 'violet',

            fontFamily: fonts.regular,
            color: theme.colors['content-primary'],
          },
        },
      },
    },
  };
};
