import {fonts} from 'utils/typography';
import {Theme} from 'react-core';
export const getStyles = (theme: Theme) => {
  return {
    backNavGrid: {
      display: 'flex',
    },
    gridContainer: {
      backgroundColor: theme.colors['background-02'],
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
    },
    gridChildStyle: {
      marginTop: '1rem',
      display: 'flex',
      flexDirection: 'column',
    },
    cardContainerType: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1.5rem',
      paddingTop: '24px',
      width: '100%',
    },

    meemCardStyle: {
      display: 'flex',
      gap: '1.5rem',
      padding: '1.5rem',
      flexDirection: 'row',
      borderRadius: '.5rem',
      backgroundColor: theme.colors['surface-01'],
      flex: 1,
    },
    cardImageStyle: {height: '145px', width: '90px'},
    cardLabelStyles: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.25rem',
    },

    meemCardLabelStyle: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      position: 'relative',
    },
    btnBottomStyles: {
      display: 'flex',
      flexDirection: 'column',
      position: 'absolute',
      marginBottom: 'auto',
      bottom: 0,
      gap: '1.5rem',
    },
    backNavigation: {
      fontFamily: fonts.regular,
      fontWeight: '600',
      color: theme.colors['content-interactive-secondary-enabled'],
      fontSize: '16px',
      paddingLeft: '8px',
    },
    ourCreditCardGrid: {
      paddingTop: '16px',
    },

    lblContentStyle: {
      flexGrow: 1,
    },
    creditCardStyle: {
      width: '70px',
      height: '50px',
      alignItem: 'center',
      justifyContent: 'center',
    },
    cardDetailstextStyle: {
      color: theme.colors['content-secondary'],
      width: '258px',
      height: '60px',
      gap: '20px',
    },

    listDataStyle: {
      width: '100%',
      color: theme.colors['content-secondary'],
    },

    dropdownStyle: {
      width: '290px',
      minHeight: '64px',
      backgroundColor:
        theme.colors['surface-interactive-primary-inverted-enabled'],
    },
    placeholderStyle: {
      marginTop: '5px',
      width: '218px',
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      '&.Mui-focused': {
        fontSize: '12px',
        marginLeft: '2px',
        marginTop: '18px',
        width: '218px',

        color: theme.colors['content-secondary'],
      },
      '&.MuiFormLabel-filled': {
        fontSize: '12px',
        marginLeft: '2px',
        width: '218px',

        marginTop: '18px',
        color: theme.colors['content-secondary'],
      },
    },

    comparecardlblStyle: {
      gap: '20px',
      paddingTop: '15px',
      paddingBottom: '15px',
    },
    gridCompareStyle: {
      display: 'flex',
      flexDirection: 'row',
      gap: '14px',
    },
    cardDetailsSTyle: {
      width: '290px',
      minHeight: '660px',
      gap: '1rem',
    },
    dropdwonBoxStyle: {
      width: '290px',
      minHeight: '660px',
      gap: '1rem',
    },

    beloDropDownBoxStyle: {
      width: '290px',
      height: '580px',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'column',
      marginTop: '16px',
      marginBottom: '16px',
      paddingTop: '16px',
      backgroundColor: 'white',
    },
    cardTypeDetaikStyle: {
      width: '290px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      minHeight: '172px',
      gap: '20px',
    },
    cardDetailLblStyle: {
      width: '258px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      minHeight: '24px',
      gap: '8px',
    },
    cardListConatinerStyle: {
      width: '258px',
      minHeight: '344px',
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'column',
      marginTop: '16px',
      marginBottom: '16px',
      gap: '1rem',
    },
    cardDetailContainerStyle: {
      display: 'flex',
      flexDirection: 'row',
      width: '258px',
      minHeight: '64px',
      gap: '8px',
    },
    checkMarkIconStyle: {height: '32px', width: '32px'},
    titleAndValueListStyle: {
      display: 'flex',
      flexDirection: 'column',
      width: '230px',
    },
  };
};
