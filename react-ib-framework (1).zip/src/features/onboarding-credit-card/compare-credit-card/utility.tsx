import {CheckmarkCircle} from 'assets/svg/checkmark-circle-04';

// note bank name has been changed to value and name has been changed to label
const creditCards = [
  {
    id: '1',
    value: 'Chase',
    label: 'Platinium',
  },
  {
    id: '2',
    value: 'Chase',
    label: 'Signature',
  },
  {
    id: '3',
    value: 'Amex',
    label: 'AL Nasar card',
  },
  {
    id: '4',
    value: 'Amex',
    label: 'meem credit card',
  },
];

const data = [
  {
    id: '1',
    title: 'Rewards',
    icon: <CheckmarkCircle></CheckmarkCircle>,
    leftCardValue:
      'Earns 1 point per SAR 1 spent domestically and 1.5 points internationally.',
  },
  {
    id: '2',
    title: 'Access \u0026 Benefits',
    icon: <CheckmarkCircle></CheckmarkCircle>,

    leftCardValue:
      'Includes access to 25 airport lounges worldwide. Includes access to 25 airport lounges worldwide.',
  },
  {
    id: '3',
    title: 'Flexibility',
    icon: <CheckmarkCircle></CheckmarkCircle>,

    leftCardValue:
      'Offers flexible installment plans through the As’hal program.',
  },
  {
    id: '4',
    title: 'Perfect fit',
    icon: <CheckmarkCircle></CheckmarkCircle>,

    leftCardValue:
      'Ideal for customers seeking simplicity and essential benefits.',
  },
];

export {data, creditCards};
