import {FC, useState} from 'react';
import Grid from '@mui/material/Grid2';
import Dropdown from 'components/select-dropdown';
import {creditCards, data} from './utility';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {Box} from '@mui/material';
import {Images} from 'constants/images';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';

const CompareCreditCardDropdown: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [creditCardType, setcreditCardType] = useState('');

  return (
    <Grid>
      <Box sx={styles.dropdwonBoxStyle}>
        <Dropdown
          id="select-dropdown"
          labelId="select-dropdown-lable"
          placeholder={'credit card'}
          options={creditCards}
          customstyle={styles.dropdownStyle}
          labelstyle={styles.placeholderStyle}
          value={creditCardType}
          setValue={setcreditCardType}
          disabled={false}
        />
        <Box sx={styles.beloDropDownBoxStyle}>
          <Box sx={styles.cardTypeDetaikStyle}>
            <img
              src={
                creditCardType && creditCardType === 'Platinium'
                  ? Images.platinum_card
                  : creditCardType === 'Signature'
                    ? Images.signature_card
                    : creditCardType === 'AL Nasar card'
                      ? Images.al_nasar_card
                      : Images.platinum_card
              }
              alt="meem_login_logo"
              style={styles.creditCardStyle}></img>

            <Box sx={styles.cardDetailLblStyle}>
              <CustomLabel
                id="idCardName"
                variant={variants.titleS}
                text={creditCardType}
              />
              <CustomLabel
                id="idCardDetail"
                style={styles.cardDetailstextStyle}
                variant={variants.bodyRegularS}
                text={
                  'A card with no hidden fees, instant rewards and attractive installment program'
                }
              />
            </Box>
          </Box>

          <Box sx={styles.cardListConatinerStyle}>
            {data?.map((value, index) => {
              return (
                <Box key={index} sx={styles.cardDetailContainerStyle}>
                  <Box sx={styles.checkMarkIconStyle}>{value.icon}</Box>
                  <Box sx={styles.titleAndValueListStyle}>
                    <CustomLabel
                      id="idCardDetail"
                      style={styles.listDataStyle}
                      variant={variants.bodySemiBoldS}
                      text={value.title}
                    />
                    <CustomLabel
                      id="idCardDetail"
                      style={styles.listDataStyle}
                      variant={variants.bodyRegularS}
                      text={value.leftCardValue}
                    />
                  </Box>
                </Box>
              );
            })}
          </Box>
        </Box>
      </Box>
    </Grid>
  );
};
export default CompareCreditCardDropdown;
