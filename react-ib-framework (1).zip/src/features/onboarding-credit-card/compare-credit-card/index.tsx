import {FC} from 'react';
import Grid from '@mui/material/Grid2';
import {useNewTheme, translation} from 'react-core';
import {getStyles} from './styles';

import {Box} from '@mui/material';
import {MeemCreditCardIcon} from 'assets/svg/meem-credit-card-icon';
import Button from 'components/button';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {AlNaseerCreditCardIcon} from 'assets/svg/al-naseer-credit-card-icon';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import CompareCreditCardDropdown from './compareCreditCardDropdown';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import Header from 'features/onboarding-cc/view/common/header';
import {Link} from 'components';
import {LinkSize, LinkType} from 'components/link/types';

// Header to be implemented
const CompareCreditCard: FC = () => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = translation.useTranslation();
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate(AppPath.BeforeWeBegin);
  };

  return (
    <>
      <Header />
      <Grid container columns={12} sx={styles.gridContainer}>
        <Grid container columns={8} size={8} sx={styles.gridChildStyle}>
          <Box sx={styles.backNavGrid}>
            <Link
              size={LinkSize.Large}
              linkText={t('OnboardingBackLblTitleWeb')}
              showIcon
              type={LinkType.Secondary}
            />
          </Box>
          <Box sx={styles.ourCreditCardGrid}>
            <CustomLabel
              id="lblTitle"
              variant={variants.titleXL}
              text={t('OnboardingOurCreditCardLblTitle')}
            />

            <CustomLabel
              id="lblSubTite"
              variant={variants.bodyRegularM}
              text={t('OnboardingOurCreditCardLblSubtitle')}
            />
          </Box>
          <Box sx={styles.cardContainerType}>
            <Box sx={styles.meemCardStyle}>
              <Box sx={styles.cardImageStyle}>
                <MeemCreditCardIcon />
              </Box>
              <Box sx={styles.meemCardLabelStyle}>
                <Box sx={styles.cardLabelStyles}>
                  <CustomLabel
                    id="lblMeemCcTitle"
                    variant={variants.bodyMediumL}
                    text={t('OnboardingOurCreditCardLblMeemCcTitle')}
                  />
                  <Box sx={styles.lblContentStyle}>
                    <CustomLabel
                      id="lblSubtitle"
                      variant={variants.bodyRegularS}
                      text={t('OnboardingOurCreditCardLblMeemCcSubtitle')}
                    />
                  </Box>
                </Box>

                <Box sx={styles.btnBottomStyles}>
                  <Button
                    variant={ButtonStyle.Primary}
                    size={ButtonSize.Small}
                    type={ButtonType.Text}
                    text={t('OnboardingOurCreditCardBtnApplyForMeemLblText')}
                    onClick={handleSubmit}></Button>
                </Box>
              </Box>
            </Box>
            <Box sx={styles.meemCardStyle}>
              <Box sx={styles.cardImageStyle}>
                <AlNaseerCreditCardIcon />
              </Box>
              <Box sx={styles.meemCardLabelStyle}>
                <Box sx={styles.cardLabelStyles}>
                  <CustomLabel
                    id="lblMeemCcTitle"
                    variant={variants.titleS}
                    text={t('OnboardingOurCreditCardLblNassrCctTitle')}
                  />
                  <Box sx={styles.lblContentStyle}>
                    <CustomLabel
                      id="lblSubtitle"
                      variant={variants.bodyRegularS}
                      text={t('OnboardingOurCreditCardLblNassrCctSubtitle')}
                    />
                  </Box>
                </Box>
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-end',
                  }}>
                  <Button
                    variant={ButtonStyle.Primary}
                    size={ButtonSize.Small}
                    type={ButtonType.Text}
                    text={t('OnboardingOurCreditCardBtnApplyForNassrLblText')}
                    onClick={handleSubmit}></Button>
                </Box>
              </Box>
            </Box>
          </Box>

          <Box sx={styles.comparecardlblStyle}>
            <CustomLabel
              id="lblTitle"
              variant={variants.titleM}
              text={t('OnboardingCompareCreditCardLblTitle')}
            />
          </Box>

          <Grid size={12} container sx={styles.gridCompareStyle}>
            <Box sx={styles.cardDetailsSTyle}>
              <CompareCreditCardDropdown />
            </Box>
            <Box sx={styles.cardDetailsSTyle}>
              <CompareCreditCardDropdown />
            </Box>
            <Box sx={styles.cardDetailsSTyle}>
              <CompareCreditCardDropdown />
            </Box>{' '}
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default CompareCreditCard;
