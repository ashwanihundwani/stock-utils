import {lazy} from 'react';

export const DashboardWrapper = lazy(() => import('./dashboard-wrapper'));
