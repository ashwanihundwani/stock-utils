import {DashboardWrapperStyleProps} from './types';

export const getStyles = (props: DashboardWrapperStyleProps) => {
  const {theme} = props;
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
    },
    topBarContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      height: 'fit-content',
      borderBottom: `0.063rem solid ${theme.colors['border-enabled-01']}`,
      backgroundColor: theme.colors['surface-01'],
      padding: '1rem 1.5rem',
    },
    logoMenuContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '2rem',
      alignItems: 'center',
    },
    menuContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.25rem',
    },
    menuLabel: {
      padding: '0 1rem',
      color: theme.colors['content-interactive-secondary-enabled'],
      cursor: 'pointer',
    },
    actionContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      alignItems: 'center',
      gap: '1.5rem',
    },
    outletContainer: {
      flex: 1,
    },
    translateContainer: {
      display: 'flex',
      gap: '0.5rem',
      cursor: 'pointer',
    },
    translateLabel: {
      color: theme.colors['content-interactive-secondary-enabled'],
    },
  };
};
