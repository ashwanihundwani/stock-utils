import {Box, Grid2} from '@mui/material';
import {Outlet} from 'react-router-dom';
import {getStyles} from './styles';
import {useNewTheme, useTranslation} from 'react-core';
import {CustomLabel, Avatar} from 'components';
import {variants} from 'components/custom-label/types';
import {
  CustomerSupport,
  Search,
  Notification02,
  Meem,
  LanguageSkill,
} from 'assets/svg';

const DashboardWrapper = () => {
  const theme = useNewTheme();
  const {t: translate} = useTranslation();
  const styles = getStyles({theme});

  const menus = [
    {id: 1, name: 'CommonDashboardWrapperLblHomeWeb'},
    {id: 2, name: 'CommonDashboardWrapperLblAccountsWeb'},
    {id: 3, name: 'CommonDashboardWrapperLblCardsWeb'},
    {id: 4, name: 'CommonDashboardWrapperLblTransfersweb'},
    {id: 5, name: 'CommonDashboardWrapperLblSadadWeb'},
    {id: 5, name: 'CommonDashboardWrapperLblFinanceWeb'},
    {id: 5, name: 'CommonDashboardWrapperLblDepositsWeb'},
  ];

  const actions = [
    {
      id: 1,
      icon: (
        <CustomerSupport
          size="20"
          color={theme.colors['icon-interactive-secondary-enabled']}
        />
      ),
    },
    {
      id: 2,
      icon: (
        <Search
          size="20"
          color={theme.colors['icon-interactive-secondary-enabled']}
        />
      ),
    },
    {
      id: 3,
      icon: (
        <Notification02
          size="20"
          color={theme.colors['icon-interactive-secondary-enabled']}
        />
      ),
    },
  ];

  return (
    <Box sx={styles.container}>
      <Grid2 container sx={styles.topBarContainer}>
        <Grid2 size={6} sx={styles.logoMenuContainer}>
          <Box>
            <Meem />
          </Box>
          <Box sx={styles.menuContainer}>
            {menus.map(item => {
              return (
                <CustomLabel
                  id={item.name}
                  key={item.id}
                  text={translate(item.name)}
                  variant={variants.bodyMediumS}
                  style={styles.menuLabel}
                />
              );
            })}
          </Box>
        </Grid2>

        <Grid2 size={3} sx={styles.actionContainer}>
          <Box sx={styles.translateContainer}>
            <LanguageSkill />
            <CustomLabel
              id={'translate-label'}
              text={'عربي'}
              variant={variants.bodySemiBoldS}
              style={styles.translateLabel}
            />
          </Box>
          {actions.map(item => {
            return item.icon;
          })}
          <Avatar
            size={'Xs'}
            type={'empty'}
            initial="Z"
            onlyIcon
            itemType="flag"
          />
        </Grid2>
      </Grid2>
      <Grid2 size={12} sx={styles.outletContainer}>
        <Outlet />
      </Grid2>
    </Box>
  );
};

export default DashboardWrapper;
