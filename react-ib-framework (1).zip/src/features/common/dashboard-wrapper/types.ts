import {Theme} from 'react-core';

export type DashboardWrapperStyleProps = {
  theme: Theme;
};
