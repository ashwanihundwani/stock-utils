import {IconProps} from 'constants/types';
import {FC} from 'react';

const Search: FC<IconProps> = props => {
  const {size = 20, color = '#7D7495'} = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 20 20"
      fill="none">
      <g clipPath="url(#clip0_5859_19779)">
        <path
          d="M14.5834 14.5859L18.3334 18.3359"
          stroke={color}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M16.6667 9.16797C16.6667 5.02583 13.3089 1.66797 9.16675 1.66797C5.02461 1.66797 1.66675 5.02583 1.66675 9.16797C1.66675 13.3101 5.02461 16.668 9.16675 16.668C13.3089 16.668 16.6667 13.3101 16.6667 9.16797Z"
          stroke={color}
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_5859_19779">
          <rect width="20" height="20" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export {Search};
