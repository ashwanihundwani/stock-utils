export function InfoIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M18.3333 9.99992C18.3333 5.39754 14.6023 1.66658 9.99996 1.66658C5.39759 1.66658 1.66663 5.39754 1.66663 9.99992C1.66663 14.6023 5.39759 18.3333 9.99996 18.3333C14.6023 18.3333 18.3333 14.6023 18.3333 9.99992Z"
        stroke="#45A1B7"
        strokeWidth="1.5"
      />
      <path
        d="M10.2017 14.1666V9.99996C10.2017 9.60712 10.2017 9.4107 10.0797 9.28866C9.95766 9.16663 9.76125 9.16663 9.36841 9.16663"
        stroke="#45A1B7"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M9.99325 6.66663H10.0007"
        stroke="#45A1B7"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function SuccessIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_7403_9134)">
        <path
          d="M18.3333 9.99998C18.3333 5.39761 14.6023 1.66665 9.99996 1.66665C5.39759 1.66665 1.66663 5.39761 1.66663 9.99998C1.66663 14.6024 5.39759 18.3333 9.99996 18.3333C14.6023 18.3333 18.3333 14.6024 18.3333 9.99998Z"
          stroke="#2CA85A"
          strokeWidth="1.5"
        />
        <path
          d="M6.66663 10.625C6.66663 10.625 7.99996 11.3854 8.66663 12.5C8.66663 12.5 10.6666 8.12499 13.3333 6.66666"
          stroke="#2CA85A"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_7403_9134">
          <rect width="20" height="20" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}

export function WarningIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M4.43472 8.06902C6.44611 4.50991 7.45181 2.73035 8.83184 2.27226C9.59105 2.02025 10.4089 2.02025 11.1681 2.27226C12.5481 2.73035 13.5538 4.50991 15.5652 8.06902C17.5766 11.6281 18.5823 13.4077 18.2806 14.8577C18.1146 15.6554 17.7057 16.379 17.1125 16.9247C16.0342 17.9166 14.0228 17.9166 9.99996 17.9166C5.97717 17.9166 3.96577 17.9166 2.88743 16.9247C2.29419 16.379 1.88528 15.6554 1.71931 14.8577C1.41762 13.4077 2.42332 11.6281 4.43472 8.06902Z"
        stroke="#D47F02"
        strokeWidth="1.5"
      />
      <path
        d="M9.99325 13.3333H10.0007"
        stroke="#D47F02"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10 10.8333L10 7.49992"
        stroke="#D47F02"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function ErrorIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <circle
        cx="9.99996"
        cy="9.99996"
        r="8.33333"
        stroke="#FF3939"
        strokeWidth="1.5"
      />
      <path
        d="M9.99325 12.5H10.0007"
        stroke="#FF3939"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10 10L10 6.66667"
        stroke="#FF3939"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
