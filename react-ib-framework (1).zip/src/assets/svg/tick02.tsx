import {FC} from 'react';
import {IconProps} from '../../constants/types';
const Tick02: FC<IconProps> = ({size = '24', color = '#19074A'}) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 12 12"
      fill="none">
      <path
        d="M2.5 7L4.25 8.75L9.5 3.25"
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export {Tick02};
