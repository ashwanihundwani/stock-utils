import {FC} from 'react';
import {IconProps} from '../../constants/types';

const IconTick02: FC<IconProps> = ({size = '15', color = '#FFFFFF'}) => {
  return (
    <svg width={size} height={size} viewBox="0 0 17 16" fill="none">
      <path
        d="M3.83301 9.33337L6.16634 11.6667L13.1663 4.33337"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export {IconTick02};
