import {IconProps} from 'constants/types';
import {FC} from 'react';

const Notification02: FC<IconProps> = props => {
  const {size = 20, color = '#7D7495'} = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      fill="none"
      viewBox="0 0 20 20"
      {...props}>
      <path
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M2.108 12.31c-.177 1.161.615 1.967 1.585 2.37 3.72 1.54 8.895 1.54 12.614 0 .97-.403 1.762-1.209 1.585-2.37-.11-.715-.648-1.31-1.047-1.89-.522-.77-.574-1.609-.574-2.502 0-3.452-2.808-6.25-6.271-6.25s-6.27 2.798-6.27 6.25c0 .893-.053 1.733-.575 2.502-.4.58-.938 1.175-1.047 1.89Z"
      />
      <path
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={1.5}
        d="M6.667 15.836c.382 1.438 1.73 2.5 3.333 2.5 1.604 0 2.951-1.062 3.333-2.5"
      />
    </svg>
  );
};
export {Notification02};
