export function HelperIcon({color = ''}: Readonly<{color?: string}>) {
  return (
    <svg
      width="12"
      height="16"
      viewBox="0 0 12 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_5628_17506)">
        <circle cx="6" cy="8" r="5" stroke={color} />
        <path
          d="M5.996 9.5H6.00049"
          stroke={color}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M6 8L6 6"
          stroke={color}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_5628_17506">
          <rect
            width="12"
            height="12"
            fill="white"
            transform="translate(0 2)"
          />
        </clipPath>
      </defs>
    </svg>
  );
}
