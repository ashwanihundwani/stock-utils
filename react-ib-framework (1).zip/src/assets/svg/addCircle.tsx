export function AddCircle() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_4723_29254)">
        <path
          d="M10.0013 6.66675V13.3334M13.3346 10.0001L6.66797 10.0001"
          stroke="#6A1CCD"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M18.3346 10.0002C18.3346 5.39779 14.6037 1.66683 10.0013 1.66683C5.39893 1.66683 1.66797 5.39779 1.66797 10.0002C1.66797 14.6025 5.39893 18.3335 10.0013 18.3335C14.6037 18.3335 18.3346 14.6025 18.3346 10.0002Z"
          stroke="#6A1CCD"
          strokeWidth="1.5"
        />
      </g>
      <defs>
        <clipPath id="clip0_4723_29254">
          <rect width="20" height="20" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}
