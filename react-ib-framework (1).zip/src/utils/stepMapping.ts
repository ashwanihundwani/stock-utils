import {AppPath} from 'constants/path';

const stepMapping: Record<string, number> = {
  [AppPath.BeforeWeBegin]: -1,
  [AppPath.employmentStatus]: 0,
  [AppPath.IdOtp]: 0,
  [AppPath.Nafath]: 0,
  [AppPath.EmailScreen]: 0,
  [AppPath.firstNameTitle]: 1,
  [AppPath.maritalStatus]: 1,
  [AppPath.noOfDependents]: 1,
  [AppPath.educationLevel]: 1,
  [AppPath.housingLevel]: 1,
  [AppPath.purposeOfAccount]: 1,
  [AppPath.MoneyTransfer]: 1,
  [AppPath.MonthlyDeposits]: 1,
  [AppPath.MonthlyWithdraw]: 1,
  [AppPath.MonthlyExpenses]: 1,
  [AppPath.EmploymentDetails]: 2,
  [AppPath.SalaryDetails]: 3,
  [AppPath.MonthlySalary]: 3,
  [AppPath.additionalIncome]: 3,
  [AppPath.SourceOfAdditionalIncome]: 3,
  [AppPath.TellUsAboutAdditionalIncome]: 3,
  [AppPath.shareTrustedDetails]: 3,
  [AppPath.taxResident]: 3,
  [AppPath.boardMember]: 3,
  [AppPath.politicalyExposed]: 3,
  [AppPath.politicalyExposedRelative]: 4,
  [AppPath.disabilities]: 4,
  [AppPath.GetLatestUpdates]: 5,
  [AppPath.onboardingCreateUsername]: 5,
  [AppPath.onboardingcreatePassword]: 5,
};

export const getActiveStep = (path: string): number => {
  return stepMapping[path] ?? 0;
};
