type value = string | undefined;

export const NULL = (value: value) => {
  console.log('value', value);
  return value === null;
};

export const UNDEFINED = (value: value) => {
  console.log('value', value);
  return value === undefined;
};

export const VALIDATEPHONENUMBER = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^[7-9]\d{9}$/.test(value);
};

export const MINLENEIGHT = (value: value) => {
  if (value === undefined) return false;
  else if (`${value}`.length >= 8) return true;
  return false;
};

export const MINLENTWELVE = (value: value) => {
  if (value === undefined) return false;
  else if (`${value}`.length >= 12) return true;
  return false;
};

export const MAXLENTWENTY = (value: value) => {
  if (value === undefined) return false;
  else if (`${value}`.length <= 20 && `${value}`.length >= 8) return true;
  return false;
};

export const VALIDATEPASSWORD = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[ !"#$%&?A-Za-z])[\d!#$%&?A-Za-z]{8,20}$/.test(
    value,
  );
};

export const ONELOWERCASE = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^(?=.*[a-z])/.test(value);
};

export const ONEUPPERCASE = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^(?=.*[A-Z])/.test(value);
};

export const ONEDIGIT = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^(?=.*\d)/.test(value);
};

export const ONESPECIALCHAR = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^(?=.*?[!#$%&*?@^-])/.test(value);
};

export const MINMAXLENGTH = (value: value) => {
  if (value === undefined) {
    return false;
  }
  return /^^.{8,20}$/.test(value);
};
