import {ENCRYPTION_KEY} from 'config';
import CryptoJS from 'crypto-js';

// Define `ENCRYPTION_KEY` as a string type for stricter type checking
const secretKey: string = ENCRYPTION_KEY;

export const appEncryption = {
  encrypt: (originalValue: string | object): string => {
    const valueToEncrypt =
      typeof originalValue === 'object'
        ? JSON.stringify(originalValue)
        : originalValue;
    return CryptoJS.AES.encrypt(valueToEncrypt, secretKey).toString();
  },

  decrypt: (encryptedValue: string): string | object => {
    const bytes = CryptoJS.AES.decrypt(encryptedValue, secretKey);
    const decryptedValue = bytes.toString(CryptoJS.enc.Utf8);
    try {
      return JSON.parse(decryptedValue); // Parse JSON if possible
    } catch {
      return decryptedValue; // Return as string if not JSON
    }
  },
};
