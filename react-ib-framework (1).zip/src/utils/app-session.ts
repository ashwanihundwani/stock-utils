const AppSession = {
  getData: (sessionName: string) => {
    try {
      sessionStorage.getItem(sessionName);
    } catch (error) {
      console.log(error);
    }
  },
  setData: (sessionName: string, sessionValue: string) => {
    try {
      sessionStorage.setItem(sessionName, sessionValue);
    } catch (error) {
      console.log(error);
    }
  },
  removeData: (sessionName: string) => {
    try {
      sessionStorage.removeItem(sessionName);
    } catch (error) {
      console.log(error);
    }
  },
};

export {AppSession};
