import Cookies from 'js-cookie';

export const AppCookie = {
  setCookie: (cookieName: string, cookieValue: string | object) => {
    const value =
      typeof cookieValue === 'object'
        ? JSON.stringify(cookieValue)
        : cookieValue;
    Cookies.set(cookieName, value, {expires: 1}); // Expiry in 1 day
  },
  getCookie: (cookieName: string): string | undefined => {
    const value = Cookies.get(cookieName);
    try {
      return value ? JSON.parse(value) : undefined; // Attempt to parse as JSON
    } catch {
      return value; // Return as string if not JSON
    }
  },
  clearCookie: (cookieName: string): void => {
    Cookies.remove(cookieName);
  },
};
