export const setCardType = (cardType: 'debit' | 'credit') => {
  localStorage.setItem('cardType', cardType);
};

export const getCardType = (): 'debit' | 'credit' | null => {
  const value = localStorage.getItem('cardType');
  return value === 'debit' || value === 'credit' ? value : null;
};

export const setNationalId = (nationalId: 'Expart' | 'Residential') => {
  localStorage.setItem('nationalId', nationalId);
};

export const getNationalId = (): 'Expart' | 'Residential' | null => {
  const value = localStorage.getItem('nationalId');
  return value === 'Expart' || value === 'Residential' ? value : null;
};

export const setCitizenshipDetails = (citizenshipDetails: 'US' | 'NonUS') => {
  localStorage.setItem('citizenshipDetails', citizenshipDetails);
};

export const getCitizenshipDetails = (): 'US' | 'NonUS' | null => {
  const value = localStorage.getItem('citizenshipDetails');
  return value === 'US' || value === 'NonUS' ? value : null;
};

// export const setOptBtnSelectedItem = (item: OptionButtonData) => {
//   localStorage.setItem('selectedOptBtnItem', JSON.stringify(item));
// };
// export const getOptBtnSelectedItem = () => {
//   localStorage.getItem('selectedOptBtnItem');
// };
// export const setOptBtnSelectedItem = (item: string) => {
//   localStorage.setItem('selectedOptBtnItem', item);
// };
// export const getOptBtnSelectedItem = (item: string) => {
//   localStorage.getItem('selectedOptBtnItem');
// };
