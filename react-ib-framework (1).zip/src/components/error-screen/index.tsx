import {FC} from 'react';
import {Box} from '@mui/material';
import {useNavigate} from 'react-router-dom';
import {AppPath} from 'constants/path';
import {buttonTypes} from 'constants/labelvalues';
import {logger} from 'logger';
import {CustomLabel} from 'components';
import ButtonList from 'components/button-list';
import {getStyles} from './styles';

interface ErrorScreenProps {
  error: string;
}

const ErrorScreen: FC<ErrorScreenProps> = ({error}) => {
  const navigate = useNavigate();
  const navigateLogin = () => navigate(AppPath.LoginScreen);
  logger.log('Error Boundary', error);

  const styles = getStyles();
  const errorBtn = [
    {
      id: 1,
      label: 'Home',
      type: buttonTypes.filled,
      onClick: navigateLogin,
    },
  ];
  return (
    <Box sx={styles.container}>
      <Box sx={styles.mainContent}>
        <CustomLabel id={'error'} text={'Oops, Something went wrong'} />
      </Box>
      <Box sx={styles.footer}>
        <ButtonList buttons={errorBtn} />
      </Box>
    </Box>
  );
};

export default ErrorScreen;
