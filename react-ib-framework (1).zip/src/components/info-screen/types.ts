import {SxProps} from '@mui/system';
import {ButtonSize, ButtonStyle, ButtonType} from 'components/button/types';
import {ReactNode} from 'react';
import {Theme} from 'react-core';

export enum InfoIconType {
  success = 'Success',
  error = 'error',
}

export type InfoScreenProps = {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
  alignCenter?: boolean;
  iconType?: InfoIconType;
  primaryBtn?: {
    label: string;
    size: ButtonSize;
    variant: ButtonStyle;
    type: ButtonType;
    onClick: () => void;
    disabled?: boolean;
  };
  Icon?: ReactNode;
  secondaryBtn?: {
    label: string;
    size: ButtonSize;
    variant: ButtonStyle;
    type: ButtonType;
    onClick: () => void;
    disabled?: boolean;
  };
  illustratorStyle?: SxProps;
};

export type InfoScreenStyleProps = {
  theme: Theme;
  alignCenter: boolean;
};
