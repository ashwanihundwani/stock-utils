import {appcolors} from 'constants/color';
import {Theme} from 'constants/theme';

export const getStyles = (theme: Theme) => {
  return {
    header: {
      background: theme.background.header,
    },
    defaultContainer: {
      height: '50%',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    defaultHeaderStyle: {
      fontWeight: 'bold',
      fontSize: '14px',
      color: appcolors.black,
    },
    defaultStartComponentStyle: {
      width: {
        xl: '35%',
        lg: '35%',
        md: '35%',
        sm: '25%',
        xs: '10%',
      },
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-start',
      overflow: 'hidden',
    },
    headerLabel: {
      color: theme.text.heading,
    },
    defaultEndComponentStyle: {
      width: {
        xl: '35%',
        lg: '35%',
        md: '35%',
        sm: '25%',
        xs: '10%',
      },
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      overflow: 'hidden',
    },
  };
};
