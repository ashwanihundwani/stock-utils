import React, {FC} from 'react';
import {Box, Stack, SxProps} from '@mui/material';
import {CustomLabel} from 'components';

import {getStyles} from './styles';
import {useAppTheme} from 'constants/theme';
import {variants} from 'components/custom-label/types';

import {translation} from 'react-core';

interface ScreenHeaderProps {
  screenName: string;
  containerStyle?: SxProps;
  startComponent?: React.ReactNode;
  endComponent?: React.ReactNode;
  startComponentStyle?: SxProps;
  endComponentStyle?: SxProps;
  topNavigation?: boolean;
}

const ScreenHeader: FC<ScreenHeaderProps> = ({
  screenName,
  containerStyle,
  startComponent,
  endComponent,
  startComponentStyle,
  endComponentStyle,
  topNavigation,
}) => {
  const {theme} = useAppTheme();
  const {t: translate} = translation.useTranslation();

  const styles = getStyles(theme);

  return (
    <Stack
      height={topNavigation ? '18%' : '8%'}
      justifyContent={topNavigation ? 'flex-end' : 'center'}
      sx={styles.header}>
      <Box sx={[{...styles.defaultContainer}, {...(containerStyle as object)}]}>
        <Box
          sx={[
            {...styles.defaultStartComponentStyle},
            {...(startComponentStyle as object)},
          ]}>
          {startComponent}
        </Box>

        <CustomLabel
          text={translate(screenName)}
          id="screenName"
          style={styles.headerLabel}
          variant={variants.bodyRegularL}
        />
        <Box
          sx={[
            {...styles.defaultEndComponentStyle},
            {...(endComponentStyle as object)},
          ]}>
          {endComponent}
        </Box>
      </Box>
    </Stack>
  );
};

export default ScreenHeader;
