import React from 'react';

export interface DropdownProps {
  id: string;
  labelId: string;
  placeholder?: string;
  value?: string;
  options: {id: string; value: string; label: string}[];
  setValue?: (value: string) => void;
  errorText?: string;
  helperText?: string;
  disabled?: boolean;
  customstyle: React.CSSProperties;
  labelstyle?: React.CSSProperties;
  multiple?: boolean;
  selectedValues?: string[];
  onSelectionChange?: (selectedValues: string[]) => void;
}
