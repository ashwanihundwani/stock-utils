import {fonts} from 'utils/typography';
import {Theme} from 'react-core';
export const getStyles = (theme: Theme, error: boolean) => {
  return {
    defaultSelectDropdown: {
      width: '100%',
      height: '64px',
      borderRadius: '8px',

      background: theme.colors['surface-interactive-secondary-enabled'],
      alignItems: 'center',
      color: theme.colors['content-secondary'],
      fontFamily: fonts.regular,
      '& .MuiOutlinedInput-notchedOutline': {
        border: 0,
      },
      '& .MuiSelect-select': {
        color: theme.colors['content-primary'],
        paddingTop: '35px',
      },
      '& .Mui-disabled': {
        borderRadius: '8px',
        padding: '20.5px 14px',
        background: theme.colors['surface-interactive-secondary-disabled'],
      },
      '&.Mui-focused fieldset': error
        ? {
            border: `${theme.colors['surface-semantic-error-02']} !important`,
          }
        : {
            border: `1px solid ${theme.colors['surface-interactive-tertiary-active']} !important`,
          },
      '&:hover:not(.Mui-disabled) fieldset': error
        ? {
            border: `${theme.colors['surface-semantic-error-02']} !important`,
          }
        : {
            border: `2px solid ${theme.colors['border-focus']} !important`,
          },
      '&.Mui-error': {
        backgroundColor: theme.colors['surface-semantic-error-01'],
        border: `1px solid ${theme.colors['surface-semantic-error-02']} !important`,
      },
      '&.Mui-disabled svg>path': {
        stroke: `${theme.colors['icon-interactive-secondary-disabled']} !important`,
      },
      '&.Mui-focused svg>path': {
        stroke: `${theme.colors['surface-interactive-tertiary-active']} !important`,
      },
      '&.Mui-error svg>path': {
        stroke: `${theme.colors['surface-semantic-error-02']} !important`,
      },
    },
    defaultSelectDropdownLabel: {
      marginTop: '5px',
      width: '100%',
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
      '&.Mui-focused': {
        fontSize: '12px',
        marginLeft: '2px',
        marginTop: '18px',
        width: '100%',

        color: theme.colors['content-secondary'],
      },
      '&.MuiFormLabel-filled': {
        fontSize: '12px',
        marginLeft: '2px',
        width: '100%',

        marginTop: '18px',
        color: theme.colors['content-secondary'],
      },
    },
    ddlErrorMessage: {
      paddingLeft: '16px',
      color: theme.colors['surface-semantic-error-02'],
    },
  };
};
