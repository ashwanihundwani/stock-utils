import {FC} from 'react';
import {
  MenuItem,
  Select,
  Box,
  SelectChangeEvent,
  Checkbox,
  ListItemText,
} from '@mui/material';

import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import {getStyles} from './styles';
import {DropdownProps} from './types';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {DropdownArrowIcon} from '../../assets/svg/dropdown';
import {useNewTheme} from 'react-core';
const Dropdown: FC<DropdownProps> = ({
  id,
  labelId,
  options,
  errorText,
  helperText,
  disabled,
  placeholder,
  customstyle,
  labelstyle,
  value,
  setValue,
  multiple = false,
  selectedValues,
  onSelectionChange,
}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme, Boolean(errorText));

  const handleOnSelect = (event: SelectChangeEvent<string>): void => {
    console.log('selected value', JSON.stringify(event.target.value));
    setValue?.(event.target.value);
  };
  const handleOnChange = (event: SelectChangeEvent<string[]>): void => {
    const value = event.target.value as string[];
    onSelectionChange?.(value);
  };
  // const handleOnSelect = (event: SelectChangeEvent) => {
  //   setValue? (event.target.value);
  // };
  return (
    <Box>
      {multiple ? (
        <FormControl fullWidth>
          <InputLabel
            id={labelId}
            sx={{...styles.defaultSelectDropdownLabel, ...labelstyle}}>
            {placeholder}
          </InputLabel>
          <Select
            multiple={multiple}
            id={id}
            data-testid={labelId}
            disabled={disabled}
            error={Boolean(errorText)}
            displayEmpty
            value={selectedValues}
            onChange={handleOnChange}
            renderValue={selected =>
              selected
                .map(val => options.find(opt => opt.value === val)?.label)
                .join(', ')
            }
            sx={{...styles.defaultSelectDropdown, ...customstyle}}
            IconComponent={_props => {
              const rotate = _props.className.toString().includes('iconOpen');
              return (
                <div
                  style={{
                    position: 'absolute',
                    cursor: 'pointer',
                    pointerEvents: 'none',
                    right: 10,
                    top: '20px',
                    transform: rotate
                      ? 'rotate(180deg)  translateY(5px)'
                      : 'none',
                  }}>
                  <DropdownArrowIcon />
                </div>
              );
            }}>
            {options.map(item => (
              <MenuItem key={item.id} value={item.label}>
                <Checkbox checked={selectedValues?.includes(item.value)} />
                <ListItemText primary={item.label} />
              </MenuItem>
            ))}
          </Select>
          <Box sx={styles.ddlErrorMessage}>
            {Boolean(helperText) && (
              <HelperText
                type={HelperTextType.HelperText}
                message={helperText}
              />
            )}
            {Boolean(errorText) && (
              <HelperText type={HelperTextType.ErrorText} message={errorText} />
            )}
          </Box>
        </FormControl>
      ) : (
        <FormControl>
          <InputLabel
            id={labelId}
            sx={{...styles.defaultSelectDropdownLabel, ...labelstyle}}>
            {placeholder}
          </InputLabel>
          <Select
            id={id}
            data-testid={labelId}
            disabled={disabled}
            error={Boolean(errorText)}
            displayEmpty
            value={value}
            onChange={handleOnSelect}
            sx={{...styles.defaultSelectDropdown, ...customstyle}}
            IconComponent={_props => {
              const rotate = _props.className.toString().includes('iconOpen');
              return (
                <div
                  style={{
                    position: 'absolute',
                    cursor: 'pointer',
                    pointerEvents: 'none',
                    right: 10,
                    top: '20px',
                    transform: rotate
                      ? 'rotate(180deg)  translateY(5px)'
                      : 'none',
                  }}>
                  <DropdownArrowIcon />
                </div>
              );
            }}>
            {options.map(item => (
              <MenuItem key={item.id} value={item.label}>
                {item.label}
              </MenuItem>
            ))}
          </Select>
          <Box sx={styles.ddlErrorMessage}>
            {Boolean(helperText) && (
              <HelperText
                type={HelperTextType.HelperText}
                message={helperText}
              />
            )}
            {Boolean(errorText) && (
              <HelperText type={HelperTextType.ErrorText} message={errorText} />
            )}
          </Box>
        </FormControl>
      )}
    </Box>
  );
};

export default Dropdown;
