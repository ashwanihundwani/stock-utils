import {PasswordRulesStyleProps} from './types';

export const getStyles = (props: PasswordRulesStyleProps) => {
  const {theme} = props;
  return {
    rulesContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    ruleFieldContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      alignItems: 'center',
    },
    iconDecoratorStyle: {
      height: '1rem',
      width: '1rem',
      borderRadius: '62.438rem',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: theme.colors['surface-02'],
    },
    inValidIconDecoratorStyle: {
      backgroundColor: theme.colors['surface-semantic-error-02'],
    },
    validIconDecoratorStyle: {
      backgroundColor: theme.colors['surface-semantic-success-02'],
    },
  };
};
