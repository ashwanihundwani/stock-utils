import {Box} from '@mui/material';
import {Cancel01, Tick02} from 'assets/svg';
import {CustomLabel} from 'components';
import {getStyles} from './styles';
import {
  checkLowerCase,
  checkMaxLength,
  checkMinLength,
  checkOneDigit,
  checkSpecialChar,
  checkUpperCase,
  useNewTheme,
  useTranslation,
} from 'react-core';
import {variants} from 'components/custom-label/types';
import {FC} from 'react';
import {PasswordRulesProps} from './types';

const PasswordRules: FC<PasswordRulesProps> = props => {
  const {
    lowerCaseTitle = 'CommonPasswordSetupLblLowerCase',
    upperCaseTitle = 'CommonPasswordSetupLblUpperCase',
    oneNumberTitle = 'CommonPasswordSetupLblOneNumber',
    oneSpecialTitle = 'CommonPasswordSetupLblOneSpecial',
    minLengthTitle = 'CommonPasswordSetupLblMinLength',
    maxLengthTitle = 'CommonPasswordSetupLblMaxLength',
    value,
  } = props;
  const theme = useNewTheme();
  const styles = getStyles({theme});

  return (
    <Box sx={styles.rulesContainer}>
      {renderValidationListItem(checkLowerCase, lowerCaseTitle, value)}
      {renderValidationListItem(checkUpperCase, upperCaseTitle, value)}
      {renderValidationListItem(checkOneDigit, oneNumberTitle, value)}
      {renderValidationListItem(checkSpecialChar, oneSpecialTitle, value)}
      {renderValidationListItem(checkMinLength, minLengthTitle, value)}
      {renderValidationListItem(checkMaxLength, maxLengthTitle, value)}
    </Box>
  );
};

const renderValidationListItem = (
  validationType: (value: string | undefined) => boolean,
  text: string,
  value: string,
) => {
  const validField = validationType(value);
  const theme = useNewTheme();
  const {t: translate} = useTranslation();
  const styles = getStyles({theme});

  return (
    <Box sx={styles.ruleFieldContainer}>
      <Box
        sx={{
          ...styles.iconDecoratorStyle,
          ...(value && validField && styles.validIconDecoratorStyle),
          ...(value && !validField && styles.inValidIconDecoratorStyle),
        }}>
        {(!value || validField) && (
          <Tick02
            size={'12'}
            color={
              validField
                ? theme.colors['icon-inverted-primary']
                : theme.colors['icon-secondary']
            }
          />
        )}
        {value && !validField && (
          <Cancel01 size={'12'} color={theme.colors['icon-inverted-primary']} />
        )}
      </Box>
      <CustomLabel
        id={'rule'}
        variant={variants.bodyRegularS}
        text={translate(text)}
      />
    </Box>
  );
};

export default PasswordRules;
