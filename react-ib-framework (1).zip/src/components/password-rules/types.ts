import {Theme} from 'react-core';

export type PasswordRulesProps = {
  lowerCaseTitle?: string;
  upperCaseTitle?: string;
  oneNumberTitle?: string;
  oneSpecialTitle?: string;
  minLengthTitle?: string;
  maxLengthTitle?: string;
  value: string;
};

export type PasswordRulesStyleProps = {
  theme: Theme;
};
