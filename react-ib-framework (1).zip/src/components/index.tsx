import {lazy} from 'react';

export const ButtonList = lazy(() => import('./button-list'));
export const Image = lazy(() => import('./image'));

// export const Label = lazy(() => import('./custom-label'));
export const ScreenContent = lazy(() => import('./screen-content'));
export const ScreenHeader = lazy(() => import('./screen-header'));

export const ErrorScreen = lazy(() => import('./error-screen'));
export const AppLoader = lazy(() => import('./app-loading'));
export const SessionPopup = lazy(() => import('./session-popup'));
export const Loading = lazy(() => import('./loading'));
export const Dropdown = lazy(() => import('./select-dropdown'));
export const ScreenContainer = lazy(() => import('./screen-container'));
export const Button = lazy(() => import('./button'));
export const TextInput = lazy(() => import('./text-input'));
export const CustomCheckbox = lazy(() => import('./checkbox'));
export const CustomLabel = lazy(() => import('./custom-label'));
export const OtpContainer = lazy(() => import('./otp-container'));
export const Timer = lazy(() => import('./timer'));
export const OtpInput = lazy(() => import('./otp-input'));
export const Link = lazy(() => import('./link'));
export const OptionButton = lazy(() => import('./option-button'));
export const CustomList = lazy(() => import('./custom-list'));
export const Avatar = lazy(() => import('./avatar'));
export const Toggle = lazy(() => import('./toggle'));
export const InfoScreen = lazy(() => import('./info-screen'));
export const PasswordRules = lazy(() => import('./password-rules'));
export const Stories = lazy(() => import('./stories'));
