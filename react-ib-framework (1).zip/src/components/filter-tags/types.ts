export interface FilterTagsProps {
  dataValue: {id: string; label: string; value: string}[];
  showButton: boolean;
}
