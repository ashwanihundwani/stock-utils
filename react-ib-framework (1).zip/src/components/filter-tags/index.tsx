import {FC, useState} from 'react';
import {FilterTagsProps} from './types';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {Button} from '@mui/material';
import {getStyles} from './styles';
import {Box} from '@mui/system';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {useNewTheme} from 'react-core/hooks';

const FilterTags: FC<FilterTagsProps> = ({dataValue, showButton}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const [data, setData] = useState(dataValue);
  const handleOnClick = (deleteId: string) => {
    return setData(data => data.filter(data => data.id !== deleteId));
  };
  const handleOnDeleteAll = () => {
    return setData([]);
  };
  return (
    <Box>
      {data.length > 1 && showButton && (
        <Link
          size={LinkSize.Medium}
          linkText="Clear all"
          onClick={handleOnDeleteAll}
        />
      )}
      {data.map(value => {
        return (
          <Button
            key={value.id}
            onClick={() => {
              handleOnClick(value.id);
            }}
            sx={styles.defaultStyle}
            endIcon={<DeleteIcon />}>
            {value.label}
          </Button>
        );
      })}
    </Box>
  );
};

export default FilterTags;
