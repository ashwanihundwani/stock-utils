import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    defaultStyle: {
      backgroundColor: theme.colors['surface-02'],
      color: theme.colors['content-secondary'],
      borderRadius: '20px',
      textTransform: 'none',
      paddingRight: '16px',
      paddingLeft: '16px',
      minWidth: '70px',
      margin: '8px',
      '&.MuiButton-root': {
        fontFamily: fonts.regular,
        fontSize: '14px',
        fontWeight: '500px',
      },
    },
  };
};
