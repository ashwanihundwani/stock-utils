import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const stepperStyles = {
  getStepStyles: (theme: Theme) => ({
    '& .MuiStepLabel-root .MuiStepLabel-label': {
      fontFamily: fonts.regular,
    },
    '& .MuiStepLabel-label': {
      color: theme.colors['content-secondary'],
    },
    '&.Mui-completed .MuiStepLabel-root .MuiStepLabel-label': {
      color: theme.colors['content-interactive-secondary-enabled'],
      fontWeight: '600',
    },
    '& .MuiStepLabel-root .Mui-active': {
      color: theme.colors['content-interactive-primary-enabled'],
      fontWeight: '600',
    },
  }),
  getStepIconStyles: (
    _completed: boolean | undefined,
    _index: number,
    active: boolean | undefined,
    theme: Theme,
  ) => ({
    stepIcon: {
      width: 24,
      height: 24,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '14px',
      background: active
        ? 'linear-gradient(to top, rgba(129, 17, 199, 1), rgb(106, 25, 196), rgba(96, 9, 195, 1))'
        : theme.colors['surface-02'],
      color: active
        ? theme.colors['border-inverted-enabled-01']
        : theme.colors['content-secondary'],
      fontFamily: fonts.regular,
    },
    completedIcon: {
      width: 24,
      height: 24,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: theme.colors['surface-semantic-success-02'],
      color: 'white',
    },
  }),

  getConnectorStyles: (activeStep: number, index: number, theme: Theme) => ({
    line: {
      '& .MuiStepConnector-line': {
        borderLeftWidth: '1px',
        minHeight: '100%',
        height: '24px',
        borderColor:
          index < activeStep
            ? theme.colors['border-semantic-success']
            : theme.colors['border-enabled-02'],
      },
    },
  }),
};
