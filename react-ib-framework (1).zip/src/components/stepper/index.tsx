import React from 'react';
import {
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  StepIconProps,
} from '@mui/material';
import {stepperStyles} from './styles';
import {useNewTheme} from 'react-core';
import {IconTick02} from 'assets/svg/IconTick-02';

interface VerticalStepperProps {
  steps: string[];
  activeStep: number;
}

const VerticalStepper: React.FC<VerticalStepperProps> = ({
  steps,
  activeStep,
}) => {
  const theme = useNewTheme();

  return (
    <Stepper activeStep={activeStep} orientation="vertical" connector={null}>
      {steps.map((label, index) => (
        <Step
          key={label}
          completed={index < activeStep}
          sx={stepperStyles.getStepStyles(theme)}>
          <StepLabel
            slots={{stepIcon: CustomStepIcon}}
            slotProps={{
              stepIcon: {
                active: index === activeStep,
                completed: index < activeStep,
                icon: index + 1,
              },
            }}>
            {label}
          </StepLabel>

          {index !== steps.length - 1 && (
            <CustomStepConnector index={index} activeStep={activeStep} />
          )}
        </Step>
      ))}
    </Stepper>
  );
};

const CustomStepConnector: React.FC<{index: number; activeStep: number}> = ({
  index,
  activeStep,
}) => {
  const theme = useNewTheme();
  const styles = stepperStyles.getConnectorStyles(activeStep, index, theme);

  return <StepConnector sx={styles.line} />;
};

const CustomStepIcon: React.FC<StepIconProps> = ({completed, active, icon}) => {
  const theme = useNewTheme();
  const index = Number(icon) - 1;
  const styles = stepperStyles.getStepIconStyles(
    completed,
    index,
    active,
    theme,
  );

  return completed ? (
    <div style={styles.completedIcon}>
      <IconTick02 />
    </div>
  ) : (
    <div style={styles.stepIcon}>{icon}</div>
  );
};

export default VerticalStepper;
