import {Box} from '@mui/material';
import {CustomLabel, Link, Timer, OtpInput} from 'components';
import {variants} from 'components/custom-label/types';
import {FC, useEffect, useState} from 'react';
import {OtpContainerProps} from './types';
import {getStyles} from './styles';

import {useNewTheme, useTranslation} from 'react-core';
import {navigationProps} from 'constants/labelvalues';
import {ArrowLeft02Sharp} from 'assets/svg';
import {useNavigate} from 'react-router-dom';

const OtpContainer: FC<OtpContainerProps> = props => {
  const {
    onResendOtp,
    title = '',
    subtitle = '',
    resendOtpLabel = '',
    requestOtpLabel = '',
    onSubmitOtp,
    backLabel = '',
  } = props;

  const navigate = useNavigate();
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const [otp, setOtp] = useState(['', '', '', '']);
  const [showResendOtp, setShowResendOtp] = useState(false);
  const {t: translate} = useTranslation();

  const handleOnResendOtp = () => {
    setShowResendOtp(false);
    onResendOtp();
  };

  useEffect(() => {
    const otpInput = otp.join('');
    if (otpInput.length === 4) {
      onSubmitOtp(otpInput);
    }
  }, [otp]);

  return (
    <Box sx={styles.otpContainer}>
      <Box sx={styles.otpHeaderFooterContainer}>
        {backLabel && (
          <Box
            sx={styles.backButton}
            onClick={() => navigate(navigationProps.goBack)}>
            <ArrowLeft02Sharp />
            <CustomLabel
              style={styles.backLabelStyle}
              text={translate(backLabel)}
              id="back"
              variant={variants.bodySemiBoldM}
            />
          </Box>
        )}
        <CustomLabel
          id={'title'}
          text={translate(title)}
          variant={variants.titleS}
        />
        <CustomLabel
          id={'subtitle'}
          text={translate(subtitle) + ' ********019'}
          variant={variants.bodyRegularS}
        />
      </Box>

      <OtpInput otp={otp} setOtp={newOtp => setOtp(newOtp)} bgWhite />

      <Box sx={styles.otpHeaderFooterContainer}>
        {showResendOtp ? (
          <Link
            linkText={translate(requestOtpLabel)}
            onClick={handleOnResendOtp}
          />
        ) : (
          <Box sx={styles.resendContainer}>
            <CustomLabel
              id={'resend-txt'}
              text={translate(resendOtpLabel)}
              variant={variants.bodyRegularS}
            />
            <Timer
              initialTimeInSeconds={60}
              onTimerComplete={() => {
                setShowResendOtp(true);
              }}
            />
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default OtpContainer;
