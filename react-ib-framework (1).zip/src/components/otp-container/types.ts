import {Theme} from 'react-core';

export type OtpContainerProps = {
  onResendOtp: () => void;
  title: string;
  subtitle: string;
  resendOtpLabel: string;
  requestOtpLabel: string;
  onSubmitOtp: (otp: string) => void;
  backLabel?: string;
};

export type OtpContainerStyleProps = {
  theme: Theme;
};
