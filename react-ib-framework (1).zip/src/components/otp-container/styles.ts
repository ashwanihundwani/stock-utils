import {OtpContainerStyleProps} from './types';

export const getStyles = (props: OtpContainerStyleProps) => {
  const {theme} = props;

  return {
    otpContainer: {
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      gap: '2rem',
      justifyContent: 'center',
    },
    otpHeaderFooterContainer: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    resendContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.25rem',
    },
    backButton: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      alignItems: 'center',
      cursor: 'pointer',
      width: 'fit-content',
    },
    backLabelStyle: {
      letterSpacing: '0rem',
      color: theme.colors['content-interactive-secondary-enabled'],
      cursor: 'pointer',
    },
  };
};
