export interface SearchInputProps {
  placeholder: string;
  value: string;
  showIcon?: boolean;
  handleOnSearch: (value: string) => void;
  errorText?: string;
  helperText?: string;
  disabled?: boolean;
}
