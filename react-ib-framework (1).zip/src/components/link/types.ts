import {SxProps} from '@mui/material';

export enum LinkSize {
  Small = 'small',
  Medium = 'medium',
  Large = 'large',
}

export enum LinkType {
  Primary = 'Primary',
  Secondary = 'Secondary',
}

export interface LinkProps {
  size?: LinkSize;
  inverted?: boolean;
  disabled?: boolean;
  linkText: string;
  showIcon?: boolean;
  onClick?: (value: string | number | boolean) => void;
  icon?: React.ReactNode;
  type?: LinkType;
  customStyle?: SxProps;
}
