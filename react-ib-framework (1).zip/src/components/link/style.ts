import {SxProps} from '@mui/system';
import {fonts} from 'utils/typography';
import {LinkSize, LinkType} from './types';
import {Theme} from 'react-core';

export const linkStyles = (
  size: LinkSize,
  inverted: boolean,
  disabled: boolean,
  type: LinkType,
  theme: Theme,
): SxProps => {
  const sizeStyles = getSizeStyles(size);
  return {
    '& .link-container': {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    color:
      type === 'Secondary'
        ? theme.colors['content-interactive-secondary-enabled']
        : getColor(inverted, disabled, theme),
    display: 'inline-flex',
    alignItems: 'center',
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    backgroundColor: 'transparent',
    fontFamily: fonts.regular,
    fontWeight: '600',
    fontSize: sizeStyles.fontSize,
    pointerEvents: disabled ? 'none' : 'auto',
    '&:hover': {
      color: inverted
        ? theme.colors['content-interactive-inverted-active']
        : theme.colors['content-interactive-primary-active'],
    },
    '&:active': {
      color: inverted
        ? theme.colors['content-interactive-inverted-active']
        : theme.colors['content-interactive-primary-active'],
    },
    '&:focus': {
      borderRadius: '4px',
      border: inverted
        ? `2px solid ${theme.colors['border-focus-inverted']}`
        : `2px solid ${theme.colors['border-focus']}`,
    },
  };
};

const getSizeStyles = (size: LinkSize) => {
  switch (size) {
    case LinkSize.Large:
      return {
        fontSize: '16px',
        fontFamily: fonts.regular,
        fontWeight: '600',
      };
    case LinkSize.Medium:
      return {
        fontSize: '14px',
        fontFamily: fonts.regular,
        fontWeight: '600',
      };
    case LinkSize.Small:
      return {
        fontSize: '12px',
        fontFamily: fonts.regular,
        fontWeight: '600',
      };
    default:
      return {
        fontSize: '15px',
        fontFamily: fonts.regular,
        fontWeight: '600',
      };
  }
};

const getColor = (
  inverted: boolean,
  disabled: boolean,
  theme: Theme,
): string => {
  if (disabled) return theme.colors['content-interactive-primary-disabled'];
  return inverted
    ? theme.colors['content-interactive-inverted-enabled']
    : theme.colors['content-interactive-primary-enabled'];
};
