import React from 'react';
import {Box} from '@mui/system';
import {linkStyles} from './style';
import {LinkProps, LinkSize, LinkType} from './types';
import {BackArrow} from 'assets/svg/backArrow';
import {useNewTheme, useTranslation} from 'react-core';

const Link: React.FC<LinkProps> = ({
  size = LinkSize.Small,
  inverted = false,
  disabled = false,
  linkText,
  showIcon = false,
  onClick,
  icon, // Allowing custom icon
  type = LinkType.Primary,
}) => {
  const {t: translate} = useTranslation();

  const handleClick = () => {
    if (!disabled && onClick) {
      onClick('navigation');
    }
  };

  const theme = useNewTheme();
  // const styles = linkStyles(theme);

  return (
    <Box
      component="a"
      sx={linkStyles(size, inverted, disabled, type, theme)}
      onClick={handleClick}>
      <Box className="link-container">
        {showIcon && (icon || <BackArrow />)}
        <span>{translate(linkText)}</span>
      </Box>
    </Box>
  );
};

export default Link;
