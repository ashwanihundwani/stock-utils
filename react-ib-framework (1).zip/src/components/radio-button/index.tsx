import {FC} from 'react';
import {RadioButtonProps} from './types';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import {useNewTheme} from 'react-core';
import {getStyles} from './styles';

const RadioButton: FC<RadioButtonProps> = ({
  options,
  errorText,
  helperText,
  disabled,
  onChange,
  id,
  icon,
}) => {
  const handleChange = (value: string) => {
    onChange(value);
  };

  const theme = useNewTheme();
  const styles = getStyles(theme, Boolean(errorText));

  return (
    <FormControl error={Boolean(errorText)} sx={styles.defaultForm}>
      <RadioGroup id={id} data-testid={id}>
        {options.map(value => (
          <FormControlLabel
            key={value.id}
            disabled={disabled}
            value={value.value}
            sx={styles.defaultLabel}
            control={
              <Radio
                sx={styles.defaultRadio}
                onChange={event => handleChange(event.target.value)}
                checkedIcon={icon}
              />
            }
            label={value.label}
          />
        ))}
      </RadioGroup>
      {Boolean(helperText) && (
        <HelperText type={HelperTextType.HelperText} message={helperText} />
      )}
      {Boolean(errorText) && (
        <HelperText type={HelperTextType.ErrorText} message={errorText} />
      )}
    </FormControl>
  );
};

export default RadioButton;
