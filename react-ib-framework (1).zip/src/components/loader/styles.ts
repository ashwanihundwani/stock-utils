import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    default: {
      color: theme.colors['border-interactive-enabled'],
    },
  };
};
