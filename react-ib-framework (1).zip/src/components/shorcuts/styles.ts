export const getStyles = () => {
  return {
    defaultLabel: {
      textAlign: 'center',
      fontWeight: '400',
      fontSize: '14px',
      lineHeight: '20px',
    },
  };
};
