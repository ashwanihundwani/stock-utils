export interface ShorcutsProps {
  label?: string;
}
