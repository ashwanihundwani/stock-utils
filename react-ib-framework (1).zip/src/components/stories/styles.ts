import {Images} from 'constants/images';
import {StoriesStyleProp} from './types';

export const getStyles = (props: StoriesStyleProp) => {
  const {theme} = props;
  return {
    storiesContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '2rem',
    },
    storyItem: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
      width: '5rem',
      textAlign: 'center',
    },
    storyImg: {
      height: '4.5rem',
      width: '4.5rem',
      borderRadius: '62.438rem',
    },
    progressTabContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      width: '100%',
    },
    progressTab: {
      flex: 1,
    },
    storyContainer: {
      '& .MuiPaper-root': {
        display: 'flex',
        flexDirection: 'column',
        borderRadius: '1rem',
        gap: '2rem',
        height: '90%',
        width: '31.111%',
        padding: '1.5rem',
        backgroundImage: `url(${Images.security_tip_illustration})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: '100% 100%',
      },
    },
    storyContent: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
      padding: '0px 1.5rem',
      textAlign: 'center',
    },
    storyBodyContainer: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      alignItems: 'center',
      flex: 1,
    },
    headerContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    headerBodyContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '1rem',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    headerTextContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      alignItems: 'center',
    },
    headerCloseIllustrator: {
      width: '1.5rem',
      height: '1.5rem',
      borderRadius: '62.438rem',
      backgroundColor: theme.colors['surface-02'],
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
    },
  };
};
