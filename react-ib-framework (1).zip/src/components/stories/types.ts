import {Theme} from 'react-core';

export type Story = {
  id: number;
  storyName: string;
  storyImg: string;
};

export type StoriesPropType = {
  data: Story[];
};

export type StoriesStyleProp = {
  theme: Theme;
};

export type ProgressTab = {
  id: number;
  status: boolean;
};
