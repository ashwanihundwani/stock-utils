import {Box, Dialog, LinearProgress} from '@mui/material';
import {CustomLabel} from 'components';
import {variants} from 'components/custom-label/types';
import {FC, useState} from 'react';
import {ProgressTab, StoriesPropType, Story} from './types';
import {Cancel01, MeemBrandIcon} from 'assets/svg';
import {useNewTheme, useTranslation} from 'react-core';
import {useCountUp} from 'use-count-up';
import {getStyles} from './styles';

const createProgressTabs = (data: Story[], activeStoryId?: number) => {
  if (activeStoryId) {
    return data.map(item => {
      return {
        id: item.id,
        status: item.id <= activeStoryId,
      };
    });
  } else {
    return [];
  }
};

const Stories: FC<StoriesPropType> = ({data}) => {
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [progressTabs, setProgressTabs] = useState<ProgressTab[]>(
    createProgressTabs(data, activeStory?.id),
  );
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const {t: translate} = useTranslation();
  const {value: progress, reset: resetProgress} = useCountUp({
    isCounting: true,
    duration: 10,
    easing: 'linear',
    start: 0,
    end: 100,
    onComplete: () => {
      const index = activeStory?.id;

      if (activeStory === data[data.length - 1]) {
        closeStory();
      } else if (index) {
        setActiveStory(data[index]);
        setProgressTabs(createProgressTabs(data, index));
      }

      return {
        shouldRepeat: true,
      };
    },
  });

  const openStory = (story: Story) => {
    setActiveStory(story);
    setProgressTabs(createProgressTabs(data, story.id));
  };

  const closeStory = () => {
    setActiveStory(null);
    resetProgress();
  };

  const getValue = (item: ProgressTab) => {
    const getValueByStatus = item.status ? 100 : 0;
    return item.id === activeStory?.id ? Number(progress) : getValueByStatus;
  };

  return (
    <Box sx={styles.storiesContainer}>
      {/* Story Screen */}
      <Dialog
        open={activeStory !== null}
        fullScreen
        onClose={closeStory}
        sx={styles.storyContainer}>
        <Box sx={styles.headerContainer}>
          <Box sx={styles.progressTabContainer}>
            {progressTabs.map(item => {
              return (
                <LinearProgress
                  variant="determinate"
                  key={item.id}
                  value={getValue(item)}
                  sx={styles.progressTab}
                />
              );
            })}
          </Box>
          <Box sx={styles.headerBodyContainer}>
            <Box sx={styles.headerTextContainer}>
              <MeemBrandIcon />
              <CustomLabel
                id={'headerTitle'}
                text={translate('SettingsSecurityLblSubheader')}
                variant={variants.bodyRegularM}
              />
            </Box>
            <Box sx={styles.headerCloseIllustrator} onClick={closeStory}>
              <Cancel01
                size="16"
                color={theme.colors['icon-interactive-secondary-enabled']}
              />
            </Box>
          </Box>
        </Box>
        <Box sx={styles.storyBodyContainer}>
          <Box sx={styles.storyContent}>
            <CustomLabel
              id={'story-content'}
              text={activeStory ? translate(activeStory.storyName) : ''}
              variant={variants.titleL}
            />
            <CustomLabel
              id={'story-content'}
              text={translate('SettingsSecurityLblStoryContent')}
              variant={variants.bodyRegularM}
            />
          </Box>
        </Box>
      </Dialog>

      {/* Stories Container */}
      {data.map(item => {
        return (
          <Box
            sx={styles.storyItem}
            key={item.id}
            onClick={() => openStory(item)}>
            <img
              src={item.storyImg}
              style={styles.storyImg}
              alt="security tips"
            />
            <CustomLabel
              id={'story-name'}
              text={translate(item.storyName)}
              variant={variants.bodyRegularXS}
            />
          </Box>
        );
      })}
    </Box>
  );
};

export default Stories;
