import {Theme} from 'react-core';
export type TimerStyleProps = {
  theme: Theme;
};
export interface CountdownTimerProps {
  initialTimeInSeconds: number;
  onTimerComplete: () => void;
}
