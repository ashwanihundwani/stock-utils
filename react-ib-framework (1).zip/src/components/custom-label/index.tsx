import {FC} from 'react';
import {getStyles} from './styles';
import {LabelProperties} from './types';
import {Typography} from '@mui/material';
import {useNewTheme, useTranslation} from 'react-core';

const CustomLabel: FC<LabelProperties> = (properties: LabelProperties) => {
  const {id, variant = 'bodyRegularM', text, style} = properties;
  const theme = useNewTheme();
  const styles = getStyles(theme);
  const {t} = useTranslation();

  return (
    <Typography key={id} style={{...styles[variant], ...style}}>
      {t(text)}
    </Typography>
  );
};

export default CustomLabel;
