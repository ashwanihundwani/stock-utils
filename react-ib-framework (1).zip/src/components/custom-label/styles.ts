import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    titleXL: {
      fontSize: '28px',
      fontWeight: '500',
      color: theme.colors['content-primary'],
      fontFamily: fonts.figtree_semibold,
      lineHeight: '32px',
    },
    titleL: {
      fontSize: '24px',
      fontWeight: '600',
      color: theme.colors['content-primary'],
      fontFamily: fonts.figtree_semibold,
      lineHeight: '28px',
    },
    titleM: {
      fontSize: '20px',
      fontWeight: '600',
      lineHeight: '28px',
      color: theme.colors['content-primary'],
      fontFamily: fonts.figtree_semibold,
    },
    titleS: {
      fontSize: '18px',
      fontWeight: '500',
      lineHeight: '24px',
      color: theme.colors['content-primary'],
      fontFamily: fonts.figtree_regular,
    },
    titleXS: {
      fontSize: '16px',
      fontWeight: '600',
      lineHeight: '24px',
      color: theme.colors['content-primary'],
      fontFamily: fonts.figtree_semibold,
    },
    bodySemiBoldL: {
      color: theme.colors['content-primary'],
      fontWeight: '600',
      lineHeight: '24px',
      fontSize: '18px',
      fontFamily: fonts.figtree_semibold,
    },
    bodyMediumL: {
      color: theme.colors['content-primary'],
      fontWeight: '500',
      lineHeight: '24px',
      fontSize: '18px',
      fontFamily: fonts.figtree_regular,
    },
    bodyRegularL: {
      color: theme.colors['content-primary'],
      fontWeight: '400',
      lineHeight: '24px',
      fontSize: '18px',
      fontFamily: fonts.figtree_regular,
    },
    bodySemiBoldM: {
      color: theme.colors['content-primary'],
      fontWeight: '600',
      lineHeight: '24px',
      fontSize: '16px',
      fontFamily: fonts.figtree_semibold,
    },
    bodyMediumM: {
      color: theme.colors['content-primary'],
      fontWeight: '500',
      lineHeight: '24px',
      fontSize: '16px',
      fontFamily: fonts.figtree_medium,
    },
    bodyRegularM: {
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      lineHeight: '24px',
      fontSize: '14px',
      fontFamily: fonts.figtree_regular,
    },
    bodySemiBoldS: {
      color: theme.colors['content-interactive-primary-enabled'],
      fontWeight: '600',
      lineHeight: '20px',
      fontSize: '14px',
      fontFamily: fonts.figtree_semibold,
    },
    bodyMediumS: {
      color: theme.colors['content-interactive-primary-enabled'],
      fontWeight: '500',
      lineHeight: '20px',
      fontSize: '14px',
      fontFamily: fonts.figtree_medium,
    },
    bodyRegularS: {
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      lineHeight: '20px',
      fontSize: '14px',
      fontFamily: fonts.figtree_regular,
    },
    bodySemiboldXS: {
      color: theme.colors['content-secondary'],
      fontWeight: '600',
      lineHeight: '16px',
      fontSize: '12px',
      fontFamily: fonts.figtree_semibold,
    },
    bodyMediumXS: {
      color: theme.colors['content-secondary'],
      fontWeight: '500',
      lineHeight: '16px',
      fontSize: '12px',
      fontFamily: fonts.figtree_regular,
    },

    bodyRegularXS: {
      color: theme.colors['content-secondary'],
      fontWeight: '400',
      lineHeight: '16px',
      fontSize: '12px',
      fontFamily: fonts.figtree_regular,
    },
  };
};
