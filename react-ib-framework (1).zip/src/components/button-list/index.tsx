import {FC} from 'react';
import {Box, Button, SxProps, Theme} from '@mui/material';
import {useTranslation} from '../../translations/index';
import {buttonTypes} from '../../constants/labelvalues';
import {getStyles} from './styles';

interface ButtonProps {
  id: number | null | undefined;
  onClick: () => void;
  disabled?: boolean;
  type: string;
  label: string;
}

interface ButtonListProps {
  buttons: ButtonProps[];
  outLinedButtonStyle?: SxProps<Theme>;
  filledButtonStyle?: SxProps<Theme>;
  standardButtonStyle?: SxProps<Theme>;
  optionButtonStyle?: SxProps<Theme>;
  buttonDirection?: string;
  optionOutlineButtonStyle?: SxProps<Theme>;
}

const ButtonList: FC<ButtonListProps> = ({
  buttons,
  outLinedButtonStyle,
  filledButtonStyle,
  standardButtonStyle,
  optionButtonStyle,
  buttonDirection,
  optionOutlineButtonStyle,
}) => {
  const {t: translate} = useTranslation();

  const style = getStyles(buttonDirection);

  const getButtonStyle = (type: string): SxProps<Theme> => {
    switch (type) {
      case buttonTypes.outlined:
        return {
          ...style.outlinedButtonDefault,
          ...(outLinedButtonStyle as object),
        } as SxProps<Theme>;
      case buttonTypes.filled:
        return {
          ...style.filledButtonDefault,
          ...(filledButtonStyle as object),
        } as SxProps<Theme>;
      case buttonTypes.standard:
        return {
          ...style.standardButtonDefault,
          ...(standardButtonStyle as object),
        } as SxProps<Theme>;
      case buttonTypes.option:
        return {
          ...style.optionButtonDefault,
          ...(optionButtonStyle as object),
        } as SxProps<Theme>;
      case buttonTypes.optionOutlined:
        return {
          ...style.option_outline_default,
          ...(optionOutlineButtonStyle as object),
        } as SxProps<Theme>;
      default:
        return {};
    }
  };

  return (
    <Box sx={style.buttonsList}>
      {buttons?.map(button => (
        <Button
          key={button.id}
          onClick={() => button.onClick()}
          disabled={button.disabled}
          sx={getButtonStyle(button.type)}>
          {translate(button.label)}
        </Button>
      ))}
    </Box>
  );
};

export default ButtonList;
