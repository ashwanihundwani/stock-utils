import {SxProps} from '@mui/material';
export interface TextAreaProps {
  placeholder?: string;
  value?: string;
  onChange: (value: string) => void;
  errorText?: string;
  helperText?: string;
  disabled?: boolean;
  id: string;
  customStyle?: SxProps;
  maximumLength?: number;
}
