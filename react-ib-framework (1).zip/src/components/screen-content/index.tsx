import React, {FC, ReactNode} from 'react';
import {Box, Card, Stack, SxProps, Theme} from '@mui/material';
import {getStyles} from './styles';
import {useAppTheme} from 'constants/theme';

interface ScreenContentProps {
  mainContentStyle?: React.CSSProperties;
  headerComponentStyle?: React.CSSProperties;
  cardStyle?: SxProps<Theme> | boolean;
  children: ReactNode;
  headercomponent?: ReactNode;
  topNavigation?: boolean;
  tabNavigation?: boolean;
  autoHeight?: boolean;
}

const ScreenContent: FC<ScreenContentProps> = ({
  mainContentStyle,
  cardStyle,
  children,
  headercomponent,
  topNavigation,
  tabNavigation,
  autoHeight,
}) => {
  const {theme} = useAppTheme();

  const styles = getStyles(headercomponent, theme);

  const getHeight = () => {
    if (topNavigation && tabNavigation === undefined) {
      return '82%';
    }
    if (topNavigation && tabNavigation) {
      return {
        xl: '78%',
        lg: '74%',
        md: '74%',
        sm: '74%',
      };
    }
    return '92%';
  };
  return (
    <Stack height={!autoHeight ? getHeight : '100%'}>
      <Box sx={[{...styles.defaultMainContentStyle}, {...mainContentStyle}]}>
        {headercomponent}
        <Card
          elevation={0}
          sx={[{...styles.defaultCardStyle}, {...(cardStyle as object)}]}>
          {children}
        </Card>
      </Box>
    </Stack>
  );
};

export default ScreenContent;
