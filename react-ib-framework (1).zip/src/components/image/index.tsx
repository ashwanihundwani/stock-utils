import {FC} from 'react';
import {Box, SxProps} from '@mui/material';
import {getStyles} from './styles';

interface ImageProps {
  imageurl: string;
  alt?: string;
  styles?: SxProps;
  type?: string;
  onClick?: () => void;
}

const Image: FC<ImageProps> = ({imageurl, alt, styles, type, onClick}) => {
  const ImageStyle = getStyles();
  return (
    <Box onClick={onClick}>
      {type === 'quick_action_icon' && (
        <img
          src={imageurl}
          style={{
            ...(ImageStyle.quick_action_icon as object),
            ...(styles as object),
          }}
          alt={alt}
        />
      )}
      {type === 'icon' && (
        <img
          src={imageurl}
          style={{
            ...(ImageStyle.iconStyles as object),
            ...(styles as object),
          }}
          alt={alt}
        />
      )}
      {type === 'small' && (
        <img
          src={imageurl}
          style={{
            ...(ImageStyle.smallStyles as object),
            ...(styles as object),
          }}
          alt={alt}
        />
      )}
      {type === 'medium' && (
        <img
          src={imageurl}
          style={{
            ...(ImageStyle.mediumStyles as object),
            ...(styles as object),
          }}
          alt={alt}
        />
      )}
      {type === 'large' && (
        <img
          src={imageurl}
          style={{
            ...(ImageStyle.largeStyles as object),
            ...(styles as object),
          }}
          alt={alt}
        />
      )}
      {type === 'sm_card' && (
        <img
          src={imageurl}
          style={{...(ImageStyle.sm_card as object), ...(styles as object)}}
          alt={alt}
        />
      )}
      {type === 'lg_card' && (
        <img
          src={imageurl}
          style={{...(ImageStyle.lg_card as object), ...(styles as object)}}
          alt={alt}
        />
      )}
      {type === 'header' && (
        <img
          src={imageurl}
          style={{...(ImageStyle.header as object), ...(styles as object)}}
          alt={alt}
        />
      )}
      {type === 'gif' && (
        <img
          src={imageurl}
          style={{...(ImageStyle.gif as object), ...(styles as object)}}
          alt={alt}
        />
      )}
      {type === 'home-finance' && (
        <img
          src={imageurl}
          style={{
            ...(ImageStyle.home_finance_image as object),
            ...(styles as object),
          }}
          alt={alt}
        />
      )}
      {!type && <img src={imageurl} alt={''} style={{...(styles as object)}} />}
    </Box>
  );
};

export default Image;
