import {appcolors} from 'constants/color';

export const getStyles = () => {
  return {
    iconStyles: {
      height: '18px',
      width: '18px',
    },
    home_finance_image: {
      width: '150px',
      height: '140px',
      display: 'flex',
      marginTop: '10%',
      justifyContent: 'center',
      alignItems: 'center',
    },
    sm_card: {
      height: '30px',
      width: '50px',
      borderRadius: '5px',
      backgroundColor: appcolors.cardgrey,
    },
    lg_card: {
      height: '150px',
      width: '260px',
      borderRadius: '5px',
      backgroundColor: appcolors.cardgrey,
    },
    smallStyles: {
      height: '80px',
      width: '80px',
    },
    mediumStyles: {
      height: '120px',
      width: '120px',
    },
    largeStyles: {
      height: '180px',
      width: '240px',
    },
    header: {
      height: '40px',
      width: '70px',
      objectFit: 'contain',
    },
    quick_action_icon: {
      height: '40px',
      width: '40px',
      cursor: 'pointer',
    },
    gif: {
      height: '80px',
      width: '80px',
    },
  };
};
