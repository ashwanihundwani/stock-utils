export interface OptionButtonData {
  id: string;
  name?: string;
}

export interface ButtonProps {
  disabled?: boolean;
  options: OptionButtonData[];
  value: OptionButtonData | null;
  onSelected: (item: OptionButtonData) => void;
  optBtnBgWhite?: boolean;
}
