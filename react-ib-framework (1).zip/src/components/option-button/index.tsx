import {FC} from 'react';
import {ButtonProps} from './types';
import {getStyles} from './styles';
import {Box, Button} from '@mui/material';
import CustomLabel from 'components/custom-label';
import {variants} from 'components/custom-label/types';
import {useNewTheme, useTranslation} from 'react-core';

const OptionButton: FC<ButtonProps> = ({
  disabled,
  options,
  value,
  onSelected,
  optBtnBgWhite = false,
}) => {
  const theme = useNewTheme();
  const style = getStyles(theme, optBtnBgWhite);
  const {t: translate} = useTranslation();

  return (
    <Box sx={style.container}>
      {options.map(item => {
        return (
          <Button
            key={item.id}
            sx={[
              {...style.defaultOption_Btn},
              value?.id === item.id && {...style.selectedOptionBtn},
            ]}
            disabled={disabled}
            onClick={() => onSelected(item)}
            disableTouchRipple>
            <CustomLabel
              id="lblOptionBtn"
              variant={
                value?.id === item.id
                  ? variants.bodySemiBoldM
                  : variants.bodyRegularM
              }
              style={
                value?.id === item.id ? style.lblSelectedStyle : style.lblStyle
              }
              text={translate(item.name)}
            />
          </Button>
        );
      })}
    </Box>
  );
};
export default OptionButton;
