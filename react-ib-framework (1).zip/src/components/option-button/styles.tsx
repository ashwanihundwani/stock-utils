import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme, optBtnBgWhite: boolean) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    defaultOption_Btn: {
      textTransform: 'none',
      borderRadius: '1.75rem',
      padding: '1rem 0',
      transition: 'none',
      width: '100%',
      color: theme.colors['surface-01'],
      backgroundColor: optBtnBgWhite
        ? theme.colors['surface-01']
        : theme.colors['surface-interactive-secondary-enabled'],
      '&:hover': {
        backgroundColor: theme.colors['surface-interactive-secondary-active'],
        color: theme.colors['content-interactive-primary-active'],
      },

      '&:active': {
        color: theme.colors['content-interactive-inverted-enabled'],
        backgroundColor: theme.colors['surface-interactive-primary-enabled'],
        border: 'none',
        fontFamily: fonts.figtree_regular,
        fontWeight: '600',
      },

      '&:disabled': {
        backgroundColor: theme.colors['surface-interactive-secondary-disabled'],
        color: theme.colors['content-interactive-inverted-disabled'],
      },
    },
    selectedOptionBtn: {
      color: theme.colors['surface-01'],

      backgroundColor: theme.colors['surface-interactive-tertiary-active'],
      border: 'none',

      '&:active': {
        color: theme.colors['content-primary'],

        backgroundColor: theme.colors['surface-interactive-tertiary-active'],
        border: 'none',
        fontFamily: fonts.figtree_regular,
        fontWeight: '600',
      },
    },
    lblStyle: {
      color: theme.colors['content-primary'],
    },
    lblSelectedStyle: {
      color: theme.colors['content-interactive-inverted-enabled'],
    },
  };
};
