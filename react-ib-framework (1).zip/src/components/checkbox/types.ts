import {JSX} from 'react';

export interface CheckboxProps {
  errorText?: string;
  helperText?: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  id: string;
  icon: JSX.Element;
  checkedIcon: JSX.Element;
  label?: string;
}
