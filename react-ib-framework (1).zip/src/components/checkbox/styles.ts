import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme, error: boolean) => {
  return {
    defaultCheckbox: {
      '&.MuiCheckbox-root': {
        color: theme.colors['surface-interactive-secondary-disabled'],
        borderRadius: '0px',
        padding: '0px',
        fontFamily: fonts.regular,
        '&:hover': error
          ? {
              boxShadow: `${theme.colors['surface-semantic-error-02']}`,
              borderRadius: `${error ? '5px' : '4px'}`,
            }
          : {
              boxShadow: `0px 0px 0px 2px ${theme.colors['border-focus']}`,
              borderRadius: `${error ? '5px' : '4px'}`,
            },
      },

      '&.Mui-checked': {
        color: error
          ? theme.colors['surface-semantic-error-02']
          : theme.colors['surface-interactive-tertiary-active'],
        backgroundColor: error ? theme.colors['surface-semantic-error-01'] : '',
      },
      '&.Mui-disabled': {
        color: theme.colors['surface-interactive-secondary-disabled'],
      },
    },
    defaultLabel: {
      '& .MuiFormControlLabel-label': {
        color: theme.colors['content-primary'],
        marginLeft: '8px',
        fontFamily: fonts.regular,
      },
      '&.MuiFormControlLabel-root': {
        marginLeft: '0px',
      },
    },
    errorMessage: {
      color: theme.colors['surface-semantic-error-02'],
    },
  };
};
