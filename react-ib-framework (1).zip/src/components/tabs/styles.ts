import {SxProps} from '@mui/system';
import {CSSProperties} from 'react';
import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export type TabVariant = 'content-switcher' | 'pill-bar';

export const getBaseStyles = (theme: Theme) => ({
  container: {
    display: 'flex',
    gap: '8px',
    borderRadius: '999px',
  },
  tab: {
    height: '40px',
    width: '100%',
    padding: '0 16px',
    borderRadius: '999px',
    border: 'none',
    cursor: 'pointer',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: fonts.regular,
    fontSize: '16px',
    fontWeight: '500',
    background: theme.colors['background-01'],
    color: theme.colors['content-secondary'],
  },

  activeTab: {
    background: theme.colors['surface-interactive-tertiary-active'],
    color: theme.colors['content-interactive-inverted-enabled'],
  },
  pillBarTab: {
    background: theme.colors['background-01'],
    border: `1px solid ${theme.colors['border-enabled-02']}`,
  },
});
export const getStyles = (
  theme: Theme,
  variant: TabVariant,
  inverted: boolean,
  active: boolean,
) => {
  const containerStyle: CSSProperties =
    variant === 'content-switcher'
      ? {
          background: inverted
            ? theme.colors['background-03']
            : theme.colors['surface-interactive-primary-inverted-enabled'],
          border: inverted
            ? 'none'
            : `1px solid ${theme.colors['border-enabled-02']}`,
        }
      : {};

  const tabStyle: SxProps<Theme> = {
    ...getBaseStyles(theme).tab,
    ...(variant === 'pill-bar' && getBaseStyles(theme).pillBarTab),
    ...(active
      ? inverted
        ? {
            background: theme.colors['background-01'],
            color: theme.colors['surface-interactive-tertiary-active'],
          }
        : getBaseStyles(theme).activeTab
      : inverted
        ? {
            background: theme.colors['background-03'],
            border: 'none',
            color: theme.colors['content-inverted-secondary'],
          }
        : {}),
  };

  return {containerStyle, tabStyle};
};
