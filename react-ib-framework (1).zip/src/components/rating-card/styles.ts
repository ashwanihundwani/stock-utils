import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
export const getStyles = (theme: Theme) => {
  return {
    card: {
      width: 448,
      height: 232,
      backgroundColor: theme.colors['surface-01'],
      borderRadius: '8px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      boxShadow: '2px 2px 8px 0 rgba(0,0,0,0.2)',
    },
    header: {
      gap: 2,
    },
    headerSection: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    heading: {
      fontSize: 18,
      fontWeight: 700,
      pl: 2,
      mb: 1,
      pt: 2,
      fontFamily: fonts.regular,
      color: theme.colors['content-primary'],
    },
    question: {
      fontSize: 16,
      pl: 2,
      fontFamily: fonts.regular,
      color: theme.colors['content-secondary'],
    },

    starsWrapper: {
      display: 'flex',
      justifyContent: 'center',
      gap: '12px',
    },
    star: {
      cursor: 'pointer',
    },
    starNumber: {
      position: 'relative',
      top: '-50%',
      left: '88%',
      transform: 'translateX(-50%)',
      cursor: 'pointer',
      color: theme.colors['content-inverted-primary'],
    },
    buttonsWrapper: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 2,
      mr: 5,
      mb: 2,
    },
  };
};

export const getStarColor = (
  theme: Theme,
  num: number,
  selectedRating: number,
): string => {
  return num <= selectedRating
    ? theme.colors['content-interactive-primary-enabled']
    : theme.colors['content-interactive-primary-disabled'];
};
