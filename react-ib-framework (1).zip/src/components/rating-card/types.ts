export interface RatingCardProps {
  title?: string;
  question?: string;
  ratingRange?: number[];
  selectedRating?: number;
  onRatingSelect?: (rating: number) => void;
  onClose?: () => void;
  onSubmit?: () => void;
  cancelText?: string;
  submitText?: string;
}
