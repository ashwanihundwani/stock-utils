import {
  AudioIcon,
  LanguageIcon,
  MeemLogo,
  NotificationIcon,
  SearchIcon,
} from 'assets/svg/headerIcons';
import {headerStyles} from './styles';
import {Avatar, Box, Button, IconButton, Typography} from '@mui/material';
import {useNewTheme} from 'react-core';

interface HeaderProps {
  onLanguageIconChange?: () => void;
  onNotificationIconClick?: () => void;
  onProfileClick?: () => void;
  userName?: string;
}

const Header = ({
  onLanguageIconChange,
  onNotificationIconClick,
  onProfileClick,
  userName = 'Z',
}: HeaderProps) => {
  const theme = useNewTheme();
  const styles = headerStyles(theme);
  return (
    <Box sx={styles.header}>
      <Box sx={styles.headerContainer}>
        <Box sx={styles.logoContainer}>
          <Typography sx={styles.logoText}>
            <MeemLogo />
          </Typography>
        </Box>

        <Box sx={styles.navigation}>
          {[
            {label: 'Home', href: '/dashboard'},
            {label: 'Accounts', href: '/dashboard'},
            {label: 'Cards', href: '/dashboard'},
            {label: 'Transfers', href: '/dashboard'},
            {label: 'SADAD', href: '/dashboard'},
            {label: 'Finance', href: '/dashboard'},
            {label: 'Deposits', href: '/dashboard'},
          ].map(item => (
            <Typography
              key={item.label}
              component="a"
              href={item.href}
              sx={styles.navLink}>
              {item.label}
            </Typography>
          ))}
        </Box>

        <Box sx={styles.controlsContainer}>
          <Button onClick={onLanguageIconChange} sx={styles.languageButton}>
            <LanguageIcon />
          </Button>

          <IconButton sx={styles.iconButton}>
            <AudioIcon />
          </IconButton>

          <IconButton sx={styles.iconButton}>
            <SearchIcon />
          </IconButton>

          <IconButton onClick={onNotificationIconClick} sx={styles.iconButton}>
            <NotificationIcon />
          </IconButton>

          <Avatar onClick={onProfileClick} sx={styles.profileButton}>
            {userName.charAt(0)}
          </Avatar>
        </Box>
      </Box>
    </Box>
  );
};

export default Header;
