import {Theme} from 'react-core';
import {fonts} from 'utils/typography';
// backgroundColor: theme.colors['content-inverted-primary'],
export const headerStyles = (theme: Theme) => ({
  header: {
    width: '100%',
    padding: '16px 24px',
    backgroundColor: theme.colors['surface-01'],
    borderBottom: `1px solid ${theme.colors['border-enabled-01']} `,
  },

  headerContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },

  logoContainer: {
    display: 'flex',
    alignItems: 'center',
  },

  logoText: {
    fontSize: '24px',
    fontWeight: 'bold',
  },

  navigation: {
    display: {xs: 'none', md: 'flex'},
    alignItems: 'center',
    gap: 3,
  },

  navLink: {
    color: theme.colors['content-interactive-secondary-enabled'],
    fontSize: '14px',
    fontWeight: 600,
    textDecoration: 'none',
    fontFamily: fonts.semi_bold,
  },

  controlsContainer: {
    display: 'flex',
    alignItems: 'center',
    gap: 2,
    pr: '55px',
  },

  languageButton: {
    display: 'flex',
    alignItems: 'center',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: 0,
  },

  iconButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    p: 1,
    borderRadius: '50%',
    width: 40,
    height: 40,
  },

  profileButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: 32,
    height: 32,
    backgroundColor: theme.colors['decorative-03'],
    color: theme.colors['content-inverted-primary'],
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
  },
});
