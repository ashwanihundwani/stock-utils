import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const getStyles = (theme: Theme, disabled: boolean) => {
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    defaultText: {
      '& .MuiOutlinedInput-root': {
        '& fieldset': {
          border: 'none',
        },
      },
      '& .MuiInputBase-input': {
        fontSize: '3.5rem',
        width: '14.06rem',
      },

      '& input': {
        fontSize: '3.5rem',
        width: '100%',
        fontFamily: fonts.regular,
        color: theme.colors['content-primary'],
        margin: '0.125rem 0rem 0rem  0rem',
        height: '1.437rem',
      },
    },
    sarIconStyle: {
      fontSize: '2rem',
      fontWeight: '500',
      color: disabled
        ? theme.colors['content-disabled']
        : theme.colors['content-primary'],
    },
    line: {
      borderBottom: '0.0625rem solid',
      borderColor: theme.colors['border-enabled-02'],
      width: '100%',
    },
    helperTextStyle: {
      display: 'grid',
      justifyContent: 'center',
    },
  };
};
