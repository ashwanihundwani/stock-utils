import React, {FC} from 'react';
import Snackbar from '@mui/material/Snackbar';
import Box from '@mui/material/Box';
import {getStyles} from './styles';
import {ToastProps, ToastAlginmentType} from './types';
import useLoginPage from '../../features/auth/hooks/useLoginPage';
import Link from 'components/link';
import {LinkSize} from 'components/link/types';
import {useNewTheme} from 'react-core';

const Toast: FC<ToastProps> = ({
  vertical = ToastAlginmentType.bottom,
  horizontal = ToastAlginmentType.center,
  message,
  startIcon,
  endIcon,
  inverted = false,
  linkText,
}) => {
  const [open, setOpen] = React.useState(true);
  const {translate} = useLoginPage();

  setTimeout(() => {
    setOpen(false);
  }, 5000);

  const theme = useNewTheme();
  const styles = getStyles(theme);
  return (
    <Box>
      <Snackbar
        sx={inverted ? styles.invertedStyle : styles.defaultStyle}
        open={open}
        anchorOrigin={{vertical, horizontal}}
        message={
          <Box sx={styles.messageStyle}>
            <Box>{startIcon}</Box>
            <Box sx={styles.messageGrid}>
              {translate(message)}
              {linkText && (
                <Link
                  size={LinkSize.Medium}
                  linkText={linkText}
                  inverted={!inverted}
                />
              )}
            </Box>
            <Box>{endIcon}</Box>
          </Box>
        }></Snackbar>
    </Box>
  );
};

export default Toast;
