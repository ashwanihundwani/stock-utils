import {fonts} from 'utils/typography';
import {Theme} from 'react-core';

export const getStyles = (theme: Theme) => {
  return {
    defaultStyle: {
      '& .MuiSnackbarContent-root': {
        width: '358px',
        backgroundColor: theme.colors['surface-05'],
        borderRadius: '16px',
        fontFamily: fonts.regular,
        fontSize: '16px',
      },
    },
    messageStyle: {
      display: 'flex',
      alignItems: 'top',
      gap: '4px',
    },
    messageGrid: {
      display: 'grid',
    },
    linkText: {
      paddingLeft: '28px',
    },

    invertedStyle: {
      '& .MuiSnackbarContent-root': {
        width: '358px',
        backgroundColor: theme.colors['surface-01'],
        borderRadius: '16px',
        fontFamily: fonts.regular,
        fontSize: '16px',
        color: theme.colors['surface-05'],
      },
    },
  };
};
