import {FC} from 'react';
import {Typography} from '@mui/material';
import {getStyles} from './styles';
import {HelperTextProps, HelperTextType} from './types';
import {HelperIcon} from 'assets/svg/helperIcon';
import {useNewTheme} from 'react-core';

const HelperText: FC<HelperTextProps> = ({type, message}) => {
  const theme = useNewTheme();
  const checkType = () => {
    if (type === HelperTextType.ErrorText) {
      return theme.colors['surface-semantic-error-02'];
    } else if (type === HelperTextType.HelperText) {
      return theme.colors['content-secondary'];
    } else {
      return '';
    }
  };

  const styles = getStyles(checkType);

  const renderHelperText = () => {
    return (
      <Typography sx={styles.defaultBox} variant="caption">
        {message && <HelperIcon color={checkType()} />}
        {message}
      </Typography>
    );
  };
  return renderHelperText();
};

export {HelperText};
