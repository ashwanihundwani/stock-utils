import {fonts} from 'utils/typography';

export const getStyles = (checkType: () => string) => {
  return {
    defaultBox: {
      display: 'flex',
      alignItems: 'center',
      marginTop: '0.175rem',
      mb: 1,
      ml: 2,
      gap: '0.25rem',
      color: checkType,
      fontFamily: fonts.regular,
      lineHeight: 'normal',
    },
  };
};
