import {FC} from 'react';
import Switch from '@mui/material/Switch';
import {getStyles} from './styles';
import {useNewTheme} from 'react-core';
import {ToggleProps} from './types';

const Toggle: FC<ToggleProps> = ({disabled, onChange}) => {
  const theme = useNewTheme();
  const styles = getStyles(theme, disabled);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.checked);
  };

  return (
    <Switch
      sx={styles.defaultStyle}
      disableRipple
      disabled={disabled}
      onChange={handleChange}
    />
  );
};

export default Toggle;
