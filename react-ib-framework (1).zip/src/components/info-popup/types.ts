export interface InfoModalProps {
  open: boolean;
  children: React.ReactNode;
  onClose: () => void;
  icon?: boolean;
}
