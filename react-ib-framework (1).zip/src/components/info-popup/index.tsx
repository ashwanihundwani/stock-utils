import {Box, SvgIcon} from '@mui/material';
import {FC} from 'react';
import Dialog from '@mui/material/Dialog';
import {InfoModalProps} from './types';
import {DeleteIcon} from 'assets/svg/deleteIcon';
import {getStyles} from './styles';

const InfoPopup: FC<InfoModalProps> = ({open, onClose, children, icon}) => {
  const styles = getStyles();
  return (
    <Dialog onClose={onClose} open={open}>
      <Box sx={styles.modalConatiner}>
        {icon && (
          <Box sx={styles.deleteIcon}>
            <SvgIcon onClick={onClose}>
              <DeleteIcon />
            </SvgIcon>
          </Box>
        )}
        {children}
      </Box>
    </Dialog>
  );
};

export default InfoPopup;
