export interface OTPInputProps {
  value?: string;
  length?: number;
  errorText?: string;
  helperText?: string;
  disabled?: boolean;
  nextScreenPath: string;
  otp: string[];
  setOtp: React.Dispatch<React.SetStateAction<string[]>>;
  bgWhite?: boolean;
}

export enum KeysType {
  Backspace = 'Backspace',
  ArrowRight = 'ArrowRight',
  ArrowLeft = 'ArrowLeft',
}
export enum RegularExpression {
  Expression = '^[0-9]+$',
}
