import {FC} from 'react';
import {Box} from '@mui/material';
import FormControl from '@mui/material/FormControl';
import Typography from '@mui/material/Typography';
import {getStyles} from './styles';
import {StoriesProps} from './types';
import {StoriesIcon} from '../../assets/svg/storiesIcon';
const Stories: FC<StoriesProps> = ({label}) => {
  const styles = getStyles();
  return (
    <Box>
      <FormControl>
        <StoriesIcon />
        <Typography sx={styles.defaultLabel}>{label}</Typography>
      </FormControl>
    </Box>
  );
};

export default Stories;
