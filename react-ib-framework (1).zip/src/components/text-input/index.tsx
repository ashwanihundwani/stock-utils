import React, {FC} from 'react';
import {Box, TextField, Typography} from '@mui/material';
import {getStyles} from './styles';
import InputAdornment from '@mui/material/InputAdornment';
import {TextInputProps} from './types';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';
import IconButton from '@mui/material/IconButton';
import {CancelIcon} from 'assets/svg/cancel-icon';
import {useNewTheme} from 'react-core';
const TextInput: FC<TextInputProps> = ({
  value,
  label,
  type,
  startElement,
  endElement,
  errorText,
  helperText,
  setValue,
  disabled,
  prefix,
  customStyle,
  autoComplete,
  errorHeight,
  autoFocus,
  maxLength,
  bgWhite = false,
  maximumLength = 0,
}) => {
  const theme = useNewTheme();
  const styles = getStyles(
    theme,
    startElement,
    endElement,
    errorHeight,
    bgWhite,
  );

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (type === 'number') {
      const value = event.target.value;

      if (value.length <= maximumLength) {
        setValue?.(value);
      }
    } else {
      setValue?.(event.target.value);
    }
  };
  const clearSearch = () => {
    setValue?.('');
  };

  return (
    <Box sx={styles.defaultBox}>
      <TextField
        label={label}
        type={type}
        autoComplete={autoComplete}
        autoFocus={autoFocus}
        value={value}
        disabled={disabled}
        sx={{...styles.defaultInputStyle, ...customStyle}}
        variant="filled"
        error={Boolean(errorText)}
        onChange={handleChange}
        slotProps={{
          htmlInput: {maxLength},
          input: {
            disableUnderline: true,
            startAdornment: startElement && (
              <InputAdornment position="start">
                <Typography sx={styles.startElementstyle}>{prefix}</Typography>
              </InputAdornment>
            ),
            endAdornment: endElement && (
              <InputAdornment position="end" sx={styles.svgIconsStyle}>
                {endElement}
                {value && (
                  <IconButton onClick={clearSearch}>
                    <CancelIcon
                      color={
                        theme.colors['surface-interactive-primary-enabled']
                      }
                    />
                  </IconButton>
                )}
              </InputAdornment>
            ),
          },
        }}
      />
      <Box sx={styles.errorMsgHeight}>
        <HelperText message={errorText} type={HelperTextType.ErrorText} />
      </Box>
      {helperText && (
        <HelperText message={helperText} type={HelperTextType.HelperText} />
      )}
    </Box>
  );
};

export default TextInput;
