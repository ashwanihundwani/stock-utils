import {Theme} from 'react-core';
export interface UploadDocumentProps {
  onFileUpload: (fileName: string, fileSize: string) => void;
  errorMessage?: string;
  label?: string;
}

export interface StyleProps {
  theme: Theme; // to be updated later
  hasError: boolean;
  hasFile: boolean;
}
