import React, {useRef, useState} from 'react';
import {Box, Typography, IconButton, Input} from '@mui/material';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import {useNewTheme} from 'react-core';
import {getStyles} from './styles';
import {UploadDocumentProps} from './types';
import {HelperText} from 'components/helper-text';
import {HelperTextType} from 'components/helper-text/types';

const UploadDocument: React.FC<UploadDocumentProps> = ({
  onFileUpload,
  errorMessage,
  label = 'Upload document', // default label
}) => {
  const [status, setStatus] = useState<'enabled' | 'uploaded'>('enabled');
  const [fileName, setFileName] = useState<string>('');
  const [fileType, setFileType] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [hasError, setHasError] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const theme = useNewTheme();

  const styles = getStyles({theme, hasError, hasFile: status === 'uploaded'});

  const allowedFileTypes = ['application/pdf', 'image/png', 'image/jpeg'];
  const maxFileSize = 1024 * 1024;

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // File Type Validation
      if (!allowedFileTypes.includes(file.type)) {
        setHasError(true);
        return;
      }

      // File Size Validation
      if (file.size > maxFileSize) {
        setHasError(true);
        return;
      }

      setFileName(file.name);
      setFileType(file.type.split('/')[1].toUpperCase());
      setFileSize(`${(file.size / 1024).toFixed(1)} KB`);
      setHasError(false);
      setStatus('uploaded');
      onFileUpload(file.name, `${(file.size / 1024).toFixed(1)} KB`);
    }
  };

  const handleFileRemove = () => {
    setFileName('');
    setFileType('');
    setFileSize('');
    setHasError(false);
    setStatus('enabled');
  };

  const openFilePicker = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <Box sx={styles.container}>
      {status === 'enabled' ? (
        <Box sx={styles.uploadBox} onClick={openFilePicker}>
          <FileUploadIcon sx={styles.uploadIcon} />
          <Typography sx={styles.uploadLabel}>{label}</Typography>
          <Input
            type="file"
            inputProps={{accept: allowedFileTypes.join(',')}}
            onChange={handleFileChange}
            sx={styles.fileInput}
            inputRef={fileInputRef}
          />
        </Box>
      ) : (
        <Box sx={styles.fileBox}>
          <Box sx={styles.fileInfo}>
            <Typography sx={styles.fileName}>{fileName}</Typography>
            <Typography sx={styles.fileSize}>
              {fileType} {fileSize}
            </Typography>
          </Box>
          <IconButton
            disableRipple
            onClick={handleFileRemove}
            sx={styles.closeIcon}>
            <DeleteOutlineIcon />
          </IconButton>
        </Box>
      )}
      {hasError && (
        <Box sx={styles.errorContainer}>
          <HelperText type={HelperTextType.ErrorText} message={errorMessage} />
        </Box>
      )}
    </Box>
  );
};

export default UploadDocument;
