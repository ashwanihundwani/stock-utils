import React from 'react';
import {Button as MuiButton} from '@mui/material';
import {styles} from './styles';
import {useNewTheme} from 'react-core';
import {ChipProps} from './types';

const Chip: React.FC<ChipProps> = ({
  label,
  isActive = false,
  isDisabled = false,
  onClick,
  isInverted,
}) => {
  const theme = useNewTheme();
  const chipStyles = styles(theme);
  return (
    <MuiButton
      disableRipple
      sx={{
        ...chipStyles.chip,
        ...(isActive ? chipStyles.active : chipStyles.inactive),
        ...(isDisabled ? chipStyles.disabled : {}),
        ...(isInverted ? chipStyles.inverted : {}),
      }}
      disabled={isDisabled}
      onClick={!isDisabled ? onClick : undefined}>
      {label}
    </MuiButton>
  );
};

export default Chip;
