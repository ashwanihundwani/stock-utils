export interface ChipProps {
  label: string;
  isActive?: boolean;
  isDisabled?: boolean;
  onClick?: () => void;
  isInverted?: boolean;
}
