import {Theme} from 'react-core';
import {fonts} from 'utils/typography';

export const styles = (theme: Theme) => ({
  chip: {
    height: '40px',
    padding: '8px 16px',
    borderRadius: '999px',
    fontFamily: fonts.regular,
    fontSize: '16px',
    cursor: 'pointer',
    textTransform: 'none',
    border: '2px solid transparent',
    '&:focus': {
      border: `1px solid ${theme.colors['border-focus']}`,
    },
  },
  disabled: {
    backgroundColor: theme.colors['surface-interactive-primary-disabled'],
    color: theme.colors['content-interactive-primary-disabled'],
    cursor: 'not-allowed',
  },
  active: {
    backgroundColor: theme.colors['surface-interactive-primary-enabled'],
    color: theme.colors['content-interactive-inverted-enabled'],
  },
  inactive: {
    backgroundColor: theme.colors['surface-interactive-secondary-enabled'],
    color: theme.colors['content-primary'],
  },
  inverted: {
    backgroundColor: theme.colors['surface-01'],
    color: theme.colors['content-primary'],
  },
});
