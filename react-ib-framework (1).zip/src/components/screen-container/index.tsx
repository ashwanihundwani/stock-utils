import {Box} from '@mui/material';
import {getStyles} from './styles';
import {CustomLabel} from 'components';
import {FC} from 'react';
import {ScreenCOntainerProps} from './types';
import {useNewTheme, useTranslation} from 'react-core';
import {ArrowLeft02Sharp} from 'assets/svg';
import {useNavigate} from 'react-router-dom';
import {variants} from 'components/custom-label/types';
import {navigationProps} from 'constants/labelvalues';

const ScreenContainer: FC<ScreenCOntainerProps> = props => {
  const {
    title = '',
    subtitle = '',
    children,
    backLabel = '',
    containerStyle,
  } = props;
  const theme = useNewTheme();
  const styles = getStyles({theme});
  const navigate = useNavigate();
  const {t: translate} = useTranslation();
  return (
    <Box sx={[styles.container, {...containerStyle}]}>
      <Box sx={styles.headerContainer}>
        <Box
          sx={styles.backButton}
          onClick={() => navigate(navigationProps.goBack)}>
          <ArrowLeft02Sharp />
          <CustomLabel
            style={styles.backLabelStyle}
            text={translate(backLabel)}
            id="back"
            variant={variants.bodySemiBoldM}
          />
        </Box>
        <Box sx={styles.titeContainer}>
          {title && (
            <CustomLabel
              text={translate(title)}
              id="title"
              variant={variants.titleM}
            />
          )}
          {subtitle && (
            <CustomLabel
              text={translate(subtitle)}
              id="subtitle"
              variant={variants.bodyRegularS}
            />
          )}
        </Box>
      </Box>
      {children}
    </Box>
  );
};

export default ScreenContainer;
