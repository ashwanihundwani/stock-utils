import {ReactNode} from 'react';
import {Theme} from 'react-core';

export type ScreenCOntainerProps = {
  title?: string;
  subtitle?: string;
  children?: ReactNode;
  backLabel?: string;
  containerStyle?: object;
};

export type ScreenContainerStyleProps = {
  theme: Theme;
};
