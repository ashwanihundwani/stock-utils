import {ScreenContainerStyleProps} from './types';

export const getStyles = (props: ScreenContainerStyleProps) => {
  const {theme} = props;
  return {
    container: {
      display: 'flex',
      flexDirection: 'column',
      marginTop: '3rem',
    },
    headerContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
    },
    titeContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
    },
    backButton: {
      display: 'flex',
      flexDirection: 'row',
      gap: '0.5rem',
      alignItems: 'center',
      cursor: 'pointer',
      width: 'fit-content',
    },
    backLabelStyle: {
      letterSpacing: '0rem',
      color: theme.colors['content-interactive-secondary-enabled'],
      cursor: 'pointer',
    },
  };
};
