import {Modal} from '@mui/material';
import {Images} from 'constants/images';
import {useSelector} from 'react-redux';
import {getAppLoading} from 'service/app-global';
import {getStyles} from './styles';

const AppLoader = () => {
  const loading = useSelector(getAppLoading);
  const styles = getStyles();
  return (
    <Modal open={loading} sx={styles.modalStyle}>
      <img src={Images.loading} alt="loading"></img>
    </Modal>
  );
};

export default AppLoader;
