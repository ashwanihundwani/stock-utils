export const getStyles = () => {
  return {
    modalStyle: {
      position: 'absolute',
      backgroundColor: 'transparent',
      alignItems: 'center',
      textAlign: 'center',
      alignContent: 'center',
      margin: 'auto',
    },
  };
};
