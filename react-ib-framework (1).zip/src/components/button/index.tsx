import React from 'react';
import {Button as MuiButton} from '@mui/material';
import {getButtonStyles} from './styles';
import {ButtonSize, ButtonType, PrimaryButtonProps} from './types';
import {useNewTheme} from 'react-core';

const Button: React.FC<PrimaryButtonProps> = ({
  variant,
  type,
  size,
  leftIcon,
  rightIcon,
  text,
  onClick,
  inverted = false,
  disabled = false,
}) => {
  const theme = useNewTheme();
  const styles = getButtonStyles(theme);
  const getVariantStyles = () => {
    const {
      default: defaultStyle,
      inverted: invertedStyle,
      disabled: disabledStyle,
    } = styles[variant];
    if (disabled) {
      return disabledStyle;
    }
    return inverted ? invertedStyle : defaultStyle;
  };

  const getSizeStyles = () => {
    if (type === ButtonType.Text) {
      if (size === ButtonSize.Large) {
        return styles.sizes.textLarge;
      } else if (size === ButtonSize.XLarge) {
        return styles.sizes.textExtraLarge;
      } else {
        return styles.sizes.textSmall;
      }
    } else if (type === ButtonType.Icon) {
      return size === ButtonSize.Large
        ? styles.sizes.iconLarge
        : styles.sizes.iconSmall;
    }
    return {};
  };

  const buttonStyles = {
    ...styles.base,
    ...getVariantStyles(),
    ...getSizeStyles(),
  };

  return (
    <MuiButton
      disableRipple
      onClick={onClick}
      disabled={disabled}
      sx={buttonStyles}>
      {leftIcon && <span style={styles.iconStyle}>{leftIcon}</span>}
      {text && <span>{text}</span>}
      {rightIcon && <span style={styles.iconStyle}>{rightIcon}</span>}
    </MuiButton>
  );
};

export default Button;
