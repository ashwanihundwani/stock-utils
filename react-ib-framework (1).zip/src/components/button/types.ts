export enum ButtonSize {
  Large = 'large',
  Small = 'small',
  XLarge = 'xl',
}
export enum ButtonType {
  Text = 'text',
  Icon = 'icon',
}
export enum ButtonStyle {
  Primary = 'primary',
  Secondary = 'secondary',
  Ghost = 'ghost',
}

export interface PrimaryButtonProps {
  variant: ButtonStyle;
  type: ButtonType;
  size: ButtonSize;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  text?: string;
  inverted?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}
