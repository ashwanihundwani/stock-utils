import {AvatarProps} from 'components/avatar/types';

export interface TransferListProps extends AvatarProps {
  name: string;
  amount: string;
  iban: string;
}
