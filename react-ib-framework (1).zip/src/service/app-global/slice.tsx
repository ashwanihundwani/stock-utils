import {createSlice} from '@reduxjs/toolkit';
import {resetAuthState} from 'service/auth-services';
import {mapThemeToColors} from 'react-core/utils';
import {MeemTheme, contextualTheme} from 'react-core/newTheme';

const initialState = {
  appLoading: false,
  activeSection: 'AuthSection',
  newThemes: {
    default: {
      name: 'default',
      displayName: 'Meem Theme',
      colors: mapThemeToColors(MeemTheme, contextualTheme),
    },
  },
};

const globalSlice = createSlice({
  name: 'global',
  initialState,
  reducers: {
    setAppLoading(state, action) {
      state.appLoading = action.payload;
    },
    setAppSection(state, action) {
      state.activeSection = action.payload;
    },
    presentLoader(state) {
      state.appLoading = true;
    },
    dismissLoader(state) {
      state.appLoading = false;
    },
    resetAppState() {
      return {
        ...initialState,
      };
    },
    resetAllStates() {
      resetAppState();
      resetAuthState();
    },
  },
});

// Reducer
export const globalReducer = globalSlice.reducer;

// Actions
export const {
  setAppLoading,
  presentLoader,
  dismissLoader,
  resetAppState,
  setAppSection,
  resetAllStates,
} = globalSlice.actions;

export const createLoader = () => {
  return {
    present: () => presentLoader(),
    dismiss: () => dismissLoader(),
  };
};
