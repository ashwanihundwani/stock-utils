import {RootState} from 'redux/root-reducer';

const globalReducer = (state: RootState) => state.global;

export const getAppLoading = (state: RootState) =>
  globalReducer(state).appLoading;

export const getActiveSection = (state: RootState) =>
  globalReducer(state).activeSection;
