import {RootState} from 'redux/root-reducer';

const authReducer = (state: RootState) => state.authReducer;

export const getUserDataState = (state: RootState) =>
  authReducer(state).userData;
