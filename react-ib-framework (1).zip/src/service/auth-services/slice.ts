import {createSlice} from '@reduxjs/toolkit';

interface UserData {
  cifNo: string;
  userId: string;
  isLimitedReached: string;
  httpStatusCode: number;
  nationalId: string;
  isDebitCreated: string;
}

interface State {
  userData: UserData | null;
}
const initialState: State = {
  userData: null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setUserData(state, action) {
      state.userData = action.payload;
    },
    resetAuthState() {
      return initialState;
    },
  },
});

// Reducer
export const authReducer = authSlice.reducer;

export const {resetAuthState, setUserData} = authSlice.actions;
