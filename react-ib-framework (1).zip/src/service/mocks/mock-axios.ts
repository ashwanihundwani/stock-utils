import axios, {AxiosInstance} from 'axios';
import applyMockAdapter from './auth-mock';
import {API_BASEURL} from 'config';

const axiosInstance: AxiosInstance = axios.create({
  baseURL: API_BASEURL,
});

const someConfigToUseMock = true;

if (someConfigToUseMock) {
  applyMockAdapter(axiosInstance);
}

export default axiosInstance;
