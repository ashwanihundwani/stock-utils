import {combineReducers} from '@reduxjs/toolkit';
import {persistReducer} from 'redux-persist';
import storageSession from 'redux-persist/lib/storage/session';
import {authReducer} from '../service/auth-services';
import {globalReducer} from 'service/app-global';
import api from 'features/auth/services/loginMockApi';

type StorageType = typeof storageSession;

interface PersistConfigType {
  key: string;
  storage: StorageType;
  timeout: number;
}

const GlobalPersistConfig: PersistConfigType = {
  key: 'global',
  storage: storageSession,
  timeout: 10,
};

const AuthPersistConfig: PersistConfigType = {
  key: 'auth',
  storage: storageSession,
  timeout: 10,
};

const rootReducer = combineReducers({
  [api.reducerPath]: api.reducer,
  global: persistReducer(GlobalPersistConfig, globalReducer),
  authReducer: persistReducer(AuthPersistConfig, authReducer),
});

export type RootState = ReturnType<typeof rootReducer>;

export {rootReducer};
